const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const acornBox={exports:{}};acornBox.module={exports:acornBox.exports};
vm.runInNewContext(process.binding('natives')['internal/deps/acorn/acorn/dist/acorn'],acornBox);
const parse=(s,comments)=>acornBox.exports.parse(s,{ecmaVersion:3,allowReserved:true,onComment:comments});
const orig=process.argv[2]||path.join(__dirname,'original/SYSTEMGUI');
const mod=process.argv[3]||path.resolve(__dirname,'../../output/SYSTEMGUI_Optimized/SYSTEMGUI');
const allowed=['dom_getChildNodeByAttrAndValue','dom_getChildNodeByNodeName','dom_getXPos','dom_getYPos'];
function walk(n,fn){if(!n||!n.type)return;fn(n);for(const k of Object.keys(n)){const v=n[k];if(Array.isArray(v))v.forEach(x=>walk(x,fn));else if(v&&v.type)walk(v,fn)}}
function clean(n){if(Array.isArray(n))return n.map(clean);if(n&&typeof n==='object'){const o={};for(const k of Object.keys(n))if(!['start','end','raw','loc'].includes(k))o[k]=clean(n[k]);return o}return n}
function src(root,file){return fs.readFileSync(path.join(root,'JS',file),'latin1')}
const files=fs.readdirSync(path.join(orig,'JS')).sort();
assert.deepStrictEqual(files,fs.readdirSync(path.join(mod,'JS')).sort());
const fileResults=[],changedFunctions=[];let totalFunctions=0;
for(const file of files){
 const a=src(orig,file),b=src(mod,file),ca=[],cb=[],aa=parse(a,ca),bb=parse(b,cb);
 const af=[],bf=[],events=[[],[]],timers=[[],[]];
 for(const [n,source,fns,idx] of [[aa,a,af,0],[bb,b,bf,1]])walk(n,x=>{
  if(/Function/.test(x.type))fns.push({name:x.id?x.id.name:null,params:x.params.map(p=>p.name)});
  if(x.type==='CallExpression'){
   const callee=source.slice(x.callee.start,x.callee.end);
   if(/Event|Handler/.test(callee))events[idx].push(source.slice(x.start,x.end));
   if(/Timeout|Interval/.test(callee))timers[idx].push(source.slice(x.start,x.end));
  }
 });
 assert.deepStrictEqual(af,bf,file+' signatures');assert.deepStrictEqual(events[0],events[1]);assert.deepStrictEqual(timers[0],timers[1]);
 let ci=0;for(const c of cb)if(ci<ca.length&&c.type===ca[ci].type&&c.value===ca[ci].value)ci++;
 assert.equal(ci,ca.length,file+' existing comments');
 const norm=[];
 for(const [ast,label] of [[aa,'before'],[bb,'after']]){
  const x=clean(ast);
  walk(x,n=>{if(n.type==='FunctionDeclaration'&&allowed.includes(n.id.name)&&file==='its_utils.js')n.body={type:'BlockStatement',body:[]}});
  norm.push(x);
 }
 assert.deepStrictEqual(norm[0],norm[1],file+' all code outside allowed bodies');
 if(file!=='its_utils.js')assert.equal(a,b,file+' byte preservation');
 assert.equal(a.replace(/\r\n/g,'').includes('\n'),false);
 assert.equal(b.replace(/\r\n/g,'').includes('\n'),false);
 assert.deepStrictEqual(Buffer.from(a,'latin1').filter(x=>x>=128),Buffer.from(b,'latin1').filter(x=>x>=128));
 totalFunctions+=af.length;
 fileResults.push({file,functions:af.length,es3:true,unchanged:a===b,events_and_timers_preserved:true});
}
function extract(root,file,name){const s=src(root,file);let result;walk(parse(s),n=>{if(n.type==='FunctionDeclaration'&&n.id.name===name)result=s.slice(n.start,n.end)});assert(result,name);return result}
for(const name of allowed){assert.notEqual(extract(orig,'its_utils.js',name),extract(mod,'its_utils.js',name));changedFunctions.push(name)}
function context(root){const box={DOM_NODE_TYPE_ELEMENT:1,v:'unchanged'};vm.createContext(box);for(const name of allowed)vm.runInContext(extract(root,'its_utils.js',name),box);return box}
const contexts=[context(orig),context(mod)];
let domCases=0,positionCases=0;
function caseDOM(spec,kind){
 return contexts.map(box=>{
  box.v='unchanged';let childListReads=0,indexReads=0,attributeReads=0;
  const nodes=spec.nodes.map((n,i)=>({key:i,nodeType:n.type,nodeName:n.name,getAttribute(attr){attributeReads++;if(spec.mutate)spec.mutate(nodes,i);return n.attrs&&attr in n.attrs?n.attrs[attr]:null}}));
  const collection=new Proxy(nodes,{get(t,k,r){if(/^\d+$/.test(String(k)))indexReads++;return Reflect.get(t,k,r)}});
  const element=spec.nullElement?null:{get childNodes(){childListReads++;return collection}};
  const result=kind==='attr'?box.dom_getChildNodeByAttrAndValue(element,spec.attr,spec.value):box.dom_getChildNodeByNodeName(element,spec.name);
  return {state:JSON.stringify({returned:result?result.key:null,v:box.v,keys:nodes.map(n=>n.key),attributeReads}),childListReads,indexReads};
 });
}
function checkDOM(spec,kind){const result=caseDOM(spec,kind);assert.equal(result[0].state,result[1].state,JSON.stringify(spec));domCases++;return result}
// Direct-child, non-element, duplicate, case-sensitive, loose equality, empty and absent cases.
const nodes=[{type:3,name:'#text'},{type:8,name:'#comment'},{type:1,name:'DIV',attrs:{id:'a',state:'0'}},{type:1,name:'INPUT',attrs:{id:'b',state:''}},{type:1,name:'DIV',attrs:{id:'a',state:'1'}}];
for(const list of [[],nodes,nodes.slice().reverse(),[{type:3,name:'#text'}]]){
 for(const name of ['DIV','INPUT','div','SPAN',null])checkDOM({nodes:list,name},'name');
 for(const attr of ['id','state','missing'])for(const value of ['a','b','0',0,false,'',null,undefined])checkDOM({nodes:list,attr,value},'attr');
}
checkDOM({nodes:[],nullElement:true,name:'DIV'},'name');checkDOM({nodes:[],nullElement:true,attr:'id',value:'a'},'attr');
// A wrapped native getAttribute may mutate the same live collection. Do not freeze length or the return slot.
checkDOM({nodes:[{type:1,name:'DIV',attrs:{id:'a'}},{type:1,name:'DIV',attrs:{id:'b'}}],attr:'id',value:'a',mutate(a,i){if(i===0)a.shift()}},'attr');
checkDOM({nodes:[{type:1,name:'DIV',attrs:{id:'a'}}],attr:'id',value:'b',mutate(a,i){if(a.length===1)a.push({key:9,nodeType:1,nodeName:'DIV',getAttribute(){return 'b'}})}},'attr');
// New collections on successive calls: partial document updates do not retain stale nodes.
for(const name of ['DIV','INPUT','DIV'])checkDOM({nodes:[{type:1,name}],name},'name');
const domOps={};
for(const kind of ['name','attr']){
 const n=Array.from({length:1000},()=>({type:1,name:'DIV',attrs:{id:'a'}}));
 const r=checkDOM({nodes:n,name:'MISSING',attr:'id',value:'missing'},kind);
 domOps[kind]={children:1000,beforeChildNodesReads:r[0].childListReads,afterChildNodesReads:r[1].childListReads,beforeIndexReads:r[0].indexReads,afterIndexReads:r[1].indexReads};
 assert.equal(r[1].childListReads,1);
}
function position(rootBox,spec,axis){
 let borderReads=0,parentReads=0,offsetReads=0,p=null;
 const border=axis==='X'?'clientLeft':'clientTop',offset=axis==='X'?'offsetLeft':'offsetTop';
 for(const v of spec){const parent=p;p={get offsetParent(){parentReads++;return parent},get [border](){borderReads++;return v.border},get [offset](){offsetReads++;return v.offset}}}
 return {value:rootBox['dom_get'+axis+'Pos'](p),borderReads,parentReads,offsetReads};
}
const positionOps={};
for(const depth of [1,2,8,32])for(const border of [0,1,7,-2])for(const offset of [0,2.5,-30])for(const axis of ['X','Y']){
 const spec=Array.from({length:depth},(_,i)=>({border,offset:offset+i}));
 const a=position(contexts[0],spec,axis),b=position(contexts[1],spec,axis);
 assert.equal(a.value,b.value);assert.equal(a.parentReads,b.parentReads);assert.equal(a.offsetReads,b.offsetReads);positionCases++;
 if(depth===32&&border===7&&offset===2.5)positionOps[axis]={ancestors:32,beforeBorderReads:a.borderReads,afterBorderReads:b.borderReads,coordinate:b.value};
}
// Existing source findings: classify only; do not automatically repair geometry/UA contracts.
const findings={};
const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36';
for(const [label,value] of [['Chrome',ua],['Edge',ua+' Edg/152.0.0.0'],['IE11','Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko']]){
 const box={navigator:{userAgent:value,appVersion:'5.0'}};vm.createContext(box);vm.runInContext(extract(orig,'its_utils.js','its_useragent'),box);const x=new box.its_useragent();findings[label]={ie:x.ie,gecko:x.gecko,ie55up:x.ie55up};
}
const uaUtil=src(orig,'its_utils.js');const ast=parse(uaUtil);let posNode;
walk(ast,n=>{if(n.type==='VariableDeclarator'&&n.id.name==='PosUtil')posNode=n.init});
const pbox={document:{documentElement:{getBoundingClientRect(){}}},isBidiRTL:()=>false,wgu_getComputedStyle:()=>null};
vm.createContext(pbox);vm.runInContext('var PosUtil='+uaUtil.slice(posNode.start,posNode.end),pbox);
const el={getBoundingClientRect(){return {top:10,left:20}},scrollTop:0,scrollLeft:0};
const doc={documentElement:{contains:()=>true,clientTop:0,clientLeft:0},defaultView:{pageYOffset:1,pageXOffset:1}};el.ownerDocument=doc;pbox.document=doc;doc.body={clientTop:0,clientLeft:0};
let originalPositionError=null;try{pbox.PosUtil.getPos(el)}catch(e){originalPositionError=e.name+': '+e.message}
assert(originalPositionError&&originalPositionError.includes('nodeName'));
findings.PosUtil_getPos={isolatedStandardBranchError:originalPositionError,reason:'el is not assigned before el.nodeName in the bounding-rectangle branch',changed:false};
const result={files:fileResults,totalFunctions,changedFunctions,wholeASTOutsideChangesPreserved:true,domCases,positionCases,totalRegressionCases:domCases+positionCases,domOps,positionOps,findings,realERPTested:false,realBrowserTested:false,wallTimePerformanceMeasured:false};
fs.writeFileSync(path.join(__dirname,'js_validation.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({totalFunctions,changedFunctions,domCases,positionCases,totalRegressionCases:domCases+positionCases,domOps,positionOps,findings},null,2));
