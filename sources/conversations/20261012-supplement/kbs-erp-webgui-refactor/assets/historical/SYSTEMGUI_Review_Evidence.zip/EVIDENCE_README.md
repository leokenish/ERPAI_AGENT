# SYSTEMGUI 검토 증빙

교체용 ZIP에는 이 증빙을 배포하지 마세요.

- `changes.diff`: 원본과 수정본의 전체 코드 차이
- `manifest.json`: 전체 파일의 수정 여부·크기·SHA-256
- `source_manifest.json`: 확보한 Drive 원본의 파일명·ID·크기·수정 시각·해시
- `js_validation.json`: 13개 JS 문법·함수·AST·회귀·원본 발견 사항 결과
- `css_validation.json`: CSS 규칙·선언·색상·경로·파일 보존 검사
- `js_changes.json`, `css_changes.json`: 상세 수정 기록
- `shared_functions.json`: SYSTEM its_utils와 기존 WEBGUI wgu_utils의 이름이 겹치는 AST 함수 목록. 익명 함수 제외; 이것만으로 런타임 로드 순서나 중복 실행을 확정하지 않음
- `package_validation.json`: 원본·수정본 ZIP 구성, CRC, 바이트 대조 결과
- `verify.js`, `verify_css.py`: 독립 재검증 스크립트

검증 스크립트는 서버 통신을 하지 않습니다. 원본과 수정본 ZIP을 각각 다른 폴더에 풀고 아래처럼 실행할 수 있습니다. Node.js와 Python 3가 필요하며 제품 실행 의존성이 아닙니다.

```sh
node verify.js /absolute/original/SYSTEMGUI /absolute/modified/SYSTEMGUI
python verify_css.py /absolute/original/SYSTEMGUI /absolute/modified/SYSTEMGUI
```

스크립트는 자신의 폴더에 결과 JSON을 기록합니다. `verify_css.py` 실행 시 같은 폴더에 `manifest.json`을 두세요. `verify.js`는 검증 환경의 Node 내장 Acorn 파서를 사용합니다. 해당 내장 모듈을 제공하지 않는 Node 배포판에서는 실행되지 않을 수 있습니다. 구문 기준은 ECMAScript 3이며 실제 브라우저 DOM·ERP 실행 검증과 구별해야 합니다.

JavaScript 모의 테스트의 Proxy/getter는 조회 횟수 계측용입니다. 배포하는 JS에는 이 문법이나 새 API를 추가하지 않았습니다. 측정값은 속성 접근 횟수로, 실제 브라우저 레이아웃 횟수나 실행 시간 향상 비율이 아닙니다.
