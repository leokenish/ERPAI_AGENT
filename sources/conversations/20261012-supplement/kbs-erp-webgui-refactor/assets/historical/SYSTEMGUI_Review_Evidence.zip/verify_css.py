from pathlib import Path
import re, json, hashlib, sys

WORK = Path(__file__).resolve().parent
ORIG = Path(sys.argv[1]) if len(sys.argv)>1 else WORK/'original/SYSTEMGUI'
OUT = Path(sys.argv[2]) if len(sys.argv)>2 else WORK.parent.parent/'output/SYSTEMGUI_Optimized/SYSTEMGUI'
TOKEN = re.compile(r'#[0-9a-fA-F]{3,8}\b|\b(?:black|white|grey|gray|red|blue|yellow)\b', re.I)
COMMENT_STRING = re.compile(r'/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
COLOR_PROPS = {'color','background-color','background','border','border-color','border-top','border-right','border-bottom','border-left','border-top-color','border-right-color','border-bottom-color','border-left-color'}
def blocks(s):
    masked=COMMENT_STRING.sub(lambda m: ''.join('\n' if c=='\n' else '\r' if c=='\r' else ' ' for c in m[0]),s)
    assert masked.count('{')==masked.count('}')
    assert not re.search(r'@(?:media|supports|import|charset|font-face)\b',masked,re.I)
    prev=0
    for m in re.finditer(r'([^{}]*)\{([^{}]*)\}',masked):
        assert not masked[prev:m.start()].strip()
        decls=[];start,end=m.start(2),m.end(2)
        for d in re.finditer(r'([^;]+)(?:;|$)',masked[start:end]):
            if not d[1].strip():continue
            prop,sep,val=d[1].partition(':');assert sep
            offset=start+d.start(1)+len(prop)+1
            decls.append((prop.strip().lower(),s[offset:offset+len(val)]))
        yield m[1].strip(),decls
        prev=m.end()
    assert not masked[prev:].strip()
a=(ORIG/'CSS/gui.css').read_bytes().decode('latin1');b=(OUT/'CSS/gui.css').read_bytes().decode('latin1')
ba,bb=list(blocks(a)),list(blocks(b));assert len(ba)==len(bb)
changed=0;tokens=0
for (s1,d1),(s2,d2) in zip(ba,bb):
    assert s1==s2 and len(d1)==len(d2)
    for (p1,v1),(p2,v2) in zip(d1,d2):
        assert p1==p2
        if v1!=v2:
            assert p1 in COLOR_PROPS
            assert TOKEN.sub('<COLOR>',v1)==TOKEN.sub('<COLOR>',v2)
            changed+=1
            tokens+=sum(x!=y for x,y in zip(TOKEN.findall(v1),TOKEN.findall(v2)))
assert re.findall(r'/\*[\s\S]*?\*/',a)==re.findall(r'/\*[\s\S]*?\*/',b)[1:]
urls=re.findall(r'url\([^)]*\)',a);assert urls==re.findall(r'url\([^)]*\)',b)
assert a.count('!important')==b.count('!important')
assert a.count('\r\n')+1==b.count('\r\n')
files=sorted(str(p.relative_to(ORIG)) for p in ORIG.rglob('*') if p.is_file())
assert files==sorted(str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file())
manifest=json.loads((WORK/'manifest.json').read_text())
assert len(manifest)==len(files)==14
for item in manifest:
    x=(ORIG/item['file']).read_bytes();y=(OUT/item['file']).read_bytes()
    assert hashlib.sha256(x).hexdigest()==item['original_sha256']
    assert hashlib.sha256(y).hexdigest()==item['modified_sha256']
    assert bytes(v for v in x if v>=128)==bytes(v for v in y if v>=128)
    if not item['changed']:assert x==y
result={'rules':len(ba),'declarations':sum(len(d) for _,d in ba),'changed_declarations':changed,'changed_color_tokens':tokens,
 'selectors_order_properties_preserved':True,'noncolor_values_preserved':True,'image_urls':urls,
 'comments_nonASCII_and_CRLF_preserved':True,'file_count':len(files),'unchanged_files':sum(not x['changed'] for x in manifest),'hashes_verified':True,
 'structural_check_only':True,'browserCSSParserTested':False}
(WORK/'css_validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
