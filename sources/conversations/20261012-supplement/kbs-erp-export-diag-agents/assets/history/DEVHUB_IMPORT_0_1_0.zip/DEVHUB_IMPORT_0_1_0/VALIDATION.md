# DEVHUB Import 0.1.0 검증 기록

## 적용 근거

- 실제 기존 `Z_PACKAGE_EXPORT.abap` 0.3.18과 배포 ZIP을 확인하여 format 0.2 manifest, 원본 baseline, 경로·component·active_state 정책을 사용했다.
- 프로그램·함수 그룹·DDIC·메시지·BSP·MIME의 읽기 및 직렬화 helper를 재사용했다.
- 변경한 기존 helper는 `preflight`의 안내 문구, ZIP 대신 현재 값 내부 테이블에 기록하는 `add_raw`, baseline 복사 호출을 제거한 `add_file` 세 개다.
- export의 최종 ZIP 배포/GUI_DOWNLOAD와 원래 선택 화면·실행 driver는 import REPORT에 넣지 않았다.
- 신규 입력, ZIP 검사, manifest 읽기, 비교, 후보 문맥 구성, SAP SYNTAX-CHECK 호출, ALV·diff 화면을 추가했다.

## 로컬에서 수행한 검증

| 점검 | 결과와 범위 |
|---|---|
| 전체 소스 ABAP 7.00 파싱 | abaplint v700 parser 오류 0, Unknown 문장 0. SAP 시스템의 실제 활성화 검사와 다르다. |
| 신규 FORM/type 연결 | 7.00 정적 타입 fixture 오류 0. SAP DDIC·GUI·iXML 등의 최소 타입/인터페이스 fixture 사용. 설치 시스템의 모든 API 서명을 입증하는 검사는 아니다. |
| A/B/C 분기 | 동일 / 변경 후보 / SAP만 변경 / 이미 반영 / 충돌 5개 분기. |
| 줄 diff | 실제 ABAP FORM을 JavaScript로 변환 실행하여 108개 사례 검사. 삽입·삭제·교체·빈 줄·한글·공백 보존·반복 행·큰 변경 블록 포함. diff로 후보를 재구성하고, 예산 안에서는 별도 LCS 계산과 최소 편집 수를 대조. |
| 경로 검증 | 절대 경로·상위 이동·빈 구간·dot 구간·드라이브·역슬래시·끝의 점/공백 8개 거부 사례, 한글 정상 경로 확인. POSIX 제어문자 정규식은 실제 SAP에서 재확인 대상. |
| Include 문맥 | 중첩·서버 외부 의존성 유지·순환·한 줄 복합/여러 줄 Include·긴 행·함수 alias·오류 행 매핑·불명확 source 9개 사례. 실제 ABAP 문맥 구성 FORM을 변환 실행. |
| 현재 SAP 보존 | 4개 overlay 사례. A=B이면 C 보존, A≠B일 때만 B 사용. 이미 반영된 변경과 충돌 후보도 별도 확인. |
| 변경 실행 경로 | repository INSERT/DELETE REPORT, activation API, COMMIT, transaction 실행, 서버 파일 쓰기 호출이 없는지 정적 점검. ZIP self-test의 메모리상 SAVE는 repository 저장과 무관하다. |
| ZIP 패키징 | ZIP 항목과 CRC 무결성, 코드 해시 확인. |

실행 fixture의 SAP read/UTF-8/메타데이터 API는 일부 mock 또는 기존 검증된 reader를 사용한다. **실제 SAP compiler, DDIF/BSP/MIME API, GUI upload 및 ALV 화면은 이 환경에서 실행하지 않았다.**

## SAP에서 첫 실행으로 확인할 항목

1. SE38 활성화 성공 여부와 첫 PREFLIGHT/self-test 결과.
2. 수정하지 않은 0.3.18 export 입력: active-source 항목이 정상적으로 같은지, U 상태 API가 `SAP_UNVERIFIED`로 구분되는지.
3. 수정한 단일 프로그램의 `CANDIDATE`, 정상 구문 `SYNTAX_PRECHECK_OK`, 일부러 만든 작은 구문 오류 `SYNTAX_PRECHECK_ERROR`.
4. Include 수정 시 주 프로그램 문맥과 원래 오류 행 번호가 맞는지.
5. 함수의 Source code 하나를 수정했을 때 실제 Include에 대응하는지. 두 표현을 다르게 수정하면 문맥 검사가 보류되는지.
6. JS/CSS/HTML 삽입·삭제와 한글·공백이 diff에 보존되는지. 웹 구문 검사를 한 것으로 표시하지 않는지.
7. 잘못 닫힌 XML이 `XML_ERROR`, 정상 XML이 `XML_WELL_FORMED_ONLY`인지.
8. baseline 누락/변경, B 파일 누락, 신규 미매핑 파일, 잘못된 패키지 선택이 각각 별도 판정되는지.
9. 대규모 패키지에서 메모리/실행 시간과 GUI 응답이 적절한지.

대상 코드의 검사 오류와 이 REPORT 자체의 활성화/실행 오류를 구분해 기록한다. 시스템의 API 차이로 REPORT 실행이 중단되면 메시지·행·필요 시 ST22 상세를 기준으로 조정한다.

## 문서 참고

- SAP: [Include Programs — 주 프로그램 문맥에서 구문 검사](https://help.sap.com/saphelp_snc70/helpdata/en/9f/db973535c111d1829f0000e829fbfe/content.htm?no_cache=true)
- SAP: [SYNTAX-CHECK 설명](https://help.sap.com/doc/abapdocu_750_index_htm/7.50/en-US/abapsyntax-check_for_itab.htm) — 이 링크는 7.50 설명이며, 7.00 호환성 증명의 대체 자료로 사용하지 않았다. 사용 문법은 별도로 v700 parser로 점검했다.

`LOCAL_VALIDATION.json`은 위 로컬 실행 결과 요약과 파일 해시를 담는다.
