REPORT z_github_connection_test LINE-SIZE 180.
* GitHub.com read-only directory probe. Target: SAP_BASIS 700.
* No SAP repository writes. No GitHub writes. No JSON add-on required.
* Token is requested on a separate dialog, not the variant screen.
* Run interactively in SAP GUI. See README.md for TLS prerequisites.

DATA: gv_title TYPE c LENGTH 70,
      gv_note TYPE c LENGTH 70.

PARAMETERS: p_owner TYPE c LENGTH 100 LOWER CASE OBLIGATORY,
            p_repo  TYPE c LENGTH 100 LOWER CASE OBLIGATORY,
            p_path  TYPE c LENGTH 255 LOWER CASE,
            p_ref   TYPE c LENGTH 100 LOWER CASE,
            p_priv  AS CHECKBOX DEFAULT ' ',
            p_dest  TYPE rfcdest.

SELECTION-SCREEN BEGIN OF SCREEN 1100 AS WINDOW TITLE gv_title.
SELECTION-SCREEN COMMENT /1(70) gv_note.
PARAMETERS p_token TYPE c LENGTH 255 LOWER CASE.
SELECTION-SCREEN END OF SCREEN 1100.

DATA: go_http TYPE REF TO if_http_client,
      gv_uri TYPE string,
      gv_url TYPE string,
      gv_part TYPE string,
      gv_escaped TYPE string,
      gv_auth TYPE string,
      gv_secret TYPE string,
      gv_body TYPE string,
      gv_status TYPE i,
      gv_reason TYPE string,
      gv_errcode TYPE i,
      gv_errtext TYPE string,
      gv_reqid TYPE string,
      gv_ct TYPE string,
      gv_offset TYPE i,
      gv_matchoff TYPE i,
      gv_matchlen TYPE i,
      gv_next TYPE i,
      gv_len TYPE i,
      gv_count TYPE i,
      gv_name TYPE string,
      gv_first TYPE c LENGTH 1,
      gt_parts TYPE STANDARD TABLE OF string,
      gv_regex TYPE string,
      gv_search TYPE string,
      gv_cr TYPE c LENGTH 1.

INITIALIZATION.
  gv_title = 'GitHub read-only token (this run only)'.
  gv_note = 'Paste token only; do not enter password or Bearer prefix.'.

AT SELECTION-SCREEN OUTPUT.
  LOOP AT SCREEN.
    IF screen-name = 'P_TOKEN'.
      screen-invisible = '1'.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.

AT SELECTION-SCREEN.
  IF sy-dynnr = '1000'.
    gv_part = p_owner.
    IF gv_part CN
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-'.
      MESSAGE 'Owner: enter account/organization name, not a URL'
        TYPE 'E'.
    ENDIF.
    gv_part = p_repo.
    IF gv_part CN
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.'.
      MESSAGE 'Repository: enter name only, without URL or .git'
        TYPE 'E'.
    ENDIF.
    IF p_repo = '.' OR p_repo = '..'.
      MESSAGE 'Invalid repository name' TYPE 'E'.
    ENDIF.
  ENDIF.

START-OF-SELECTION.
  IF sy-batch = 'X'.
    WRITE / 'STOP: Run interactively in SAP GUI; no batch token input.'.
    RETURN.
  ENDIF.
  IF p_priv = 'X'.
    CLEAR p_token.
    CALL SELECTION-SCREEN 1100 STARTING AT 5 5 ENDING AT 80 10.
    IF sy-subrc <> 0 OR p_token IS INITIAL.
      CLEAR p_token.
      WRITE / 'STOP: Token entry cancelled or empty.'.
      RETURN.
    ENDIF.
    gv_secret = p_token.
    CLEAR p_token.
    IF gv_secret CN
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_'.
      CLEAR gv_secret.
      WRITE / 'STOP: Paste a GitHub token only, without spaces/prefix.'.
      RETURN.
    ENDIF.
  ENDIF.

  CONCATENATE '/repos/' p_owner '/' p_repo '/contents'
    INTO gv_uri.
  gv_part = p_path.
  SPLIT gv_part AT '/' INTO TABLE gt_parts.
  LOOP AT gt_parts INTO gv_part.
    IF gv_part IS INITIAL.
      CONTINUE.
    ENDIF.
    IF gv_part = '.' OR gv_part = '..'.
      CLEAR gv_secret.
      WRITE / 'STOP: Relative dot segments are not allowed.'.
      RETURN.
    ENDIF.
    CALL METHOD cl_http_utility=>escape_url
      EXPORTING unescaped = gv_part
      RECEIVING escaped = gv_escaped.
    CONCATENATE gv_uri '/' gv_escaped INTO gv_uri.
  ENDLOOP.
  IF p_ref IS NOT INITIAL.
    gv_part = p_ref.
    CALL METHOD cl_http_utility=>escape_url
      EXPORTING unescaped = gv_part
      RECEIVING escaped = gv_escaped.
    CONCATENATE gv_uri '?ref=' gv_escaped INTO gv_uri.
  ENDIF.

  IF p_dest IS INITIAL.
    CONCATENATE 'https://api.github.com' gv_uri INTO gv_url.
    CALL METHOD cl_http_client=>create_by_url
      EXPORTING url = gv_url
      IMPORTING client = go_http
      EXCEPTIONS argument_not_found = 1
                 plugin_not_active = 2
                 internal_error = 3
                 OTHERS = 4.
  ELSE.
* Destination must be HTTPS api.github.com:443, no path prefix/login.
* Configure and verify it in SM59 before entering a token.
    CALL METHOD cl_http_client=>create_by_destination
      EXPORTING destination = p_dest
      IMPORTING client = go_http
      EXCEPTIONS argument_not_found = 1
                 destination_not_found = 2
                 destination_no_authority = 3
                 plugin_not_active = 4
                 internal_error = 5
                 OTHERS = 6.
  ENDIF.
  IF sy-subrc <> 0.
    gv_errcode = sy-subrc.
    CLEAR gv_secret.
    WRITE: / 'STOP: HTTP client creation failed. SY-SUBRC:',
             gv_errcode.
    RETURN.
  ENDIF.

  go_http->propertytype_logon_popup = if_http_client=>co_disabled.
  go_http->propertytype_redirect = if_http_client=>co_disabled.
  IF p_dest IS NOT INITIAL.
    CALL METHOD cl_http_utility=>set_request_uri
      EXPORTING request = go_http->request uri = gv_uri.
  ENDIF.
  CALL METHOD go_http->request->set_method
    EXPORTING method = 'GET'.
  CALL METHOD go_http->request->set_header_field
    EXPORTING name = 'Accept' value = 'application/vnd.github+json'.
  CALL METHOD go_http->request->set_header_field
    EXPORTING name = 'User-Agent' value = 'SAP-BASIS700-GitHub-Probe'.
  CALL METHOD go_http->request->set_header_field
    EXPORTING name = 'X-GitHub-Api-Version' value = '2026-03-10'.
  IF gv_secret IS NOT INITIAL.
    CONCATENATE 'Bearer' gv_secret INTO gv_auth SEPARATED BY space.
    CALL METHOD go_http->request->set_header_field
      EXPORTING name = 'Authorization' value = gv_auth.
    CLEAR gv_auth.
  ENDIF.

  CALL METHOD go_http->send
    EXPORTING timeout = 30
    EXCEPTIONS http_communication_failure = 1
               http_invalid_state = 2
               http_processing_failed = 3
               OTHERS = 4.
  IF sy-subrc <> 0.
    PERFORM transport_error USING 'SEND'.
    PERFORM close_client.
    RETURN.
  ENDIF.
  CALL METHOD go_http->receive
    EXCEPTIONS http_communication_failure = 1
               http_invalid_state = 2
               http_processing_failed = 3
               OTHERS = 4.
  IF sy-subrc <> 0.
    PERFORM transport_error USING 'RECEIVE'.
    PERFORM close_client.
    RETURN.
  ENDIF.
  CALL METHOD go_http->response->get_status
    IMPORTING code = gv_status reason = gv_reason.
  CALL METHOD go_http->response->get_header_field
    EXPORTING name = 'x-github-request-id'
    RECEIVING value = gv_reqid.
  CALL METHOD go_http->response->get_header_field
    EXPORTING name = 'content-type'
    RECEIVING value = gv_ct.
  IF gv_status = 200.
    CALL METHOD go_http->response->get_cdata
      RECEIVING data = gv_body.
  ENDIF.
  PERFORM close_client.

  WRITE: / 'GitHub directory probe - read only',
         / 'Owner:', p_owner, / 'Repository:', p_repo,
         / 'Directory:', p_path, / 'Ref (blank = default):', p_ref,
         / 'HTTP status:', gv_status,
         / 'GitHub request ID:', gv_reqid.
  CASE gv_status.
    WHEN 200.
      IF gv_ct NS 'application/json'.
        WRITE / 'STOP: HTTP 200 but response is not application/json.'.
        RETURN.
      ENDIF.
      PERFORM show_names.
    WHEN 301 OR 302 OR 307 OR 308.
      WRITE / 'Redirect not followed. Check current owner/repo name.'.
    WHEN 401.
      WRITE / 'Authentication failed. Check token value/expiry.'.
    WHEN 403 OR 429.
      WRITE / 'Check token permissions, org policy/SSO and rate limit.'.
    WHEN 404.
      WRITE / 'Check owner/repo/path/ref AND private repository access.'.
    WHEN OTHERS.
      WRITE / 'HTTP request failed. Check GitHub/network/proxy status.'.
  ENDCASE.

FORM transport_error USING pv_stage TYPE c.
  CALL METHOD go_http->get_last_error
    IMPORTING code = gv_errcode message = gv_errtext.
  IF gv_secret IS NOT INITIAL.
    REPLACE ALL OCCURRENCES OF gv_secret IN gv_errtext WITH '[REDACTED]'.
  ENDIF.
  WRITE: / 'STOP: Transport failure at', pv_stage,
         / 'SAP error code:', gv_errcode,
         / gv_errtext,
         / 'Check server DNS, outbound HTTPS, proxy, STRUST and TLS.'.
ENDFORM.

FORM close_client.
  IF go_http IS BOUND.
    CALL METHOD go_http->request->set_header_field
      EXPORTING name = 'Authorization' value = ''.
    CALL METHOD go_http->close EXCEPTIONS OTHERS = 1.
    FREE go_http.
  ENDIF.
  CLEAR: gv_secret, gv_auth, p_token.
ENDFORM.

FORM show_names.
* Directory API response is an array. A file response is rejected.
* Display JSON string literals unchanged: escapes are not decoded.
* This is a diagnostic name extractor, NOT a general JSON parser.
  gv_cr = cl_abap_char_utilities=>cr_lf.
  gv_len = strlen( gv_body ).
  gv_offset = 0.
  WHILE gv_offset < gv_len.
    gv_first = gv_body+gv_offset(1).
    IF gv_first <> space AND gv_first <>
       cl_abap_char_utilities=>horizontal_tab AND gv_first <>
       cl_abap_char_utilities=>newline AND gv_first <>
       gv_cr.
      EXIT.
    ENDIF.
    gv_offset = gv_offset + 1.
  ENDWHILE.
  IF gv_first <> '['.
    WRITE / 'STOP: Expected directory array; choose a directory path.'.
    RETURN.
  ENDIF.
  gv_regex = '"name"[[:space:]]*:[[:space:]]*("([^"\\]|\\.)*")'.
  gv_count = 0.
  WRITE / 'Names (JSON notation; files and directories together):'.
  WHILE gv_offset < gv_len.
    CLEAR gv_name.
    gv_search = gv_body+gv_offset.
    FIND FIRST OCCURRENCE OF REGEX gv_regex IN gv_search
      IN CHARACTER MODE
      MATCH OFFSET gv_matchoff MATCH LENGTH gv_matchlen
      SUBMATCHES gv_name.
    IF sy-subrc <> 0.
      EXIT.
    ENDIF.
    gv_count = gv_count + 1.
    WRITE: / gv_count, gv_name.
    gv_next = gv_offset + gv_matchoff + gv_matchlen.
    IF gv_next <= gv_offset.
      EXIT.
    ENDIF.
    gv_offset = gv_next.
  ENDWHILE.
  WRITE: / 'Displayed entries:', gv_count,
         / 'HTTP/response check complete; SAP code was not changed.'.
  IF gv_count >= 1000.
    WRITE / 'WARNING: API directory limit reached; listing may be partial.'.
  ENDIF.
  IF gv_count = 0.
    WRITE / 'No names extracted. Empty/unexpected response needs review.'.
  ENDIF.
ENDFORM.
