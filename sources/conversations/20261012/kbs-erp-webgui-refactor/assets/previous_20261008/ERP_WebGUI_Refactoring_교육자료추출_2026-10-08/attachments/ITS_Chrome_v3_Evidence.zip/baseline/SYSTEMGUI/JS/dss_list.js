//<html><script>

function isList( x ) {
	return ( (typeof x == "object") && (x.constructor == List) );
}

function List( id ) {
	this.id		= id;

	this.hd		= null;
	this.tl		= null;
	this.len	= 0;
}


// ------------------------------------------------------------------------
                          
function List_link( lefty, righty ) {
	if (lefty != null) {
		if (! lefty[this.id]) lefty[this.id] = {pred: null, succ: null};
		lefty[this.id].succ = righty;
	}
	if (righty != null) {
		if (! righty[this.id]) righty[this.id] = {pred: null, succ: null};
		righty[this.id].pred = lefty;
	}
}

// ------------------------------------------------------------------------

function List_insertHead( newElem ) {			
	this.link( newElem, this.hd );
	this.link( null, newElem );
	this.hd = newElem;
	if (++this.len == 1) this.tl = newElem;
		
	return newElem;
}

// ------------------------------------------------------------------------

function List_insertTail( newElem ) {			
	this.link( this.tl, newElem );
	this.link( newElem, null );
	this.tl = newElem;
	if (++this.len == 1) this.hd = newElem;
	
	return newElem;
}

// ------------------------------------------------------------------------

function List_insertAt( newElem, pos ) {		
	if (pos == 0) {
		this.insertHead( newElem );
	} else if (pos < this.len) {
		this.insertBefore( this.getAt( pos ), newElem );
	} else {
		this.insertTail( newElem );
	}
	
	return newElem;
}

// ------------------------------------------------------------------------
	
function List_insertBefore( me, newElem ) {
	if (me != this.hd) {
		this.link( this.predOf( me ), newElem  );
		this.link( newElem, me );
		this.len++;
	} else {
		this.insertHead( newElem );
	}
	return newElem;
}

// ------------------------------------------------------------------------

function List_insertAfter( me, newElem ) {
	if (me != this.tl) {
		this.link( newElem, this.succOf( me ) );
		this.link( me, newElem );
		this.len++;
	} else {
		this.insertTail( newElem );
	}	
	return newElem;	
}

// ------------------------------------------------------------------------
                          
function List_removeHead() {
	var oldHd = this.hd;
	var newHd = this.succOf( oldHd );
	
	this.link( null, newHd );
	this.hd = newHd;
	if (--this.len == 0) this.tl = null;
	delete oldHd[this.id];
	
	return oldHd;
}

// ------------------------------------------------------------------------

function List_removeTail() {
	var oldTl = this.tl;
	var newTl = this.predOf( oldTl );
	
	this.link( newTl, null );
	this.tl = newTl;
	if (--this.len == 0) this.hd = null;
	delete oldTl[this.id];
	
	return oldTl;
}

// ------------------------------------------------------------------------

function List_remove( e ) {			

	if (e == this.hd) {
		this.removeHead();
	} else if (e == this.tl) {
		this.removeTail();
	} else {
		var elem = e[this.id];
        this.link( elem.pred, elem.succ );	
        this.len--;
    }
	delete e[this.id];	
	return e;
}

// ------------------------------------------------------------------------

function List_removeAt( pos ) {			
	this.remove( this.getAt( pos ) );
}

// ------------------------------------------------------------------------

function List_clean() {
var len=this.length();
	for (var i = 0; i < len; i++) {
		this.removeHead();
	}
}

// ------------------------------------------------------------------------
                          
function List_head() {				
	return this.hd;
}

// ------------------------------------------------------------------------

function List_tail() {				
	return this.tl;
}

// ------------------------------------------------------------------------

function List_getAt( pos ) {				
	var i, e;
	
	for (i = 0, e = this.head(); (i < pos) && (e != null); i++, e = this.succOf( e ) );
	return e;
}
                          
// ------------------------------------------------------------------------

function List_positionOf( e ) {
	var pos = 0;
	
	for (var i = this.head(); i != null; i = this.succOf( i ) ) {
		if (i == e) return pos;
		pos ++;
	}
	return null;
}

// ------------------------------------------------------------------------

function List_succOf( e ) {	
	return e[this.id].succ; 
}

// ------------------------------------------------------------------------

function List_predOf( e ) {
	return e[this.id].pred;
}	

// ------------------------------------------------------------------------
                          
function List_isEmpty() {				
	return (this.len == 0);
}

// ------------------------------------------------------------------------

function List_length() {				
	return this.len;
}

// ------------------------------------------------------------------------
                          
function List_add( l2 ) {					
	var sum = this.copy();

	for (var e = l2.head(); e != null; e = l2.succOf( e ) ) {
		sum.insertHead( e );
	}	
	return sum;
}

// ------------------------------------------------------------------------

function List_insert( pivot, f ) {
	for (var elem = this.hd; elem != null; elem = this.succOf( elem ) ) {
		if ( f( pivot, elem ) ) {
			this.insertBefore( elem, pivot );
			return pivot;
		}
	}
	this.insertTail( pivot );
	return pivot;
}

// ------------------------------------------------------------------------

List.prototype.link			= List_link;				
List.prototype.insertHead	= List_insertHead;			// List x T -> T; 
List.prototype.insertTail	= List_insertTail;			// List x T -> T; 
List.prototype.insertAt		= List_insertAt;			// List x T x Num -> T; 
List.prototype.insertBefore	= List_insertBefore;		// List x T x T -> T
List.prototype.insertAfter	= List_insertAfter;			// List x T x T -> T
	
List.prototype.removeHead	= List_removeHead;			// List -> T
List.prototype.removeTail	= List_removeTail;			// List -> T
List.prototype.remove		= List_remove;				// List x T -> T
List.prototype.removeAt		= List_removeAt;			// List x Num -> T
List.prototype.clean		= List_clean;				// List ->

List.prototype.head			= List_head;				// List -> T
List.prototype.tail			= List_tail;				// List -> T
List.prototype.getAt		= List_getAt;				// List x Num -> T
List.prototype.positionOf	= List_positionOf;			// List x T -> Num;
	
List.prototype.succOf			= List_succOf;				// List x T -> T
List.prototype.predOf			= List_predOf;				// List x T -> T
	
List.prototype.isEmpty		= List_isEmpty;				// List -> Bool
List.prototype.length			= List_length;				// List -> Num
List.prototype.add			= List_add;					// List x List -> List
List.prototype.insert			= List_insert;				// List x T x (T x T -> Bool) -> T

/*
List.prototype.swap			= List_swap;				// List x T x T -> List
	
List.prototype.copy			= List_copy;				// List -> List
List.prototype.reverse		= List_reverse;				// List -> List
List.prototype.filter			= List_filter;				// List x (T -> Bool) -> List
List.prototype.front			= List_front;				// List -> List
List.prototype.rest			= List_rest;				// List -> List
	
List.prototype.map			= List_map;					// List x (T x ... -> ) x ... -> List
List.prototype.lfold			= List_lfold;				// List x (T x T -> T) -> T
List.prototype.rfold			= List_rfold;				// List x (T x T -> T) -> T
	
List.prototype.isort			= List_isort;				// List x (T x T -> Bool) -> List	
List.prototype.qsort			= List_qsort;				// List x (T x T -> Bool) -> List
	
List.prototype.toString		= List_toString;			// List -> String
List.prototype.toHTML			= List_toHTML;				// List -> String
*/
// ------------------------------------------------------------------------
