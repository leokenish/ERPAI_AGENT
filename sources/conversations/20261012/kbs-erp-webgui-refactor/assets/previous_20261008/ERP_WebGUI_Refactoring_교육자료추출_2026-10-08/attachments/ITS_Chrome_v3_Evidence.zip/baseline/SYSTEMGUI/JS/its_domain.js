// its_domain.js
//
// SAP GUI for HTML / ITS Domain Relaxing
// (c) 2002-2010, SAP AG
//
// Set document.domain for allowing inter-frame communication in SAP GUI for HTML
//
// /tj/2004-01-12
//

function its_setdomain ()
{
  if (its_setdomain.domain == null)
  {
    var isNumAddr = its_setdomain.regexp_ipaddr.test( window.location.hostname),
        sDomain   = null;

    if (!isNumAddr)
    {
      sDomain = window.location.hostname.match(its_setdomain.regexp_server)[8];
      if (sDomain != null && sDomain != "")
        document.domain = its_setdomain.domain = sDomain;
    }  // if (!isNumAddr)
    else
    {
      its_setdomain.domain = document.domain;
    }
  }  // if (serverinfo already set) ... else
  else
  {
    document.domain = its_setdomain.domain;
  }
}
its_setdomain.domain = null;
its_setdomain.regexp_ipaddr = /^\d+\.\d+\.\d+\.\d+/;
its_setdomain.regexp_server = /^(([a-zA-Z0-9-_\.!~\*'\(\)%;&=\+\$,]*)@)?(([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)|(([^:\.]+)(\.([^:]+))*\.?))(:([0-9]*))?$/;
//                                12                                      34                                56        7  8             9 A
//                              +-------------User Info------------+    +----------IPv4Address---------+  +HostNam++--Domain-+        +-Port-+
//                                                                     +------------------------Host-------------------------------+

wgu_setdomain = its_setdomain;

// its_domain.js end
