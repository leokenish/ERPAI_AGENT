const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const W=__dirname,inv=JSON.parse(fs.readFileSync(path.join(W,'html_inventory.json')));
function element(tag){return{nodeName:tag.toUpperCase(),tagName:tag.toUpperCase(),style:{},childNodes:[],attributes:{},rows:[],setAttribute(n,v){this.attributes[n]=String(v);if(n==='id')this.id=v},getAttribute(n){return this.attributes[n]??null},removeAttribute(n){delete this.attributes[n]},appendChild(el){this.childNodes.push(el);el.parentNode=this;return el},getElementsByTagName(){return[]},addEventListener(){},removeEventListener(){}}}
function environment(){
 const doc={documentElement:element('html'),body:element('body'),compatMode:'BackCompat',domain:'erp.example.com',location:{hostname:'erp.example.com'},createElement:element,getElementById(){return null},getElementsByTagName(){return[]},addEventListener(){},removeEventListener(){},write(){},writeln(){},images:[],forms:[]};doc.documentElement.outerHTML='<html></html>';doc.body.ownerDocument=doc;doc.documentElement.ownerDocument=doc;
 const b={document:doc,navigator:{userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',appVersion:'5.0'},location:{hostname:'erp.example.com'},originAgentCluster:true,Image:function(){},setTimeout(){return 1},clearTimeout(){},setInterval(){return 2},clearInterval(){},addEventListener(){},removeEventListener(){},console,alert(){},frames:[],CFWAddFinalizeHandler(){}};
 b.self=b.window=b;b.top=b;b.parent={webguiMimeURL:'/sap/public/bc/its/mimes',webguiTheme:'sl',shSeloptStrings:Array.from({length:20},(_,i)=>['i','eq','option'+i])};doc.defaultView=b;return vm.createContext(b)
}
function exec(b,s,name){return vm.runInContext(s,b,{filename:name,timeout:1000})}
function source(root,f){return fs.readFileSync(path.join(W,root,f),'latin1')}
let results=[];
// Both utility copies can occur in generated documents; verify both loading orders explicitly.
for(const order of [['SYSTEMGUI/JS/its_utils.js','WEBGUI/JS/wgu_utils.js'],['WEBGUI/JS/wgu_utils.js','SYSTEMGUI/JS/its_utils.js']]){
 const b=environment(),errors=[];for(const f of order){try{exec(b,source('modified',f),f)}catch(e){errors.push(e.message)}}
 results.push({test:'utility load order',order,errors,ie:b.its_ua?.ie,dropdown:null});
}
// Execute the supplied shmult script sequence in a minimal DOM model. This does not execute SAP callbacks.
for(const root of ['baseline','modified']){
 const b=environment(),errors=[],loads=[];
 for(const script of (root==='baseline'?JSON.parse(fs.readFileSync(path.join(W,'baseline_scripts.json')))['shmult.html']:inv['shmult.html'].scripts)){let src=script.attrs.src,code=script.text;
  if(src){if(root==='baseline'&&src.endsWith('gui_dropdown.js'))src='/sap/public/bc/its/mimes/webgui/SL/scripts/gui_dropdown.js';
   if(src.includes('/SL/')){errors.push({source:src,error:'Case-sensitive dependency path has no matching sl source'});continue}
   const f='WEBGUI/JS/'+src.split('/').pop();code=source(root,f);loads.push(f)
  }
  try{exec(b,code,src||'shmult-inline')}catch(e){errors.push({source:src||'shmult-inline',error:e.name+': '+e.message})}
 }
 results.push({test:'shmult ordered scripts',root,loads,errors,dropdown:typeof b.gui_dropdownManager,managerType:b.its_ddMgrDynpro?.parentType});
}
// Table control constructor consumes the real dropdown module after the actual utility API definitions.
const b=environment(),errors=[];
for(const f of ['WEBGUI/JS/wgu_utils.js','WEBGUI/JS/gui_dropdown.js','WEBGUI/JS/gui_tablecontrol.js'])try{exec(b,source('modified',f),f)}catch(e){errors.push(e.message)}
try{b.wgu_global_eventhandler=new b.wguObjEventHandler(); b.document.getElementById=()=>element('div'); const tc={name:'sample'}; b.its_tcMgr.init(tc); assert.equal(tc.dropdown.parentType,'TC');}catch(e){errors.push(e.name+': '+e.message)}
results.push({test:'table control and dropdown init',errors});
for(const r of results) if(r.root!=='baseline') assert.equal(r.errors.length,0,JSON.stringify(r));
fs.writeFileSync(path.join(W,'integration_validation.json'),JSON.stringify({mode:'Minimal DOM model; not a browser',results},null,2));console.log(JSON.stringify(results,null,2));
