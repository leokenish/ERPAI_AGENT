// wgu_frameset.js
//
// SAP GUI for HTML / ITS Frameset Management
//
// /tj/2004-02      / SAPGUI for HTML ITSSM Frameset Management
// /tj/2008-09-16   / improved "slow" disconnectonclose
// /tj/2009-06-05   / simplification of the framework
//


/*****************************************
 *  Helper functions
 */

function appendGetParameter ( inout_url, in_parm, in_value, in_encode, in_duplicate )
{ var sep = "?";
  if (null != inout_url && null != in_parm)
  { if (inout_url.indexOf("?") != -1) sep = "&";
    if (inout_url.toLowerCase().indexOf(in_parm.toLowerCase() + "=") == -1 || in_duplicate)
    { inout_url = [inout_url, sep, in_parm, (null != in_value ? ["=", (in_encode ? encodeURIComponent(in_value) : in_value)].join("") : "")].join("");
    }
  }
  return inout_url;
} // appendGetParameter()


function getFrameDocumentByFrame ( in_frameobj )  // in_frameobj must be reference to <frame> tag
{ rv = false;
  if (in_frameobj)
  { try
    // it might happen that a redirect URL is accessed on exit
    // but we don't get any chance to know about it :(
    { if (typeof in_frameobj.contentDocument == "undefined")
        rv = in_frameobj.contentWindow.document;  // IE
      else
        rv = in_frameobj.contentDocument;         // Mozilla
    } catch(err) {}  // what shall we do?!? :(
  }
  return rv;
} // getFrameDocumentByFrame()



/*****************************************************************************/



/*****************************************
 *  Session management
 */

function wguSessionDoNothing() {}

function wguSessionBuildTerminationURL ( in_sessionInfo )
{
  var termurl = null;

  wguSessionTerminate.wFrame = document.getElementById("ITSTERMFRAME").contentWindow;
  wguSessionTerminate.boSlow = !!(typeof its_boDisconnectSlow != "undefined" && its_boDisconnectSlow)
                               || (typeof goSettings != "undefined" && !!goSettings && goSettings.itssm_slow);

  if (wguSessionTerminate.boSlow)
  {
    if ("undefined" == typeof its_mimeendsessUrl)
      its_mimeendsessUrl = "/sap/public/bc/its/mimes/system/sl/page/endsess.html";
  }

  if (in_sessionInfo && in_sessionInfo._url)
  {
    termurl = in_sessionInfo._url.replace(/\/[^/]*\/data\/.*/, "");
    wguSessionTerminate.URL =
    termurl = [ appendGetParameter( termurl, in_sessionInfo._termParm),
    //          "&~session=", encodeURIComponent( in_sessionInfo._session),
                "&~closewindow=1&~exiturl="
              ].join("");
    if (document.getBoxObjectFor != null)
    {
      wguSessionTerminate.boSlow = true;
      wguSessionTerminate.winParm = "height=120,width=180,top=40,left=80,screenX=40,screenY=80,location=no,dependent=no";
    }
  }
  else
    wguSessionTerminate.URL = null;

  return termurl;
} // wguSessionBuildTerminationURL()


function wguSessionTerminate ( in_event, in_sessionInfo )
{
  var rc = false;
  var ev;
  var termurl = wguSessionTerminate.URL;
  var f = wguSessionTerminate.wFrame;

  if (in_event != null) ev = in_event; else ev = window.event;
  if (ev) ev.cancelBubble = true;

  if (null != termurl)
  {
    if (wguSessionTerminate.boSlow)
    {
      termurl = [its_mimeendsessUrl, "?url=", encodeURIComponent(termurl)].join("");
      f = window.open(termurl, "ITSCloseSess", wguSessionTerminate.winParm);
    }
    else if (null != f)
    {
      f.location.href = termurl;
      if (!document.all)
        f.src = termurl;
    }
    else
      new Image().src = termurl;

    rc = true;
  }

  return rc;
} // wguSessionTerminate()
wguSessionTerminate.URL    = null;
wguSessionTerminate.wFrame = null; // Termination frame : index 3!)
wguSessionTerminate.winParm = "height=20,width=20,top=8000,left=0,screenX=0,screenY=8000,location=no,dependent=no";


/* Call on SRV_CLOSE to redirect to ~exitURL
 */
function wguSessionRedirect ( in_sessionInfo )
{
  if (in_sessionInfo._exiturl != "") {
    window.self.location.replace( in_sessionInfo._exiturl);
  }
} // wguSessionRedirect()



/*****************************************************************************/



/*****************************************
 *  Frameset management
 */

  /* its_frame_root is a variable that has to be defined on
   * the root frameset in order to identify the root uniquely;
   * the variable should be defined as boolean true (!)
   * so that it can be evaluated to not being initialized
   * yet. Later it will be initialized to our frameset management
   * object (see below).
   * If its_frame_root is set to null or is currently
   * undefined, the current page/frame is assumed to be NOT
   * the root frameset.
   *
   * its_frame_root will be defined on both the root and childs.
   *
   * its_frame_mgr is a variable that refers to either
   * its_frame_root on the root frameset or
   * its_frame_child on the child frames.
   */
if (typeof self.its_frame_root != "undefined" && typeof self.its_frame_root != "object" && null != self.its_frame_root)
{
  self.its_frame_child = false;
  self.its_frame_mgr =
  self.its_frame_root = {

    _frameroot  : this,       // reference to this object in root frameset
    _rootwindow : self,

    _frame1     : null,       // reference to frame tag #1
    _frame2     : null,       // reference to frame tag #2

    _activeframe  : null,     // reference to currently active (visible) frame tag

    _bo_swapframes: true,     // in some cases the frames must not be swapped (user override)

    _inactivationstate : [ false, false ],  // currently in toggle / activation of a frame?


    InitializeManager : function ( in_frametagid1, in_frametagid2 )
    {
    } // InitializeManager()
    ,


    Initialize : function ( in_frametagid1, in_frametagid2 )
    {
      this._frame1 = document.getElementById(in_frametagid1);
      this._frame2 = document.getElementById(in_frametagid2);

      this._activeframe = this.FindActiveFrame();
    } // Initialize()
    ,


    IsFramesetExist : function () { return true; }
    ,


    FindRoot  : function ()
    {
      return this;
    } // FindRoot()
    ,


    FindRootWindow  : function ()
    {
      return self;  // this._rootwindow
    } // FindRootWindow()
    ,


    FindActiveFrame : function ()
    { var rv = null;
      if (null == this._activeframe)
      { if (null != this._frame2 && this._frame2.style.zIndex > 0) this._activeframe = this._frame2;
        else if (null != this._frame1) this._activeframe = this._frame1;
      }
      if (null != this._activeframe)
      { rv = this._activeframe;
      }
      return rv;
    } // FindActiveFrame()
    ,


    FindInactiveFrame : function ()
    { var rv = null;
      if (this.FindActiveFrame == this._frame2) rv = this._frame1;
      else rv = this._frame2;
      return rv;
    } // FindInactiveFrame()
    ,


    FindOtherFrame : function ( in_frametagobj )
    { var rv = null;
      if (in_frametagobj == this._frame1) rv = this._frame2;
      else if (in_frametagobj == this._frame2) rv = this._frame1;
      return rv;
    } // FindOtherFrame()
    ,


    GetFrameNo : function ( in_frametagobj )    // return internal id of frametag (Note: diff to its_frame_child!)
    { var rv = null;
      if (in_frametagobj == this._frame1) rv = 0;
      else if (in_frametagobj == this._frame2) rv = 1;
      return rv;
    } // GetFrameNo()
    ,


    ShowFrame : function ( in_frameno, in_bo_regarddotoggle, in_bo_cleanotherframe )
    { if (true === in_bo_regarddotoggle && this._bo_swapframes)
      { if (1 == in_frameno)
        { this._activeframe = this._frame2;
          this.FadeIn(this._frame2);
          this.FadeOut(this._frame1);
          if (!!in_bo_cleanotherframe)
            this.CleanFrame(this._frame1);
        }
        else
        { this._activeframe = this._frame1;
          this.FadeIn(this._frame1);
          this.FadeOut(this._frame2);
          if (!!in_bo_cleanotherframe)
            this.CleanFrame(this._frame2);
        }
      }
      return this;
    } // ShowFrame()
    ,


    CleanFrame : function ( in_frametagobj )
    {
      var f, d;
      if (null != in_frametagobj)
      {
        try {
          if (null != (f = in_frametagobj.contentWindow)
              && null != (d = f.document)
             )
          {
            d.body.onunload =
            d.body.onresize =
            d.body.onfocus  = null;
            d.body.innerHTML = "";
          }
        }
        catch(ex) {}
      }
      return this;
    } // CleanFrame()
    ,


    FadeIn : function ( in_frametagobj )
    { if (null != in_frametagobj)
      { in_frametagobj.style.zIndex = 999;
        in_frametagobj.style.left = in_frametagobj.style.top = "0px";
      }
      return this;
    } // FadeIn()
    ,


    FadeOut : function ( in_frametagobj )
    { if (null != in_frametagobj)
      { in_frametagobj.style.zIndex = 0;
        in_frametagobj.style.left = in_frametagobj.style.top = "-8000px";
      }
      return this;
    } // FadeOut()
    ,


    GetTitle : function ( in_frameno )
    { var rv = null,
          f;
      if (null == in_frameno)
      { f = FindActiveFrame();
      }
      else
      { f = (0 === in_frameno)
            ? this._frame1
            : ((1 === in_frameno)
               ? this._frame2
               : null
              ) ;
      }
      if (null != f)
      { try
        { rv = f.contentWindow.document.title;
        }
        catch (ex) { rv = "" };
      }
      return rv;
    } // GetTitle()
    ,


    SetTitle : function ( in_titletext )
    { if (null == in_titletext)
        in_titletext = "";
      self.document.title = in_titletext.toString();
      return true;
    } // SetTitle()
    ,


    SetFocus : function ( in_frameno )
    { var f;
      f = (0 === in_frameno)
          ? this._frame1
          : ((1 === in_frameno)
             ? this._frame2
             : this.FindActiveFrame()
            ) ;
      if (null != f)
      { f = f.contentWindow;
        if (null != f && null != f.its_frame_mgr)
        { f.its_frame_mgr.SetFocus(null);
        }
      }
    } // SetFocus()
    ,


    SetDontSwap : function ( in_boDontSwap )
    {  this._bo_swapframes = !in_boDontSwap;
       return this;
    } // SetDontSwap()
    ,


    GetSwapSetting : function ()
    {  return this._bo_swapframes;
    } // GetSwapSetting()


  };  // its_frame_root

  self.its_frame_root.InitializeManager();
}



/*****************************************
 *  Frame management
 */

else if (typeof self.its_frame_child == "undefined")
{
  self.its_frame_root = null;
  self.its_frame_mgr =
  self.its_frame_child = {

    _frameroot  : null,       // reference to its_frame_mgr of root frameset
    _rootwindow : null,

    _dontfocus  : false,


    Initialize  : function ()
    {
      this._frameroot  = this.FindRoot();
      this._rootwindow = this.FindRootWindow();
      return this;
    } // Initialize()
    ,


    IsFramesetExist : function () { return (null != this._frameroot) ? true : false; }
    ,


    FindRoot  : function ()
    { var rv = null,
          f, pf;
      if (null == this._frameroot)
      { for (f = self; true; f = pf)
        { pf = f.parent;
          try
          { if (!!f.its_frame_root)   // root frameset found?
            { rv = f.its_frame_root.FindRoot();
              break;
            }
            else if (f === pf)
            { break;
            }
          }
          catch (ex) { rv = null; break; }
        }
      }
      else
      { rv = this._frameroot;
      }
      return rv;
    } // FindRoot()
    ,


    FindRootWindow  : function ()
    { var rv = null,
          f, pf;
      if (null == this._frameroot)
      { for (f = self; true; f = pf)
        { pf = f.parent;
          try
          { if (!!f.its_frame_root)   // root frameset found?
            { rv = f;
              break;
            }
            else if (f === pf)
            { break;
            }
          }
          catch (ex) { rv = null; break; }
        }
      }
      else
      { rv = this._rootwindow;
      }
      return rv;
    } // FindRootWindow()
    ,


    FindActiveFrame : function ()
    { var rv = null;
      if (null != this._frameroot)
      { rv = this._frameroot.FindActiveFrame();
      }
      if (null == rv)   // no frameset -> return myself :)
      { rv = self;
      }
      return rv;
    } // FindActiveFrame ()
    ,


    FindInactiveFrame : function ()
    { var rv = null;
      if (null != this._frameroot)
      { rv = this._frameroot.FindInactiveFrame();
      }
      return rv;
    } // FindInactiveFrame()
    ,


    FindOtherFrame : function ()
    { var rv = null;
      if (null != this._frameroot)
      { rv = this._frameroot.FindOtherFrame(self.frameElement);
      }
      return rv;
    } // FindOtherFrame()
    ,


    GetFrameNo : function ()      // return id # of current frame
    { var rv = null;
      if (null != this._frameroot)
      { rv = this._frameroot.GetFrameNo(self.frameElement);
      }
      else
        rv = 0;
      return rv;
    } // GetFrameNo()
    ,


    GetTitle : function ( in_frameno )
    { var rv = null,
          r;
      if (null != in_frameno && null != (r = fmgr.FindRoot()))
      { rv = r.GetTitle(in_frameno);
      }
      else
      { rv = self.document.title;
      }
      return rv;
    } // SetTitle()
    ,


    SetTitle : function ( in_titletext )
    {
      if (null == in_titletext)
        in_titletext = "";
      if (null != this._frameroot)
      { rv = this._frameroot.SetTitle(in_titletext);
      }
      else
      { self.document.title = in_titletext.toString();
        rv = true;
      }
      return rv;
    } // SetTitle()
    ,


    SetFocus : function ( in_frameno )
    { var r, f, d,
          at, it, i, j;
      if (null != in_frameno && null != (r = fmgr.FindRoot()))
      { r.SetFocus(in_frameno);
      }
      else
      { f = self;
        d = self.document;
        if (f.webguiHasPopup)  // dynpro has popups
        { if (null != (f = d.getElementsByName("webguiPopupWindow"+f.webguiHasPopup)[0]))
          { d = getFrameDocumentByFrame(f);
            f = f.contentWindow;
          }
        }
        if (!dom_focus(f))
          top.status = "SAP GUI for HTML: Could not set focus on window!";
        if (!this._dontfocus)
        { try
          { if (!!f.webguiSetFocus && !!f.webguiFocusField)
            { f.webguiSetFocus();
            }
            else
            { it = d.getElementsByTagName("input");
              j = it.length;
              for (i = 0; i < j; i++)
              { if (it[i].type != "hidden")
                { dom_focus(it[i]);
                  j = -1;
                  break;
                }
              }
              if (j >= 0 && null != (at = d.getElementsByTagName("a")[0]))
              { dom_focus(at);
              }
            }
          }
          catch (ex) {}
        }
      }
    } // SetFocus()


  };  // its_frame_child

  self.its_frame_child.Initialize();
}



/*****************************************************************************/



/*****************************************
 * Interface function for SAP GUI for HTML and IACs
 */

function ITS_Frameset( in_action, inout_parm1, inout_parm2 ) // inout_parm3, ...
{
  var rv = null;    // return value
  var argl = arguments.length,
      i, j,
      fmgr = self.its_frame_mgr;

  if (null != fmgr)
  {
    switch (in_action)
    {
      case "ROOT" :
      case "BASE" :
        rv = fmgr.FindRoot();
        break;

      case "IS_ACTIVE" :
        rv = fmgr.IsFramesetExist();
        break;

      case "FRAMESET" :
        rv = null;    // not supported anymore
        break;

      case "FRAME" :
        if (null != (rv = fmgr.FindActiveFrame()))
          rv = rv.contentWindow;
        break;

      case "FRAMENO" :
        rv = fmgr.GetFrameNo();
        break;

      case "FRAME_OTHER" :
        rv = fmgr.FindOtherFrame();
        break;

      case "FRAMENO_OTHER" :
        i = fmgr.FindRoot();
        rv = (null != i) ? i.GetFrameNo(fmgr.FindOtherFrame()) : 0;
        break;

      case "FRAMEDOCUMENT" :
        rv = (null != (i = fmgr.FindActiveFrame())) ? i.contentWindow.document : self.document;
        break;

      case "DONT_SWAP_FRAMES" :
        rv = (null != (i = fmgr.FindRoot())) ? i.SetDontSwap(true) : false;
        break;

      case "DO_SWAP_FRAMES" :
        rv = (null != (i = fmgr.FindRoot())) ? i.SetDontSwap(false) : false;
        break;

      case "GET_SWAP_SETTING" :
        rv = (null != (i = fmgr.FindRoot())) ? i.GetSwapSetting() : false;
        break;

      case "SHOWFRAME" :
        i = fmgr.FindRoot();
        rv = (null != i) ? i.ShowFrame(self.frameElement) : false;
        break;

      case "ISACTIVATING" :
        /*
          inout_parm1 contains frame no or null (-> self)
          Resize functions want to know if a resize event is fired
          due to the activation process (frame toggle);
          Note: the flag is reset after evaluation!
        */

        if (null == inout_parm1) inout_parm1 = fmgr.GetFrameNo();
        if (null != (i = fmgr.FindRoot()) && -1 != inout_parm1)
        {
          rv = i._inactivationstate[inout_parm1];
          i._inactivationstate[inout_parm1] = false;
        }
        else rv = false;
        break;

      case "RESETACTIVATINGFLAG" :
        if (null == inout_parm1) inout_parm1 = fmgr.GetFrameNo();
        if (null != (i = fmgr.FindRoot()) && -1 != inout_parm1)
        {
          i._inactivationstate[inout_parm1] = false;
        }
        break;

      case "ACTIVATEFRAME" :
        /* inout_parm1 contains frame no
           inout_parm2 ist true, when called from frameset
        */
        // self.ITS_Frameset.itsrootwin.document.title = mydoc.title;
        fmgr.SetTitle(fmgr.GetTitle(inout_parm1));

       // here no break but continue with FOCUS
      case "FOCUS" :
        fmgr.SetFocus(inout_parm1);
        rv = true;
        break;

      // we don't want the ITS_Frameset("FOCUS") to set the focus
      case "DONT_FOCUS" :
          fmgr._dontfocus = true;
        break;

      case "DIMENSION" :
        inout_parm1 = self.document.body.offsetWidth;
        inout_parm2 = self.document.body.offsetHeight;
        rv = true;
        break;

      case "SET_TITLE" :
       /*
          Sets the base ITS frameset's title
            (for showing it in the browser title)
          inout_parm1 contains title to be set
        */
       if (inout_parm1 != null)
       {
         return fmgr.SetTitle();
       }
       break;

      case "CALL_ON" :
        /*
          inout_parm1 contains event, when the function will be called
                      valid events are ( "load" )
          inout_parm2 contains reference to user function to be called

          following parameters will be forwarded to the callback function (only up to three allowed!)
          ----
          use myCallbackHdl of ITS frameset
        */
        if (null != (i = fmgr.FindRootWindow()) && !!inout_parm1 && !!inout_parm2)
        {
          var arrparm = new Array( 3);
          for (i = 3, j = 0; i < argl; i++, j++)
          {
            if (j < 3)    // max. three parameters
              arrparm[ j] = arguments[ i];
          }
          if (!!i.myCallbackHdl)
          {
            i.myCallbackHdl.RegisterHandler( inout_parm1, "callback", 1, inout_parm2, arrparm[0], arrparm[1], arrparm[2]);
          }
        }
       break;

    } // switch

  } // if (self.ITS_Frameset.itsrootwin  == null)

  return rv;
}
