// =======================================================================================
// SAP_ExternalWindowInterface.js
// ------------------------------
// SAP External Window interface
//

// --------------------------------------------------------------------------------------
// SAP_ExternalWindowInterface() - INTERFACE
// -----------------------------------------
// declares the External Window Interface
//

function SAP_ExternalWindowInterface_open( url, name, features, bReplace ) {
    function uniqueName() {
        return "SAP_ExternalWindow" + (new Date().getTime() );
    }
    
    var loOldWnd = null;
    var loNewWnd = null;
    
    if (! name) {
        name = uniqueName();
    }
    
    loNewWnd = window.open( url, name, features, bReplace );
    
    if ( (null != ( loOldWnd = this.theWindows.query( name ) ) ) && 
         (this._isAlive( loOldWnd ) ) && 
         (loNewWnd != loOldWnd) ) {
        /* window with name = <name> already exists, but the returned reference is different! */
        /* it seems the window changed its name */
        this.add( loOldWnd, uniqueName() );
    }
    this.add( loNewWnd, name );

    return loNewWnd;
}

function SAP_ExternalWindowInterface__isAlive( ref ) {
    var lbResult = false;
    
    if (ref != null) {
        var lsState = typeof( ref.opener );
        lbResult = (lsState != "unknown") && (lsState != "undefined");
    }
    return lbResult;
}

function SAP_ExternalWindowInterface_isAlive( name ) {
    return this._isAlive( this.getWindowRef( name ) );
}

function SAP_ExternalWindowInterface__checkAll() {
    for (var leRef = this.theWindows.keys(); leRef.hasMoreElements(); ) {
        var lsWinName = leRef.nextElement();
        if (! this.isAlive( lsWinName ) ) {
            this.theWindows.unregister( lsWinName );
        }
    }
}

function SAP_ExternalWindowInterface_add( ref, name ) {
    this.theWindows.unregister( name );
    return this.theWindows.register( name, ref );
}

function SAP_ExternalWindowInterface_getWindowRef( name ) {
    return this.theWindows.query( name );
}

function SAP_ExternalWindowInterface__close( ref ) {
    if (this._isAlive( ref ) ) {
        ref.close();
    }
}

function SAP_ExternalWindowInterface_close( name ) {
    this._close( this.getWindowRef( name ) );
    this.theWindows.unregister( name );
}

function SAP_ExternalWindowInterface_closeAll() {
    for (var leRef = this.theWindows.keys(); leRef.hasMoreElements(); ) {
        this.close( leRef.nextElement() );
    }
}

function SAP_ExternalWindowInterface_getLength() {
    this._checkAll();
    return this.theWindows.getLength();
}

function SAP_ExternalWindowInterface_elements() {
    this._checkAll();
    return this.theWindows.keys();
}

var SAP_ExternalWindowInterface = {
    id:             "SAP_ExternalWindowInterface",
    theWindows:     new SAPWF_Repository(),
    
    open:           SAP_ExternalWindowInterface_open,
    add:            SAP_ExternalWindowInterface_add,
    isAlive:        SAP_ExternalWindowInterface_isAlive,
    _isAlive:       SAP_ExternalWindowInterface__isAlive,
    _checkAll:      SAP_ExternalWindowInterface__checkAll,
    getWindowRef:   SAP_ExternalWindowInterface_getWindowRef,
    close:          SAP_ExternalWindowInterface_close,
    _close:         SAP_ExternalWindowInterface__close,
    closeAll:       SAP_ExternalWindowInterface_closeAll,
    getLength:      SAP_ExternalWindowInterface_getLength,
    elements:       SAP_ExternalWindowInterface_elements
}
// --------------------------------------------------------------------------------------

// =======================================================================================


