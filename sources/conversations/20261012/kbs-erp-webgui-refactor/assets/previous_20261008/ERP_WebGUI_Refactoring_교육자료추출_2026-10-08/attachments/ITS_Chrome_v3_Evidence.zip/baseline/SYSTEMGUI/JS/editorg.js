//<html><script>

//possible state changes

var stateMap = { "_": { "a": "A", "m": "M", "d": "D" }, 
		  		 "A": { "m": "AM", "d": "AD" }, 
		  		 "AM": { "m": "AM", "d": "AD" }, 
		  		 "M": { "m": "M", "d": "D" } };

//returns the next state
function nextState( currState, action ) {
	return stateMap[currState][action];
}

//construction for action class
function Action(id, oObject, nObject, pFcn, undoFcn, saveFcn){
 this._id = id;
 this._oObject = oObject;
 this._nObject = nObject;
 this._pFcn = pFcn;
 this._undoFcn = undoFcn;
 this._saveFcn = saveFcn;
}

//methods of action class
function Action_perform(){
 this._pFcn(this._oObject, this._nObject);
}

function Action_undo(){
 this._undoFcn(this._oObject, this._nObject);
}

function Action_redo(){
 this.perform();
}

function Action_Save(){
 this._saveFcn(this._nObject);
}

function Action_id(){
 return this._id;
}

function Action_getOObject(){
  return this._oObject;
}

function Action_getNObject(){
  return this._nObject;
}

Action.prototype.perform=Action_perform;
Action.prototype.undo=Action_undo;
Action.prototype.redo=Action_redo;
Action.prototype.save=Action_Save;
Action.prototype.id=Action_id;
Action.prototype.prevObject = Action_getOObject;
Action.prototype.currObject = Action_getNObject;

//constructor edit class
function Edit(name){
 this._todo = new List(name);
 this._currIndex=-1;
 
 //events
 //onStackChange: raised when an object is added or removed from the stack
 //parameters: currLength, totalLength
 this.SAPWF_EVENT_onStackChange = new Function(";");
}

//functions of edit class

function Edit_add(actionObject){
 if(this._currIndex > 0) //remove the first (this._currIndex - 1) objects
 {
  var index;
  for(index=0; index < this._currIndex;index++)
  {
   this._todo.removeHead();
  }
 }
 this._todo.insertHead(actionObject);
 actionObject.perform();
 this._currIndex = 0;
 //raise event stack changed
 this.SAPWF_EVENT_onStackChange(this.length(), this.totalLen());
}

function Edit_getObject(id){
 var index;
 var tLen=this._todo.length();
 var item;
 for(index=this._currIndex; index< tLen;index++)
 {
   item =this._todo.getAt(index);
   if(item !=null && item.id() == id)
     return item;
 }
}

function Edit_undo(){
 var cAct = this._todo.getAt(this._currIndex)
 if(cAct != null)
 {
   cAct.undo();
   this._currIndex += 1;
 //raise event stack changed
 this.SAPWF_EVENT_onStackChange(this.length(), this.totalLen());
 }
}

function Edit_redo(){
 var cAct = this._todo.getAt(this._currIndex - 1)
 if(cAct != null && this._currIndex != 0 )
 {
   cAct.redo();
   this._currIndex -= 1;
  //raise event stack changed
   this.SAPWF_EVENT_onStackChange(this.length(), this.totalLen());
 }
}

function Edit_save(allObjects){
 var savedList = new List("savedList");
 var item;
 var lItem;
 var iItem;
 
 for(item=this._todo.tail();item!=null;item = this._todo.predOf(item))
 {
  if(this._todo.positionOf(item) < this._currIndex)
    break; //get out of for loop. no more valid items
    
  if(allObjects == false) //call save for only the last of object of the given "id"
  {
   //check if this item has been processed.
   if(savedList.positionOf(item.id()) == null)
   {
    savedList.insertHead(new Object(item.id()));
    //get the last item with this id
    for(iItem=item; iItem != null; iItem = this._todo.predOf(iItem))
    {
      if(iItem.id() == item.id() && this._todo.positionOf(iItem) >= this._currIndex)
       lItem = iItem;
    }
    lItem.save(); //call the save for the last item with this id
   }
  }
  else //call save for all objects
   item.save(); 
 }
 this._todo.clean(); //remove all items
 this._currIndex = -1;
  //raise event stack changed
 this.SAPWF_EVENT_onStackChange(this.length(), this.totalLen());
}

function Edit_length(){
  return this._todo.length();
}

function Edit_activeLength(){
  return (this._currIndex == -1? 0 : ((this._todo.length() - this._currIndex)) ) ;
}


Edit.prototype.add= Edit_add;
Edit.prototype.item = Edit_getObject;
Edit.prototype.undo = Edit_undo;
Edit.prototype.redo = Edit_redo;
Edit.prototype.save = Edit_save;
Edit.prototype.length = Edit_activeLength;
Edit.prototype.totalLen = Edit_length;