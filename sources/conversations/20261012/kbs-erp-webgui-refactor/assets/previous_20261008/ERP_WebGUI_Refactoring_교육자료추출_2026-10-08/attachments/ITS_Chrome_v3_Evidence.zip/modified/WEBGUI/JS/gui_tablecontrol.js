/*******************************************************************************
 *
 * tablecontrol.js
 *
 * Description: table control framework for sap gui for html / webgui
 *
 * Date       : 2005/02/16
 * Author     : Simon Kruska
 *
 * History    :
 *
 * YYYY/MM/DD ID DESCRIPTION
 * 2005/02/16 sk initial implementation
 *
 *
 *
 *
 *
 *
 *
 *
 *
 ******************************************************************************/

its_tcMgr = null;
its_tcCurrentInputField = null;
its_tcTimeout = 0;
its_tcLeave = false;
its_tcFocusTimeout = 10;
if (its_ua.ie55up)
{
  its_tcFocusTimeout = 50;
}
css_tcCurrent = "tcCurrent";
if (its_ua.ie6)
  css_tcCurrent = "tcCurrent_ie6";

/** <its_tablecontrolManager>
  *
  *   cunstructor for the class its_tablecontrolManager
  *     its_toolbar_control_manager encapsulates all interactive functions and
  *     actions on a tablecontrol. the data of the tablecontrol is thereby hold
  *     in the extern class its_tablecontrolObject.
  *
  *   params:
  */
function its_tablecontrolManager(obj)
{
  // object that keeps data during an resize event
  this.cr = null;
}

/** <its_tablecontrolManager::searchHelp>
  *
  *
  *   params:
  */
its_tablecontrolManager.prototype.searchHelp = function(evt)
{
  var name, e;

  if (!(evt instanceof its_event))
    e = new its_event(evt);
  else
    e = evt;

  if (e.valid)
  {
    if (e.target.className == "tcSearchHelp")
      name = e.target.getAttribute("name");
    else if (e.keyCode)
    {
      var kc = Number(e.keyCode);
      kc += 400;
      e.event.keyCode = kc;
      var td = dom_getParentNodeByNodeName(e.target, "TD");
      if (td)
        name = td.getAttribute("iname");
    }
    if (name)
    {
      webguiRaiseSearchhelp(name);
    }
    e.cancel();
  }
}
// </its_tablecontrolManager::searchHelp>


/** <its_tablecontrolManager::setFocusField>
  *
  *
  *   params:
  *     focusField - String - row/column position of the focus field
  */
its_tablecontrolManager.prototype.setFocusField = function(obj, focusField)
{
  ITS_Frameset("DONT_FOCUS");
  obj.focusField = focusField;
}
// </its_tablecontrolManager::setFocusField>


/** <its_tablecontrolManager::setCurrentCellOnLoad>
  *
  *
  *   params:
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.setCurrentCellOnLoad = function(obj)
{
  if ("undefined" == typeof webguiIsActive || webguiIsActive())
  {
    if (obj.focusField.length > 0)
    {
      var rowColumn = obj.focusField.split(",");
      if (rowColumn.length == 2)
      {
        var table = this.getContainingBodyTable(obj, rowColumn[1]);
        var row = parseInt(rowColumn[0], 10);
        var column = parseInt(rowColumn[1], 10);
        var virtualColumn = this.getVirtualColumnNo(obj, rowColumn[1]);
        if (row >= obj.firstVisibleRow && row <= obj.lastVisibleRow &&
            column >= 0 && column <= obj.columns)
        {
          var node = table.rows[row-obj.firstVisibleRow].cells[virtualColumn];
          if (node)
          {
            this.setCurrentCell(obj, node, false, true);
          }
        }
      }
    }
  }
}
// </its_tablecontrolManager::setCurrentCellOnLoad>


/** <its_tablecontrolManager::init>
  *
  *
  *   params:
  *     handler - String - javascript event handler that will be called through
  *                        eval()
  */
its_tablecontrolManager.prototype.init = function(obj)
{
  obj.container           = document.getElementById(obj.name + "_TCContainer");
  obj.titleContainer      = document.getElementById(obj.name + "_TCTitleContainer");
  obj.fixHeaderContainer  = document.getElementById(obj.name + "_TCFixHeaderContainer");
  obj.freeHeaderContainer = document.getElementById(obj.name + "_TCFreeHeaderContainer");
  obj.fixBodyContainer    = document.getElementById(obj.name + "_TCFixBodyContainer");
  obj.freeBodyContainer   = document.getElementById(obj.name + "_TCFreeBodyContainer");
  obj.fixHeaderTable      = document.getElementById(obj.name + "_TCFixHeaderTable");
  obj.freeHeaderTable     = document.getElementById(obj.name + "_TCFreeHeaderTable");
  obj.fixBodyTable        = document.getElementById(obj.name + "_TCFixBodyTable");
  obj.freeBodyTable       = document.getElementById(obj.name + "_TCFreeBodyTable");
  obj.searchHelpButton    = document.getElementById(obj.name + "_TCSearchHelp");
  obj.layoutTable         = document.getElementById(obj.name + "_TCLayoutTable");
  obj.hScrollbarOffset    = document.getElementById(obj.name + "-HScrollbarOffset");

  var fScroll = function() { its_tcMgr.scrollOnLoad(obj); };
  window.wgu_global_eventhandler.RegisterHandler( "load", "~tc", 0, fScroll );

  fClick = function(evt) { its_tcMgr.click(evt, obj); };
  its_eMgr.registerEvent(obj.container, "click", fClick);

  fMousedown = function(evt) { its_tcMgr.mousedown(evt, obj); };
  its_eMgr.registerEvent(obj.container, "mousedown", fMousedown);

  fDoubleClick = function(evt) { its_tcMgr.doubleclick(evt, obj); };
  its_eMgr.registerEvent(obj.container, "dblclick", fDoubleClick);

  fKeydown = function(evt) { its_tcMgr.keydown(evt, obj); };
  its_eMgr.registerEvent(obj.container, "keydown", fKeydown);

  fContextMnu = function(evt) { its_tcMgr.contextmenu(evt, obj); };
  its_eMgr.registerEvent(obj.container, "contextmenu", fContextMnu);

  // assign focus event handler
  fFocus = function(evt) { its_tcMgr.focus(evt); };
  its_eMgr.registerEvent(obj.container, "focus", fFocus);

  CFWAddFinalizeHandler(function() { its_tcMgr.setCurrentCellOnLoad(obj); });

  obj.dropdown = new gui_dropdownManager(obj, "TC");

  if (typeof webguiShButtonManager != "undefined" &&
      typeof webguiShButtonManager.New != "undefined")
  {
    webguiShButtonManager.New("tcSearchHelpButton", its_tcMgr.hideSearchHelpButton, null, null);
  }
}
// </its_tablecontrolManager::init>


/** <its_tablecontrolManager::click>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.click = function(evt, obj)
{
  var e = new its_event(evt);
  var preventDefault = true;
  if (e)
  {
    var node = this.getParentCell(e.target);
    var input = null;
    var div = null;
    if (node)
    {
      // click on a body cell
      if (node.nodeName == "TD")
      {
        if (node.className.indexOf("tcBody") == 0)
        {
          var input = this.getInputFieldR(node);
          var itype = node.getAttribute("itype");
          if (input)
          {
            if (this.isButton(input) && !input.getAttribute("idisabled"))
            {
              // submit button fcode
              var okcode = input.getAttribute("okcode");
              var okname = input.getAttribute("okname");
              if (typeof okcode != "undefined" && typeof okname != "undefined")
              {
                setOkCode(okcode, okname);
              }
            }
            else if (this.isCheckbox(input))
            {
              this.toggleCheckbox(input);
            }
            else if (this.isRadiobutton(input))
            {
              this.toggleRadiobutton(input);
            }
          }
          if (e.target.className.indexOf("ddButton") == 0)
          {
            if (itype && itype == "dropdown")
            {
              obj.dropdown.initDropdown(node);
              obj.dropdown.click(e.event);
            }
          }
        }
      }
    }
    if (e)
    {
      e.stopPropagation();
      if (preventDefault)
      {
        e.preventDefault();
      }
      delete(e);
    }
  }
}
// </its_tablecontrolManager::click>


/** <its_tablecontrolManager::mousedown>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.mousedown = function(evt, obj)
{
  if (typeof CloseMenus != "undefined")
  {
    CloseMenus(0);
  }
  else if (typeof CloseMenus_crobro != "undefined")
  {
    CloseMenus_crobro(0);
  }
  if (obj.dropdown)
  {
    obj.dropdown.holdBlocking = false;
    if (obj.dropdown.opened)
    {
      return;
    }
  }
  var e = new its_event(evt);
  if (e)
  {
    var node = this.getParentCell(e.target);
    var input = null;
    if (node)
    {
      // mousedown on a header cell?
      if (node.nodeName == "TH" && e.target.className != "tcHeaderColresize" && e.button != EVT_MB_RIGHT )
      {
        this.headerMousedown(obj, node);
      }
      // mousedown on a body cell
      else if (node.nodeName == "TD")
      {
        if (node.className.indexOf("tcBodyRowSelector") == 0)
        {
          node = this.rowSelectorMousedown(obj, node);
          if (node && node.className.indexOf("tcBody") == 0)
            this.setCurrentCell(obj, node, true, false);
        }
        else if (node.className.indexOf("tcBody") == 0)
        {
          this.setCurrentCell(obj, node, true, false);
          if (node.getAttribute("hotspot") == "hotspot" && node.className.indexOf("tcBodyHotspotOutput") > -1)
            webguiRaiseFKey(2);
        }
      }
    }
    if (e)
    {
//      e.stopPropagation();
      delete(e);
    }
  }
}
// </its_tablecontrolManager::mousedown>


/** <its_tablecontrolManager::doubleclick>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.doubleclick = function(evt, obj)
{
  var e = new its_event(evt);
  if (e)
  {
    webguiRaiseFKey(2);
    e.stopPropagation();
    delete(e);
  }
}
// </its_tablecontrolManager::doubleclick>

/** <its_tablecontrolManager::contextmenu>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.contextmenu = function(evt, obj)
{
  var e = new its_event(evt);
  if (e)
  {
    var node = this.getParentCell(e.target);
    var input = null;
    if (node)
    {
        if (node.getAttribute("cm") == "X")
        {
          this.setCurrentCell(obj, node, true, false);
          OpenControlContextMenu(node.getAttribute("iid"), "OnDynproContextMenu", "", evt.clientX, evt.clientY);
        }
    }
    if (e)
    {
      e.cancel();
      delete(e);
    }
  }
}
// </its_tablecontrolManager::contextmenu>


/** <its_tablecontrolManager::scrollCellIntoView>
  *
  *  scroll the current cell into the view that the complete cell can be seen
  *
  *   params:
  *   obj   - Object - the its_tablecontrol_object
  *   td    - Object - the current cell
  *   table - Object - the table the cell belongs to
  */
its_tablecontrolManager.prototype.scrollCellIntoView = function(obj, td, table)
{
  var scrollbarOffset = 1;
  var f4Offset = 0;
  var container = dom_getParentNodeByNodeName(table, "DIV");
  var scrollLeft = container.scrollLeft;
  if (td.getAttribute("f4") == "1")
  {
    //
    f4Offset = 16;
  }
  if (td.offsetLeft + td.offsetWidth + f4Offset + scrollbarOffset > container.offsetWidth + container.scrollLeft)
  {
    var scrollLeft = td.offsetLeft + td.offsetWidth - container.offsetWidth + f4Offset + scrollbarOffset;
    if (scrollLeft > td.offsetLeft)
    {
        scrollLeft = td.offsetLeft
    }
  }
  if (container.scrollLeft > td.offsetLeft)
  {
    scrollLeft = td.offsetLeft;
  }
  if (obj.freeColContainer && container.className.indexOf("tcFreeBody") == 0)
    its_scrollContainerMgr.scrollIntoView(obj.freeColContainer, td);
}
// </its_tablecontrolManager::scrollCellIntoView>


/** <its_tablecontrolManager::scroll>
  *
  *  called when the scroll event appears on the free table body container
  *
  *   params:
  *   obj   - Object - the its_tablecontrol_object
  */
/*
its_tablecontrolManager.prototype.scroll = function(obj)
{
//  this.hideSearchHelpButton(obj);
  if (obj.freeHeaderContainer)
  {
    if (!isBidiRTL())
    {
      obj.freeHeaderContainer.scrollLeft = obj.freeBodyContainer.scrollLeft;
      if (obj.hScrollbarOffset)
      {
        obj.hScrollbarOffset.value = obj.freeHeaderContainer.scrollLeft;
      }
    }
    else
    {
//      obj.freeHeaderContainer.scrollLeft = 0;
      obj.freeHeaderContainer.scrollLeft = obj.freeBodyContainer.scrollLeft;
      if (obj.hScrollbarOffset)
      {
        obj.hScrollbarOffset.value = obj.freeHeaderContainer.scrollLeft;
      }
    }
  }
  if (obj.currentCell && obj.currentCell.nodeName == "TD" && obj.currentCell.getAttribute("sh"))
  {
    this.displaySearchHelpButton(obj, obj.currentCell);
  }
}
*/
// </its_tablecontrolManager::scroll>

/** <its_tablecontrolManager::scrollTo>
  *
  *  called when the scroll event appears on the free table body container
  *
  *   params:
  *   obj   - Object - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.scrollTo = function(obj, pos)
{
  this.hideSearchHelpButton(obj);
  if (obj.freeHeaderContainer)
  {
    if (!isBidiRTL())
    {
      obj.freeHeaderContainer.scrollLeft = pos;

      if (obj.hScrollbarOffset)
      {
        obj.hScrollbarOffset.value = obj.freeHeaderContainer.scrollLeft;
      }
    }
    else
    {
      if ((obj.freeHeaderContainer.scrollWidth - obj.freeHeaderContainer.offsetWidth - pos) > 0)
        obj.freeHeaderContainer.scrollLeft = obj.freeHeaderContainer.scrollWidth - obj.freeHeaderContainer.offsetWidth - pos;
      else
        obj.freeHeaderContainer.scrollLeft = 0;

      if (obj.hScrollbarOffset)
      {
        obj.hScrollbarOffset.value =  obj.freeHeaderContainer.scrollWidth - obj.freeHeaderContainer.offsetWidth - obj.freeHeaderContainer.scrollLeft;
      }
    }
  }
//  if (obj.currentCell && obj.currentCell.nodeName == "TD" && obj.currentCell.getAttribute("sh"))
//  {
//    this.displaySearchHelpButton(obj, obj.currentCell);
//  }
}
// </its_tablecontrolManager::scrollTo>


/** <its_tablecontrolManager::scrollOnLoad>
  *
  *  sets the scroll position of the containers on load
  *
  *   params:
  *   obj   - Object - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.scrollOnLoad = function(obj)
{
  if (obj.hScrollbarOffset)
  {
    if (obj.freeHeaderContainer)
    {
      if (isBidiRTL())
      {
        if ((obj.freeHeaderContainer.scrollWidth - obj.freeHeaderContainer.offsetWidth - obj.hScrollbarOffset.value) > 0)
          obj.freeHeaderContainer.scrollLeft = obj.freeHeaderContainer.scrollWidth - obj.freeHeaderContainer.offsetWidth - obj.hScrollbarOffset.value;
        else
          obj.freeHeaderContainer.scrollLeft = 0;
      }
      else
         obj.freeHeaderContainer.scrollLeft = obj.hScrollbarOffset.value;
    }
  }
}
// </its_tablecontrolManager::scrollOnLoad>


/** <its_tablecontrolManager::setCurrentCell>
  *
  *  set the current cell including className (for background-color), focus and
  *  text selection
  *
  *   params:
  *   obj       - Object - the its_tablecontrolObject
  *   node      - Object - the current cell object (td)
  *   setFocus  - Boolean - whether to set the focus to the element or not
  *   setSelect - Boolean - whether to select the content of the element or not
  */
its_tablecontrolManager.prototype.setCurrentCell = function(obj, node, setFocus, setSelect)
{
  var input = this.getInputFieldR(node);
  var table = dom_getParentNodeByNodeName(node, "TABLE");
  var searchHelp = node.getAttribute("sh");
  var required = node.getAttribute("irequired")? true : false;

  webguiSaveFocus(new webguiFocusObj(WEBGUI_FOCUS_TYPE_TABLE, obj));

  if (node && node != obj.currentCell)
  {
    obj.currentCell = node;
    var itype = node.getAttribute("itype");
    if (input == null && itype)
    {
      if (itype == "text")
      {
        input = this.renderInputField(obj, node);
      }
    }
  }
  //
  // SETTING THE BROWSERS FOCUS
  //
  if (input)
  {
    if (input.type == "text" && required)
    {
      input.className = dom_removeClass(input.className, "tcTextRequired");
    }
    else if (itype == "dropdown")
    {
      setFocus = true;
      setSelect = false;
    }
    else if (input.className == "tcButton" ||
             input.className.indexOf("tcCheckbox") != -1 ||
             input.className.indexOf("tcRadiobutton") != -1)
    {
      setFocus = true;
      setSelect = false;
    }
    this.setBrowserFocus(obj, input, setFocus, setSelect);
  }
  else if (itype == "dropdown")
  {
    setFocus = false;
    setSelect = true;
    input = obj.dropdown.initDropdown(node);
    this.setBrowserFocus(obj, input, setFocus, setSelect);
  }
  else if (obj.currentCell.nodeName == "TD" &&
           obj.currentCell.className.indexOf("tc") == 0)
  {
    if (its_ua.gecko)
    {
      setFocus = true;
      setSelect = false;
      this.setBrowserFocus(obj, node, setFocus, setSelect);
    }
    else if (its_ua.ie55up)
    {
      var div = dom_getChildNodeByNodeName(obj.currentCell, "DIV");
      if (div)
      {
        setFocus = true;
        setSelect = false;
        this.setBrowserFocus(obj, div, setFocus, setSelect);
      }
    }
  }

  //
  // SETTING THE NODES STYLE
  //
  if (input && (input.getAttribute("itype") != "checkbox" &&
                input.getAttribute("itype") != "radiobutton" ||
                input.className == "tcButton"))
  {
    node.className = dom_addClass(node.className, "tcBodyCurrent");
  }
  else
  {
    var div = dom_getChildNodeByNodeName(node, "DIV");
    if (div)
    {
      div.className = dom_addClass(div.className, css_tcCurrent);
    }
  }
  //
  // REMEMBERING THE WEBGUIS FOCUS FIELD
  //
  var webguiFocusField = document.getElementsByName("~Focusfield");
  var id = node.getAttribute("iid");
  if (webguiFocusField && webguiFocusField.length == 1 && id)
  {
    webguiFocusField[0].value = id;
  }
  //
  // SCROLL THE CELL INTO VIEW
  //
  this.scrollCellIntoView(obj, node, table);
  //
  // DISPLAY THE SEARCHHELP BUTTON
  //
  if (typeof webguiShButtonManager != "undefined" &&
      typeof webguiShButtonManager.Update != "undefined")
  {
    webguiShButtonManager.Update("tcSearchHelpButton", obj, null);
  }
  if (searchHelp)
  {
    this.displaySearchHelpButton(obj, node);
  }
}
// </its_tablecontrolManager::setCurrentCell>


/** <its_tablecontrolManager::setBrowserFocus>
  *
  *  set the focus to an input field and select the input field if it is from
  *  type text
  *
  *   params:
  *   input     - Object - the input field
  *   setFocus  - Boolean - whether to set the focus to the element or not
  *   setSelect - Boolean - whether to select the content of the element or not
  */
its_tablecontrolManager.prototype.setBrowserFocus = function(obj, input, setFocus, setSelect)
{
  if (input.nodeName == "INPUT")
  {
    if (typeof setSelect != "undefined" && setSelect == true)
    {
      dom_delayedSelect(input);
    }
    else
    {
      dom_delayedFocus(input);
    }
  }
  else if (typeof setFocus != "undefined" && setFocus == true)
  {
    dom_delayedFocus(input);
  }
}
// </its_tablecontrolManager::setBrowserFocus>


/** <its_tablecontrolManager::unsetCurrentCell>
  *
  *  unset the current cell including className (for background-color) and
  *  selection; only if focus is set outside the TC, this method is invoked by
  *  the blur event handler, otherwise it is called from method setCurrentCell.
  *
  *   params:
  *   obj - Object - the its_tablecontrolObject
  */
its_tablecontrolManager.prototype.unsetCurrentCell = function(obj)
{
  this.hideSearchHelpButton(obj);
  if (obj.currentCell)
  {
    var input = this.getInputFieldR(obj.currentCell);
    if (input)
    {
      obj.currentCell.className = dom_removeClass(obj.currentCell.className,
                                                  "tcBodyCurrent");
      if (input.getAttribute("itype") == "checkbox" ||
          input.getAttribute("itype") == "radiobutton")
      {
        var div = dom_getChildNodeByNodeName(obj.currentCell, "DIV");
        div.className = dom_removeClass(div.className, css_tcCurrent);
      }
      else if (input.type == "text")
      {
        var required = obj.currentCell.getAttribute("irequired")? true : false;
        if (input.value.length == 0 && required)
        {
          input.className = dom_addClass(input.className, "tcTextRequired");
        }
      }
      if (its_tcCurrentInputField && its_tcCurrentInputField.nodeName == "INPUT")
      {
        setTimeout("its_tcCurrentInputField.blur();", 0);
      }
    }
    else
    {
      var div = dom_getChildNodeByNodeName(obj.currentCell, "DIV");
      if (div)
      {
        div.className = dom_removeClass(div.className, css_tcCurrent);
      }
    }
    obj.currentCell = null;
  }
}
// </its_tablecontrolManager::unsetCurrentCell>


/** <its_tablecontrolManager::focus>
  *
  *  Event handler for focus event on the tablecontrol; does only stop
  *  propagation of focus to the dynpro (webguiDoFocus)
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_tablecontrolManager.prototype.focus = function(evt)
{
  e = new its_event(evt);
  if (e.valid)
  {
    e.stopPropagation();
    delete(e);
  }
}
// </its_tablecontrolManager::focus>


/** <its_tablecontrolManager::elfocus>
  *
  *  Event handler for focus event on the elements tcTabenter or tcTabLeave;
  *  sets the focus into the tc when one of these elements is focused
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.elfocus = function(evt, obj)
{
  var node = null;
  if (evt)
  {
    var e = new its_event(evt);
    if (its_tcLeave)
    {
      its_tcLeave = false;
      e.cancel();
    }
    else if (e.target.id.indexOf("Enter") > -1)
    {
      var node = this.getFirstEditableCell(obj, true);
      if (node)
      {
        this.setCurrentCell(obj, node, true, false);
      }
      e.cancel();
    }
    else if (e.target.id.indexOf("Leave") > -1)
    {
      var node = this.getFirstEditableCell(obj, false);
      if (node)
      {
        this.setCurrentCell(obj, node, true, false);
      }
      e.cancel();
    }
  }
}
// </its_tablecontrolManager::elfocus>


/** <its_tablecontrolManager::getFirstEditableCell>
  *
  *  searches for the first editable field, either forward or backward
  *
  *   params:
  *     obj     - Object  - the its_tablecontrol_object
  *     forward - Object  - search cell from the beginning or from the end
  */
its_tablecontrolManager.prototype.getFirstEditableCell = function(obj, forward)
{
  var table = null;
  var virtualColumnNo = 0;
  if (forward)
  {
    for (var r = 0; r < (obj.lastVisibleRow - obj.firstVisibleRow + 1); r++)
    {
      for (var c = 0; c < obj.columns; c++)
      {
        table = this.getContainingBodyTable(obj, c+1);
        virtualColumnNo = this.getVirtualColumnNo(obj, c+1);
        if (table)
        {
          var node = table.rows[r].cells[virtualColumnNo];
          var itype = node.getAttribute("itype");
          if (node)
          {
            var input = this.getInputFieldR(node);
            if ((input && !input.getAttribute("idisabled")) || itype)
            {
              return node;
            }
          }
        }
      }
    }
  }
  else
  {
    for (var r = (obj.lastVisibleRow - obj.firstVisibleRow); r >= 1 ; r--)
    {
      for (var c = obj.columns-1; c >= 0; c--)
      {
        table = this.getContainingBodyTable(obj, c+1);
        virtualColumnNo = this.getVirtualColumnNo(obj, c+1);
        if (table)
        {
          var node = table.rows[r].cells[virtualColumnNo];
          var itype = node.getAttribute("itype");
          if (node)
          {
            var input = this.getInputFieldR(node);
            if ((input && !input.getAttribute("idisabled")) || itype)
            {
              return node;
            }
          }
        }
      }
    }
  }
  return null;
}
// </its_tablecontrolManager::getFirstEditableCell>


/** <its_tablecontrolManager::toggleCheckbox>
  *
  *  toggles the state of a checkbox and sets its appendant hidden input field
  *
  *   params:
  *     checkbox - Object  - HTML DIV element representing the checkbox
  */
its_tablecontrolManager.prototype.toggleCheckbox = function(checkbox)
{
  var idisabled = checkbox.getAttribute("idisabled");
  if (!idisabled)
  {
    var iname = checkbox.getAttribute("iname");
    if (iname != "")
    {
      var iinput = document.getElementById(iname);
      if (iinput && typeof iinput != "undefined")
      {
        if (iinput.value == "X")
        {
          iinput.value = " ";
          checkbox.className = dom_removeClass(checkbox.className, "tcCheckboxChecked");
          checkbox.className = dom_addClass(checkbox.className, "tcCheckboxUnchecked");
        }
        else
        {
          iinput.value = "X";
          checkbox.className = dom_removeClass(checkbox.className, "tcCheckboxUnchecked");
          checkbox.className = dom_addClass(checkbox.className, "tcCheckboxChecked");
        }
      }
    }
  }
  // send okcode if provided
  var okcode = checkbox.getAttribute("iokcode");
  if (okcode != null && typeof okcode != "undefined" && okcode != "")
  {
    setOkCode(okcode);
  }
}
// </its_tablecontrolManager::toggleCheckbox>


/** <its_tablecontrolManager::toggleRadiobutton>
  *
  *  toggles the state of a checkbox and sets its appendant hidden input field
  *
  *   params:
  *     checkbox - Object  - HTML DIV element representing the checkbox
  */
its_tablecontrolManager.prototype.toggleRadiobutton = function(radiobutton)
{
  var idisabled = radiobutton.getAttribute("idisabled");
  if (!idisabled)
  {
    var iname = radiobutton.getAttribute("iname");
    if (iname != "")
    {
      var iinput = document.getElementById(iname);
      if (!iinput)
      {
        iinput = document.createElement("input");
        iinput.setAttribute("type", "hidden");
        iinput.setAttribute("name", radiobutton.getAttribute("iname"));
        iinput.setAttribute("id", radiobutton.getAttribute("iname"));
        var webguiForm = document.getElementById("webguiform");
        if (webguiForm)
        {
          webguiForm.appendChild(iinput);
        }
      }
      else
      {
        var ivalue = iinput.getAttribute("value");
        if (ivalue != "")
        {
          prevRadiobutton = document.getElementById(ivalue);
          if (prevRadiobutton)
          {
            prevRadiobutton.className = dom_removeClass(prevRadiobutton.className, "tcRadiobuttonChecked");
            prevRadiobutton.className = dom_addClass(prevRadiobutton.className, "tcRadiobuttonUnchecked");
          }
        }
      }
      iinput.setAttribute("value", radiobutton.getAttribute("ivalue"));
      radiobutton.className = dom_addClass(radiobutton.className, "tcRadiobuttonChecked");
      radiobutton.className = dom_removeClass(radiobutton.className, "tcRadiobuttonUnchecked");
    }
  }
  // send okcode if provided
  var okcode = radiobutton.getAttribute("iokcode");
  if (okcode != null && typeof okcode != "undefined" && okcode != "")
  {
    setOkCode(okcode);
  }
}
// </its_tablecontrolManager::toggleRadiobutton>



/** <its_tablecontrolManager::keydown>
  *
  *  Event handler for keydown event on TDs in the tablecontrol
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *   obj - Object       - the its_tablecontrol_object
  */
its_tablecontrolManager.prototype.keydown = function(evt, obj)
{
  // Do not select a row or submit while Chrome is committing IME text.
  var composingEvent = evt || window.event;
  if (composingEvent && (composingEvent.isComposing || composingEvent.keyCode == 229)) return;
  if (obj.dropdown)
  {
    obj.dropdown.holdBlocking = false;
  }
  // if a dropdown is opened it has to handle the keydown event
  if (obj.dropdown.opened)
  {
    obj.dropdown.keydown(evt);
  }
  else
  {
    var e = new its_event(evt);
    if (e)
    {
      node = obj.currentCell;
      var keydownProcessed = false;
      if (node)
      {
        // focus on a body cell
        if (node.nodeName == "TD")
        {
          switch (e.keyCode)
          {
            case EVT_KEY_TAB :
              keydownProcessed = this.kbTab(e, obj, node);
              break;
            case EVT_KEY_UP :
              keydownProcessed = this.kbUp(e, obj, node);
              break;
            case EVT_KEY_DOWN :
              keydownProcessed = this.kbDown(e, obj, node);
              break;
            case EVT_KEY_LEFT :
              keydownProcessed = this.kbLeft(e, obj, node);
              break;
            case EVT_KEY_RIGHT :
              keydownProcessed = this.kbRight(e, obj, node);
              break;
            case EVT_KEY_RETURN :
              keydownProcessed = this.kbReturn(e, obj, node);
              break;
            case EVT_KEY_PGUP :
              keydownProcessed = true;
              if (obj.firstVisibleRow > 1)
              {
                raiseEvent(obj.name, "PrevPage");
              }
              break;
            case EVT_KEY_PGDOWN :
              keydownProcessed = true;
              if (obj.firstVisibleRow < obj.rows)
              {
                raiseEvent(obj.name, "NextPage");
              }
              break;
            case EVT_KEY_POS1 :
              if (e.ctrlKey)
              {
                keydownProcessed = true;
                if (obj.firstVisibleRow > 1)
                {
                  raiseEvent(obj.name, "TopPage");
                }
              }
              break;
            case EVT_KEY_END :
              if (e.ctrlKey)
              {
                keydownProcessed = true;
                if (obj.firstVisibleRow < obj.rows)
                {
                  raiseEvent(obj.name, "LastPage");
                }
              }
              break;
            case EVT_KEY_F1 :
              keydownProcessed = false;
              break;
            case EVT_KEY_F4 :
              this.searchHelp(e);
              keydownProcessed = true;
              break;
            case EVT_KEY_SPACE :
              var input = this.getInputFieldR(node);
              if (input && this.isCheckbox(input))
              {
                this.toggleCheckbox(input);
                keydownProcessed = true;
              }
              else if (input && this.isRadiobutton(input))
              {
                this.toggleRadiobutton(input);
                keydownProcessed = true;
              }
              else if (this.isDropdown(input))
              {
                keydownProcessed = true;
              }
              if (input && this.isButton(input))
              {
                // submit button fcode
                var okcode = input.getAttribute("okcode");
                var okname = input.getAttribute("okname");
                if (typeof okcode != "undefined" && typeof okname != "undefined")
                {
                  setOkCode(okcode, okname);
                }
              }
              break;
            default :
              // prevent keyboard entries on closed dropdown
              if (e.target.className.indexOf("dd") == 0)
              {
                keydownProcessed = true;
              }
              break;
          }
        }
      }
      if (keydownProcessed)
      {
        e.cancel();
      }
      delete(e);
    }
  }
}
// </its_tablecontrolManager::keydown>


/** <its_tablecontrolManager::kbUp>
  *
  *  Navigation with the arrow key up
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbUp = function(e, obj, node)
{
  var tr        = dom_getParentNodeByNodeName(node, "TR");
  var td        = null;
  var bodyTable = dom_getParentNodeByNodeName(tr, "TABLE");
  var cellIndex = node.cellIndex;
  var rowIndex  = tr.rowIndex;

  if (node.className.indexOf("tcBody") == 0)
  {
    rowIndex -= 1;
    if (rowIndex >= 0)
    {
      if (bodyTable.rows[rowIndex])
      {
        td = bodyTable.rows[rowIndex].cells[cellIndex];
        if (td)
        {
          this.setCurrentCell(obj, td, false, true);
          return true;
        }
      }
    }
    else
    {
        // we should return false as we should leave the table, but dynpro
        // does not handle up/down arrow keys
        return true;
    }
  }
  return false;
}
// </its_tablecontrolManager::kbUp>


/** <its_tablecontrolManager::kbDown>
  *
  *  Navigation with the arrow key down
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbDown = function(e, obj, node)
{
  var tr         = dom_getParentNodeByNodeName(node, "TR");
  var td         = null;
  var bodyTable  = dom_getParentNodeByNodeName(tr, "TABLE");
  var cellIndex  = node.cellIndex;
  var rowIndex   = tr.rowIndex;

  var div = dom_getChildNodeByNodeName(node, "DIV");
  if (div && e.altKey && this.isDropdown(div))
  {
    div = dom_getChildNodeByNodeName(div, "DIV");
    if (div)
    {
      e.target = div;
      obj.dropdown.initDropdown(node);
      obj.dropdown.click(e);
    }
  }
  else
  {
    if (node.className.indexOf("tcBody") == 0)
    {
      rowIndex += 1;
      if (rowIndex < bodyTable.rows.length)
      {
        if (bodyTable.rows[rowIndex])
        {
          td = bodyTable.rows[rowIndex].cells[cellIndex];
          if (td)
          {
            this.setCurrentCell(obj, td, false, true);
            return true;
          }
        }
      }
      else
      {
          // we should return false as we should leave the table, but dynpro
          // does not handle up/down arrow keys
          return true;
      }
    }
  }
  return false;
}
// </its_tablecontrolManager::kbDown>


/** <its_tablecontrolManager::kbLeft>
  *
  *  Navigation with the arrow key left
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbLeft = function(e, obj, node)
{
  var tr        = dom_getParentNodeByNodeName(node, "TR");
  var td        = null;
  var bodyTable = dom_getParentNodeByNodeName(tr, "TABLE");
  var cellIndex = node.cellIndex;
  var rowIndex  = tr.rowIndex;

  if (e.target.nodeName != "INPUT" || e.target.className == "dd")
  {
    if (node.className.indexOf("tcBody") == 0)
    {
      cellIndex -= 1;
      if (cellIndex >= 0 && (bodyTable != obj.fixBodyTable || cellIndex >= obj.rowSelector))
      {
        if (bodyTable.rows[rowIndex])
        {
          td = bodyTable.rows[rowIndex].cells[cellIndex];
        }
      }
      else if (bodyTable == obj.freeBodyTable && obj.fixBodyTable)
      {
        bodyTable = obj.fixBodyTable;
        cellIndex = bodyTable.rows[rowIndex].cells.length;
        if (cellIndex > 0)
        {
          td = bodyTable.rows[rowIndex].cells[cellIndex-1]
        }
      }
      else
      {
          // we should return false as we should leave the table, but dynpro
          // does not handle up/down arrow keys
          return true;
      }
      if (td)
      {
        this.setCurrentCell(obj, td, false, true);
        return true;
      }
    }
  }
  else if (e.target.nodeName == "INPUT")
  {
    return false;
  }
  else
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::kbLeft>


/** <its_tablecontrolManager::kbRight>
  *
  *  Navigation with the arrow key left
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbRight = function(e, obj, node)
{
  var tr        = dom_getParentNodeByNodeName(node, "TR");
  var td        = null;
  var bodyTable = dom_getParentNodeByNodeName(tr, "TABLE");
  var cellIndex = node.cellIndex;
  var rowIndex  = tr.rowIndex;

  if (e.target.nodeName != "INPUT" || e.target.className == "dd")
  {
    if (node.className.indexOf("tcBody") == 0)
    {
      cellIndex += 1;
      if (cellIndex < bodyTable.rows[rowIndex].cells.length)
      {
        if (bodyTable.rows[rowIndex])
        {
          td = bodyTable.rows[rowIndex].cells[cellIndex];
        }
      }
      else if (bodyTable == obj.fixBodyTable && obj.freeBodyTable)
      {
        bodyTable = obj.freeBodyTable;
        cellIndex = 0;
        if (cellIndex < bodyTable.rows[rowIndex].cells.length)
        {
          td = bodyTable.rows[rowIndex].cells[cellIndex]
        }
      }
      else
      {
          // we should return false as we should leave the table, but dynpro
          // does not handle up/down arrow keys
          return true;
      }
      if (td)
      {
        this.setCurrentCell(obj, td, false, true);
        return true;
      }
    }
  }
  else if (e.target.nodeName == "INPUT")
  {
    return false;
  }
  else
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::kbRight>


/** <its_tablecontrolManager::kbReturn>
  *
  *  process return key down
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbReturn = function(e, obj, node)
{
  var button = this.getInputFieldR(node);
  if (button)
  {
    if (this.isButton(button))
    {
      // submit button fcode
      var okcode = button.getAttribute("okcode");
      var okname = button.getAttribute("okname");
      if (typeof okcode != "undefined" && typeof okname != "undefined")
      {
        setOkCode(okcode, okname);
      }
      return true;
    }
  }
  return false;
}
// </its_tablecontrolManager::kbReturn>


/** <its_tablecontrolManager::kbTab>
  *
  *  Navigation through the tabulator key
  *
  *   params:
  *   e    - Object - the its_event
  *   obj  - Object - the its_tablecontrol_object
  *   node - Object - the node (TD)
  */
its_tablecontrolManager.prototype.kbTab = function(e, obj, node)
{
  var tr           = dom_getParentNodeByNodeName(node, "TR");
  var td           = null;
  var input        = null;
  var bodyTable    = dom_getParentNodeByNodeName(tr, "TABLE");
  var cellIndex    = node.cellIndex;
  var rowIndex     = tr.rowIndex;
  var found        = false;
  var switchResult = null;
  var leaveRow     = false;
  var i            = 0;

  if (node.className.indexOf("tcBody") != 0)
  {
    return false;
  }
  else
  {
    if (e.shiftKey)
    {
      while (!found)
      {
        cellIndex--;
        if (cellIndex < 0 ||
            cellIndex == 0 &&
            obj.fixBodyTable &&
            bodyTable == obj.fixBodyTable &&
            obj.rowSelector
           )
        {
          leaveRow = false;
          switchResult = this.switchBodyTable(obj, bodyTable, false);
          bodyTable = switchResult.table;
          leaveRow  = switchResult.leaveRow;
          cellIndex = bodyTable.rows[rowIndex].cells.length - 1;
          if (leaveRow)
          {
            rowIndex--;
            if (rowIndex < 0)
            {
              var elem = document.getElementById(obj.name + "_TCTabEnter");
              if (elem)
              {
                its_tcLeave = true;
                dom_focus(elem);
                this.unsetCurrentCell(obj);
              }
              return false;
            }
          }
        }
        td = bodyTable.rows[rowIndex].cells[cellIndex];
        input = this.getInputFieldR(td);
        if (td.className.indexOf("Disabled") == -1)
        {
          found = true;
        }
      }
    }
    else
    {
      while (!found)
      {
        cellIndex ++;
        if (cellIndex >= bodyTable.rows[rowIndex].cells.length)
        {
          leaveRow = false;
          switchResult = this.switchBodyTable(obj, bodyTable, true);
          bodyTable = switchResult.table;
          leaveRow  = switchResult.leaveRow;
          cellIndex = 0;
          if (bodyTable == obj.fixBodyTable && obj.rowSelector)
          {
            cellIndex++;
          }
          if (leaveRow)
          {
            rowIndex++;
            if (rowIndex >= bodyTable.rows.length)
            {
              var elem = document.getElementById(obj.name + "_TCTabLeave");
              if (elem)
              {
                its_tcLeave = true;
                dom_focus(elem);
                this.unsetCurrentCell(obj);
              }
              return false;
            }
          }
        }
        td = bodyTable.rows[rowIndex].cells[cellIndex];
        input = this.getInputFieldR(td);
        if (td.className.indexOf("Disabled") == -1)
        {
          found = true;
        }
      }
    }
    this.setCurrentCell(obj, td, false, true);
  }
  return true;
}
// </its_tablecontrolManager::kbTab>


/** <its_tablecontrolManager::switchBodyTable>
  *
  *  return the opposite table, e. g. when fixBodyTable is given, freeBodyTable
  *  is returned; if fixBodyTable is null, freeBodyTable will be returned.
  *
  *   params:
  *   obj     - Object  - the its_tablecontrolObject
  *   table   - Object  - the table
  *   forward - Boolean - navigate for- or backward
  */
its_tablecontrolManager.prototype.switchBodyTable = function(obj, table, forward)
{
  var result = new Object();
  if (table == obj.fixBodyTable)
  {
    if (obj.freeBodyTable)
    {
      result.leaveRow = (forward? false : true);
      result.table = obj.freeBodyTable;
    }
    else
    {
      result.leaveRow = true;
      result.table = obj.fixBodyTable;
    }
  }
  else if (table == obj.freeBodyTable)
  {
    if (obj.fixBodyTable && obj.fixBodyTable.rows[0].cells.length > obj.rowSelector)
    {
      result.leaveRow = (forward? true : false);
      result.table = obj.fixBodyTable;
    }
    else
    {
      result.leaveRow = true;
      result.table = obj.freeBodyTable;
    }
  }
  return result;
}
// </its_tablecontrolManager::switchBodyTable>


/** <its_tablecontrolManager::isButton>
  *
  *  checks if a node is a button
  *
  *   params:
  *   node            - Object  - the note to check for
  */
its_tablecontrolManager.prototype.isButton = function(node)
{
  if (node.nodeType  == DOM_NODE_TYPE_ELEMENT &&
      node.nodeName  == "DIV" &&
      node.className == "tcButton")
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::isButton>


/** <its_tablecontrolManager::isInputfield>
  *
  *  checks if a node is an inputfield (not a hidden inputfield)
  *  considers whether the inputfield is disabeld if needed
  *
  *   params:
  *   node            - Object  - the note To check for
  */
its_tablecontrolManager.prototype.isInputfield = function(node)
{
  if (node.nodeType           == DOM_NODE_TYPE_ELEMENT &&
      node.nodeName           == "INPUT" &&
      node.type.toUpperCase() != "HIDDEN")
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::isInputfield>


/** <its_tablecontrolManager::isDropdown>
  *
  *  checks if a node is a dropdown
  *  considers whether the inputfield is disabeld if needed
  *
  *   params:
  *   node            - Object  - the note to check for
  */
its_tablecontrolManager.prototype.isDropdown = function(node)
{
  if (node.nodeType == DOM_NODE_TYPE_ELEMENT &&
      node.nodeName == "DIV" &&
      node.getAttribute("itype") == "dropdown")
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::isDropdown>


/** <its_tablecontrolManager::isCheckbox>
  *
  *  checks if a node is a checkbox
  *  considers whether the inputfield is disabeld if needed
  *
  *   params:
  *   node            - Object  - the note to check for
  */
its_tablecontrolManager.prototype.isCheckbox = function(node)
{
  if (node.nodeType              == DOM_NODE_TYPE_ELEMENT &&
      node.nodeName              == "DIV" &&
      node.getAttribute("itype") == "checkbox")
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::isCheckbox>


/** <its_tablecontrolManager::isRadiobutton>
  *
  *  checks if a node is a radiobutton
  *  considers whether the inputfield is disabeld if needed
  *
  *   params:
  *   node            - Object  - the note to check for
  */
its_tablecontrolManager.prototype.isRadiobutton = function(node)
{
  if (node.nodeType              == DOM_NODE_TYPE_ELEMENT &&
      node.nodeName              == "DIV" &&
      node.getAttribute("itype") == "radiobutton")
  {
    return true;
  }
  return false;
}
// </its_tablecontrolManager::isRadiobutton>


/** <its_tablecontrolManager::getInputFieldR>
  *
  *  recursively search an inputfield - which is not hidden or disabled -
  *  within a td node; if nothing is found return null
  *
  *   params:
  *   node - Object - the td to search for the input field
  */
its_tablecontrolManager.prototype.getInputFieldR = function(node)
{
  var n = null;
  var i = 0;
  while (i < node.childNodes.length)
  {
    n = node.childNodes[i];
    if (this.isInputfield(n)  ||
        this.isButton(n)      ||
        this.isCheckbox(n)    ||
        this.isRadiobutton(n) ||
        this.isDropdown(n)
       )
    {
      return n;
    }
    else
    {
      if (n.childNodes.length > 0)
      {
        n = this.getInputFieldR(n);
        if (n != null)
        {
          return n;
        }
      }
    }
    i++;
  }
  return null;
}
// </its_tablecontrolManager::getInputFieldR>


/** <its_tablecontrolManager::headerMousedown>
  *
  *   process the click on a header cell
  *
  *   params:
  *     obj  - Object - the its_tablecontrolObject
  *     node - Object - the th tag/node to process
  */
its_tablecontrolManager.prototype.headerMousedown = function(obj, node)
{
  var columnNo = parseInt(node.getAttribute("columnno"), 10);
  var input = dom_getChildNodeByNodeName(node, "INPUT");
  var columnSelected = obj.selectedColumns[columnNo-1];
  // if the th tag contains an input tag, it is selectable
  if (input)
  {
    if (obj.columnSelectionType != "multiple" && !columnSelected)
    {
      this.setAllColumnsSelection(obj, false);
    }
    if (input.value == "")
    {
      // select column
      input.value = "X";
      select = true;
    }
    else if (input.value == "X")
    {
      // deselect column
      input.value = "";
      select = false;
    }
    this.updateColumnSelection(obj, columnNo, select);
    var bodyTable = this.getContainingBodyTable(obj, columnNo);
    var virtualColumnNo = this.getVirtualColumnNo(obj, columnNo);
    if (bodyTable && bodyTable.rows.length > 0 && virtualColumnNo >= 0)
    {
      var td = bodyTable.rows[0].cells[virtualColumnNo];
      var input = dom_getChildNodeByNodeName(td, "INPUT");
      if (td)
      {
        this.setCurrentCell(obj, td, true, false);
      }
    }
  }
  else if (node.className == "tcHeaderCustomize")
  {
    var customizable = node.getAttribute("customizable");
    if (customizable && customizable == 1)
    {
      raiseEvent(obj.name, "customize", "");
    }
  }
  else if (node.className == "tcHeaderRowSelector" &&
           obj.columnSelectionType == "multiple"
          )
  {
    // select/deselect all columns
    var i = 0;
    var select = false;
    // check if all columns are selected, if so, deselect all columns, otherwise
    // select all columns
    while (i < obj.selectedColumns.length)
    {
      if (obj.selectedColumns[i] == false)
      {
        // at least one column is not selected => select all columns
        select = true;
        break;
      }
      i++;
    }
    this.setAllColumnsSelection(obj, select);
  }
}
// </its_tablecontrolManager::headerMousedown>


/** <its_tablecontrolManager::rowSelectorMousedown>
  *
  *   process the click on a header cell
  *
  *   params:
  *     obj  - Object - the its_tablecontrolObject
  *     node - Object - the th tag/node to process
  */
its_tablecontrolManager.prototype.rowSelectorMousedown = function(obj, node)
{
  var tr = dom_getParentNodeByNodeName(node, "TR");
  var rowNo = parseInt(tr.getAttribute("rowno"), 10) - obj.firstVisibleRow + 1;
  var input = dom_getChildNodeByNodeName(node, "INPUT")
  var rowSelected = obj.selectedRows[node.parentNode.rowIndex];
  // if the th tag contains an input tag, it is selectable
  if (input)
  {
    if (obj.rowSelectionType != "multiple" && !rowSelected)
    {
      this.setAllRowsSelection(obj, false);
    }

    if (input.value == "")
    {
      // select column
      input.value = "X";
      select = true;
    }
    else if (input.value == "X")
    {
      // deselect column
      input.value = "";
      select = false;
    }
    this.updateRowSelection(obj, rowNo, select);
    var bodyTable = this.getContainingBodyTable(obj, 1);
    var virtualColumnNo = this.getVirtualColumnNo(obj, 1);
    if (bodyTable && bodyTable.rows.length >= rowNo && virtualColumnNo >= 0)
    {
      var td = bodyTable.rows[rowNo-1].cells[virtualColumnNo];
      return td;
    }
  }
}
// </its_tablecontrolManager::rowSelectorMousedown>


/** <its_tablecontrolManager::setAllRowsSelection>
  *
  *   select or deselect all rows
  *
  *   params:
  *     obj    - Object  - the its_tablecontrolObject
  *     select - Boolean - select (true) or deselect (false) all rows
  */
its_tablecontrolManager.prototype.setAllRowsSelection = function(obj, select)
{
  for (var i = 0; i < obj.selectedRows.length; i++)
  {
    if (obj.selectedRows[i] == !select)
    {
      if (obj.fixBodyTable)
      {
        var td = obj.fixBodyTable.rows[i].cells[0];
        if (td)
        {
          var input = dom_getChildNodeByNodeName(td, "INPUT");
          if (input)
          {
            input.value = (select? "X" : "");
            obj.selectedRows[i] = select;
            var rowNo = parseInt(td.getAttribute("rowno"), 10) -
                                 obj.firstVisibleRow + 1;
            this.updateRowSelection(obj, rowNo, select);
          }
        }
      }
    }
  }
}
// </its_tablecontrolManager::setAllRowsSelection>


/** <its_tablecontrolManager::setAllColumnsSelection>
  *
  *   select or deselect all columns
  *
  *   params:
  *     obj    - Object  - the its_tablecontrolObject
  *     select - Boolean - select (true) or deselect (false)
  */
its_tablecontrolManager.prototype.setAllColumnsSelection = function(obj, select)
{
  var node  = null;
  var input = null;
  var table = null;
  if (obj.fixHeaderTable)
  {
    table = obj.fixHeaderTable;
    for (var i = 0; i < table.rows[0].cells.length; i++)
    {
      node = table.rows[0].cells[i];
      input = dom_getChildNodeByNodeName(node, "INPUT")
      // if the th tag contains an input tag, it is selectable
      if (input)
      {
        input.value = (select? "X" : "");
      }
    }
  }
  if (obj.freeHeaderTable)
  {
    table = obj.freeHeaderTable;
    for (var i = 0; i < table.rows[0].cells.length; i++)
    {
      node = table.rows[0].cells[i];
      input = dom_getChildNodeByNodeName(node, "INPUT")
      // if the th tag contains an input tag, it is selectable
      if (input)
      {
        input.value = (select? "X" : "");
      }
    }
  }
  for (var i = 1; i <= obj.columns; i++)
  {
    this.updateColumnSelection(obj, i, select);
  }
}
// </its_tablecontrolManager::setAllColumnsSelection>


/** <its_tablecontrolManager::updateColumnSelection>
  *
  *   update the selection of a singel column
  *
  *   params:
  *     obj      - Object  - the its_tablecontrolObject
  *     columnNo - Number  - the number of the column to be updated
  *     select   - Boolean - select (true) or deselect (false)
  */
its_tablecontrolManager.prototype.updateColumnSelection = function(obj, columnNo, select)
{
  var headerTable     = this.getContainingHeaderTable(obj, columnNo);
  var bodyTable       = this.getContainingBodyTable(obj, columnNo);
  var virtualColumnNo = this.getVirtualColumnNo(obj, columnNo);

  obj.selectedColumns[columnNo-1] = select;

  // header
  var th = headerTable.rows[0].cells[virtualColumnNo];
  if (th)
  {
    if (select)
    {
      th.className = dom_addClass(th.className, "tcHeaderSelected");
    }
    else
    {
      th.className = dom_removeClass(th.className, "tcHeaderSelected");
    }
  }
  // body
  var td = new Array();
  for (var i = 0; i < bodyTable.rows.length; i++)
  {
    td.push(bodyTable.rows[i].cells[virtualColumnNo]);
  }
  if (select)
  {
    this.addClassNames(td, "tcBodySelected");
  }
  else
  {
    this.removeClassNames(td, "tcBodySelected");
  }
}
// </its_tablecontrolManager::updateColumnSelection>


/** <its_tablecontrolManager::updateRowSelection>
  *
  *   update the selection of a singel row
  *
  *   params:
  *     obj    - Object  - the its_tablecontrolObject
  *     rowNo  - Number  - the number of the row to be updated
  *     select - Boolean - select (true) or deselect (false)
  */
its_tablecontrolManager.prototype.updateRowSelection = function(obj, rowNo, select)
{
  obj.selectedRows[rowNo-1] = select;
  var td = null;

  if (select)
  {
    if (obj.fixBodyTable)
    {
      td = obj.fixBodyTable.rows[rowNo-1];
      td.className = dom_addClass(td.className, "tcBodySelected")
    }
    if (obj.freeBodyTable)
    {
      td = obj.freeBodyTable.rows[rowNo-1];
      td.className = dom_addClass(td.className, "tcBodySelected")
    }
  }
  else
  {
    if (obj.fixBodyTable)
    {
      td = obj.fixBodyTable.rows[rowNo-1];
      td.className = dom_removeClass(td.className, "tcBodySelected")
    }
    if (obj.freeBodyTable)
    {
      td = obj.freeBodyTable.rows[rowNo-1];
      td.className = dom_removeClass(td.className, "tcBodySelected")
    }
  }
}
// </its_tablecontrolManager::updateRowSelection>


/** <its_tablecontrolManager::addClassNames>
  *
  *  add the attribute className to all elements of the array of html objects
  *
  *   params:
  *     nodes     - Array  - the nodes to change the classname
  *     className - Strnig - the classname to add
  */
its_tablecontrolManager.prototype.addClassNames = function(nodes, className)
{
  var oldName = "";
  var newName = "";
  var i;
  for (i = 0; i < nodes.length; i++)
  {
    if (nodes[i].className != oldName)
    {
      oldName = nodes[i].className;
      newName = nodes[i].className = dom_addClass(nodes[i].className, className);
    }
    else
    {
      nodes[i].className = newName;
    }
  }
}
// </its_tablecontrolManager::addClassNames>


/** <its_tablecontrolManager::removeClassNames>
  *
  *  remove the attribute className from all elements of the array of html
  *  objects
  *
  *   params:
  *     nodes     - Array  - the nodes to change the classname
  *     className - Strnig - the the classname to add
  */
its_tablecontrolManager.prototype.removeClassNames = function(nodes, className)
{
  var oldName = "";
  var newName = "";
  var i;
  for (i = 0; i < nodes.length; i++)
  {
    if (nodes[i].className != oldName)
    {
      oldName = nodes[i].className;
      newName = nodes[i].className = dom_removeClass(nodes[i].className,
                                                    className);
    }
    else
    {
      nodes[i].className = newName;
    }
  }
}
// </its_tablecontrolManager::removeClassNames>


/** <its_tablecontrolManager::getContainingHeaderTable>
  *
  *   get the table (fix/free) that contains column columnNo
  *   params:
  *     obj      - Object - the its_tablecontrolObject
  *     columnNo - Number - the real number of the columns
  */
its_tablecontrolManager.prototype.getContainingHeaderTable = function(obj, columnNo)
{
  if (obj.fixColumns > 0)
  {
    if (columnNo <= obj.fixColumns)
    {
      return obj.fixHeaderTable;
    }
  }
  return obj.freeHeaderTable;
}
// </its_tablecontrolManager::getContainingHeaderTable>


/** <its_tablecontrolManager::getContainingBodyTable>
  *
  *   get the table (fix/free) that contains column columnNo
  *   params:
  *     obj      - Object - the its_tablecontrolObject
  *     columnNo - Number - the real number of the columns
  */
its_tablecontrolManager.prototype.getContainingBodyTable = function(obj, columnNo)
{
  if (obj.fixColumns > 0)
  {
    if (columnNo <= obj.fixColumns)
    {
      return obj.fixBodyTable;
    }
  }
  return obj.freeBodyTable;
}
// </its_tablecontrolManager::getContainingBodyTable>


/** <its_tablecontrolManager::displaySearchHelpButton>
  *
  *   display the searchhelp button on the appropriate position
  *   params:
  *     obj  - Object - the its_tablecontrolObject
  *     node - Object - the node the sh button is applied to
  */
its_tablecontrolManager.prototype.displaySearchHelpButton = function(obj, node)
{
  var top = 0;
  var left = 0;
  var parentNode = node;
  var name = node.getAttribute("iname");

  if (obj.searchHelpButton)
  {
    while (node != obj.container)
    {
      if (node.nodeType == DOM_NODE_TYPE_ELEMENT && node.nodeName == "TD")
      {
        if (node.className.indexOf("tcBody") == 0)
        {
          left += node.offsetWidth;
        }
        top += node.offsetTop;
        left += node.offsetLeft;
      }
      if (node.nodeName == "SPAN")
      {
        var l = parseInt(node.style.left, 10);
        if (l != NaN)
          left += l;
      }
      node = node.parentNode;
    }

    if (obj.titleContainer)
    {
      top += obj.titleContainer.offsetHeight;
    }
    obj.searchHelpButton.style.visibility = "visible";
    obj.searchHelpButton.style.top = top + 1;
    obj.searchHelpButton.style.left = left + 1;
    obj.searchHelpButton.setAttribute("name", name);
  }
}
// </its_tablecontrolManager::displaySearchHelpButton>


/** <its_tablecontrolManager::hideSearchHelpButton>
  *
  *   hide the searchhelp button
  *   params:
  *     obj      - Object - the its_tablecontrolObject
  */
its_tablecontrolManager.prototype.hideSearchHelpButton = function(obj)
{
  if (obj.searchHelpButton)
  {
    obj.searchHelpButton.style.visibility = "hidden";
  }
}
// </its_tablecontrolManager::hideSearchHelpButton>


/** <its_tablecontrolManager::renderInputField>
  *
  *   render an input field in the appropriate cell
  *   params:
  *     node - Object - the td object to render the input field
  */
its_tablecontrolManager.prototype.renderInputField = function(obj, node)
{
  var input = this.getInputFieldR(node);
  var iclass, itype, iname, ivalue, iivalue = "", imaxlength, itabindex, ialign,
      ivalueset, iselectedindex, idisabled;
  var selectedIndex = -1, i;

  if (!input)
  {
    if ((itype = node.getAttribute("itype")))
    {
      node.removeAttribute("itype");
    }
    iclass     = node.getAttribute("iclass");
    iname      = node.getAttribute("iname");
    ivalue     = node.getAttribute("ivalue");
    if (ivalue && ivalue.length > 0)
    {
      iivalue    = ivalue.replace(/\xA0/g, " ");
    }
    imaxlength = node.getAttribute("imaxlength");
    itabindex  = node.getAttribute("tabIndex");
    ialign     = node.getAttribute("ialign");

    if (itype == "text")
    {
      input = document.createElement("INPUT");
      input.setAttribute("type", itype);
    }
    input.className = iclass;
    input.setAttribute("name", iname);
    input.setAttribute("id", iname);
    input.setAttribute("value", iivalue);
    input.setAttribute("tabIndex", -1);
    input.style.textAlign = ialign;
    input.maxLength = imaxlength;
    input.style.width = node.offsetWidth - 1;
    node.innerHTML = "";
    node.appendChild(input);
  }
  return input;
}
// </its_tablecontrolManager::renderInputField>


/** <its_tablecontrolManager::getVirtualColumnNo>
  *
  *   get the virtual column number in consideration of the fix/free columns and
  *   the appropriate containers; the number is equivalent to the columns number
  *   in the html table object.
  *
  *   params:
  *     obj      - Object - the its_tablecontrolObject
  *     columnNo - Number - the real number of the columns
  */
its_tablecontrolManager.prototype.getVirtualColumnNo = function(obj, columnNo)
{
  if (obj.fixColumns > 0 && columnNo <= obj.fixColumns)
  {
    return columnNo - 1 + obj.rowSelector;
  }
  return columnNo - obj.fixColumns - 1;
}
// </its_tablecontrolManager::getVirtualColumnNo>


/** <its_tablecontrolManager::getParentCell>
  *
  *  Get the containing cell of an element
  *
  *   params:
  *     node - Object - the node to get the parent cell (td/th) from
  */
its_tablecontrolManager.prototype.getParentCell = function(node)
{
  var cell     = node;
  var maxDepth = 3;
  var depth    = 0;
  while (depth < maxDepth)
  {
    if (cell.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      if (cell.nodeName == "TH" || cell.nodeName == "TD")
      {
        return cell;
      }
      else
      {
        cell = cell.parentNode;
        depth++;
      }
    }
  }
  return null;
}
// </its_tablecontrolManager::getParentCell>


/** <its_tablecontrolManager::startColResize>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *   obj - Object       - the its_tablecontrolObject
  */
its_tablecontrolManager.prototype.startColResize = function(evt, obj)
{
  e = new its_event(evt);
  if (e)
  {
    var node = e.target;
    var th = node;
    while (th.nodeName != "TH")
    {
      th = th.parentNode;
    }
    its_tcMgr.cr = new its_columnResizeObject();
    its_tcMgr.cr.initialX         = e.pageX;
    its_tcMgr.cr.initialY         = e.pageY;
    its_tcMgr.cr.initialWidth     = th.offsetWidth;
    its_tcMgr.cr.controlName      = obj.name;
    its_tcMgr.cr.columnIndex      = th.getAttribute("columnno");

    its_tcMgr.cr.hTable = dom_getParentNodeByNodeName(th, "TABLE");
    its_tcMgr.cr.hTableIW = parseInt(its_tcMgr.cr.hTable.offsetWidth, 10);

    colgroup = dom_getChildNodeByNodeName(its_tcMgr.cr.hTable, "COLGROUP");
    its_tcMgr.cr.hCol = dom_getChildNodeByIndex(colgroup, th.cellIndex);
    its_tcMgr.cr.hColIW = parseInt(its_tcMgr.cr.hCol.offsetWidth, 10);

    its_tcMgr.cr.hDivText = dom_getChildNodeByNodeName(th, "DIV");
    its_tcMgr.cr.hDivTextIW = parseInt(its_tcMgr.cr.hDivText.offsetWidth, 10);

    if (its_tcMgr.cr.hTable == obj.fixHeaderTable)
    {
      its_tcMgr.cr.bTable = obj.fixBodyTable;
    }
    else if (its_tcMgr.cr.hTable == obj.freeHeaderTable)
    {
      its_tcMgr.cr.bTable = obj.freeBodyTable;
    }
    if (its_tcMgr.cr.bTable)
    {
      its_tcMgr.cr.bTableIW = its_tcMgr.cr.bTable.offsetWidth;

      colgroup = dom_getChildNodeByNodeName(its_tcMgr.cr.bTable, "COLGROUP");
      its_tcMgr.cr.bCol = dom_getChildNodeByIndex(colgroup, th.cellIndex);
      its_tcMgr.cr.bColIW = parseInt(its_tcMgr.cr.bCol.offsetWidth, 10);

      if (its_tcMgr.cr.hTable == obj.fixHeaderTable)
      {
        its_tcMgr.cr.hLayoutDiv = dom_getParentNodeByNodeName(its_tcMgr.cr.hTable, "DIV");
        its_tcMgr.cr.hLayoutDivIW = parseInt(its_tcMgr.cr.hLayoutDiv.offsetWidth, 10);

        its_tcMgr.cr.hLayoutTd = dom_getParentNodeByNodeName(its_tcMgr.cr.hLayoutDiv, "TD");
        its_tcMgr.cr.hLayoutTdIW = parseInt(its_tcMgr.cr.hLayoutTd.offsetWidth, 10);

        its_tcMgr.cr.gLayoutTable = dom_getParentNodeByNodeName(its_tcMgr.cr.hLayoutTd, "TABLE");
        its_tcMgr.cr.gLayoutTableIW = parseInt(its_tcMgr.cr.gLayoutTable.offsetWidth, 10);

        its_tcMgr.cr.bLayoutDiv = dom_getParentNodeByNodeName(its_tcMgr.cr.bTable, "DIV");
        its_tcMgr.cr.bLayoutDivIW = parseInt(its_tcMgr.cr.bLayoutDiv.offsetWidth, 10);

        its_tcMgr.cr.bLayoutTd = dom_getParentNodeByNodeName(its_tcMgr.cr.bLayoutDiv, "TD");
        its_tcMgr.cr.bLayoutTdIW = parseInt(its_tcMgr.cr.bLayoutTd.offsetWidth, 10);

        its_tcMgr.cr.bLayoutTable = dom_getParentNodeByNodeName(its_tcMgr.cr.bLayoutTd, "TABLE");;
        its_tcMgr.cr.bLayoutTableIW = parseInt(its_tcMgr.cr.bLayoutTable.offsetWidth, 10);
      }
    }
    document.onmousemove = its_tcMgr.colResize;
    document.onmouseup   = its_tcMgr.stopColResize;
    delete(e);
  }
}
// </its_tablecontrolManager::startColResize>

/** <its_tablecontrolManager::colResize>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_tablecontrolManager.prototype.colResize = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    its_tcMgr.cr.deltaX = e.pageX - its_tcMgr.cr.initialX;
    if ((its_tcMgr.cr.hColIW + its_tcMgr.cr.deltaX) < 30)
    {
      its_tcMgr.cr.deltaX = its_tcMgr.cr.hColIW * (-1) + 30;
    }
    its_tcMgr.cr.hCol.style.width = its_tcMgr.cr.hColIW + its_tcMgr.cr.deltaX;
    its_tcMgr.cr.hTable.style.width = its_tcMgr.cr.hTableIW + its_tcMgr.cr.deltaX;
    its_tcMgr.cr.hDivText.style.width = its_tcMgr.cr.hDivTextIW + its_tcMgr.cr.deltaX;
    if (its_tcMgr.cr.hLayoutDiv)
    {
      width = its_tcMgr.cr.hLayoutTdIW + its_tcMgr.cr.deltaX;
      if (width >= 0)
      {
        its_tcMgr.cr.hLayoutTd.style.width = its_tcMgr.cr.hLayoutTdIW + its_tcMgr.cr.deltaX;
      }
      width = its_tcMgr.cr.gLayoutTableIW + its_tcMgr.cr.deltaX;
      if (width >= 0)
      {
        its_tcMgr.cr.gLayoutTable.style.width = width;
      }
      width = its_tcMgr.cr.hLayoutDivIW + its_tcMgr.cr.deltaX;
      if (width >= 0)
      {
        its_tcMgr.cr.hLayoutDiv.style.width = width;
      }
    }
    width = its_tcMgr.cr.bTableIW + its_tcMgr.cr.deltaX;
    if (width >= 0)
    {
      its_tcMgr.cr.bTable.style.width = width;
    }
    width = its_tcMgr.cr.bColIW + its_tcMgr.cr.deltaX;
    if (width >= 0)
    {
      its_tcMgr.cr.bCol.style.width = width;
    }
    if (its_tcMgr.cr.bLayoutDiv)
    {
      its_tcMgr.cr.bLayoutTd.style.width = its_tcMgr.cr.bLayoutTdIW + its_tcMgr.cr.deltaX;
      its_tcMgr.cr.bLayoutDiv.style.width = its_tcMgr.cr.bLayoutDivIW + its_tcMgr.cr.deltaX;
    }
    e.cancel();
    delete(e);
  }
}
// </its_tablecontrolManager::colResize>

/** <its_tablecontrolManager::stopColResize>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_tablecontrolManager.prototype.stopColResize = function(evt)
{
  e = new its_event(evt)
  if (e)
  {
    e.cancel();
    document.onmousemove = null;
    document.onmouseup   = null;
    if (typeof its_tcMgr.cr.deltaX != "undefined" && its_tcMgr.cr.deltaX != 0)
    {
      var newWidth = ((its_tcMgr.cr.initialWidth + its_tcMgr.cr.deltaX) / 7);
      newWidth = (newWidth < 3)? 3 : newWidth;
      raiseEvent(its_tcMgr.cr.controlName,
                 "resizecol",
                 "colindex=" + its_tcMgr.cr.columnIndex +
                 "&" +
                 "width=" + newWidth
                );
    }
    delete(e);
  }
}
// </its_tablecontrolManager::stopColResize>



// instantiate the tablecontrol manager
if (its_tcMgr == null)
{
  its_tcMgr = new its_tablecontrolManager(null);
}



/** <its_tablecontrolObject>
  *
  *   cunstructor for the class its_tablecontrolObject
  *     its_tablecontrolObject is used to keep the data of a tablecontrol that
  *     is processed by its_tablecontrolManager.
  *
  *   params:
  *   name          - String  - name of the tablecontrol
  */
function its_tablecontrolObject(name,
                                firstVisibleRow,
                                lastVisibleRow,
                                rows,
                                columns,
                                fixColumns,
                                rowSelector,
                                rowSelectionType,
                                columnSelectionType)
{
  this.name                = name;
  this.firstVisibleRow     = firstVisibleRow;
  this.lastVisibleRow      = lastVisibleRow;
  this.rows                = rows;
  this.columns             = columns;
  this.fixColumns          = fixColumns;
  this.rowSelector         = rowSelector;
  this.rowSelectionType    = rowSelectionType;
  this.columnSelectionType = columnSelectionType;
  this.focusField          = "";
  this.selectedRows        = null;
  this.selectedColumns     = null;
  this.currentCell         = null;

  this.container           = null;
  this.titleContainer      = null;
  this.fixHeaderContainer  = null;
  this.freeHeaderContainer = null;
  this.fixBodyContainer    = null;
  this.freeBodyContainer   = null;
  this.fixHeaderTable      = null;
  this.freeHeaderTable     = null;
  this.fixBodyTable        = null;
  this.freeBodyTable       = null;
  this.searchHelpButton    = null;
}

its_tablecontrolObject.prototype.setSelectedRows = function(selectedRows)
{
  this.selectedRows = selectedRows;
}


its_tablecontrolObject.prototype.setSelectedColumns = function(selectedColumns)
{
  this.selectedColumns = selectedColumns;
}

/** <its_columnResizeObject>
  *
  *   cunstructor for the class its_columnResizeObject
  *     its_columnResizeObject is used to keep the data of a resize event that
  *     is processed by its_tablecontrolManager.
  *
  *   params:
  */
function its_columnResizeObject()
{
  this.initialX         = 0;
  this.initialY         = 0;
  this.initialWidth     = 0;
  this.controlName      = null;
  this.columnIndex      = 0;
  this.slider           = null;

  // the following vars hold the elements and their resize data while dragging
  // the colresizer:
  // abbreviations:
  // g = entire grid
  // h = header
  // b = body
  // IW = initial width
  this.hTable           = null;
  this.hTableIW         = 0;
  this.hCol             = null;
  this.hColIW           = 0;
  this.hDivText         = null;
  this.hDivTextIW       = 0;
  this.hLayoutTd        = null;
  this.hLayoutTdIW      = 0;
  this.gLayoutTable     = null;
  this.gLayoutTableIW   = 0;
  this.hLayoutDiv       = null;
  this.hLayoutDivIW     = 0;
  this.bTable           = null;
  this.bTableIW         = 0;
  this.bCol             = null;
  this.bColIW           = 0;
  this.bLayoutTd        = null;
  this.bLayoutTdIW      = 0;
  this.bLayoutTable     = null;
  this.bLayoutTableIW   = 0;
  this.bLayoutDiv       = null;
  this.bLayoutDivIW     = 0;
  this.deltaX           = 0;
  this.deltaY           = 0;
}
