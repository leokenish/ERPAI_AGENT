function webguiDialogboxResized( in_objResizePopup, in_popup )
{
  var obj = in_objResizePopup,
      f, id,
      dim, sdim,
      input, form,
      popup;

  if (null != obj)
  {
    f   = obj.GetPopupFrame();
    dim = obj.GetSize();
    if (null != f && null != (id = f.getAttribute("dialogbox")) )
    {
      id   = id + "-ResizedDim";
      sdim = dim.width + ":" + dim.height;

      if (null == (input = document.getElementById(id)) )
      {
        if (null != (form = document.getElementById("webguiform")) )
        {
          // create input field
          if (null != document.all)
          {
            input = document.createElement('<input type="hidden" '
                                           + 'id="' + id + '" name="' + id + '" '
                                           + 'value="' + sdim + '">'
                                          );
          }
          else
          {
            input = document.createElement("input");
            input.setAttribute("type",  "hidden");
            input.setAttribute("id",    id);
            input.setAttribute("name",  id);
            input.setAttribute("value", sdim);
          }
          input = form.appendChild(input);
        }
      } // if (input)
      else
      {
        input.value = sdim;
      }

      /* ... and now inside the popup
       */
      if (true != in_popup)
      {
        if (null != (popup = f.contentWindow))
        {
          if (popup.webguiDialogboxResized)
           popup.webguiDialogboxResized(in_objResizePopup, true);
        }
      }
    } // if (form && id)
  } // if (obj)
}
