// =======================================================================================
// SAP_TerminateInterface.js
// -------------------------
// SAP terminate interface
//

// --------------------------------------------------------------------------------------
// SAP_TerminateInterface() - INTERFACE
// ------------------------------------
// declares the SAP Terminate Interface 
//
function SAP_TerminateInterface_isOk() {
    return true;
}

var SAP_TerminateInterface = {
    id:             "SAP_TerminateInterface",
    isOk:           SAP_TerminateInterface_isOk,
    terminate:      SAPWF_fnop
}
// --------------------------------------------------------------------------------------

// =======================================================================================


