// ==========================================================
// Searchhelp Button
// ==========================================================


/*
 * Central searchhelp button "manager"
 */

if ("undefined" == typeof window.webguiShButtonManager)
{
  var webguiShButtonManager = {

    // PUBLIC

    New : function ( in_uniqueId, in_methodOnBlur, in_methodParm1, in_methodParm2 )
    {
      var rv = null,
          obj;

      if (null != in_uniqueId && null != in_methodOnBlur)
      {
        obj = this._arrObj[in_uniqueId] = {
          _method : in_methodOnBlur,
          _parm1  : in_methodParm1,
          _parm2  : in_methodParm2
        };
      }

      return rv;
    },    // webguiShButtonManager.NewShButton()

    Update : function ( in_uniqueId, in_methodParm1, in_methodParm2 )
    {
      var oldSh = this._currentSh;

      this._currentSh = (null != in_uniqueId) ? this._arrObj[in_uniqueId] : null;

      if (null != oldSh)
      {
        oldSh._method(oldSh._parm1, oldSh._parm2);
      }
      if (null != this._currentSh)
      {
        if (null != in_methodParm1) this._currentSh._parm1 = in_methodParm1;
        if (null != in_methodParm2) this._currentSh._parm2 = in_methodParm2;
      }
    },    // webguiShButtonManager.Update()

    // "Protected"

    Init : function ()
    {
    },    // webguiShButtonManager._Init()


    // PRIVATE

    _arrObj    : {},
    _currentSh : null,

    _BlurOldShButton : function ()
    {

    }    // webguiShButtonManager._BlurOldSHManager()

  }; // webguiShButtonManager

  window.webguiShButtonManager.Init();
}




/*
 * Dynpro searchhelp button
 */

function webguiGetSearchhelpButtonHTML ( fieldname, ondynpro )
{
  var styleDef, html;

  styleDef = "width:17px;height:17px;margin:-1px;border-width:0;padding:0;-moz-box-sizing:border-box;";
  html = ['<div style="overflow:hidden;width:15px;height:15px;">',
          '<img src="', webguiMimeURL, '/webgui/'+webguiTheme+'/images/buttons/tanicon.gif" ',
          'style="', styleDef, '" ',
          'onmouseout="status=\' \';"\ onmouseover="status=\'?\';"\ onclick="javascript:webguiRaiseSearchhelp(\'', fieldname, '\');" ',
          '/></div>'].join("");
/*
  styleDef = (null != ondynpro)? "width:19;height:19" : "width:17;height:17";
  html = '<img src="' + webguiMimeURL + '/webgui/'+webguiTheme+'/images/buttons/tanicon.gif" style="' + styleDef  + '"\
                   onmouseout="status=\' \';"\ onmouseover="status=\'?\';"\ onclick="javascript:webguiRaiseSearchhelp(\'' + fieldname + '\')">';
*/
  return (html);

} // webguiGetSearchhelpButtonHTML()


function DisableSearchHelpButton( in_elem )
{
  var el = (null != in_elem) ? in_elem : (null != (el = document.getElementById("webguiSearchHelpButton")) ? el : webguiSearchhelpButton);
  if (null != el)
  {
    if (null != webguiSearchhelpButton)
    {
      webguiSearchhelpButton.style.visibility = "hidden";
      webguiSearchhelpButton = null;
    }
    el.innerHTML = "";
  }
} // DisableSearchHelpButton()


function EnableSearchHelpButton ( fieldname, e, selectedElement )
{
  var topPos = 0, leftPos = 0,
      vParent, parentToFind,
      TSDivHandle, ContainerHandle,
      sh_button,
      isFlip = false,
      imgobj,
      isRTL = isBidiRTL(),
      w,
      offset = 0;

  ContainerHandle = webguiGetContainer(selectedElement);
  vParent = selectedElement;

  if (null != ContainerHandle)
  {
    var ContainerHandleAll = ContainerHandle.all ? ContainerHandle.all : ContainerHandle.getElementsByTagName('*');
    if (ContainerHandle.getAttribute("cn") == "webguicontainer")
    {
      sh_button = ContainerHandleAll["webguiConSHButton" + ContainerHandle.getAttribute("sh_id")];
    }
    else if (ContainerHandle.className && ContainerHandle.className == "webguiTSDiv")
    {
      sh_button = ContainerHandleAll["webguiTSSHButton-" + ContainerHandle.getAttribute("id")];
    }
  }
  else
  {
    sh_button = document.getElementById("webguiSearchHelpButton");
  }

  if (null != sh_button)
  {
    webguiShButtonManager.Update("webguiSearchHelpButton", sh_button);

    sh_button.style.left = "33px";        // we want to avoid scrollbars on first display
    sh_button.style.top  = "80px";
    sh_button.style.display = "block";
    sh_button.innerHTML = webguiGetSearchhelpButtonHTML(fieldname) ;

    parentToFind = (null != ContainerHandle) ? ContainerHandle : ((null != TSDivHandle) ? TSDivHandle : webguiDynpro);
    topPos  = wgu_getAbsolutePosition(selectedElement, parentToFind);
    leftPos = topPos.x + (isRTL ? -sh_button.offsetWidth : selectedElement.offsetWidth);
    topPos  = topPos.y;

    if (!!selectedElement.ct && selectedElement.ct == "ifield")
    {
      sh_button.innerHTML = webguiGetSearchhelpButtonHTML(fieldname, true) ;
    }
    else
    {
      sh_button.innerHTML = webguiGetSearchhelpButtonHTML(fieldname) ;
    }

    if (null != ContainerHandle)
    {
      if ( (leftPos + sh_button.offsetWidth > ContainerHandle.offsetWidth)
          && (selectedElement.offsetWidth >= (sh_button.offsetWidth * 2))
          && (fieldname && fieldname.indexOf("DDSHSELOPT-LOW") < 0)
          && (ContainerHandle.offsetWidth > 0)
          && (!!(ContainerHandle.parentNode) && (ContainerHandle.offsetWidth + ContainerHandle.offsetLeft + 16 > ContainerHandle.parentNode.offsetWidth))
         )
      { // Note 0528489
        if (sh_button.hasChildNodes())
        {
          leftPos += (isRTL) ? sh_button.offsetWidth : -sh_button.offsetWidth;
          isFlip = true;
        }
      }
    }

    // flip the SH button image?
    if (isFlip ? !isRTL : isRTL)  // XOR
    {
      imgobj = sh_button.firstChild;
      imgobj.setAttribute("src", webguiMimeURL + "/webgui/"+webguiTheme+"/images/buttons/tanicon_flipped.gif");
    }

    sh_button.style.left       = leftPos + "px";
    sh_button.style.top        = topPos  + "px";
    sh_button.style.visibility = "visible" ;

    webguiSearchhelpButton = sh_button;
  }
} // EnableSearchHelpButton()


function webguiEnableSearchhelpButton ( fieldname, e )
{
  var selectedElement;

  if (!e)
  {
    if (!!event)
      e = event;
    else
      e= window.Event;
  }

  //crossbrowser
  if (e.srcElement) { selectedElement = e.srcElement;}
  else if (e.target){ selectedElement = e.target;}

  if (null != selectedElement && null != selectedElement.getAttribute("sh"))
  {
    EnableSearchHelpButton(fieldname, e, selectedElement);
  }
} // webguiEnableSearchhelpButton


if ("undefined" == typeof webguiInitSearchHelpButton)
{
  (webguiInitSearchHelpButton = function ()
  {
    webguiShButtonManager.New("webguiSearchHelpButton", DisableSearchHelpButton, null, null);
  })();
}
