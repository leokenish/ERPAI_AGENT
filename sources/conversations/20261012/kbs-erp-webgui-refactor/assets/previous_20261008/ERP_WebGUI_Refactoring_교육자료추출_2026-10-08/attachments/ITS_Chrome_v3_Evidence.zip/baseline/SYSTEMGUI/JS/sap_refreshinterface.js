// =======================================================================================
// SAP_RefreshInterface.js
// -----------------------
// SAP refresh interface
//

// --------------------------------------------------------------------------------------
// SAP_RefreshInterface() - INTERFACE
// -----------------------------------
// declares the Refresh Interface
//
function SAP_RefreshInterface_refresh() {
	navigate( SAP_wgateUrl( { '~event': 'onLoad' } ) );
}

function SAP_RefreshInterface_setInterval( sec ) {
	if (sec > 0) {
		this.interval = sec * 1000;
	}
	this.setAutomation( this.getAutomation() );
}

function SAP_RefreshInterface_getInterval() {
	return this.interval / 1000;	
}

function SAP_RefreshInterface_getAutomation() {
	return (this.timer != null);
}

function SAP_RefreshInterface_setAutomation( status ) {
	clearInterval( this.timer );
	this.timer = null;
	
	if (status && this.interval) {
		this.timer = setInterval( "SAPWF_getInterface( 'SAP_RefreshInterface' ).refresh(); ", this.interval )
	}
}

var SAP_RefreshInterface = {
    id:             "SAP_RefreshInterface",
    interval:       0,
    timer:          null,
    
    refresh:		SAP_RefreshInterface_refresh,
	setInterval:	SAP_RefreshInterface_setInterval,
	getInterval:	SAP_RefreshInterface_getInterval,
	getAutomation:	SAP_RefreshInterface_getAutomation,
	setAutomation:	SAP_RefreshInterface_setAutomation
}
// --------------------------------------------------------------------------------------

// =======================================================================================


