//<HTML><SCRIPT>
// =======================================================================================
// SAPWebFramework.js
// ------------------
// web framework core libraray
//
var SAPWF_gcVersion         =   "4.6d/02";  // SP2
var SAPWF_gcVersionNumber   =   "46402";    // 46 -> Version 4.6, 4 -> d, 02 -> SP2

// --------------------------------------------------------------------------------------
// deprecated SAPWF_cacheImages()
// ------------------------------
// provides browser image caching 
//
// NEEDS:		String		path		directory relative to wwwroot
//				String[]	imageArr	Array of gif-image-names including .gif or .jpg ...
//
// RETURNS:		nothing
//
function SAP_cacheImages( path, imageArr ) { return SAPWF_cacheImages( path, imageArr ); } 
function SAPWF_cacheImages( path, imageArr ) {
	with (SAPWF_cacheImages) {
		var liLength = path.length;
		if ( (liLength > 0) && (path.charAt( liLength - 1 ) != "/") ) path += "/";
		for (img in imageArr) {
			imageCache[img]		= new Image();
			imageCache[img].src = path + imageArr[img];
		}
	}
}
SAPWF_cacheImages.imageCache = new Array();
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_getAncestor()
// ---------------------------
// internal function - do not use
//
// NEEDS:		nothing
//
// RETURNS:									opener OR parent OR window.self
//	
function SAP_getAncestor() { return SAPWF_getAncestor() }
function SAPWF_getAncestor() {
	if (SAPWF_isInternetExplorer())
  	{
	return (typeof( opener ) == "object")? opener: parent; 
}
	else
	{
		return ( opener == null)?  parent: opener; 
	}
	
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_Enumeration() - CONSTRUCTOR
// -----------------------------------------
// creates an enumeration object from a given array (index- or assoc-array)
//
// NEEDS:		Array		array			index- or associative-array
//
// RETURNS:		Object						enumeration object has two public 
//											methods:
//											* hasMoreElements(): 
//												returns true, if the enum has more elements
//											* nextElement():
//												returns the next element of the enum - 
//												skips null references of the original array
//				
function SAP_Enummeration( assocArray ) { return new SAPWF_Enumeration( assocArray ) }
function SAPWF_Enumeration( assocArray ) {
	var li;
	var loEntry;
		
	this.elements			= new Array();
	this.pos				= 0;
	for (li in assocArray) {
		if ( (loEntry = assocArray[li]) != null) {
			this.elements[this.elements.length] = loEntry;
		}
	}		
}
new SAPWF_Enumeration(); // netscape needs this!!!
SAPWF_Enumeration.prototype.hasMoreElements = SAPWF_Enumeration_hasMoreElements;
SAPWF_Enumeration.prototype.nextElement     = SAPWF_Enumeration_nextElement;
function SAPWF_Enumeration_hasMoreElements() {
	return (this.pos < this.elements.length);
}
function SAPWF_Enumeration_nextElement() {
	return this.elements[this.pos++];	
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_Repository() - CONSTRUCTOR
// ----------------------------------------
// stores names to reference relations in an associative manner
//
// NEEDS:		nothing
//
// RETURNS:		Object						
//											
function SAP_Repository() { return new SAPWF_Repository() }
function SAPWF_Repository() {
	// private member vars 
	this.length			= 0;
	this.entries		= new Array();
}
new SAPWF_Repository(); // netscape needs this!!!
SAPWF_Repository.prototype.getLength    = SAPWF_Repository_getLength;		
SAPWF_Repository.prototype.register     = SAPWF_Repository_register;		
SAPWF_Repository.prototype.unregister	= SAPWF_Repository_unregister;
SAPWF_Repository.prototype.query		= SAPWF_Repository_query;
SAPWF_Repository.prototype.elements		= SAPWF_Repository_elements;
SAPWF_Repository.prototype.keys		    = SAPWF_Repository_keys;
SAPWF_Repository.prototype.getElements	= SAPWF_Repository_getElements;
SAPWF_Repository.prototype.getKeys		= SAPWF_Repository_getKeys;

function SAPWF_Repository_getLength() {
	return this.length;
}
		
function SAPWF_Repository_register( id, ref ) {
	var loResult = null;
	if (this.entries[id] == null) {
		this.entries[id] = ref;
		this.length++;
		loResult = ref;
	} else {
		alert("Error: You have chosen the ID '" + id + "' multiple times. Choose unique IDs!");
		loResult = null;
	}
	return loResult;
}
		
function SAPWF_Repository_unregister( id ) {
	if (this.entries[id] != null) {
		this.entries[id] = null;
		delete this.entries[id];
		this.length--;
	}
}

function SAPWF_Repository_query( id ) {
	return this.entries[id];
}
		
function SAPWF_Repository_elements() {
	return new SAPWF_Enumeration( this.entries );
}

function SAPWF_Repository_keys() {
    return new SAPWF_Enumeration( this.getKeys() );
}

function SAPWF_Repository_getElements() {
    return this.entries;
}

function SAPWF_Repository_getKeys() {
    var li;
    var laKeys = [];
	for (li in this.entries) {
		laKeys[laKeys.length] = li;
	}		
	return laKeys;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_Stack() - CONSTRUCTOR
// -----------------------------------
// it's simple a stack
//
// NEEDS:		noting
//
// RETURNS:		                            empty stack object
function SAPWF_Stack() {
    // constructor
    this.stack = new Array();
    this.TOS   = -1;
}

function SAPWF_Stack_push( obj ) {
    ++this.TOS;
    this.stack[this.TOS] = obj;
}

function SAPWF_Stack_pop() {
    if (this.TOS < 0) 
      return null;
    var obj = this.stack[this.TOS];
    this.stack[this.TOS] = null;
    --this.TOS;
    return obj;
}
        
function SAPWF_Stack_top() {
    if ( this.TOS < 0 ) 
      return null;
    return this.stack[this.TOS];
}
  
function SAPWF_Stack_getLength() {
    return this.TOS + 1;
}

function SAPWF_Stack_isEmpty() {
    return this.TOS < 0;
}

function SAPWF_Stack_item( i ) {
    if ( i < 0 || i > this.TOS ) 
      return null;
    return this.stack[i];
}

SAPWF_Stack.prototype.push	    = SAPWF_Stack_push;
SAPWF_Stack.prototype.pop 	    = SAPWF_Stack_pop;
SAPWF_Stack.prototype.top	      = SAPWF_Stack_top;
SAPWF_Stack.prototype.item      = SAPWF_Stack_item;
SAPWF_Stack.prototype.isEmpty   = SAPWF_Stack_isEmpty;
SAPWF_Stack.prototype.getLength	= SAPWF_Stack_getLength;

// --------------------------------------------------------------------------------------

// ---------------------------------------------------------- 
// private SAPWF_Queue() - CONSTRUCTOR
// -----------------------------------
// A general queue for objects or values.
// Simple Q that just has a 'first used' (next read) index in an array
// and deletes the whole array when the Q is empty (start over).
//
// NEEDS:		noting
//
// RETURNS:		                            empty queue object
//
function SAPWF_Queue() {
    this.queue = new Array();
    this.firstUsed = 0;           
}

function SAPWF_Queue_add(item) {
    var ql = this.queue.length;
    this.queue[ql] = item;
}

function SAPWF_Queue_remove() {
    var ql = this.queue.length;
    if ( this.firstUsed >= ql ) 
      return null;
    var res = this.queue[this.firstUsed];
    
    ++this.firstUsed;
    if ( this.firstUsed >= ql ) {
      this.queue = new Array();       
      this.firstUsed = 0;    
    }
    return res;
}

SAPWF_Queue.prototype.add     = SAPWF_Queue_add;
SAPWF_Queue.prototype.remove  = SAPWF_Queue_remove;
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_bindPageToOrigin()
// --------------------------------
// binds this page to its origin (i.e domain or hostname it was loaded from )
// lsDomain can be null for IP address; ignore then (pure webgui apps)
// 
// NEEDS:		noting
//
// RETURNS:		nothing
//			

function SAP_bindPageToDomain() { return SAPWF_bindPageToOrigin() }	
function SAPWF_bindPageToOrigin() {
  // Keep all three domain entry points consistent in modern Chrome.
  if (window.originAgentCluster === true) return;
  var ipaddrexpr = /^\d+\.\d+\.\d+\.\d+/;
  var bo = ipaddrexpr.test( window.location.hostname);
  if (!bo) {
    var lsDomain = SAPWF_parseServer( location.hostname ).domain;
    if (lsDomain != null && lsDomain != "") {
      document.domain = lsDomain;
    }
  }
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_bindPageToService()
// ---------------------------------
// binds this page to a specific service and creates a service object
//
// NEEDS:		String		serviceName		name of the service the page is binded to
//              String      serviceInstance instance id of the service
//
// RETURNS:		nothing
//				
function SAP_bindPageToService( serviceName, serviceInstance ) { return SAPWF_bindPageToService( serviceName, serviceInstance ) }
function SAPWF_bindPageToService( serviceName, serviceInstance ) {
	window.SAPWF_serviceName	    = serviceName;
	window.SAPWF_serviceInstance    = serviceInstance;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_getAllAncestorServices()
// --------------------------------------
// returns an array of all ancestors
//
// NEEDS:		noting
//
// RETURNS:		Array                       list of all ancestors of this services
//		
function SAPWF__getAllAncestorServices() {
    var laResult    = new Array();
    var lwService   = window;
    var lwAncestor  = SAPWF_getAncestorService();
    
    while (lwAncestor != lwService) {
        laResult[laResult.length] = lwAncestor;
        lwService   = lwAncestor;
        lwAncestor  = lwService.SAPWF_getAncestorService();
    }
    return laResult;
}	
function SAPWF_getAllAncestorServices() {
	return SAPWF_getServiceRootPage().SAPWF__getAllAncestorServices();
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_getObjectRepository()
// -----------------------------------
// returns the object repository stored in this page
//
// NEEDS:		nothing
//
// RETURNS:		Object						the object rep. for this page
//										
function SAP_getObjectRepository() { return SAPWF_getObjectRepository() }	
function SAPWF_getObjectRepository() {
	with (SAPWF_getObjectRepository) {
		if (objRep == null) {
			objRep = new SAPWF_Repository();
		}
		return objRep;
	}
}
SAPWF_getObjectRepository.objRep = null;
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_registerObject()
// ------------------------------
// registers an object in the per page object repository
//
// NEEDS:		String		id				object's id (must be unique)
//
// RETURNS:		Object						reference to the object
//	
function SAP_registerObject( id ) { return SAPWF_registerObject( id ) }
function SAPWF_registerObject( id ) {
    // TODO: Netscape implementation
	var loRef;
	if( document.all ) loRef = document.all[id];
	else loRef = document.getElementById( id );	
	SAPWF_getObjectRepository().register( id, loRef );
	return loRef;	
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_registerObjectByRef()
// -----------------------------------
// registers an object given by <ref> in the per page object repository under the given <id>
//
// NEEDS:		String		id				object's id (must be unique)
// 		        String		ref				reference to the object
//
// RETURNS:		Object						reference to the object
//	
function SAPWF_registerObjectByRef( id, ref ) {
	SAPWF_getObjectRepository().register( id, ref );
	return ref;	
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_unregisterObject()
// --------------------------------
// unregisters an object in the per page object repository
//
// NEEDS:		String 		id				object's id (must be unique)
//
// RETURNS:		nothing
//	
function SAP_unregisterObject( is ) { return SAPWF_unregisterObject( is ) }
function SAPWF_unregisterObject( is ) {
	SAPWF_getObjectRepository().unregister( id );
}			
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_queryInterfaceInside()
// ------------------------------------
// searches inside the direct children and 
// returns an interface object (non determ.) with the given id
//
// NEEDS:		String		id				interface id, must be unique inside the service
//
// RETURNS:		Object						interface object OR null
//	
function SAP_queryInterfaceInside( id ) { return SAPWF_queryInterfaceInside( id ) }
function SAPWF_queryInterfaceInside( id ) {
	var laServices	= SAPWF_getChildServices();
	var li			= 0;
	var loResult	= null;
	var loIntf		= null;
		
	while ( (li < laServices.length) && (loResult == null) ) {
		loResult = laServices[li++].SAPWF_getInterface( id );
	}
	return loResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_queryAllInterfacesInside()
// ----------------------------------------
// returns a collection of interfaces implemented by my direct child services
//
// NEEDS:		String		id				interface id, must be unique inside the service
//
// RETURNS:		Array						list of all interfaces with the given id 
//	
function SAP_queryAllInterfacesInside( id ) { return SAPWF_queryAllInterfacesInside( id ) }
function SAPWF_queryAllInterfacesInside( id ) {
	var laServices	= SAPWF_getChildServices();
	var li			= 0;
	var laResult	= new Array();
	var loIntf		= null;
		
	for (li = 0; li < laServices.length; li++) {
		if ( (loIntf = laServices[li].SAPWF_getInterface( id ) ) != null) {
			laResult[laResult.length] = loIntf;
		}
	}
	return laResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_queryInterfaceOutside()
// -------------------------------------
// searches my ancestors for an interface with the given id
//
// NEEDS:		String		id				interface id 
//
// RETURNS:		Object						reference to an interface object OR null
//	
function SAPWF__queryInterfaceOutside( id ) {
	var lwAncestorSrvc	= null;
	var loResult		= null;
		
	if ( (loResult = SAPWF_getInterface( id ) ) == null) {
		lwAncestorSrvc	= SAPWF_getAncestorService();	
		if (lwAncestorSrvc != window) {
			loResult = lwAncestorSrvc.SAPWF__queryInterfaceOutside( id );
		} 
	} 
	return loResult;
}
function SAP_queryInterfaceOutside( id ) { return SAPWF_queryInterfaceOutside( id ) }
function SAPWF_queryInterfaceOutside( id ) {
	return SAPWF_getAncestorService().SAPWF__queryInterfaceOutside( id );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_queryAllInterfacesOutside()
// -----------------------------------------
// searches my ancestors for interfaces with the given id
//
// NEEDS:		String		id				interface id 
//
// RETURNS:		Array						list of all interfaces with the given id 
//	
function SAPWF__queryAllInterfacesOutside( id, intfList ) {
	var lwAncestorSrvc	= SAPWF_getAncestorService();		
	var loIntf			= null;

	if ( (loIntf = SAPWF_getInterface( id ) ) != null) {
		intfList[intfList.length] = loIntf;				
	}
	if (lwAncestorSrvc != window) {
		intfList = lwAncestorSrvc.SAPWF__queryAllInterfacesOutside( id, itfList );
	}
	return intfList;
}
function SAP_queryAllInterfacesOutside( id ) { return SAPWF_queryAllInterfacesOutside( id ) }
function SAPWF_queryAllInterfacesOutside( id ) {
	return SAPWF_getAncestorService().SAPWF__queryAllInterfacesOutside( id, new Array() );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_raiseEvent()
// --------------------------
// raises the given event
//
// NEEDS:		String      id              event id
//              Object      data            event specific data object
//
// RETURNS:		Object                      event object, if a handler was found, 
//                                          null otherwise
//                                          the event object contains the following attributes:
//                                           type:          the type of the event - 
//                                                          e.g: 'SAPWF_LaunchEvent'
//                                           scrService:    reference to the service which raised
//                                                          the event
//                                           cancleBubble:  event handlers set this to 'true', if 
//                                                          they want to cancle the event bubbling
//                                           returnValue:   false <=> cancles default event behaviour
//                                           data:          event producer can pass an additional data
//                                                          object to the handlers
//                                           result:        event handlers can pass result values to the
//                                                          event producer
function SAPWF_raiseEvent( id, data ) {
    function findObjectInService( service, obj ) {
        var loResult    = null;
        var laPages     = service.SAPWF_getRelatedPages();
        
        for (var i=0; (i < laPages.length) && (loResult == null); i++) {
            loResult = laPages[i][obj];
        }
        return loResult;
    }
    var loResult    = null;
    var laService   = SAPWF_getAllAncestorServices();
    var lsMethod    = id + "_handler";
    var lbDoBubble  = true;
    var loHandler   = null;
    var loEvtObj    = { type:           id, 
                        scrService:     SAPWF_getServiceInstance(),
                        scrFrame:       SAPWF_getServiceRootPage(),
                        cancleBubble:   false,
                        returnValue:    true,
                        data:           data,
                        result:         null
                      };
    
    for (var i = 0; (i < laService.length) && lbDoBubble; i++) {
        if ( null != (loHandler = findObjectInService( laService[i], lsMethod ) ) ) {
            loHandler( loEvtObj );
            lbDoBubble  = ! loEvtObj.cancleBubble;
            loResult    = loEvtObj;
        }
    }
    return loResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_subscribeEvent()
// ------------------------------
//
// NEEDS:		Object		producer		object that raises the event
//				String		name			name of the event
//				Function	fPtr			call back function
//
// RETURNS:		nothing
//	
function SAP_subscribeEvent( producer, name, fPtr ) { return SAPWF_subscribeEvent( producer, name, fPtr ) }
function SAPWF_subscribeEvent( producer, name, fPtr ) {
    producer["SAPWF_EVENT_" + name]=fPtr;	
}

// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_unsubscribeEvent()
// --------------------------------
//
// NEEDS:		Object		producer		object that raises the event
//				String		name			name of the event to unsubscribe
//
// RETURNS:		nothing
//	
function SAP_unsubscribeEvent( producer, name ) { return SAPWF_unsubscribeEvent( producer, name ) }
function SAPWF_unsubscribeEvent( producer, name ) {
    producer["SAPWF_EVENT_" + name]=new Function(";");	
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// private SAPWF_fnop()
// --------------------
// function which does exactly nothing - for internal use only
//
// NEEDS:		nothing
//
// RETURNS:		nothing
//
function SAPWF_fnop() {}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getNowSeconds()
// ----------------------------
// returns the current time in seconds (seconds since 1970...)
//
// NEEDS:		nothing
//
// RETURNS:		Number              current browser time in seconds
//
function SAPWF_getNowSecs() {
    return Math.round( (new Date()).valueOf() / 1000 );
}    
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getVersion()
// -------------------------
// returns the SWF's version
//
// NEEDS:		nothing
//
// RETURNS:		nothing
//
function SAPWF_getVersion() {
    return SAPWF_gcVersion;    
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getUserAgentVersion()
// ----------------------------------
// returns user agent type and version
//
// NEEDS:		noting
//
// RETURNS:		Object                      object containing user agent type and version:
//                                              agentType:      (string) "IE" for Microsoft Internet Explorer
//                                                                       "NN" for Netscape Navigator
//                                              agentVersion:   (number) user agent version (e.g: 4, 5.0, 6, ...)
//			
function SAPWF_getUserAgentVersion() {
    //var laMatch = navigator.userAgent.match( /(Netscape|MSIE )([\d|\.]*)/ );
	//tj/2003-07-17/ what do we do with Mozilla?
	var laMatch = navigator.userAgent.match( /(Netscape|Gecko|MSIE )([\d|\.|\/]*)/);
  
    if (laMatch.length==3) {
        var lsAgentType = "unknown";
        switch (laMatch[1]) {
            case "MSIE ":       lsAgentType = "IE";
                                break;
            case "Netscape":
			case "Gecko"   :    lsAgentType = "NN"; 
                                break;
        }                                                               
        return { agentType: lsAgentType, agentVersion: parseFloat( laMatch[2] ) };
    } else {
        return { agentType: "unknown", agentVersion: "0" };
    }
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_isInternetExplorer()
// ---------------------------------
// returns true <=> user agent is MSIE
//
// NEEDS:		noting
//
// RETURNS:		Boolean                     true <=> user agent is MSIE
//			
function SAPWF_isInternetExplorer() {
    return SAPWF_getUserAgentVersion().agentType == "IE";
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_isNetscapeNavigator()
// ----------------------------------
// returns true <=> user agent is NN
//
// NEEDS:		noting
//
// RETURNS:		Boolean                     true <=> user agent is NN
//			
function SAPWF_isNetscapeNavigator() {
    return SAPWF_getUserAgentVersion().agentType == "NN";
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_isPageScriptable()
// -------------------------------
// returns true <=> the page is scriptable from this page 
//
// NEEDS:		Window		page			foreign page to test
//
// RETURNS:		Boolean						true => page is scriptable
//				
function SAP_isPageScriptable( page ) { return SAPWF_isPageScriptable( page ) }
function SAPWF_isPageScriptable( page ) {
  
  if (page == null) return false;
  var lsType = typeof( page.document ); // try to access the foreign page in a safe way -> typeof
  return ( (lsType != "unknown") && (lsType != "undefined") );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_isSWFPage()
// ------------------------
// returns true <=> the page is scriptable from this page 
//					AND it uses the SAPWF-Web-Framework!
//
// NEEDS:		Window		page			foreign page to test
//
// RETURNS:		Boolean						true => page is scriptable
//				
function SAPWF_isSWFPage( page ) {
    return SAPWF_isPageScriptable( page ) && (page.SAPWF_fnop != null);
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getServiceName()
// -----------------------------
// returns the service the page is bound to
//
// NEEDS:		nothing
//
// RETURNS:		String						service name the page is bound to
//				
function SAP_getServiceName() { return SAPWF_getServiceName() }
function SAPWF_getServiceName() {
	var lsResult = window.SAPWF_serviceName;
	return (lsResult != null)? lsResult: "";
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getServiceInstance()
// ---------------------------------
// returns the id of the service
//
// NEEDS:		nothing
//
// RETURNS:		String						id of the service instance
//				
function SAPWF_getServiceInstance() {
	var lsResult = window.SAPWF_serviceInstance;
	return (lsResult != null)? lsResult: "";
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_checkPageRelation()
// --------------------------------
// returns true <=> window.self and page belongs to the same services
//
// NEEDS:		Window		page			window reference to compare with window.self
//
// RETURNS:		Boolean						true <=> the pages belongs to the same service
//				
function SAP_checkPageRelation( page ) { return SAPWF_checkPageRelation( page ) }
function SAPWF_checkPageRelation( page ) {
    return SAPWF_isSWFPage( page ) && (page.SAPWF_getServiceName != null) &&
		       (SAPWF_getServiceName() == page.SAPWF_getServiceName() );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_isServiceRootPage()
// --------------------------------
// returns true <=> the page has no parent page which is binded to the same service
//
// NEEDS:		noting
//
// RETURNS:		Boolean						true <=> the page is a service root page
//				
function SAP_isServiceRootPage() { return SAPWF_isServiceRootPage() }
function SAPWF_isServiceRootPage() {
	var lwAncestor	= SAPWF_getAncestor();
	
	return (lwAncestor == window) || 
		   (! SAPWF_checkPageRelation( lwAncestor ) );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getServiceRootPage()
// ---------------------------------
// returns the service root page
//
// NEEDS:		noting
//
// RETURNS:		Window						page which is bounded to the same service
//											and is a service root page
//				
function SAP_getServiceRootPage() { return SAPWF_getServiceRootPage() }
function SAPWF_getServiceRootPage() {
	var lwResult = null;
	
	if (SAPWF_isServiceRootPage() ) {
		lwResult = window;
	} else {
		lwResult = SAPWF_getAncestor().SAPWF_getServiceRootPage();
	}	
	return lwResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getRelatedPages()
// ------------------------------
// returns a collection of all pages, which belongs to the same service
//
// NEEDS:		noting
//
// RETURNS:		Array						list of all pages of this service
//		
function SAPWF__getRelatedPages( collection ) {
	var lwChild;
	var laChildren	= frames;
	var li;

	collection[collection.length] = this;
	for (li = 0; li < laChildren.length; li++) {
		lwChild = laChildren[li];
		if (SAPWF_checkPageRelation( lwChild ) ) {
			collection = lwChild.SAPWF__getRelatedPages( collection );
		} 
	}
	return collection;
}	
function SAP_getRelatedPages() { return SAPWF_getRelatedPages() }
function SAPWF_getRelatedPages() {
	return SAPWF_getServiceRootPage().SAPWF__getRelatedPages( new Array() );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getChildServices()
// -------------------------------
// returns a collection of direct child services
//
// NEEDS:		noting
//
// RETURNS:		Array						list of direct child services
//		
function SAPWF__getChildServices( collection ) {
	var laChildren	= frames;
	var lwChild;
	var li;
	for (li = 0; li < laChildren.length; li++) {
		lwChild = laChildren[li];
		if (SAPWF_isSWFPage( lwChild ) ) {
			if (SAPWF_checkPageRelation( lwChild ) ) {
				collection = lwChild.SAPWF__getChildServices( collection );
			} else {
				collection[collection.length] = lwChild;
			}
		} 
	}
	return collection;
}	
function SAP_getChildServices() { return SAPWF_getChildServices() }
function SAPWF_getChildServices() {
	return SAPWF_getServiceRootPage().SAPWF__getChildServices( new Array() );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getAncestorService()
// ---------------------------------
// returns the direct ancestor service, if available, or null otherwise
//
// NEEDS:		noting
//
// RETURNS:		Window						reference to the ancestor service root page
//											OR window.self, if no ancestor is present
//		
function SAPWF__getAncestorService() {
	var lwAncestor	= SAPWF_getAncestor();
	var lwResult	= window;
	
	if ( (lwAncestor != window) && SAPWF_isSWFPage( lwAncestor ) ) {
		lwResult = lwAncestor.SAPWF_getServiceRootPage();
	}
	return lwResult;
}	
function SAP_getAncestorService() { return SAPWF_getAncestorService() }
function SAPWF_getAncestorService() {
	return SAPWF_getServiceRootPage().SAPWF__getAncestorService();
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getObject()
// ------------------------
// returns a reference to the object given by its id
//
// NEEDS:		String		id				object id, must be unique inside the service
//
// RETURNS:		Object						reference to the object
//	
function SAP_getObject( id ) { return SAPWF_getObject( id ) }
function SAPWF_getObject( id ) {
	var laPages = SAPWF_getRelatedPages();
	var li;
	var loResult = null;
		
	for (li = 0; (li < laPages.length) && (loResult == null); li++) {
		loResult = laPages[li].SAPWF_getObjectRepository().query( id );
	}
	return loResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// public SAPWF_getInterface()
// ---------------------------
// returns a reference to the interface object given by its id
//
// NEEDS:		String		id				interface id, must be unique inside the service
//
// RETURNS:		Object						reference to the interface object
//	
function SAPWF_getInterface( id ) {
	var laPages = SAPWF_getRelatedPages();
	var li;
	var loResult = null;
		
	for (li = 0; (li < laPages.length) && (loResult == null); li++) {
		loResult = laPages[li][id];
	}
	return loResult;
}
// --------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_createUrl()
// --------------------------------
// creates a url from a url description
//
// NEEDS:  		Object
//                  protocol            the protocol of the url 
//				    server	            the host of the url 
//				    path	            the path of the url 
//				    query	            the query part of the url
//				    fragmet	            the fragment part of the url
//
// RETURNS		String url         	    the generated url
//
function SAPWF_createUrl(loUrlInfo) {
  function isEmpty(loProperty) {
    return ((loProperty==null) || (loProperty==""));
  }
  with (loUrlInfo) {
    return (isEmpty(protocol)? "": protocol+":")+
           (isEmpty(server)? "": "//"+server)+
           (isEmpty(path)? "" : path)+
           (isEmpty(query)? "": "?"+query)+
           (isEmpty(fragment)? "": "#"+fragment);
  }      
}
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_parseUrl()
// --------------------------------
// parses the given Url and returns an object containing the entire parts
//
// NEEDS:		String		url			the url to be parsed
// 
// RETURNS		Object:	            	protocol	the protocol of the url (or empty)
//				    server	            the host of the url (or empty)
//				    path	            the path of the url (or empty)
//				    query	            the query part of the url (or empty)
//				    fragmet	            the fragment part of the url (or empty)
//
function SAPWF_parseUrl( url ) {
	var loResult = null;
	with (SAPWF_parseUrl) {
		var laMatch = url.match( spUrl );
		
		if (laMatch[0] == url) {
			loResult = { protocol: laMatch[2], server: laMatch[4], path: laMatch[5], query: laMatch[7], fragment: laMatch[9] };		
		}
	}
	return loResult;	
}
SAPWF_parseUrl.spUrl= /^(([a-zA-Z][a-zA-Z0-9+-\.]*):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/;
//					    12							3 4    5		   6       7           8 9
//                       +--------Protocol--------+        +-Server-+  +-Path+    +Query+    +Fr+    
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_parseServer()
// -----------------------------------
// parses the given Url and returns a server object
//
// NEEDS		String		server		the server to be parsed
// 
// RETURNS		Object:		            userInfo	the user info
//					host	            the host
//					port	            the port (or empty)
//
function SAPWF_parseServer( server ) {
	var loResult = null;

	var laMatch = server.match( SAPWF_parseServer.spServer );
	if (laMatch != null) {
		if (laMatch[4] != "" && laMatch[4] != null) {
			loResult = { userInfo: laMatch[2], host: laMatch[3], IPv4Addr: laMatch[4], port: laMatch[10], isIPv4Addr: true, isName: false };
		} else if (laMatch[6] != "") {
			loResult = { userInfo: laMatch[2], host: laMatch[3], hostName: laMatch[6], domain: laMatch[8], port: laMatch[10], isIPv4Addr: false, isName: true };
		}
	}

	return loResult;
}
SAPWF_parseServer.spServer = /^(([a-zA-Z0-9-_\.!~\*'\(\)%;&=\+\$,]*)@)?(([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)|(([^:\.]+)(\.([^:]+))*\.?))(:([0-9]*))?$/;
//  						   12                                      34                                56        7  8             9 A
//                              +-------------User Info------------+    +----------IPv4Address---------+  +HostNam++--Domain-+        +-Port-+
//                                                                     +------------------------Host-------------------------------+                
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_parseQuery()
// ----------------------------------
// parses the given query-string and returns an array with the name/value pairs
//
// NEEDS	String		query		the query string to be parsed
// 
// RETURNS	Array[]		<index>		the name 
//					    <value>		the value of the name=value pair
//
function SAPWF_parseQuery( query ) {
	var laResult = new Array();
	var laMatch	 = null;
		
	with (SAPWF_parseQuery) {
		while (query.length > 0) {
			laMatch = spQuery.exec( query );
		
			if ( laMatch != null) {
				laResult[laMatch[1]] = laMatch[2];		
				// Match arrays have index, not lastIndex: always consume the matched pair.
				query = query.substr( laMatch.index + laMatch[0].length );
			} else {
				query = "";
			}
		}
	}
	return laResult;	
}
SAPWF_parseQuery.spQuery = /([^=&]+)=([^&]*)&?/;
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_objectToQueryString()
// -------------------------------------------
// converts a query representation of the given javascript object
// ATTENTION:   only numbers, strings and booleans are converted!!!
//
// NEEDS	Object      obj         object to be converted
// 
// RETURNS	String                  escaped query string representation
//
function SAPWF_objectToQueryString( obj ) {
	var lsResult = "";
	var lsSep    = "";
	
	for (var i in obj) {
	    if ( "numberstringboolean".indexOf( typeof( obj[i] ) ) != -1) {
	        lsResult += lsSep + escape( i ) + "=" + escape( obj[i] );
	        lsSep = "&";
	    }
	}
	return lsResult;
}		
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_addQueryToUrl()
// -------------------------------------
// appends the given query string to the given url and returns the extended Url
// Url and query string will be separeted by a '?' or a '&', depending on if 
// the given url contains a query string or not.
//
// NEEDS	String      url         a url with or without a query
//          String      query       query string to be added to the url
//
// RETURNS	String                  the url extended with the query string
//
function SAPWF_addQueryToUrl( url, queryString ) {
    var loUrl = SAPWF_parseUrl( url );
    
    if (loUrl.query != "") loUrl.query += "&" + queryString;
    else loUrl.query = queryString;
         
    return SAPWF_createUrl( loUrl );
}		
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_setCookie()
// ---------------------------------
// sets a "crumb" inside the cookie storage
//
// NEEDS	String		name		the name of the cookie
//		    String		value		the value of the cookie
// 
// OPTIONAL	String		expires		time, when the cookie expires (in GMT format)
//		    String		path		the path pattern
//		    String		domain		the domain the cookie belongs to
//		    Boolean		secure		cookie information is visible only from a secure environment	
//
// RETURNS	nothing
//
function SAPWF_setCookie( name, value, expires, path, domain, secure ) {
    function cookieParam( name, value ) {
    	return (value != null)? name + "=" + value + ";": "";
    }
	if ( (name != null)	&& (name != "") ) {
	    if (value == null) value = "";
	    document.cookie =	cookieParam( name, escape( value ) ) + 
							cookieParam( "expires", expires ) +
							cookieParam( "path", path ) +
							cookieParam( "domain", domain ) +
							( (secure == true)? "secure": "" );
	}
}
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_getCookieArray()
// --------------------------------------
// returns the cookie "crumbs" in an array
//
// NEEDS	nothing
//
// RETURNS	Array					associative array with cookie name/values
//
function SAPWF_getCookieArray() {
	var laResult		= new Array();

	if (document.cookie != "") {
		var laCookieList	= document.cookie.split( "; " );
	
		for (var i = 0; i < laCookieList.length; i++) {
			var lsNameValue = laCookieList[i].split( "=" );
            switch (lsNameValue.length) {
              case 1:
                laResult[unescape( lsNameValue[0] )] = "";
                break;
              case 2:
  			    laResult[unescape( lsNameValue[0] )] = unescape( lsNameValue[1] );
                break;
            }
		}
	}
	return laResult;
}

// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_getCookie()
// ---------------------------------
// gets the value of cookie "crumb" by its name
//
// NEEDS	String		name		the name of the cookie
//
// RETURNS	String					the value of the cookie
//
function SAPWF_getCookie( name ) {
	var lsCookie = SAPWF_getCookieArray()[name];
	if ( lsCookie == "deleted" )
	  lsCookie = null;
	return lsCookie;
}
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_deleteCookie()
// ------------------------------------
// deletes a cookie given by its name
// ATTENTION: it seems that the browser deletes cookies with some delay, 
//            use with care!
//
// NEEDS    String		name		the name of the cookie
//
// OPTIONAL	String		path		the path pattern
//		    String		domain		the domain the cookie belongs to
//
// RETURNS	nothing
//
function SAPWF_deleteCookie( name, path, domain ) {	
	var loPast = new Date();
	
	loPast.setYear( 1111 );
  SAPWF_setCookie( name, "deleted", loPast.toGMTString(), path, domain );
}
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_encode()
// ------------------------------
// encodes the given object into a string representation
//
// NEEDS    Object		obj			the object to encode
//
// RETURNS	String					string representation of the object
//
function SAPWF_encode( obj ) {	
	var lsResult	= "";
	var lsType		= (obj != null)? typeof( obj ): "null";
		
    if ( (lsType == "boolean")  ||
         (lsType == "function") ||
         (lsType == "number")   ||
         (lsType == "null") ) {
        lsResult = obj;            
    } else if (lsType == "object") {
		var lsDelim  = "";
		lsResult = "{";
		for (var i in obj) {
			lsResult += lsDelim + "'" + i + "':" + SAPWF_encode( obj[i] );
			lsDelim = ",";
		}
		lsResult += "}";
    } else if (lsType == "string") {
		lsResult = "'" + obj + "'";
    } else if ( (lsType == "undefined") ||
                (lsType == "unknown") ) {
        lsResult = null;
    }
	return lsResult;
}
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// public function SAPWF_decode()
// ------------------------------
// decodes the given encoded string representation of an object
//
// NEEDS	String		encoded		the string representation of the object 
//
// RETURNS	Object					the decoded object
//
function SAPWF_decode( encoded ) {
    var loResult = null;
    // trick: if an element in encoded is 'undefined', it will be set to null
    var undefined = null;       
    
    if ( (encoded != null) && (encoded != "") ) {
        eval( "loResult=" + encoded );
    }
    return loResult;
}
// ----------------------------------------------------------------------------


// ============================================================================
