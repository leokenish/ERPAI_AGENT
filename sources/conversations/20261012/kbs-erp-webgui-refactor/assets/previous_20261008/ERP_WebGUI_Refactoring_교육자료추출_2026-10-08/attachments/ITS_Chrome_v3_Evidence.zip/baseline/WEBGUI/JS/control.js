/*
 * Javascript Control Framework
 *
 */


var   // Global flag for control data iframe
  treeDataIFRAMEcreated = false,
  calendarDataIFRAMEcreated = false,
  tsDataIFRAMEcreated = false,
  toolbarIFRAMEcreated = false;


// Utilitities

function ismoz()     { return (navigator.appVersion.indexOf("MSIE") == -1) ? true : false; }
function isIE4()     { return (navigator.appVersion.indexOf("MSIE 4.0") != -1) ? true : false; }
function isIE55()    { return (navigator.appVersion.indexOf("MSIE 5.5") != -1) ? true : false; }
function isIE5()     { return (navigator.appVersion.indexOf("MSIE 5.0") != -1) ? true : false; }
function isIE5_up()  { return (navigator.appVersion.substr(navigator.appVersion.indexOf("MSIE")+5,1) >= 5) ? true : false; }
function isIE55_up() { return (navigator.appVersion.substr(navigator.appVersion.indexOf("MSIE")+5,3) >= 5.5) ? true : false; }
function isIE6_up()  { return (navigator.appVersion.substr(navigator.appVersion.indexOf("MSIE")+5,1) >= 6) ? true : false; }


  // Workarounds for browser bugs

  function controlFixAlignHorizontal(element)
  {
    var w = controlGetScrollbarWidth();

    if (element.style.overflow == "scroll")
    {
    element.style.width = parseInt(element.style.width) + w + "px";
  }
  else if (element.style.overflow == "auto")
  {
    if (element.scrollWidth <= element.offsetWidth)
      element.style.width = element.offsetWidth + w + "px";
  }
}

function controlGetScrollbarWidth()
{
  var rv;
  if (ismoz())          rv = 18;
  else if (isIE55_up()) rv = 11;
  else                  rv = 0;
  return rv;
}


// ----------------------------------------------------------

// Here Controls can add an eventhandler which will be executed
// on load and after sizing operations by docking/splitter

var CFWonFinalSizeHandlers = new Array(120),  // currently size is limited to 120 entries;
    CFWarrFinalizeHdl = new Array();

var CFWonFinalSizeHandlersCnt = 0;

function CFWAddonFinalSizeHandler(jsfnname)
{
  if ( CFWonFinalSizeHandlersCnt >= 120 )
  {  alert("Skipping OnFinalSizeHandlers:"+ jsfnname + "() skipped; Size(120) exceeded!");
     return -1;
  }
  CFWonFinalSizeHandlers[CFWonFinalSizeHandlersCnt] = jsfnname;
  ++CFWonFinalSizeHandlersCnt;
  return 0;
}

function CFWAddFinalizeHandler( in_fnref )
{
  if (null != in_fnref)
  {
    window.CFWarrFinalizeHdl.push(in_fnref);
  }
} // CFWAddFinalizeHandler()


// ----------------------------------------------------------

// CallOnFinalSizeHandler
function CFWExeconFinalSizeHandlers( isonload )
{
  // run only once onload, but everytime later
  if ((isonload && !CFWExeconFinalSizeHandlers._runonload) || (CFWExeconFinalSizeHandlers._runonload && !isonload))
  {
    clearTimeout(CFWExeconFinalSizeHandlers._timeout);
    CFWExeconFinalSizeHandlers._timeout = setTimeout("_CFWExeconFinalSizeHandlers()", 300);
  }
}
CFWExeconFinalSizeHandlers._timeout   = null;
CFWExeconFinalSizeHandlers._runonload = false;

function CFWFinalize()
{
  for (var i = 0, l = window.CFWarrFinalizeHdl.length; i < l; i++)
    (window.CFWarrFinalizeHdl.pop())();
}

function _CFWExeconFinalSizeHandlers()
{
  var i, f = ITS_Frameset("FRAME");
  if (self == f || parent == f || !ITS_Frameset("IS_ACTIVE"))
  {
    for (i = 0; i < CFWonFinalSizeHandlersCnt; i++)
    {
      eval(CFWonFinalSizeHandlers[i]+"()");
    }
    CFWExeconFinalSizeHandlers._runonload = true;
  }
  CFWFinalize();
}


// ----------------------------------------------------------

function controlOnLoad()
{
  controlUpdateAlignment() ;

  if (window.treeOnLoad)
  {
    treeOnLoad();
  }
}

// ----------------------------------------------------------

function controlDoResize(in_event, in_immediate)
{
  if (window.splitterDoResize)
    splitterDoResize(in_immediate);
}


// Alignment

function controlSetAlignment(element, halign, valign)
{
  if (element && element.style && (halign || valign))
  {
    if (!window.alignments)
    {
      window.alignments = new Array();
    }

    window.alignments[window.alignments.length] = element;

    element.setAttribute("userHAlign", halign);
    element.setAttribute("userVAlign", valign);
  }
}

// ----------------------------------------------------------

function controlUpdateAlignment()
{
  if (window.alignments)
  {
    for (var i = 0; i < window.alignments.length; i++)
    {
      controlAlignHorizontal(window.alignments[i], window.alignments[i].getAttribute("userHAlign"));
      controlAlignVertical(window.alignments[i], window.alignments[i].getAttribute("userVAlign"));
    }
  }
}

// ----------------------------------------------------------

function controlAlignHorizontal(element, align)
{
  if (element && align && align == "right")
  {
    element.style.width = element.parentElement.offsetWidth
                        - element.offsetLeft
                        - (element.parentElement.offsetWidth - element.parentElement.clientWidth) + "px";
    controlFixAlignHorizontal(element);

    element.setAttribute("userHAlign", "right");
  }
}

// ----------------------------------------------------------

function controlAlignVertical(element, align)
{
  if (element && align && align == "bottom")
  {
    if (element.parentElement.clientHeight - element.offsetTop > 0)
    {
      if(element.style.height!="100%")
        element.style.height = element.parentElement.clientHeight - element.offsetTop + "px";
    }
    else
    {
      element.style.pixelTop += 8;
    }
    element.setAttribute("userVAlign", "bottom");
  }
}

// ----------------------------------------------------------

function controlUpdateVerticalAlignment(element)
{
  if (element.childNodes && element.childNodes.length > 0)
  {
    for (var i = 0; i < element.childNodes.length; i++)
    {
      if (element.childNodes[i])
      {
        if (element.childNodes[i].getAttribute("userVAlign") == "bottom")
        {
          controlAlignVertical(element.childNodes[i], "bottom");
        }
      }
    }
  }
}

// ----------------------------------------------------------

function controlUpdateHorizontalAlignment(element)
{
  if (element.childNodes && element.childNodes.length > 0)
  {
    for (var i = 0; i < element.childNodes.length; i++)
    {
      if (element.childNodes[i])
      {
        if (element.childNodes[i].getAttribute("userHAlign") == "right")
        {
          controlAlignHorizontal(element.childNodes[i], "right");
        }
      }
    }
  }
}

// ----------------------------------------------------------

function controlUpdateOverflow(pane)
{
  var i, l, child, el,
      h, hh;

  if (pane)
  {
    for (var i = 0, l = pane.childNodes.length; i < l; i++)
    {
        child = pane.childNodes[i];

      if (child && child.tagName == "DIV")
      {
        var
          bo_relativeheight,
          bo_relativewidth,
          overflow,
          width,
          height;

        if (null == (overflow = child.getAttribute("controloverflow")) )
        {
          if (child.style.controloverflow)
            overflow = child.style.controloverflow;
          else if (child.style.overflow)
            overflow = child.style.overflow;
          else
            overflow = null;
        }

        bo_relativeheight = child.style.height.indexOf("%") != -1;
        bo_relativewidth = child.style.width.indexOf("%") != -1;

        // Save original dimensions
        if (!child.controlPixelWidth || webguiSplitterLocalResize || webguiDockLocalResize)
        {
          child.controlPixelWidth = child.offsetWidth;
        }
        if (!child.controlPixelHeight || webguiSplitterLocalResize || webguiDockLocalResize)
        {
          child.controlPixelHeight = child.offsetHeight;
        }

        if ( child.offsetLeft + child.controlPixelWidth > pane.offsetWidth )
        {                                                                       // /tj/080929/ no resize of TC
          if (overflow == "auto" || overflow == "fixed" || overflow == "hidden")// || overflow == null)
            child.style.width = ((pane.clientWidth > child.offsetLeft) ? (pane.clientWidth - child.offsetLeft) : 0) + "px";
          else
            pane.style.overflow = "auto";
        }
        else if (webguiSplitterLocalResize || webguiDockLocalResize)
        {
          h = child.offsetWidth;
          child.style.width = "100%";
          hh = child.offsetWidth;
          child.style.width = ((hh == 0 && child.parentNode.offsetWidth > 5) ? h : hh) + "px";
        }


        if ( child.offsetTop + child.controlPixelHeight > pane.offsetHeight )
        {                                                                       // /tj/080929/ no resize of TC
          if (overflow == "auto" || overflow == "fixed" || overflow == "hidden")// || overflow == null)
          {
            if (!(child.offsetHeight == child.style.height && child.offsetHeight <= 100 && bo_relativeheight))
              child.style.height = ((pane.clientHeight > child.offsetTop) ? (pane.clientHeight - child.offsetTop) : 0) + "px";
          }
          else
            pane.style.overflow = "auto"
        }
//        else if ((webguiSplitterLocalResize || webguiDockLocalResize) && overflow!="fixed")
        else if (webguiSplitterLocalResize || webguiDockLocalResize)
        {
          h = child.offsetHeight;
          child.style.height = "100%";
          hh = child.offsetHeight;
          child.style.height = ((hh == 0 && child.parentNode.offsetHeight > 5) ? h : hh) + "px";
        }
      }
      if (child && child.isSplitter)
      {
        if (null != window.splitters && null != (el = window.splitters.Get(child.id)) && null != el.Update)
        {
          el.Update();
        }
      }
    }
  }
}

function controlCreateDataIFRAME(name, style, control, attr)
{
  var iFrameElement;

  /* please add an entry for the control that uses this function */
  if (control == "columntree")
  {
    if (treeDataIFRAMEcreated)
      return;
    treeDataIFRAMEcreated = true;
  }
  else if (control == "calendar")
  {
    if (calendarDataIFRAMEcreated)
      return;
    calendarDataIFRAMEcreated = true;
  }
  else if (control == "tabstrip")
  {
    if (tsDataIFRAMEcreated)
      return;
    tsDataIFRAMEcreated = true;
  }
  else if (control == "toolbar")
  {
    if (toolbarIFRAMEcreated)
      return;
    toolbarIFRAMEcreated = true;
  }

  if (document.all) // IE
  {
    iFrameElement = '<iframe'
                  + ' name=' + name
                  + ' id=' + name
                  + ' style="' + style + '" '
                  + attr
                  + ' src=\"' + webguiMimeURL + '/system/' + webguiTheme + '/page/emptypage.html\"'
                  + '></iframe>';

    document.body.insertAdjacentHTML("BeforeEnd", iFrameElement);
  }
  else  // Mozilla
  {
    var src = webguiMimeURL + '/system/' + webguiTheme + '/page/emptyPage.html';

    iFrameElement = document.createElement("iframe");
    iFrameElement.setAttribute("name" , name);
    iFrameElement.setAttribute("id"   , name);

    iFrameElement.frameborder = 0;
    iFrameElement.style.height = 0;
    iFrameElement.style.width = 0;
    iFrameElement.setAttribute("style", style);

    iFrameElement = document.body.appendChild(iFrameElement);
    iFrameElement.src = src;

    /* if IFRAME style is set to "display:none" a new browser window will be opened */
    /* This also happens if we set iFrameElement.style.display = "";                */
    iFrameElement.style.display = "block";
  }
}

/**
 * DragDropManager
 */

function wguDragDropManager( ddbarray ){

  /**
  * debug
  */

  this.debug = function( msg )
  {
/*
    if (window.console) console.log( msg ); //output to firebug or js companion console
    if ((typeof(Debug) !== 'undefined') && Debug.writeln) {
      Debug.writeln( msg );
    }
    else if (its_ua.gecko ) dump( msg + '\n'); //enable old school console in firefox with browser.dom.window.dump.enabled
*/
  }

  /**
  *  draginit
  */
  //todo: do we need this?
  this.draginit = function()
  {
    this.dragisinit = true;
  }

  /**
  *  cancelEvent
  */

  this.cancelEvent = function(e)
  {
      dragManInstance.debug("cancelEvent");
      var event = new its_event(e);
      event.cancel();
  }

  /**
  * dragstart
  *
  * is called when a new drag operation is started (on mousedown)
  * this method should not be called from a global mousedown handler, instead
  * it should be accessed from controls. For example,
  * tree control cares for mousedown events itself and calls this method if needed
  *
  * params:
  * @element - the dom element on which the mousedown event was captured, must have a abapddid
  * @e - the event
  * @cid - control id (short form, the stuff behind the period char)
  * @key - item key (for example tree node key)
  */

  this.dragstart = function( element, e, cid, key )
  {
      /*if (this.ddwait) return false;
      this.ddwait = 1;
      setTimeout ( 'ddwait = 0;', 10 ); //todo: what is this good for?
      */
      this.debug("dragstart attempt ##########################");
      var event = new its_event(e);
      //event.preventDefault(); //prevent native browser handling in msie regarding dragstart on images

      if (event.button != 1 || !this.dragisinit || !element || !element.attributes['abapddid'])
          return true;

      var abapddid = element.getAttribute('abapddid');
      if (abapddid === null)
          return true;
      this.dragHandle = abapddid;
      this.debug("dragstart abapddid = " + abapddid);

      //do we still need this?
      if (event.target.parentNode.attributes['DDCID'] &&
          event.target.parentNode.attributes['DDCID'].value == "0")
          return true;

      //dragManInstance.DDBArray can be null in case of a specific obsolete kernel version
      if (this.DDBArray == null) return true;

      //find out if object is empty
      var arrayIsEmpty = true;
      for (i in this.DDBArray){
        arrayIsEmpty = false;
      }
      if (arrayIsEmpty) return true;

      //check if abapddid is present
      var dragHandleIsPresent = (typeof this.DDBArray[ this.dragHandle ] === 'object');
      if (!dragHandleIsPresent){
          this.debug("Error: draghandle with current abapddid does not exist.");
          return;
      }

      if (this.dragHandle !== null && this.isDragSource() )
      {
        if (its_ua.gecko){
          //prevent selection of text on web page in firefox
          this.ddselectStyle = document.body.style.MozUserSelect ;
          document.body.style.MozUserSelect = 'none'; //TODO: checkthis!
        }
        this.dragFlavors = this.getDragFlavors();
        //cid: not the full control id, but the part of the id behind the period of the full control id
        if (cid.indexOf('.') !== -1)
        {
          var idParts = cid.split('.');
          if (idParts.length == 2)
          {
            cid = idParts[1];
          }
        }
        this.dragId = cid;
        this.dragKey = key;
        this.dragElement = element; //store dom element for later comparison

        var timestamp = new Date();
        dragManInstance.dragStartTime = timestamp.getTime();
        dragManInstance.dragCanceled = false;
        dragManInstance.inOperation  = true;

        /*mouse move events*/
        //firefox bug regarding onmousemove https://bugzilla.mozilla.org/show_bug.cgi?id=307792
        window.wgu_global_eventhandler.RegisterHandler( "mouseup", "dragdrop", 999, dragManInstance.dragdone);
        window.wgu_global_eventhandler.RegisterHandler( "mousemove", "dragdrop", 999, dragManInstance.dragging);
        document.body.ondragstart   = dragManInstance.cancelEvent;
        document.body.onselectstart = dragManInstance.cancelEvent;
        this.debug("end of dragStart");
        return false;
      }
      return true;
  }

  /**
  * creates CSS rules for all valid drop targets to visualize them as being drop targets (mouse cursor)
  */

  this.createCSSRules = function()
  {
        if (wguCSSManager){
          this.debug("drag - createCSSRules started ");
          wguCSSManager.addRule('body','{cursor: no-drop;}');
          //enable all matching drop targets by creating css classes for them
          //loop through this.dragFlavors and find the handles with matching flavors being a dropTarget
          for (var i in this.DDBArray)
          {
            if ( this.isDropTarget( i ) )
            {
              //use cursor: -moz-copy only for ancient gecko engines
              var cursor = its_ua.gecko ? 'copy' : 'crosshair';
              wguCSSManager.addRule(
                '.drop-handle-active-' + i,
                '{'+
                ' cursor: ' + cursor + ';' +
                //' background-color: lightyellow;'+ only used for debug purposes
                '}'
              );
            }
            else{
              this.debug("handle "+i+" is not a drop target.");
            }
          }
          //within tree controls, link items should not have fancy cursors during an ongoing drag operation
          //these rules have to be seperate to make them digestable for internet explorer
          wguCSSManager.addRule('a.tree_link_item','{cursor: inherit;}');
          wguCSSManager.addRule('div.treeColResizeArea','{cursor: inherit;}');
          wguCSSManager.addRule('input.tree_item_checkbox','{cursor: inherit;}');
          wguCSSManager.addRule('a.treeButtonLinkOverride','{cursor: inherit;}');
          this.debug("drag - createCSSRules ended");
        }
        else{
          this.debug("wguCSSManager is undefined");
        }
  }


  /**
  * modifies mouse cursor if valid drop target is passed
  */

  this.dragging = function(e)
  {
      dragManInstance.debug('dragging in progress...');
      if (!dragManInstance.dragisinit || dragManInstance.dragCanceled)
      {
        dragManInstance.debug('dragging stopped...');
        return false;
      }

      var timestamp = new Date();
      var duration = timestamp.getTime() - dragManInstance.dragStartTime;
      //dragManInstance.debug('dragging - duration since dragstart: ' + duration + "ms");

      if (!dragManInstance.dragCSSCreated &&  duration > 500){
        dragManInstance.dragCSSCreated = true;
        dragManInstance.createCSSRules();
      }

      var targetElement = dragManInstance.findClosestElementWithAbapddid(e);

      //debug
      var event2 = new its_event(e);
      var targetElement2 = event2.target;
      var debugString;
      if (targetElement2.tagName) debugString = targetElement2.tagName;
      if (targetElement2.id) debugString += " " + targetElement2.id;
      if (targetElement2.className) debugString += " " + targetElement2.className;
      dragManInstance.debug('dragging over target:' + debugString);
/*
      //check if the id indicates that this is a drop target
      if (dragManInstance.dragElement == targetElement || !targetElement.getAttribute || !targetElement.getAttribute('abapddid') || !dragManInstance.isDropTarget(targetElement.getAttribute('abapddid')))
      {
        //don't mark any element as a drop target
        if (dragManInstance.lastdroptarget != null)
          dragManInstance.unMarkDropTarget(dragManInstance.lastdroptarget);
        dragManInstance.lastdroptarget = null;
      }
      else if (targetElement && targetElement != dragManInstance.lastdroptarget )
      {
        if (dragManInstance.lastdroptarget != null)
          dragManInstance.unMarkDropTarget(dragManInstance.lastdroptarget);

        targetElement.style.cursor = its_ua.gecko ? '-moz-copy' : 'crosshair';
        dragManInstance.lastdroptarget = targetElement;
      }
*/
      return false;
  }

  /**
  * findClosestElementWithAbapddid
  */

  this.findClosestElementWithAbapddid = function(e)
  {
    return this.findClosestElementWithAttribute(e, 'abapddid', 8);
  }

  /**
  * findClosestElementWithDdcid
  */

  this.findClosestElementWithDdcid = function(e)
  {
    return this.findClosestElementWithAttribute(e, 'ddcid', 15);
  }

  /**
  * findClosestElementWithAttribute
  */

  this.findClosestElementWithAttribute = function(e, attrName, depth)
  {
      var event = new its_event(e);
      var targetElement = event.target;
      while (targetElement.getAttribute && !targetElement.getAttribute( attrName ) && depth > 0 && targetElement.parentNode){
        depth--;
        targetElement = targetElement.parentNode;
      }
      return targetElement;
  }

  /**
  * unMarkDropTarget
  */

  this.unMarkDropTarget = function(lastdroptarget)
  {
    lastdroptarget.style.cursor = 'default';
  }


  /**
   * dragdone - this is called on mouseup event
   */

  //controls should be aware of being a control with valid droptargets

  this.dragdone = function(e)
  {
    dragManInstance.dragCanceled = true;
    window.wgu_global_eventhandler.UnregisterHandler( "mousemove", dragManInstance.dragging, "dragdrop");
    window.wgu_global_eventhandler.UnregisterHandler( "mouseup", dragManInstance.dragdone, "dragdrop");

    dragManInstance.debug("dragdone");
    if (wguCSSManager){
      var currentRule = wguCSSManager.ruleExists('body');
      if (currentRule != -1) wguCSSManager.deleteRule( currentRule );
      //control specific rule to ensure cursor: inherit
      currentRule = wguCSSManager.ruleExists('a.tree_link_item');
      if (currentRule != -1) wguCSSManager.deleteRule( currentRule );
      currentRule = wguCSSManager.ruleExists('div.treeColResizeArea');
      if (currentRule != -1) wguCSSManager.deleteRule( currentRule );
      currentRule = wguCSSManager.ruleExists('input.tree_item_checkbox');
      if (currentRule != -1) wguCSSManager.deleteRule( currentRule );
      currentRule = wguCSSManager.ruleExists('a.treeButtonLinkOverride');
      if (currentRule != -1) wguCSSManager.deleteRule( currentRule );

      for (var i in dragManInstance.DDBArray)
      {
        if (dragManInstance.isDropTarget( i ))
        {
          var ruleNo = wguCSSManager.ruleExists('.drop-handle-active-' + i );
          if (ruleNo != -1)
            wguCSSManager.deleteRule( ruleNo );
        }
      }
    }
    dragManInstance.dragCSSCreated = false;
    var event = new its_event(e);
    var targetElement = dragManInstance.findClosestElementWithAbapddid( e );
    //check if the id indicates that this is a drop target
    if (dragManInstance.dragElement != targetElement && targetElement.getAttribute && targetElement.getAttribute('abapddid') && dragManInstance.isDropTarget(targetElement.getAttribute('abapddid')))
    {
      dragManInstance.debug("dragdone - element found");
      if (dragManInstance.lastdroptarget != null)
        dragManInstance.unMarkDropTarget(dragManInstance.lastdroptarget);
      var targetData = null;
      //todo: check here if internet explorer is active and work around
      //non-existing wgu_getControlDetails
      var ddcidElement  = dragManInstance.findClosestElementWithDdcid( e );
      if (ddcidElement.getAttribute('ddctype') == 'tree')
      {
        //todo: call a callback within tree control
        targetData = dragManInstance.getTreeNodeDetails( targetElement );
      }
      else
      {
        //todo check if this string contains a period!!!!
        //var id = ddcidElement.getAttribute('ddcid').split('.');
        targetData = {
          dragDrop_controlSpecificGetParams : '',
          controlId : ddcidElement.getAttribute('ddcid')
        };
      }
      if (targetData !== null){
        if (targetData.dragDrop_controlSpecificGetParams !== null)
          targetData.dragDrop_controlSpecificGetParams = '&' + targetData.dragDrop_controlSpecificGetParams;
        else
          targetData.dragDrop_controlSpecificGetParams = '';
        dragManInstance.debug(targetData);
        var params =
          'DragControlId='+ dragManInstance.dragId +
          '&dragHandle='  + dragManInstance.dragHandle +
          '&dropHandle='  + targetElement.getAttribute('abapddid') +
          '&~dragKey='    + dragManInstance.dragKey +
          targetData.dragDrop_controlSpecificGetParams;
        webguiRaiseEvent( targetData.controlId, 'OnDrop', params, '_self');
      }
      else{
        dragManInstance.debug('targetData is null');
      }
    }
    dragManInstance.dragstop();
    return false;
  }


  /**
   * dragstop - called by dragdone
   * (there is no logical separation between dragstop and dragdone)
   */

  this.dragstop = function()
  {
      dragManInstance.lastdroptarget = null;

      document.body.ondragstart   = null;
      document.body.onselectstart = null;
      if (its_ua.gecko){
        document.body.style.MozUserSelect = dragManInstance.ddselectStyle;
        dragManInstance.ddselectStyle  = '';
      }
      dragManInstance.draggingobject = null;
      dragManInstance.dragHandle     = null;
      dragManInstance.dragFlavors    = null;
      dragManInstance.dragId         = null;
      dragManInstance.inOperation    = false;
  }

  /**
   * isActive
   *
   */

  this.isActive = function()
  {
    if (dragManInstance.inOperation)
      return dragManInstance.inOperation;
    else
      return false;
  }

  /**
   * getTreeNodeDetails
   *
   */

this.getTreeNodeDetails = function( treeNode )
{
  try
  {
    //check if id exists
    if (!treeNode.id)
      throw 'TableRowElement has no id.';
    if (!treeNode.getAttribute("tree_key"))
      throw 'TableRowElement has no attribute tree_key.';
    //check if it starts with string tree
    var idParts = treeNode.id.split("::");
    if (idParts.length !== 3)
      throw 'The id of TableRowElement (tree node) is not in the expected format.';
    var objectName = idParts[0];
    if (objectName.length < 5)
      throw 'The first section of the tree node id is not of the expected length:' + objectName.length;
    if (objectName.substring(0, 4) !== "tree")
      throw 'The first section of the tree node id does not refer to a tree control.';
    //we now have successfully detected that the TableRowElement is inside of a tree control
    if (!treeCollection.treeArray[ objectName ])
      throw 'Tree control with id ' + objectName + ' does not exist in treeCollection.';
    var treeControlPointer = treeCollection.treeArray[ objectName ];
    return {
      'dragDrop_controlSpecificGetParams' : '~dropKey=' + treeNode.getAttribute("tree_key"),
      'controlId' : treeControlPointer.controlId
    };
  }
  catch(e)
  {
    dragManInstance.debug( e );
    return null;
  }
}

  /**
   * getDragFlavors
   *
   * returns an array containing the flavor(s) of the drag source.
   * a drag source can have multiple flavors
   * the flavor is needed in the moment where we have to check
   * for a valid droptarget (should have the same flavor)
   */

  this.getDragFlavors = function()
  {
      if (!dragManInstance.dragisinit)
          return null;
      var flavors = new Array();
      //loop through atoms
      for ( var j = 0; j < dragManInstance.DDBArray[dragManInstance.dragHandle].length; j++)
        if (dragManInstance.DDBArray[dragManInstance.dragHandle][j]['DragSrc']  == 'X')
          flavors[flavors.length] = dragManInstance.DDBArray[dragManInstance.dragHandle][j]['Flavor'];
      return flavors;
  }

  /**
   * isDragSource
   */

  this.isDragSource = function()
  {
    if (!dragManInstance.dragisinit)
        return false;
    var isDrgSrc = false;
    //loop through atoms
    for ( var j = 0; j < dragManInstance.DDBArray[dragManInstance.dragHandle].length; j++)
      if (dragManInstance.DDBArray[dragManInstance.dragHandle][j]['DragSrc']  == 'X')
        isDrgSrc = true;
    return isDrgSrc;
  }

  /**
   * isDropTarget
   * returns true if the matching dragdrop handle has an atom
   * a) declaring it to be an active droptarget and
   * b) has the same flavor as the dragsrc,
   * otherwise returns false
   *
   * dropTargetId ddid is the handle of the potential drop target
   */

  this.isDropTarget = function( dropTargetId )
  {
    //dragManInstance.debug('entering isDropTarget with id: ' + dropTargetId);

    if (!dragManInstance.dragisinit || typeof dragManInstance.DDBArray[dropTargetId] !== 'object')
      return false;
    var
      isDrpTgt =  false;
    //loop through atoms of this handle
    for ( var j = 0; j < dragManInstance.DDBArray[dropTargetId].length; j++)
      if (dragManInstance.DDBArray[dropTargetId][j]['DropTarget']  == 'X')
        for (var k = 0; k < dragManInstance.dragFlavors.length; k++)
          if (dragManInstance.DDBArray[dropTargetId][j]['Flavor']  == dragManInstance.dragFlavors[k])
            isDrpTgt = true;
    //dragManInstance.debug("isDropTarget? " + dropTargetId + " => " + isDrpTgt);
    return isDrpTgt;
  }

  //constructor

  this.DDBArray        = ddbarray;
  var
    dragManInstance = this,
    draggingobject  = null,
    dragisinit      = false,
    dragCSSCreated  = false,
    dragFlavors     = null,
    dragId          = null,

    inOperation     = false,

    oldonmousemove  = null,
    oldonmouseup    = null,
    lastdroptarget  = null,
    dragKey,
    dragHandle      = null,
    dragElement     = null,

    ddselectStyle   ='',
    ddwait          = 0,
    dragStartTime   = 0,
    dragCanceled    = false;

} //end of class definition

/**
 *   class for dynamic stylesheet manipulation
 */

function wguDynamicCSSManager(){

    this.addRule = function(className, properties){
        if (this.styleTag){
            if (this.w3cDomPresent) //firefox
                this.styleTag.sheet.insertRule(className + properties, this.getCssRules.length);
            else if (document.styleSheets) //msie
                document.styleSheets[this.styleTagId].addRule (className, properties);
            else{
                wguDDManager.debug("wguDynamicCSSManager: Error on addRule");
            }
        }
    }

    this.deleteRule = function( ruleNumber ){
        if (this.styleTag){
            if (this.w3cDomPresent)
                this.styleTag.sheet.deleteRule( ruleNumber );
            else if (document.styleSheets) //msie
                document.styleSheets[this.styleTagId].removeRule( ruleNumber );
            else{
                wguDDManager.debug("wguDynamicCSSManager: Error on deleteRule");
            }
        }
    }

    this.ruleExists = function ( className ){
        var present = -1;
        if (this.styleTag){
            //var cssRules = this.getCssRules();
            //check if css selector is already present
            //var debug = "search: " + className + "\n";
            for ( z=0; z < this.getCssRules.length; z++ ){
                var rule = this.getCssRules[z];
                var info = this.w3cDomPresent ? rule.cssText : rule.selectorText;
                //debug += info + "\n";
                var suspect = info.toLowerCase().slice( 0, className.length);
                if ( suspect == className.toLowerCase()){
                    present = z;
                }
            }
        }
        //alert( debug);
        return present;
    }

    //constructor
    this.styleTagId    = 'wguDynamicCSSManagerStorage';
    this.styleTag      = document.getElementById( this.styleTagId );
    if (this.styleTag){
        this.w3cDomPresent = this.styleTag.sheet != undefined;
        this.getCssRules   = this.w3cDomPresent ? this.styleTag.sheet.cssRules : this.styleTag.styleSheet.rules;
/*
          //attempt to circumvent firefox 2 exception "Access to restricted URI denied"
          //see: https://bugzilla.mozilla.org/show_bug.cgi?id=346945
        if (this.w3cDomPresent)
        {
          if (this.styleTag.sheet.href == null)
            this.getCssRules   = this.styleTag.sheet.cssRules;
          else
          {
            this.getCssRules   = null;
          }
        }
        else
        {
          this.getCssRules   = this.styleTag.styleSheet.rules;
        }
*/
    }

} //end of wguDynamicCSSManager()
