/**************************************
 *
 * CUA scripts
 *
 */


/******************
 * OK code field
 */

function webguiCUAtoggleOKCodeFieldOnKeyDown ()
{
  if (event.keyCode == 13 || event.keyCode == 32) {
    webguiCUAtoggleOKCodeField();
    event.cancelBubble = true;
  }
  return true;
} // webguiCUAtoggleOKCodeFieldOnKeyDown()

function webguiCUAtoggleOKCodeField ()
{
  var el_btn = document.getElementById( "webguiCUAOkToggle"),
      el_cnt = document.getElementById( "webguiCUAOkCodeCnt"),
      el_vis = document.getElementById("~ToolbarOkCodeVisible"),
      el_img = (null != el_btn) ? el_btn.getElementsByTagName("img")[0] : null,
      s;

  if (el_cnt && el_btn && el_vis)
  {
    if (el_vis.value == "X")
    {
      el_cnt.style.display = "none";
      el_btn.className = "Open";
      el_vis.value = " ";
      el_btn.setAttribute("alt", "Open transaction field");
      el_btn.setAttribute("title", "Open transaction field");
      if (null != el_img)
      {
        s = el_img.getAttribute("src");
        el_img.setAttribute("src", s.replace(/l\.gif$/, "r.gif"));
      }
    }
    else
    {
      el_cnt.style.display = "inline";
      el_btn.className = "Close";
      el_vis.value = "X";
      el_btn.setAttribute("alt", "Close transaction field");
      el_btn.setAttribute("title", "Close transaction field");
      if (null != el_img)
      {
        s = el_img.getAttribute("src");
        el_img.setAttribute("src", s.replace(/r\.gif$/, "l.gif"));
      }
    }
  }

  webguiCUAresizeButtonBar();
  webguiCUAsettokcfcookie();
} // webguiCUAtoggleOKCodeField()

function webguiCUAsettokcfcookie ()
{
  var mycookie = new wguObjCookie();
  var tokcf = document.getElementById("~ToolbarOkCodeVisible");
  if (tokcf) {
    if (tokcf.value == "X") {
      var exp = mycookie.EvalExpDays( 7);
      mycookie.Set( "~ToolbarOkCodeVisible", "X", exp, "/");
    }
    else {
      mycookie.Delete( "~ToolbarOkCodeVisible", "/");
    }
  }
  //  alert(document.cookie);
  return true;
} // webguiCUAsettokcfcookie()



/******************
 * Button bar
 */


function webuiCUAAddSystemButtonTooltip ( in_arrmnu, in_oButtons )
{
  var o = in_oButtons,
      m = in_arrmnu,
      i, j, el;

  if (null != o && null != in_arrmnu)
  {
    for (i = 0; i < o.length; i += 2)
    {
      for (j = 0; j < m.length; j += 6)
      {
        if (m[j+5] == o[i+1])
        {
          if (null != (el = document.getElementById(o[i])))
          {
            el.setAttribute("title", m[j]);
            if (null != (el = el.parentNode.getElementsByTagName("label")) && null != (el = el[0]))
            {
              el.innerHTML = m[j]; break;
            }
          }
        }
      }
    }
  }
} // webuiCUAAddSystemButtonTooltip()



/******************
 * Button bar
 */

function webguiCUAresizeButtonBar()
{
  if (webguiCUAresizeButtonBar.drin)
    return;
  else
    webguiCUAresizeButtonBar.drin = true;

  var myData = webguiCUAresizeButtonBar.data,
      myButtonbar     = document.getElementById("webguiCUAButtonBar"),
      myMenubar       = document.getElementById("webguiCUAMenuBar"),
      myMenubarDiv    = document.getElementById("webguiCUAMenuBarDiv"),
      myMetaAppButton = document.getElementById("webguiCUAMnuMetaAppButton"),
      mytr            = document.getElementById("webguiCUAtr");
  var myArrButtons, myButtonCnt,
      i, l, x,
      myMaxWidth,
      myHideMetaAppButton = true;

  /* Trick:
   *   If we don't hide the div at the beginning, the initial size of
   *   the CUA toolbar might be much too big for the screen.
   *   Instead, we hide it at first (style) and make it visible at
   *   this place.
   */
  // if (myMenubarDiv)
  //   myMenubarDiv.style.display = "block";

  if (myButtonbar)
  {
    myArrButtons = myButtonbar.getElementsByTagName("a");
    myButtonCnt = myArrButtons.length - 1;    // don't consider "More" button

    myButtonbar.style.display = "inline";
    if (myMenubar && !myMenubar.style.height)
      myMenubar.style.height = myMenubar.offsetHeight + "px";

    if (myButtonCnt > 1)
    {
      // collect the initial dimensions
      if (myData.buttoncount != myButtonCnt)
      {
        myData.buttoncount = myButtonCnt;

        myMetaAppButton.style.display = "inline";
        myArrButtons[0].parentNode.style.display = "inline";
        myData.buttondistance = (myArrButtons[1].parentNode.offsetLeft
                                - (myArrButtons[0].parentNode.offsetLeft + myArrButtons[0].parentNode.offsetWidth));
        for (i = 0, l = 0; i < myButtonCnt; i++)
        {
          myArrButtons[i].parentNode.style.display = "inline";
          l += (myData.arrButtonWidth[i] = (myArrButtons[i].parentNode.offsetWidth + myData.buttondistance));
          myData.arrButtonRight[i] = l;
        }
        // determine width of meta app button
        myData.metabuttonwidth = myMetaAppButton.parentNode.offsetWidth;

        myData.buttonbarwidth = myButtonbar.offsetWidth;
      }

      // determine absolute position of buttonbar
      x = wgu_getAbsolutePosition(myButtonbar).x;

      /* we might need some correction for x if dir = rtl due
       * to values from the IE far from reality in this case :(
       */
      if (isBidiRTL() && myMenubarDiv.parentElement.offsetWidth > myButtonbar.offsetWidth)
        x = myMenubarDiv.parentElement.offsetWidth - myButtonbar.offsetWidth;

      // calculate maximum allowed width of buttonbar
      if ((myMaxWidth = document.body.offsetWidth - myData.metabuttonwidth - x) < 0)
        myMaxWidth = 0;

      // calculate max number of buttons to show
      for (l = 0; l < myButtonCnt; l++)
      {
        if (myMaxWidth < myData.arrButtonRight[l])
        {
          break;
        }
      }

      // make buttons visible until max width is reached
      for (i = 0; i < l; i++)
      {
          myArrButtons[i].parentNode.style.display    = "inline";
          myArrButtons[i].parentNode.style.visibility = "visible";
      }

      // make rest of buttons invisible
      for (; i < myButtonCnt; i++)
      {
        myArrButtons[i].parentNode.style.display    = "none";
        myArrButtons[i].parentNode.style.visibility = "hidden";
        myHideMetaAppButton = false;
      }
    } // if (l <= 2)

  } // if (myButtonbar)
  else
  {
    if (myMenubar && !myMenubar.style.height)
      myMenubar.style.height = myMenubar.offsetHeight + "px";
  }

  if (myMetaAppButton)
  {
    if (myHideMetaAppButton)
    {
      myMetaAppButton.parentNode.style.display    = "none";
      myMetaAppButton.parentNode.style.visibility = "hidden";
    }
    else
     {
      myMetaAppButton.parentNode.style.display    = "inline";
      myMetaAppButton.parentNode.style.visibility = "visible";
    }
  }

  webguiCUAresizeButtonBar.drin = false;
}
webguiCUAresizeButtonBar.drin = false;
webguiCUAresizeButtonBar.data = {
  metabuttonwidth : -1,
  buttonbarwidth : -1,
  buttoncount    : -1,
  buttondistance : 0,
  arrButtonWidth : new Array(),
  arrButtonRight : new Array()
};


/******************
 * Local menu / About
 */

function webguiCUACreateLocalMenu ()
{
  var mainmnu = ("undefined" != typeof arMenu_1) ? arMenu_1 : null,
      entry, am, i, l,
      sMenuName = "arMenu_1_99";

  CUADefineWebguiLocalMenuEntries();

  if (null != mainmnu)
  {
    if ("undefined" != typeof wguGuiMenu)
    {
      wguGuiMenu.buildMenu();
      delete menuArray[sMenuName];
    }

    if (!webguiCUACreateLocalMenu.done)
    {
      l = mainmnu.length / 6;
      mainmnu.push(
        "-","OFF","STD","1/"+(l+1),"-","",
        webguiTextResource("JS_MNU_ABOUT"),"ON","STD","1/"+(l+3),"-","JCUAShowAbout()",
//      "-","OFF","STD","1/"+(l+4),"-","",
        "SAP GUI for HTML " + webguiTextResource("JS_MNU_OPTIONS"),'ON','POP',sMenuName,'-',""
      );
      webguiCUACreateLocalMenu.done = true;
    }
  }
} // webguiCUACreateLocalMenu()
webguiCUACreateLocalMenu.done = false;

function CUAShowAbout ()
{
  var w = self,
      aboutid  = "WebguiAboutBox",
      aboutdiv,
      myel, myel1,
      info;

  if (null != w.parent.its_root_frameset)
    w = parent;

  w.CUAHideAbout = CUAHideAbout;

  aboutdiv = w.document.getElementById(aboutid);
  if (null == aboutdiv)
  {
    // create div
    myel = owguDOM.HTMLCreateElement("div", {"id":(aboutid+"Bg"), "name":(aboutid+"Bg")}, w.document, 3, w.document.body);
    myel = owguDOM.HTMLCreateElement("div", {"id": aboutid,       "name": aboutid      }, w.document, 3, w.document.body);
    // myel.onclick = CUAHideAbout;
    // myel.onclick = CUAHideAbout;
  } // if (!aboutdiv)
  else
  {
    aboutdiv.style.display = "block";
    if (null != (aboutdiv = w.document.getElementById(aboutid+"Bg")))
      aboutdiv.style.display = "block";
  }

  aboutdiv = w.document.getElementById(aboutid);
  if (null != aboutdiv)
  {
    info = webguiAbout;

    // aboutdiv.onclick = CUAHideAbout;
    aboutdiv.innerHTML = ['<div id="', aboutid, 'Info">',
                          null != info
                            ? ['SAP Integrated ITS, WebAS: ', info.ITSVS, '<br />',
                               'Workprocess: ', info.WP, '<br />',
                               'Creation time: ', info.CREATETIME
                              ].join("")
                            : "SAP Internet Transaction Server / SAP GUI for HTML",
                          '</div>',
                          '<div id="', aboutid, 'Copy">Copyright&nbsp;&copy;&nbsp;1996&ndash;2008&nbsp;SAP&nbsp;AG. All rights reserved</div>',
                          '<a href="javascript:void(0);" id="', aboutid, 'Btn" onclick="CUAHideAbout();" onkeydown="if (13==event.keyCode)CUAHideAbout();">&nbsp;OK&nbsp;</a>'
                         ].join("");
    dom_focus(w.document.getElementById(aboutid+"Btn"));
  }
} // CUAShowAbout()

function CUAHideAbout ()
{
  var w = self,
      aboutid  = "WebguiAboutBox",
      aboutdiv;

  if (null != w.parent.its_root_frameset)
    w = parent;

  aboutdiv = w.document.getElementById(aboutid);
  if (null != aboutdiv)
  {
    aboutdiv.style.display = "none";
  }
  aboutdiv = w.document.getElementById(aboutid+"Bg");
  if (null != aboutdiv)
  {
    aboutdiv.style.display = "none";
  }
} // CUAHideAbout()


function _borderControlCnt()
{
  if (!window.goOutliner)
    window.goOutliner = new ContainerOutliner();

  if (!!window.goOutliner) window.goOutliner.trigger();
}
function _analyeNesting()
{
  var oNA = new NestingAnalyzer();
  oNA.trigger();
  oNA.reset();
}

function CUADefineWebguiLocalMenuEntries()
{
  if ("undefined" == typeof wguGuiMenu)
  {
    wguGuiMenu = new wguObjGuiMenu("arMenu_1_99");

    if (webguiDebugMode())
    {
      wguGuiMenu.addEntry("FEDEBUG"  , "Frontend Debugging", true, false, null, null, false, false, false, null, "FEDBG", true);
      wguGuiMenu.addEntry("FEDNSTANL", "Analyze Nesting", true, false, "F151", "N", true, true, true, "_analyeNesting()", "FEDBG");
      wguGuiMenu.addEntry("FEDHIER"  , "Border control container", true, false, "F152", "O", true, true, true, "_borderControlCnt()", "FEDBG");
      wguGuiMenu.addEntry("DIV1", "-", true, false, null, null, false, false, false, null, "FEDBG");    // divider
      wguGuiMenu.addEntry("TESTXSRFSHWTOK"  , "Show Session Token", true, false, "F155", "D", true, true, true, "XSRFSessionTokenDo(\\\"Show\\\")", "FEDBG");
      wguGuiMenu.addEntry("TESTXSRFDELTOK"  , "Delete Session Token", true, false, "F156", "D", true, true, true, "XSRFSessionTokenDo(\\\"Delete\\\")", "FEDBG");
      wguGuiMenu.addEntry("TESTXSRFMODTOK"  , "Modify Session Token", true, false, "F157", "D", true, true, true, "XSRFSessionTokenDo(\\\"Modify\\\")", "FEDBG");
    }

    wguGuiMenu.addEntry("SCRHRDCPY", webguiTextResource("JS_MNU_SCRHDCOPY"), true, false, "F181", "P", true, false, true, "wgu_global_updown.webguiDoHardCopy()");

    /* Examples
    //                 { ID:         Menu text,           Active?, checked?, vfcode, Key, Shift, Ctrl,  Alt,  function }

    wguGuiMenu.addEntry("DIV1", "-", true);    // divider
    wguGuiMenu.addEntry("TEST"     , "A test entry",        false, true,     "F180", "P", true,  true, false, "alert(\\\"Just a test\\\")");
    wguGuiMenu.addEntry("TEST2"    , "Another text entry",  true,  false,    "F182", "U", true,  false, true, "alert(\\\"Whow! You managed to trigger this SAP GUI for HTML local menu test entry. Congrats! ;-)\\\")");
    wguGuiMenu.addEntry("DIV2", "-", true);
    wguGuiMenu.addEntry("TEST3"    , "Remove second entry", true,  false,    "F183", "R", false, true,  true, "wguGuiMenu.removeEntry(\\\"TEST\\\");parent.wguGuiMenu.removeEntry(\\\"TEST3\\\");parent.webguiCUACreateLocalMenu();");
    */
  }
}


// only for temporary TEST !

function XSRFSessionTokenDo( in_action )
{
  var ainpf = [oSAPSecu.CONST.TOKEN_SESS_INPUT_ID, oSAPSecu.CONST.TOKEN_SESS_INPUT_ID2],
      inpf, i;

  for (i = 0; i < ainpf.length; i++)
  {
    if (null != (inpf = document.getElementById(ainpf[i])))
    {
      eval(["XSRFSessionToken", in_action, "(", i, ", \"", ainpf[i], "\")"].join(""));
    }
  }
}

function XSRFSessionTokenShow( in_i, in_inpfname )
{
  var inp = document.getElementById(in_inpfname);
  if (0 == in_i)
  {
    alert("XSRF Session Token: \"" + inp.getAttribute("value") + "\"");
  }
}

function XSRFSessionTokenDelete( in_i, in_inpfname )
{
  var inp = document.getElementsByName(in_inpfname), i, el;
  for (i = 0; i < inp.length; i++)
    if (null != (el = inp[i]))
      el.setAttribute("value", "");

  if (0 == in_i)
    alert("XSRF Session Token deleted\n" + inp.length + " occurences changed");
}

function XSRFSessionTokenModify( in_i, in_inpfname )
{
  var inp = document.getElementsByName(in_inpfname), i, el,
      s, smod,
      pos;

  if (0 == in_i)
  {
    XSRFSessionTokenModify.store.boInitialize = true;
  }

  for (i = 0; i < inp.length; i++)
  {
    if (null != (el = inp[i]))
    {
      if (XSRFSessionTokenModify.store.boInitialize && 0 == i)
      {
        XSRFSessionTokenModify.store.token = s    = el.getAttribute("value");
        XSRFSessionTokenModify.store.pos   = pos  = parseInt(Math.random() * s.length);
        XSRFSessionTokenModify.store.smod  = smod = [s.substring(0, pos), String.fromCharCode(s.charCodeAt(pos)+1), s.substr(pos+1)].join("");
      }
      else
      {
        s    = XSRFSessionTokenModify.store.token;
        pos  = XSRFSessionTokenModify.store.pos;
        smod = XSRFSessionTokenModify.store.smod;
      }
      el.setAttribute("value", smod);
    }
  }

  if (0 == in_i)
    alert("XSRF Session Token:\n  old: \"" + s + "\"\n new: \"" + smod + "\"\n\n" + inp.length + " occurences changed");
}
XSRFSessionTokenModify.store = {};
