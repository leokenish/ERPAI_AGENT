/************************************************************************************
 * **********************************************************************************
 * *
 * *   object its_statusbarManager
 * *   author: Henning Pingel
 * *
 * **********************************************************************************
 ************************************************************************************/

 /************************************************************************************
 *
 *   function its_statusbarManager
 *   constructor
 *
 **/
function its_statusbarManager(){
    window.gITSStatusbarManager = this;

    this.isInitial         = true;
    this.popup             = null;
    this.infobox           = null;
    this.buttonOpenBox     = null;
    this.buttonOpenBoxCell = null;
    this.isPopupVisible    = false;
    this.fpopupShow        = its_statusbarManager_popupShow;
    this.fpopupHide        = its_statusbarManager_popupHide;
    this.fInfoboxShow      = its_statusbarManager_InfoboxShow;
    this.fInfoboxHide      = its_statusbarManager_InfoboxHide;
    this.sbCookie          = null;
    this.statusBarCookieName = "~StatusbarInfoVisible";
}


/*
 * Event handler
 */

its_statusbarManager_popupShow   = function (event) { window.gITSStatusbarManager.popupShow(event); }
its_statusbarManager_popupHide   = function (event) { window.gITSStatusbarManager.popupHide();      }
its_statusbarManager_InfoboxShow = function (event) { window.gITSStatusbarManager.infoboxShow();    }
its_statusbarManager_InfoboxHide = function (event) { window.gITSStatusbarManager.infoboxHide();    }


 /************************************************************************************
 *
 *   public method init
 *
 **/

  its_statusbarManager.prototype.init = function(event){
    this.popup             = document.getElementById('webguiStatusbarPopup');
    this.infobox           = document.getElementById('WebguiMessageLineInfoBox');
    this.buttonOpenBox     = document.getElementById('WebguiMessageLineOpenBoxButton');
    this.buttonOpenBoxCell = document.getElementById('WebguiMessageLineOpenBoxButtonCell');
    this.isPopupVisible    = false;
    this.isInitial         = false;

    this.popupTrigger   = document.getElementById('WebguiMessageLinePulldown');
    this.buttonCloseBox = document.getElementById('WebguiMessageLineCloseBoxButton');

    //register events
    its_eMgr.registerEvent(this.popupTrigger, "mousedown", this.fpopupShow);
    its_eMgr.registerEvent(this.buttonOpenBox, "mousedown", this.fInfoboxShow);
    its_eMgr.registerEvent(this.buttonCloseBox, "mousedown", this.fInfoboxHide);

    this.sbCookie = new wguObjCookie();
    if (this.sbCookie.IsCookieEnabled){
      var cookieValue = null;
      if (cookieValue = this.sbCookie.Get( this.statusBarCookieName )){
        //there is already a cookie defined
        if (cookieValue == "1"){
          this.infoboxShow();
        }
        else{
          this.infoboxHide();
        }
      }
      else{
        //we have to set the cookie
        this.setCookieValue("1");
        this.infoboxShow();
      }
    }
  }

 /************************************************************************************
 *
 *   private method setCookieValue
 *
 **/

  its_statusbarManager.prototype.setCookieValue = function(value){
    if (this.sbCookie.IsCookieEnabled)
      this.sbCookie.Set( this.statusBarCookieName , value, null, "/");
  }

 /************************************************************************************
 *
 *   public method popupShow
 *
 **/

  its_statusbarManager.prototype.popupShow = function(event){
    if (this.isPopupVisible || this.isInitial) return;
    var ev = new its_event(event);
    var newTop = ev.pageY - this.popup.clientHeight - 5;
    var newLeft = ev.pageX - this.popup.clientWidth - 5;
    if (newTop >= 0) this.popup.style.top = newTop + "px";
    if (newLeft >= 0) this.popup.style.left = newLeft + "px";
    freezeOfficeControl();
    this.showElement( this.popup );
    this.isPopupVisible = true;
    ev.cancel();
    its_eMgr.registerEvent(document.body, "mousedown", this.fpopupHide);
  }

 /************************************************************************************
 *
 *   public method popupHide
 *
 **/

  its_statusbarManager.prototype.popupHide = function(){
    if (!this.isPopupVisible || this.isInitial) return;
    this.hideElement( this.popup );
    unFreezeOfficeControl();
    this.isPopupVisible = false;
    its_eMgr.unregisterEvent(document.body, "mousedown", this.fpopupHide);
  }

 /************************************************************************************
 *
 *   public method infoboxShow
 *
 **/

  its_statusbarManager.prototype.infoboxShow = function(){
    if (this.isInitial) return;
    this.buttonOpenBoxCell.style.display = "none";
    this.infobox.parentNode.style.display = "block";
    this.setCookieValue("1");
  }

 /************************************************************************************
 *
 *   public method infoboxHide
 *
 **/

  its_statusbarManager.prototype.infoboxHide = function(){
    if (this.isInitial) return;
    this.popupHide();
    this.infobox.parentNode.style.display = "none";
    this.buttonOpenBoxCell.style.display = "block";
    this.showElement( this.buttonOpenBox );
    this.setCookieValue("0");
  }


 /************************************************************************************
 *
 *   private method hideElement
 *
 **/

  its_statusbarManager.prototype.hideElement = function(element){
    if (null != element) element.style.visibility = 'hidden';
  }

 /************************************************************************************
 *
 *   private method showElement
 *
 **/

  its_statusbarManager.prototype.showElement = function(element){
    if (null != element) element.style.visibility = 'visible';
  }

