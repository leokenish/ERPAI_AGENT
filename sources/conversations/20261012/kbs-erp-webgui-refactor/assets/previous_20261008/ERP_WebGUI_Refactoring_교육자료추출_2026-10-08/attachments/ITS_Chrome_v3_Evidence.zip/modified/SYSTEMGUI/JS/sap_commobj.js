//object for communication with r/3
var CONST_VALUE="Value";
var CONST_NAME="Name";
var CONST_FIELD="Fields";

function SAP_commObject(name, iframeObj){
	this.id=name;
	this.tables = new Object("Tables");
	this.tblNames = new Array();
	this.attributes = new Object("Attributes");	
	this.attrNames = new Array();	
	this.frame = iframeObj;
	this.itsEvent="";
	this.responseFcnName="";
}

//functions of SAP_commObject

function SAP_commObject_addTable(tableName, fieldsArray){
	if(this.tables[tableName] == null)
	{
	 var tbl=new Object(tableName);
	 this.tblNames[this.tblNames.length]=tableName;
	 tbl[CONST_NAME]=tableName;
	 tbl[CONST_FIELD]=fieldsArray;
	 tbl[CONST_VALUE]= new Array();
	 
	 this.tables[tableName]= tbl;
	 return true;	
	}
	return false;
}

function  SAP_commObject_addRecord(tableName, valuesArray){
//values Array must contain the values in the same sequence of the fields as in
//fieldsArray of addTable
 var tbl;
	if((tbl=this.tables[tableName]) != null)
	{
		
	  var values =tbl[CONST_VALUE];
	  values[values.length] = valuesArray;
	  return values.length ;
	}
	return -1;//error
}


function  SAP_commObject_deleteRecord(tableName, recordNo){
 var tbl;
	if((tbl=this.tables[tableName]) != null)
	{		
	  var values =tbl[CONST_VALUE];
	  if(values.length >= recordNo)
	   values[recordNo] = null;
	  return true;
	}
	return false;
}


function  SAP_commObject_modifyRecord(tableName,recordNo, valuesArray){
 var tbl;
	if((tbl=this.tables[tableName]) != null)
	{		
	  var values =tbl[CONST_VALUE];
	  if(values.length >= recordNo)
	   values[recordNo] = valuesArray;
	  return true;
	}
	return false;	
}


function  SAP_commObject_getTableRecords(tableName){
	return this.tables[tableName][CONST_VALUE];
}

//add/sets the value for the attr
function  SAP_commObject_setAttribute(attrName,value){
 var attr;
 if((attr=this.attributes[attrName]) == null)
 {
  attr = new Object(attrName);
  attr[CONST_NAME]=attrName;
  this.attributes[attrName]=attr;
  this.attrNames[this.attrNames.length] = attrName;
 }
  attr[CONST_VALUE]=value;	
}


function  SAP_commObject_getAttribute(attrName){
	return this.attributes[attrName][CONST_VALUE];
}


function  SAP_commObject_getSubmitData(itsEventName){
	// Escape attribute text, not request values: the HTML parser restores exact data.
 function attributeText(value) {
   return String(value).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
     .replace(/</g, "&lt;").replace(/>/g, "&gt;")
     .replace(/\r/g, "&#13;").replace(/\n/g, "&#10;");
 }
 //return html form string
	//<INPUT type="text" name="~event" value="">
 var retValue="";
 var startStr = '<INPUT type="hidden" name="';
 var valueStr = '" value="';
 var endStr='"> ';
	
 retValue = startStr + "~event" + valueStr + attributeText(itsEventName) + endStr;
	
 var index;
 var item=this.tables;
 var itemLen=this.tblNames.length;
 var value;
 var flen;
 var vIndex;
 var lIndex;
 var name;
 var fld;
 var fIndex;
 var vlen;
 
 for(lIndex=0;lIndex< itemLen;lIndex++)
 {
 	//for every table
  index = this.tblNames[lIndex];
  value=item[index][CONST_VALUE];	
  name=item[index][CONST_NAME];
  fld=item[index][CONST_FIELD];
  flen = fld.length;
  vlen =value.length;
  for(vIndex=0; vIndex< vlen; vIndex++)
  {
  	// Deleted records remain holes; preserve the original one-based field indexes.
    if (value[vIndex] == null) continue;
  	//for every value set
  	for(fIndex=0;fIndex<flen;fIndex++)
  	{
  	  	//for every field value
  	 if(value[vIndex][fld[fIndex]] != null)
  	 {
  	  retValue = retValue +
  			  	startStr + 
  			  	attributeText(name) + "-" + 
  			  	attributeText(fld[fIndex]) + "[" +
  			  	(vIndex + 1) + "]" +
  			  	valueStr + attributeText(value[vIndex][fld[fIndex]])  +
  			  	endStr;
  	 }
  	}
  }
 }
 
 item =this.attributes;
 itemLen =this.attrNames.length;
 var attrName;
 for(index=0;index< itemLen;index++)
 {
  attrName = this.attrNames[index];
  if(item[attrName][CONST_VALUE] != null)
  {
  	value=item[attrName][CONST_VALUE];
  	// Preserve the existing scalar/comma-joined array submission contract.
    retValue = retValue + startStr + attributeText(item[attrName][CONST_NAME]) +
      valueStr + attributeText(value) + endStr;
  }
 } 
 
 return retValue;	
}


function  SAP_commObject_submit(itsEvent,responseFcn){
	if(this.frame != null)
	{
	 this.responseFcn =responseFcn;
	 this.itsEvent=itsEvent;
	 this.frame.submit(this);	
	}
}

function  SAP_commObject_submitImmediate(itsEvent,tgtFrameName){
	if(this.frame != null)
	{
	 this.itsEvent=itsEvent;
	 this.frame.submitImmediate(this,tgtFrameName);	
	}
}


function  SAP_commObject_clear(){
	//clear all data
 var index;
 var item=this.tables;
 var itemLen=this.tblNames.length;
 for(index=0;index< itemLen;index++)
 {
  item[this.tblNames[index]][CONST_VALUE]= new Array();	
 }
 
 item =this.attributes;
 itemLen =this.attrNames.length;
 for(index=0;index< itemLen;index++)
 {
  item[this.attrNames[index]][CONST_VALUE]= null;	
 }  
}

SAP_commObject.prototype.addTable=SAP_commObject_addTable;
SAP_commObject.prototype.addRecord=SAP_commObject_addRecord;
SAP_commObject.prototype.deleteRecord=SAP_commObject_deleteRecord;
SAP_commObject.prototype.modifyRecord=SAP_commObject_modifyRecord;
SAP_commObject.prototype.getTableRecords=SAP_commObject_getTableRecords;

SAP_commObject.prototype.setAttribute=SAP_commObject_setAttribute;
SAP_commObject.prototype.getAttribute=SAP_commObject_getAttribute;

SAP_commObject.prototype.getSubmitData=SAP_commObject_getSubmitData;
SAP_commObject.prototype.submit  =SAP_commObject_submit;
SAP_commObject.prototype.submitImmediate  =SAP_commObject_submitImmediate;

SAP_commObject.prototype.clear=SAP_commObject_clear;