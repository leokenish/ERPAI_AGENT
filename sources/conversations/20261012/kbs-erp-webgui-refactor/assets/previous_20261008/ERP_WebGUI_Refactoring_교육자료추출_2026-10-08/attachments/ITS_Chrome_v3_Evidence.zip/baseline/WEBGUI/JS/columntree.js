/*
  SAP ITS
  ITS Tree control javascript functions
  gui_columntree.js
  Author: Henning Pingel / Former Author: Johannes Bartsch
*/

/**
 *  Sets the result of a subtraction to zero if it's smaller than zero.
 *  Needed to get safe width and height values
 *  @param oldVal minuend
 *  @param substrVal subtrahend
 *  @return difference with minimum value null
 */
function treeSafeSubtraction(oldVal, substrVal){
    var newVal = oldVal - substrVal;
    return (newVal >= 0)? newVal : 0;
}

/**
 *  formatString
 *  @param strObj
 *  @param specialChar
 */

function formatString(strObj, specialChar){
    if (!strObj) return(null);

    var
      strArray = strObj.split(specialChar),
      doubleSpecialChar = specialChar + specialChar,
      splits = strArray.length - 1,
      strObj="";

    for (var i = 0; i < splits; i++){
        strObj += (strArray[i] + doubleSpecialChar);
    }
    strObj += strArray[i];
    return(strObj);
}

/**
 *  unformatString
 *  @param strObj
 *  @param specialChar
 */

function unformatString(strObj, specialChar){
    var doubleSpecialChar = specialChar + specialChar;
    var strArray=strObj.split(doubleSpecialChar);
    var splits=strArray.length - 1;
    var i;
    strObj="";
    for (i = 0; i < splits; i++){
        strObj += (strArray[i] + specialChar);
    }
    strObj += strArray[i];
    return(strObj);
}

/**
 *   treeNothing
 */

function treeNothing(){
}

/**
 *  treeRowLoop
 *  @param row
 *  @param table
 */

function treeRowLoop(row, table){

    // Only descendant visibility changes below; keep this attribute cache local to the call.
    var rowLevel = row.getAttribute('tree_level');
    if ( rowLevel && row.rowIndex !== undefined && table.rows.length){
        var displayValue  = (its_ua.ie55up) ? "block" : "table-row", //ie / moz
            nodeCollapsed = table.rows.length,
            i;
        for ( i = row.rowIndex + 1; i < table.rows.length; i++ ){
            var rowItem = table.rows.item(i),
                rowItemLevel = rowItem.getAttribute("tree_level");
            if (rowItemLevel && rowItemLevel <= rowLevel)
                break;
            if (nodeCollapsed >= rowItemLevel && rowItem.getAttribute("tree_state") == "collapsewithdata"){
                nodeCollapsed = rowItemLevel;
                rowItem.style.display = displayValue;
            }
            else if (nodeCollapsed == rowItemLevel)
                nodeCollapsed = table.rows.length;
            if ( nodeCollapsed > rowItemLevel ){
                rowItem.style.display = displayValue;
            }
        }
    }
}

/**
 *  treeRowsChangeStyle
 *  @param row
 *  @param param should be "Open" or "Close"
 */

function treeRowsChangeStyle(row, param){
    var row_elements = row.all ? row.all : row.getElementsByTagName('*');
    if (row_elements["expimg"])
        row_elements["expimg"].className = "ColumnTreeExp" + param;
    if (row_elements["fldrimg"])
        row_elements["fldrimg"].className = "ColumnTreeFldr" + param;
}

/**
 *  treeNodeGetNeighbour
 *  (to do: this looks really sick - we should use previoussibling/nextSibling here!)
 *  @param row
 *  @param direction should be +1 or -1
 *  @return neighbouring DOM element, or 0 in case of no success
 */

function treeNodeGetNeighbour(row, direction){
    if(!row) return(0);
    var
        result = 0,
        z = 0,
        z2 = 0,
        rows = row.parentNode.rows,
        rowsLength = rows.length;

    for (z=0; z < rowsLength; z++){
        if (rows[z] == row && z + direction >= 0 && rows[z + direction]){
            result = rows[z + direction];
            z2 = z;
            break;
        }
    }
    if (result !== 0 && result.style.display == "none"){
        while (result.style.display == "none"){
            z2 = z2 + direction;
            if (z2 < rows.length && z2 > 0 ) result = rows[z2];
            else {
                result = 0;
                break;
            }
        }
    }
    return result;
}

/**
 *  Converts color value in hex fromat to value in rgb format
 *  FIXME: This should be part of wgu utils (together with convertHexDoubleChar2Int)
 *  @param colorHex hex string representing a color with a length of 7 chars (example: #FFFFFF)
 *  @return rgb string or false
 */

function convertColorHexToRGB( colorHex){

    if (colorHex.length == 7){
        var value = new Array();
        value[0] = convertHexDoubleChar2Int(colorHex.substr(1,2));
        value[1] = convertHexDoubleChar2Int(colorHex.substr(3,2));
        value[2] = convertHexDoubleChar2Int(colorHex.substr(5,2));
        return 'rgb(' + value[0] + ', ' + value[1] + ', ' +value[2] + ')';
    }
    else{
        return false;
    }
}

/**
 *   convertHexDoubleChar2Int
 */

function convertHexDoubleChar2Int(charac){
    var digitValue = 16 * convertHexSingleChar2Int(charac.charAt(0)) + convertHexSingleChar2Int(charac.charAt(1));
    return digitValue;
}

/**
 *   convertHexSingleChar2Int
 */

function convertHexSingleChar2Int(charac){
    var digitValue = charac.toLowerCase().charCodeAt(0);

    if ( digitValue > 47 && digitValue < 58)
        digitValue = digitValue - 48;
    else if ( digitValue > 96 && digitValue    < 103)
        digitValue = digitValue -87;
    else{
        return false;
    }
    return digitValue;
}

/**
 *  This is called if a docking sash was moved and trees have to be resized
 *  It is a wrapper for optimizeAllTreeDimensions
 *  @see optimizeAllTreeDimensions
 *  he.pi 20090203: this function seems to be obsolete!
 */
/*
function treeUpdateAll(){
    if (treeCollection){
        treeCollection.optimizeAllTreeDimensions();
    }
}
*/

/**
 *  wgu_parseIntelligent2
 *  FIXME: move this into wgu_utils
 *  @param element
 *  @param mode can be "h" or "w" for height or width
 */

function wgu_parseIntelligent2(element, mode){
  if (mode == "w")
    value = element.style.width;
  else
    value = element.style.height;
  var intValue = parseInt(value, 10);
  if (intValue > 0){
    if (value.indexOf("%") >= 0){
      //unit: percentage
      if (mode == "w")
        return parseInt(element.parentNode.clientWidth/100*intValue, 10);
      else
        return parseInt(element.parentNode.clientHeight/100*intValue, 10);
    }
    else{
      //unit: pixel
      return intValue;
    }
  }
  else{
    return 0;
  }
}

/**
 *   its_treeCollection
 *   constructor
 */

function its_treeCollection( P ){
    this.treeArray = new Array(); // associative array
    this.treeCount = 0;
    this.windowName = window.name;
    this.globalResizeTimer = null;
    this.globalColResizeObj = null;

    var scrollBarHeight = 16;

    //constants that are valid and the same for all tree controls
    this.settings = {
      'prefix'                 :'tree',
      'tree1x1'                : P.tree1x1,
      'inDebugMode'            : P.debugMode === "1",
      'rtlMode'                : P.rtlMode,
      'noCTLinkClassChangeNecessary' : P.noCTLinkClassChangeNecessary,
      'selection_bg_color'     : P.selection_bg_color,
      'selection_textcolor'    : P.selection_textcolor,
      'scrollBarHeight'        : scrollBarHeight,
      'minRightContainerWidth' : 4 * scrollBarHeight,
      'innerDivOffset'         : 3,
      'suffixes'               : {
        'NODELEVEL_CLASS'      : "ColumnTreeNodeLevel", // + 1,2,3,4
        'TOPNODEKEY'           : "-TopNodeKey",
        'NODES_COLLOC'         : "-NodesCollapsedLocally",
        'NODES_LOCREEXPANDED'  : "-NodesCollLocReExpanded",
        'SELITEMSKEY'          : "-SelectedItemsKey",
        'SELITEMSNAME'         : "-SelectedItemsName",
        'SELNODES'             : "-SelectedNodes",
        'SELECTED'             : "-Selected",
        'SELCOLS'              : "-SelectedColumns",
        'LEFT_MAIN_SCROLLCONT'    : "tree_node_scrollcontainer_left_",
        'RIGHT_MAIN_SCROLLCONT'   : "tree_node_scrollcontainer_right_",
        'LEFT_HEADER_TABLE'       : "tree_header_table_left_",
        'RIGHT_HEADER_TABLE'      : "tree_header_table_right_",
        'RIGHT_HEADER_SCROLLCONT' : "tree_header_scrollcontainer_right_",
        'LEFT_MAINTABLE'          : "tree_node_table_left_",
        'RIGHT_MAINTABLE'         : "tree_node_table_right_"
      }
    }
}

/**
 *   Add a tree instance to the collection
 *   @param treeObj pass tree object (by reference)
 */

its_treeCollection.prototype.addTree = function(treeObj){
    if (treeObj.id){
        treeName = this.settings.prefix + treeObj.id;
        if (!this.treeArray[treeName]){
            this.treeArray[treeName] = treeObj;
            this.treeCount++;
            treeObj.hasBeenAddedToCollection = true;
        }
    }
}

/**
 *   getTreeById
 *   @param id id of the tree that should be returned
 *   @return a reference to the tree object or null
 */

its_treeCollection.prototype.getTreeById = function(id){
  if (this.treeArray[ this.settings.prefix + id ]){
        return this.treeArray[ treeCollection.settings.prefix + id ];
    }
    else{
        return null;
    }
}

/**
 *   getNumberOfTrees
 *   @return the total number of trees on dynpro
 */

its_treeCollection.prototype.getNumberOfTrees = function(){
    return this.treeCount;
}


/************************************************************************************
 * **********************************************************************************
 * * *   object its_treeManager
 * * **********************************************************************************
 ************************************************************************************/

/**
 *   function its_treeManager
 *   constructor
 */

function its_treeManager(P){

  this.isInitial     = true;
  this.debugDiv      = null;
  this.isDbgTimerInitialized  = false;
  this.areEventsRegistered    = false;
  this.repeatSetFocusOnLateMouseClick = false;

  //read basic properties from json array P
  this.id            = P.id;
  this.jsName        = P.jsName;
  this.controlId     = P.controlId;
  this.SCL_width     = P.leftScrContainerWidth;
  this.SCR_width     = P.rightScrContainerWidth;
  this.restWidth     = P.restWidth;
  this.origWidth     = P.treeWidth;
  this.treeHeight    = P.treeHeight;
  this.treeTop       = P.treeTop;
  this.topNodeKey    = P.topNodeKey;
  this.nodeCount     = P.numberOfNodes;
  this.selectMode    = P.selectMode;
  this.hasNodes      = (P.hasNodes !== "") ? true : false;
  this.hasHeader     = (P.hasHeaders !== "") ? true : false;
  this.splitted      = (P.splittedDisplay === 1) ? true : false;
  this.localExpand   = P.localExpand;
  this.events        = P.events;
  this.hideSelection = P.hideSelection;
  this.nodeHeightIndication = (P.nodeHeightIndication === null) ? 0 : P.nodeHeightIndication;

  //selection related properties
  this.rowSelectOnInit       = new Array();
  this.itemToSelectOnInit    = null;
  this.colNumberSelectOnInit = new Array();
  this.selectModeDetails     = null;
  this.selectionHasChanged   = false;
  this.deselectOnMouseClickInfo  = null;

  //properties related to surrounding docker splitter detection
  this.DS_isInside  = false;
  this.DS_Cont      = null;
  this.DS_OldDim    = null;

  this.topNodeKeyItem  = null; // will be filled by function storeTopNodeKeyItem
  this.formfields      = null;
  this.elementFocus    = null;
  this.hasRightHeader  = false;
  this.hasLeftHeader   = false;
  this.topNodeKeyWasPreserved = false;
  this.hasBeenAddedToCollection = false;
  this.resizeInProgress = false; //indicates column resize operation

  //ECData stores the last expand operation
  this.ECData = {
    'treeState'       : null,
    'key'             : null,
    'rowid'           : null,
    'nodeRowNumber'   : null,
    'nextNodeTreeKey' : null,
    'nextNodeId'      : null
  };

  this.sendPostAfterColResize = (P.sendPostAfterColResize === true);
  this.multiPurposeFlag = (P.multiPurposeFlag) ? P.multiPurposeFlag : "";
  this.colResizeDisabled = (this.multiPurposeFlag.search(/colResizeDisabled/) != -1);

  var thisTree = this;

  /**
   *  dumpBasicProperties
   */

  this.dumpBasicProperties = function( prefix, P ){
    var item;
    for (item in P) {
      if ( typeof P[item] === 'object'){
        this.addDbgMsg( prefix + "* " + item + " = ");
        this.dumpBasicProperties( prefix + "*" , P[item] );
      }
      else
        this.addDbgMsg( prefix + "* " + item + " = '" + P[item] + "'");
    }
  }

  /**
   *  Initialize tree properties.
   *  The following variables that are not always set:
   *  in case of this.splitted:
   *    this.HTL, this.MCL, this.MCR, this.lastColumn
   *  in case of this.splitted + this.hasNodes:
   *    this.SCL, this.NTL, this.MCLCell
   *  in case of this.splitted + this.hasHeader:
   *    this.lastHeaderColumn
   *  HT = HeaderTable, SC = ScrollContainer, NT = NodeTable
   *  HSC =HeaderScrollContainer, MC = MetaColumn, MT = MetaTable,
   *  TB = tree border div
   */

    this.init = function(){

        if (this.isInitial === false) return; //we only need to call this once
        if (treeCollection.settings.inDebugMode && this.debugDiv === null){
            this.debugDiv = document.getElementById( treeCollection.settings.prefix + this.id + "DebugDiv");
            this.initDbgT();
            //dump basic properties
            //loop over basic properties to prepare string for debug log
            if (treeCollection.settings.inDebugMode){
              this.addDbgMsg("---- Basic Tree Properties: ----");
              this.dumpBasicProperties( " " , P );
            }
        }
        this.formfields = {
            'topNodeKey'               : document.getElementById( this.jsName + treeCollection.settings.suffixes.TOPNODEKEY ),
            'collapsedNodes'           : document.getElementById( this.jsName + treeCollection.settings.suffixes.NODES_COLLOC ),
            'reExpandedCollapsedNodes' : document.getElementById( this.jsName + treeCollection.settings.suffixes.NODES_LOCREEXPANDED ),
            'selected'                 : document.getElementById( this.jsName + treeCollection.settings.suffixes.SELECTED ),
              //indicates if there currently is a selected item/node/column at all. values: '1'.
            'selectedItemsKey'         : document.getElementById( this.jsName + treeCollection.settings.suffixes.SELITEMSKEY ),
            'selectedItemsName'        : document.getElementById( this.jsName + treeCollection.settings.suffixes.SELITEMSNAME ),
            'selectedNodes'            : document.getElementById( this.jsName + treeCollection.settings.suffixes.SELNODES ),
            'selectedColumns'          : document.getElementById( this.jsName + treeCollection.settings.suffixes.SELCOLS )
        };

        this.SCL  = null;
        this.SCR  = document.getElementById( treeCollection.settings.suffixes.RIGHT_MAIN_SCROLLCONT + this.id );

        this.NTL  = null;
        this.NTR  = document.getElementById( treeCollection.settings.suffixes.RIGHT_MAINTABLE + this.id ); //can be null if no node content

        this.HTL  = null;
        this.HTR  = document.getElementById( treeCollection.settings.suffixes.RIGHT_HEADER_TABLE + this.id ); //can be null if no header exists

        this.HSCR = null;

        //update number of nodes value
        if (this.NTR){
          this.nodeCount = this.NTR.rows.length;
          if (this.nodeCount > 0) this.hasNodes = true;
        }
        //register scroll event on right scroll container
        if (this.hasNodes && this.areEventsRegistered === false){
          var fScroll = function(){thisTree.scroll();};
          its_eMgr.registerEvent(this.SCR, "scroll", fScroll);
        }

        if (this.HTR){
          this.hasRightHeader = true;
          this.HSCR   = this.HTR.parentNode;
        }

        this.MT             = document.getElementById( this.jsName);
        this.BGDiv          = this.MT.parentNode;
        this.TB             = this.BGDiv.parentNode;
        this.TB_Style       = this.TB.style;
        this.TB_Parent      = this.TB.parentNode;

        if (this.SCR){
          this.treeMainWrapperTr        = this.SCR.parentNode.parentNode;
          this.MCRCell  = this.SCR.parentNode;
        }
        else if (this.hasNodes){
          this.addDbgMsg("ERROR: tree " + this.id + " has got no right scroll container!");
        }

        if (this.splitted){
            if (this.hasNodes){
                this.SCL = document.getElementById( treeCollection.settings.suffixes.LEFT_MAIN_SCROLLCONT + this.id);
                this.NTL = document.getElementById( treeCollection.settings.suffixes.LEFT_MAINTABLE + this.id);
            }
            this.HTL = document.getElementById( treeCollection.settings.suffixes.LEFT_HEADER_TABLE + this.id);
            if (this.HTL){
                this.hasLeftHeader = true;
            }
            this.MCL = document.getElementById("tree_meta_column_left_width_"  + this.id);
            this.MCR = document.getElementById("tree_meta_column_right_width_" + this.id);
            if (this.hasNodes){
                this.MCLCell = this.SCL.parentNode;
            }
            this.lastColumn = document.getElementById("col_b_width_rest_" + this.id); //colgroup-col
            if (this.hasHeader){
                this.lastHeaderColumn = document.getElementById("col_h_width_rest_" + this.id); //colgroup-col
            }
            //register scroll event on left scrollcontainer
            if (this.hasNodes  && this.areEventsRegistered === false)
                its_eMgr.registerEvent(this.SCL, "scroll", function(){thisTree.scrollOnLeftContainer();} );
        }
        if (this.hasLeftHeader && this.hasRightHeader && !this.colResizeDisabled){
            this.hasHeader = true;
        }
        //register keydown event on tree
        if (this.areEventsRegistered === false){
          var fKeyDown = function(event){thisTree.keyDown(event);};
          its_eMgr.registerEvent(this.MT,  "keydown", fKeyDown);
        }

        //register event to work around the "mouse-cursor-inherit-bug" in msie
        //to prevent the cursor to remain an hour glass after roundtrip has finished
        //we have to avoid that the element under the mouse cursor has the setting
        //"cursor: inherit", hence the additional events...
        if (its_ua.ie55up){
          this.bufferedCursorDesign = false;
          var fOnMouseOver = function(event){thisTree.onMouseOver(event);};
          var fOnMouseOut = function(event){thisTree.onMouseOut(event);};
          its_eMgr.registerEvent(this.MT, "mouseover", fOnMouseOver);
          its_eMgr.registerEvent(this.MT, "mouseout",  fOnMouseOut);
        }

        this.checkForSurroundingDockerSplitter();
        this.singleColumnTreeMaxCellWidth = 0;

        //setup selection mode hints
        this.selectModeDetails = {
          'isSingleItemEnabled': this.selectMode.indexOf('singleitem') !== -1,
          'isMultiEnabled'     : this.selectMode.indexOf('multinode')  !== -1
        };

        //select item if necessary
        if (this.itemToSelectOnInit){
            var
                itemID = treeCollection.settings.prefix + this.id + "::" + this.itemToSelectOnInit,
                itemElement = document.getElementById(itemID),
                itemInfos = this.itemToSelectOnInit.split('::');
            if (itemElement){
              this.selectItem({ 'element' : itemElement, 'key' : itemInfos[0], 'item' : itemInfos[1] });
            }
            else{
                this.addDbgMsg("item to be selected on init does not exist: " + itemID);
            }
            this.itemToSelectOnInit = null;
        }

        //select row if necessary
        if (this.rowSelectOnInit.length > 0){
            for (z=0; z < this.rowSelectOnInit.length; z++)
              this.markNodeAsSelected_byName( this.rowSelectOnInit[z] );
            this.rowSelectOnInit = new Array();
        }

        //select column if necessary
        if (this.colNumberSelectOnInit.length > 0){
            this.selectHeader(this.colNumberSelectOnInit, true);
            this.colNumberSelectOnInit = new Array();
        }
        this.isInitial = false;
        this.areEventsRegistered  = true;
    }

   /**
    * storeTopNodeKeyItem
    */

    this.storeTopNodeKeyItem = function(topnodekeyitem){
        this.topNodeKeyItem = topnodekeyitem;
    }

   /**
    *   showDebugDiv
    */

    this.showDebugDiv = function(){
        this.debugDiv.style.visibility = "visible";
        this.resizeDebugDiv();
    }

  /**
   *   hideDebugDiv
   */

    this.hideDebugDiv = function(){
        this.debugDiv.style.visibility = "hidden";
    }

  /**
   *   init Debug Log Timer
   */

  this.initDbgT = function(){
    this.debugProfileTimeStart = new Date();
    this.profileTimeLast       = this.debugProfileTimeStart;
    this.timerArray            = new Array();
    this.isDbgTimerInitialized = true;
  }

  /**
   *   addDbgMsg
   */

  this.addDbgMsg = function(string){
    if (treeCollection.settings.inDebugMode){
        var
            profileTimeNow = new Date(),
            profileTimeUsedLastStep = 0,
            profileTimeUsedOverall  = 0,
            debugString = string;
        if (this.isDbgTimerInitialized){
            profileTimeUsedLastStep = profileTimeNow.getTime() - this.profileTimeLast.getTime();
            profileTimeUsedOverall  = profileTimeNow.getTime() - this.debugProfileTimeStart.getTime();
        }
        this.profileTimeLast = profileTimeNow;
        debugString += "  (" + profileTimeUsedOverall + " / " + profileTimeUsedLastStep + ") ";
        if (this.debugDiv !== null) this.debugDiv.innerHTML +=
          "<p style=\"margin-top: 0px; margin-bottom: 0px; text-indent:-10px; margin-left: 10px;\">" + debugString
          "</p>";
        var msg = treeCollection.settings.prefix + this.id + " : " + debugString;
        //window.console support for firefox / companjon support for msie
        //for using firefox dump feature enable browser.dom.window.dump.enabled and start firefox with parameter -console
        if (window.console) console.log( msg ); //output to firebug or js companjon console
        else if (its_ua.gecko) dump( msg + '\n'); //enable old school console in firefox with browser.dom.window.dump.enabled
        if ((typeof(Debug) !== 'undefined') && Debug.writeln) {
          Debug.writeln( msg );
        }
      }
  }

   /**
    *   dbgTStart
    */

    this.dbgTStart = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            this.timerArray[timeTicketKey] = new Date();
            this.addDbgMsg("StopWatch START: " + timeTicketKey + "");
        }
    }

    /**
     *   dbgTStop
     */
    this.dbgTStop = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            var profileTimeNow = new Date();
            timerResult = profileTimeNow.getTime() - this.timerArray[timeTicketKey].getTime();
            this.addDbgMsg("Stopwatch STOP: " + timeTicketKey + " = " + timerResult  + "ms");
            //this.timerArray[timeTicketKey] = null;
            return timerResult;
        }
    }

   /**
    *   dbgTAverageInit
    */

    this.dbgTAverageInit = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            this.timerArray[timeTicketKey] = {'lastrun' : 0, 'sum' : 0, 'count': 0};
            this.addDbgMsg("StopWatch Avarage INIT: " + timeTicketKey + "");
        }
    }

   /**
    *   dbgTAverageStart
    */

    this.dbgTAverageStart = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            this.timerArray[timeTicketKey].lastrun = new Date();
            //this.addDbgMsg("StopWatch Average START: " + timeTicketKey + "");
        }
    }

    /**
     *   dbgTAverageStop
     */
    this.dbgTAverageStop = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            var profileTimeNow = new Date();
            timerResult = profileTimeNow.getTime() - this.timerArray[timeTicketKey].lastrun.getTime();
            this.timerArray[timeTicketKey].sum += timerResult;
            this.timerArray[timeTicketKey].count++;
            //this.addDbgMsg("Stopwatch Average STOP: " + timeTicketKey + " = " + timerResult  + "ms");
            //this.timerArray[timeTicketKey] = null;
            return timerResult;
        }
    }

   /**
    *   dbgTAverageResults
    */

    this.dbgTAverageResults = function( timeTicketKey ){
        if (treeCollection.settings.inDebugMode){
            this.addDbgMsg(
                "StopWatch Avarage Results: " + timeTicketKey +
                ", Count: " + this.timerArray[timeTicketKey].count +
                ", Sum: <b>" + this.timerArray[timeTicketKey].sum +
                "ms</b>, Average: <b>" + this.timerArray[timeTicketKey].sum / this.timerArray[timeTicketKey].count + "ms</b>"
            );
            this.timerArray[timeTicketKey] = 0;
        }
    }

    /**
     *   resizeDebugDiv
     */

    this.resizeDebugDiv = function(string){
        this.debugDiv.style.width  = treeSafeSubtraction(this.TB.offsetWidth,  20) + "px";
        this.debugDiv.style.height = treeSafeSubtraction(this.TB.offsetHeight, 20) + "px";
    }

  /**
  *  cancelEvent
  */

  this.cancelEvent = function(e)
  {
      var event = new its_event(e);
      event.cancel();
  }


    /**
     * treeGetFolder
     * @param nextNode
     * @return DOM element
     */

    this.treeGetFolder = function (nextNode){
        if (nextNode === 0 || !nextNode.hasChildNodes) return false;
        var firstCellChildren = nextNode.childNodes;
        for( var i=0; i<firstCellChildren.length; i++)
        {
            if( firstCellChildren[i].nodeType == 1){
                if (firstCellChildren[i].getAttribute("tree_class") == "Folder")
                    return(firstCellChildren[i]);
                else if (firstCellChildren[i].hasChildNodes){
                    var retval = this.treeGetFolder( firstCellChildren[i] );
                    if (retval != false) return retval;
                }
            }
        }
        return false;
    }

    /**
     *   getRow (starting with element loop up until we got the TR tag)
     */

  this.getRow = function(element){
    var
      treeClass;
    while (element){
      if(element.nodeType == 9) //DOCUMENT_NODE
        return(null);
      if(element.nodeType == 1){ //ELEMENT_NODE
        treeClass = element.getAttribute('tree_class');
        if (treeClass && treeClass == "Node")
          return element;
        element = element.parentNode;
      }
    }
    return(null);
  }

    /**
     *   getElement
     */

  this.getElement = function (element){
    while (element){
      if(element.nodeType == 9) //DOCUMENT_NODE
        return(null);
      if (element.getAttribute('tree_class'))
        return element;
      element = element.parentNode;
    }
    return null;
  }

    /**
     *   checkForSurroundingDockerSplitter
     *   (todo: maybe fullscreencontainer case must also be treated in the same way as docker/splitter,
     *   WebguiDynproBorder as a parent element is used for this purpose)
     *   Caution: WebguiDynproBorder has 15px border on each side!!!!
     *   Caution: Tree directly wrapped by dynproborder doesn't necessary mean a full screen container!
     */

  this.checkForSurroundingDockerSplitter = function(){
    var dospliIsPresent =
        //(this.TB_Parent.className == "WebguiDynproBorderNS") || (this.TB_Parent.className == "WebguiDynproBorder") || //fullscreencontainer
        (this.TB_Parent.className == "Docking") ||
        (this.TB_Parent.className == "SplitterChild") ||
        (this.TB_Parent.parentNode && this.TB_Parent.parentNode.className == "SplitterChild") ||
        (its_ua.gecko && this.TB_Parent.parentNode && this.TB_Parent.parentNode.className == "splitter");
    if (dospliIsPresent){
      this.DS_isInside = true;
      this.DS_Cont = this.TB_Parent;
    }
  }

    /**
     *   scroll
     */

  this.scroll = function(){

    // Sync differing offsets only; preserve immediate top-node form updates.
    //sync left container
    if (this.splitted){
      var scrollTop = this.SCR.scrollTop;
      if (this.SCL.scrollTop !== scrollTop)
        this.SCL.scrollTop = scrollTop;
    }

    //sync right tree header also (horizontally) if horizontal scrolling occured
    if (this.hasHeader){
      var scrollLeft = this.SCR.scrollLeft;
      if (this.HSCR.scrollLeft !== scrollLeft)
        this.HSCR.scrollLeft = scrollLeft;
    }
    this.setTopNodeKey();
  }

    /**
     *   scrollOnLeftContainer
     */

   this.scrollOnLeftContainer = function(){

    if (this.SCR.style.visibility != "hidden"){
       //sync left container because of problem in Mozilla
        var scrollTop = this.SCR.scrollTop;
        if (this.SCL.scrollTop !== scrollTop)
          this.SCL.scrollTop = scrollTop;
    }
    this.setTopNodeKey();
  }

  /**
   *   setTopNodeKey
   */

  this.setTopNodeKey = function(){

    var
        top_row = "",
        currentRow,
        tree,
        treeContainer;

    if (!this.hasNodes || this.resizeInProgress)
      return;

    if (this.SCR.style.visibility != "hidden"){
      tree = this.NTR;
      treeContainer = this.SCR;
    }
    else{
      tree = this.NTL;
      treeContainer = this.SCL;
    }

    var numberOfTreeRows = tree.rows.length - 1;
    if (numberOfTreeRows >= 0){
      // This scan does not move the container. Snapshot only for this invocation.
      var treeScrollTop = treeContainer.scrollTop;
      for (j=0; j <= numberOfTreeRows; j++){
        currentRow = tree.rows[j];
        if (currentRow.offsetTop >= treeScrollTop){
          if (currentRow.id !== ""){
            top_row = currentRow.getAttribute("tree_key");
            break;
          }
        }
      }
    }
    if (top_row !== "" && this.formfields.topNodeKey){
        this.formfields.topNodeKey.value = top_row;
//        this.addDbgMsg("scrollEvent - topnodekey form field value was updated to: element " + top_row + " / scrollTop = " + treeContainer.scrollTop );
    }
  }


    /**
     *   optimizeTreeSize
     *   calls setScrollContainerDimensions (after a successful check if docker/splitter container
     *   size has changed)
     */

  this.optimizeTreeSize = function(){
    this.resizeInProgress = true;
//    this.addDbgMsg("OPTIMIZETREESIZE begin Framset is active = " + ITS_Frameset("IS_ACTIVE") + "\nFramenumber: " + ITS_Frameset("FRAMENO") +  "\n window.name = " + window.name + "" );
    this.dbgTStart("OPTIMIZETREESIZE");

    if (this.hasHeader || this.hasNodes){
        if (this.DS_isInside){
            if( !this.DS_OldDim || (this.DS_OldDim && (this.DS_Cont.offsetWidth != this.DS_OldDim.width || this.DS_Cont.offsetHeight != this.DS_OldDim.height))){
            this.setScrollContainerDimensions();
        }
        this.DS_OldDim = {
          'width' : this.DS_Cont.offsetWidth,
          'height' : this.DS_Cont.offsetHeight
        };
        //this.addDbgMsg("container size before resize: width=" + this.DS_Cont.offsetWidth + " height=" + this.DS_Cont.offsetHeight );
      }
      else{
        this.setScrollContainerDimensions();
        /* we are not in a docker/splitter container
           therefore setScrollContainerDimensions will only correct the height
           we also have to check if the hierarchy column width is not bigger
           than the tree in a multi column tree (this may be the case if ABAP coding is sloppy)
           he.pi 20090204
        */
        if (this.splitted && this.hasNodes && (this.SCL_width + this.SCR_width + this.restWidth > this.origWidth)){
          this.resizeScrContWidthIfInDockSplitCont( this.origWidth );
        }
      }
    }

    this.resizeInProgress = false; // has to be turned off to make scrollToTopNodeKey --> setTopNodeKey possible
    // make sure that the topnodekey is visible
    if (this.hasNodes && !this.topNodeKeyWasPreserved) this.scrollToTopNodeKey();

    this.dbgTStop("OPTIMIZETREESIZE");
  }

  /**
   *   syncRowHeightsNeeded
   *   if there are items that exceed the normal height of a table row (e.g. buttons) we have to increase the
   *   row height in the other scrollcontainer too
   */

   this.syncRowHeightsNeeded = function(){
        if (this.splitted && this.NTR.offsetHeight != this.NTL.offsetHeight){
            this.addDbgMsg("syncRowHeights is needed");
            return true;
        }
        else
            return false;
   }


  /**
   *   syncRowHeights
   *   if there are items that exceed the normal height of a table row (e.g. buttons) we have to increase the
   *   row height in the other scrollcontainer too
   */

   this.syncRowHeights = function(){

        //does left scrollcontainer also exist?
        if (this.splitted){
            this.dbgTStart("syncRowHeight new");
            var maxHeight = 25,
                numberOfRows = this.NTR.rows.length,
                syncJobsLeft = new Array(),
                syncJobsRight = new Array();

            //loop through table rows
            for (z=0; z < numberOfRows; z++){
                var rhr = this.NTR.rows[z].offsetHeight,
                    rhl = this.NTL.rows[z].offsetHeight,
                    diff = rhr - rhl;
                if (diff < 0){
                    //check if maxHeight is violated
                    if (rhl > maxHeight){
                        syncJobsLeft.push({ 'row' : z , 'height' : maxHeight });
                        syncJobsRight.push({ 'row' : z , 'height' : maxHeight });
                    }
                    else{
                        syncJobsRight.push({ 'row' : z , 'height' : rhl });
                    }
                }
                else if (diff > 0){
                    //check if maxHeight is violated
                    if (rhr > maxHeight){
                        syncJobsLeft.push({ 'row' : z , 'height' : maxHeight });
                        syncJobsRight.push({ 'row' : z , 'height' : maxHeight});
                    }
                    else{
                        syncJobsLeft.push({ 'row' : z , 'height' : rhr });
                    }
                    this.NTL.rows[z].style.height = this.NTR.rows[z].offsetHeight + "px";
                }
                else if (rhr > maxHeight){
                    // diff == 0 is true, but maybe bigger than maxheight?
                    syncJobsLeft.push({ 'row' : z , 'height' : maxHeight });
                    syncJobsRight.push({ 'row' : z , 'height' : maxHeight });
                }
            }

            //apply collected height corrections
            for (z=0; z < syncJobsLeft.length; z++){
                this.NTL.rows[ syncJobsLeft[z].row ].style.height = syncJobsLeft[z].height;
            }
            for (z=0; z < syncJobsRight.length; z++){
                this.NTR.rows[ syncJobsRight[z].row ].style.height = syncJobsRight[z].height;
            }

            this.dbgTStop("syncRowHeight new");
        }
    }

    /**
     *   expanderClickWrapper
     */

    this.expanderClickWrapper = function(element, row){

        this.addDbgMsg("-------------------- expanderClick is being handled ----------------------");
        this.dbgTStart("expClickPostURL");
        var stateBuffer = row.getAttribute('tree_state');

        if (!treeDataIFRAMEcreated)
            controlCreateDataIFRAME("treeData","display:none; visibility: hidden","columntree","");

        if (this.NTR){
            if (this.NTL){
                var rowId = row.id.substring(0, row.id.length - 1),
                    rowR = document.getElementById( rowId + "r"),
                    rowL = document.getElementById( rowId + "l");
                this.expanderClick(element, rowL, this.NTL, false);
                this.expanderClick(element, rowR, this.NTR, true);
                row = rowL;
            }
            else{
                this.expanderClick(element, row, this.NTR, true);
            }
        }

    if (row.getAttribute('tree_state') === null){
      if (this.nodeHeightIndication === 0 || this.syncRowHeightsNeeded())
        this.syncRowHeights(); //this is only necessary if nodes were EXpanded
    }

    //in case adding new rows might trigger a vertical scroll bar we have to resize last column
    // after an expanded node was closed we have to check scrollcontainer sizes
    if (stateBuffer == "expanded" || stateBuffer == "collapsewithdata"){
      this.scrollBarChecks();
    }
  }

    /**
     *   expanderClick
     */

  this.expanderClick = function(element, row, table, doPost){

    if (!element || !row)
      return;

    this.singleColumnTreeMaxCellWidth = 0; //forced to be recalculated

    var
      key = row.getAttribute('tree_key'),
      treeState = row.getAttribute('tree_state'),
      numberOfRows,
      eventName = "OnExpandClick";

    if (doPost){
      this.ECData.treeState = treeState;
      this.ECData.key = key;
      //make sure the id belongs to left container
      this.ECData.rowid = row.id.substring(0, row.id.length - 1) + "l";
      var rows = row.parentNode.parentNode.rows;
      numberOfRows = rows.length;

      for ( z = 0; z < numberOfRows; z++){
        if (rows[z].id == row.id){
          this.ECData.nodeRowNumber = z;
          /*  also store tree_key of followup node (if the to be expanded row is not the last one in tree)
              we need this information for pasteNewTreeData in case that only the new tree rows
              are to be inserted in the old tree/page
          */
          this.ECData.nextNodeTreeKey = null;
          this.ECData.nextNodeId = null;
          if (z+1 < numberOfRows){
            this.ECData.nextNodeTreeKey = rows[z+1].getAttribute("tree_key");
            this.ECData.nextNodeId = rows[z+1].id.substring(0, row.id.length - 1) + "l";
          }
          //temporarily disabled to avoid side effects
          //eventName  = ( typeof rows[z].getAttribute("tree_key") !== "undefined" ? "OnExpandNoChildren" : "OnExpandClick");
          eventName  = "OnExpandClick";

        }
      }
    }
    this.addDbgMsg("tree_state = '" + treeState + "'");
    if (!treeState)
    {
      if (doPost){
        this.postURL( eventName, escape(key), "");
      }
      return;
    }

    var
      selectedItemsRow = false,
      treeLevel        = eval(row.getAttribute('tree_level')),
      rowItemLevel,
      rowItem;

    if (treeState === "expanded") // here an expanded node should be closed/collapse
    {
      var
        subRowSelected  = false,
        subItem = null,
        subItemSelected = false;
      numberOfRows = table.rows.length;

      //check for active node selection or item selection and indicate this if found
      if (typeof(this.MT.selection) === 'object' && this.MT.selection.element)
        selectedItemsRow = this.getRow( this.MT.selection.element );
      var rgbColor = convertColorHexToRGB(treeCollection.settings.selection_bg_color);
      for (var i = row.rowIndex + 1; i < numberOfRows ; i++)
      {
        rowItem = table.rows.item(i);
        rowItemLevel = rowItem.getAttribute('tree_level');

        //leave loop as soon as we reach the end of the sub level of the tree
        if (rowItemLevel && rowItemLevel <= treeLevel)
          break;

        if ( this.isNodeSelected( rowItem )) {
          subRowSelected = true;
          this.markNodeAsDeselected(rowItem );
        }
        else if (selectedItemsRow && rowItem.id == selectedItemsRow.id){
          if (this.selectModeDetails.isSingleItemEnabled){
            subItemSelected = true;
            subItem = this.MT.selection.item;
          }
          else{
            subRowSelected = true;
          }
          this.deselectItem();
        }
        rowItem.style.display = "none";
      }

      //set the current node to be selected if there was a subnode that was selected
      if ( !this.isNodeSelected( row ) && subRowSelected === true){
        this.markNodeAsSelected( row );
      }
      else if(subItemSelected === true){
        //we should not mark the complete node as selected,
        //but the corresponding item instead
        var nodeKey = row.getAttribute('tree_key');
        var elementId = treeCollection.settings.prefix + this.id + '::' + nodeKey + '::' + subItem;
        //this.addDbgMsg(elementId);
        this.selectItem({
          'element' : document.getElementById( elementId ),
          'key'     : nodeKey,
          'item'    : subItem
        });
      }

      row.setAttribute("tree_state", "collapsewithdata");
      treeRowsChangeStyle(row, "Close");
      this.redoRowColorsOnExpand(table); // he.pi 20060316
      //update hidden lists
      if (doPost){
        //add node to collapsed list
        this.addNodeToHiddenFieldList( this.formfields.collapsedNodes, row );
        //remove node From re-expanded list (in case it is on this list)
        this.removeNodeFromHiddenFieldList( this.formfields.reExpandedCollapsedNodes, row );
        this.setFocusOnClosestElementWithTabindex();
        this.repeatSetFocusOnLateMouseClick = true;
      }
      if (accessibility){
        element.alt =
          treeLevelText + " " +
          element.parentNode.parentNode.tree_level +
          treeNodeTypeText +
          treeNodeCollapsedText + " " +
          element.parentNode.innerText;
      }

      return;
    }
    else if (treeState == "collapsewithdata") // here a collapsed node should be expanded (data is already there)
    {
      treeRowLoop(row, table);  //new stuff he.pi
      row.setAttribute("tree_state","expanded");
      treeRowsChangeStyle(row, "Open");
      this.redoRowColorsOnExpand(table);

      //update hidden lists, this doesn't trigger a HTTP POST
      if (doPost){
        //remove node from collapsed list
        this.removeNodeFromHiddenFieldList( this.formfields.collapsedNodes, row );
        //add node To Re-Expanded list
        this.addNodeToHiddenFieldList( this.formfields.reExpandedCollapsedNodes, row );
      }

      if (accessibility)
      {
        element.alt =
          treeLevelText + " " + element.parentNode.parentNode.tree_level +
          treeNodeTypeText + treeNodeExpandedText + " " + element.parentNode.innerText;
      }
      this.setFocusOnClosestElementWithTabindex();
      this.repeatSetFocusOnLateMouseClick = true;
      return;
    }
    else if (!this.localExpand)
    {
      if (doPost){
        this.postURL( eventName, escape(key), "");
      }
      return;
    }

    if (this.rowWait(row, table) === false)
      return;

    if (doPost){
      this.postURL( eventName, escape(key), "", "", true, "treeData");
    }
  }


    /**
     *   clearHiddenLists
     */

    this.clearHiddenLists = function(){
      //this.addDbgMsg("clear Collapsed List (old value: <pre>'" + this.formfields.collapsedNodes.value + "'</pre>");
      if (this.formfields.collapsedNodes) this.formfields.collapsedNodes.value = "";
      //this.addDbgMsg("clear ReExpanded List (old value: <pre>'" + this.formfields.reExpandedCollapsedNodes.value + "'</pre>");
      if (this.formfields.reExpandedCollapsedNodes) this.formfields.reExpandedCollapsedNodes.value = "";

    }

    /**
     *   addNodeToHiddenFieldList
     *   this is not only used for node selection, but also for keeping node re-expand/locally collapsed infos up to date
     */

  this.addNodeToHiddenFieldList = function( field, row ){
    if (field){
      // if the node is not already stored in the list of collapsed nodes, then add it.
      //format the character to support the special delimiter ';'
      var strFormatted = formatString(row.getAttribute('tree_key'), "\\") + "\\;";
      if ( field.value.indexOf(strFormatted) == -1)
         field.value += (strFormatted);
      // otherwise keep the row in the list.
      //this.addDbgMsg("addNodeToHiddenFieldList " + field.name + ": '" + strFormatted + "', new complete value: <pre>'" + field.value + "'</pre>");
    }
  }

    /**
     *   removeNodeFromHiddenFieldList
     *   this is not only used for node selection, but also for keeping node re-expand/locally collapsed infos up to date
     */

  this.removeNodeFromHiddenFieldList = function( field, row ){
    if (field){
      var
        clpsValue = field.value,
        treeKeyFormatted = formatString( row.getAttribute('tree_key'), "\\") + "\\;",
        index = clpsValue.indexOf(treeKeyFormatted);
      //this.addDbgMsg("remove node from " + field.name + " / value before remove: </pre>'" + field.value + "'</pre>");

      if (index != -1)  //then on list.  so need to remove it.
      {
        var newList = clpsValue.substring(0, index);
        newList += clpsValue.substring(index + treeKeyFormatted.length);
        field.value = newList;
        //this.addDbgMsg("remove node from " + field.name + ": '" + treeKeyFormatted + "' complete value: <pre>'" + field.value + "'</pre>");
      }
    }
  }


    /**
     *   nodeBelongsToLeftContainer
     */

  this.nodeIdBelongsToLeftContainer = function(rowID){
    if (rowID.substring(rowID.length - 1) == "l")
      return true;
    else
      return false;
  }

    /**
     *   rowWait
     */

  this.rowWait = function(row, table){
    this.addDbgMsg("rowWait " + row.id);
    var
      rowIndex = row.rowIndex + 1,
      cells = row.cells.length;
      cellCount = 0;

    treeRowsChangeStyle(row, "Open");
    table.insertRow(rowIndex);

    var waitingRow = table.rows[rowIndex];
    //the separator should not be copied ColumnTreeNodeLevel
    waitingRow.className = "ColumnTreeNodeLevel1";
    waitingRow.insertCell(0);

    if (this.nodeIdBelongsToLeftContainer(row.id)){
      //ie only - insert another cell because of dummy cell to fix ie scroll bug
      if (its_ua.ie55up && this.splitted){
        waitingRow.insertCell(0);
        cellCount++;
      }

      waitingRow.cells[cellCount].innerHTML=
        '<img class="ColumnTreeEmpty" style="height: 16px; width:' + ((eval(row.getAttribute('tree_level'))+1)*16) +
        '" src="' + treeCollection.settings.tree1x1 + '">' +
        '<img class="ColumnTreeWait" src="' + treeCollection.settings.tree1x1 + '">';
    }
    else{
      waitingRow.cells[0].innerHTML= "&nbsp;";
    }

    if (row.cells.length > 0){
      waitingRow.cells[cellCount].className=row.cells[0].className;
    }
    else{
        this.addDbgMsg("cell 0 does not exist.");
    }

    for (var i=1+cellCount; i<cells; i++)
    {
      waitingRow.insertCell(i); //he.pi crossbrowser added i
      waitingRow.cells[i].innerHTML="&nbsp;";
      waitingRow.cells[i].className = row.cells[i].className;
    }
    return true;
  }

    /**
     *   redoRowColorsOnExpand
     */

  this.redoRowColorsOnExpand = function(tree){

  //local changes must have been made to the tree table (the depth has possibly increased or decreased)
  // must redo background colors for visible tree table rows.
    this.dbgTStart("redoRowColorsOnExpand");

    var
      numOfNodeLevelClasses = 4, //there are only 4 different classes, change this if theme changes
      rows = tree.rows,
      numRows = rows.length,
      deepestLevel = 0,
      visibleNodes = new Array(),
      row,
      rowLevel,
      i;

    //find the level of the deepest visible node
    for ( i=0, j=0; i < numRows; i++)
    {
      row = rows.item(i);
      if ( row.className.indexOf( treeCollection.settings.suffixes.NODELEVEL_CLASS) != -1 ) //found a node in the tree
      {
        if (row.style.display!="none") // then a visible row
        {
          currentTreeLevel = row.getAttribute("tree_level");
          if (currentTreeLevel > deepestLevel)
            deepestLevel = currentTreeLevel;

          visibleNodes[j] = row;  //keep track of which nodes are visible so we don't have to refind them
          j++;
        }
      }
    }
    //from that depth change the background color of each row (keep other css selectors used there intact)
    var numberOfVisibleNodes = visibleNodes.length;
    for ( i=0; i < numberOfVisibleNodes; i++)
    {
      row = visibleNodes[i];
      rowLevel = row.getAttribute("tree_level");
      //do we also have to take care for a separator class?
      //search for double whitespace and replace with single whitespace, than split
      var classNames = row.className.replace(/\s+/," ").split(" ");
      if (deepestLevel > numOfNodeLevelClasses -1 && rowLevel < deepestLevel - numOfNodeLevelClasses + 1){ rowLevel = 1; }
      newLevel = 1 + parseInt(deepestLevel) - parseInt(rowLevel, 10);
      //replace node level selector without hurting other selectors
      row.className = row.className.replace(new RegExp(classNames[0]), treeCollection.settings.suffixes.NODELEVEL_CLASS + newLevel);

    }
    this.dbgTStop("redoRowColorsOnExpand");
  }


  /**
   *   leftScrollContHasHorizScrollbar
   *   scrollbar detection (true / false)
   */

  this.leftScrollContHasHorizScrollbar = function(){
    if (this.splitted)
      return (this.SCL.clientWidth  < this.SCL.scrollWidth);
    else{
      return false;
    }
  }

  /**
   *   leftScrollContHasVerticScrollbar
   *   scrollbar detection (true / false)
   */

  this.leftScrollContHasVerticScrollbar = function(){
    return (this.SCL.clientHeight < this.SCL.scrollHeight);
  }


  /**
   *   rightScrollContHasHorizScrollbar
   *   scrollbar detection (true / false)
   */

  this.rightScrollContHasHorizScrollbar = function(){
    return (this.SCR.clientWidth < this.SCR.scrollWidth);
  }

  /**
   *   rightScrollContHasVerticScrollbar
   *   scrollbar detection (true / false)
   */

  this.rightScrollContHasVerticScrollbar = function(){
    return (this.SCR.clientHeight < this.SCR.scrollHeight);
  }

  /**
   *   toggleHorizScrollbarInLeftContInMozilla
   *   mozilla only: check if left scrollcontainer doesn't need a
   *   horizontal scrollbar if bar is not needed change style
   */

  this.toggleHorizScrollbarInLeftContInMozilla = function(){
    if (its_ua.gecko && this.splitted){
      var className = "tree_node_scrollcontainer_left";
      if (!this.leftScrollContHasHorizScrollbar() ){
        className += "_noscroll"; //disable the presence of a horizontal scrollbar
      }
      this.SCL.className = className;
    }
  }

  /**
   *   resizeContainersInCaseOfUnevenHorizScrollbars
   *   check if only one of two scrollcontainers has got a horizontal scrollbar
   *   if this is the case, decrease height of the other scrollcontainer
   *   *** ONLY check this if splitted is true ***
   *   This belongs to scrollbarchecks
   */

  this.resizeContainersInCaseOfUnevenHorizScrollbars = function(){
    var
      newHeight,
      lSCHHS = this.leftScrollContHasHorizScrollbar(),
      rSCHHS = this.rightScrollContHasHorizScrollbar();

    //in case that only the left scrollcontainer has a horizontal scrollbar
    if (lSCHHS && !rSCHHS){
        //this.addDbgMsg("left scrollcontainer smaller because of horiz scrollbar ");
       this.SCR.style.height = treeSafeSubtraction(this.MCRCell.offsetHeight, treeCollection.settings.scrollBarHeight) + "px";
    }
    else if ( this.hasNodes && lSCHHS && rSCHHS && this.SCL.offsetHeight < this.MCLCell.offsetHeight){
        this.SCL.style.height = this.MCLCell.offsetHeight + "px";
    }
    //in case only the right container has a horizontal scrollbar
    else if ( this.hasNodes && !lSCHHS && rSCHHS){
//       this.addDbgMsg("right scrollcontainer smaller because of horiz scrollbar ");
       //step in here ONLY if tree has nodes
       this.SCL.style.height = treeSafeSubtraction(this.MCLCell.offsetHeight, treeCollection.settings.scrollBarHeight) + "px";
    }
  }

  /**
   *   careForVertScrollBarOnLastContainer
   */

  this.careForVertScrollBarOnLastContainer = function(){
    var
      _hasVerticScrollbar,
      _SC,
      _SCHeader,
      _SCVisibility = this.SCR.style.visibility,
      updateFirstHeaderColInnerDiv = false;

    //check if last scrollcontainer has got a vertical scrollbar

    if (_SCVisibility != "hidden"){
      _hasVerticScrollbar = this.rightScrollContHasVerticScrollbar();
      _SC = this.SCR;
      _SCHeader = this.HSCR;
    }
    else{
      _hasVerticScrollbar = this.leftScrollContHasVerticScrollbar();
      _SC = this.SCL;
      _SCHeader = this.HTL;  //left header hasn't got a scrollcontainer
      //also resize innerDiv in left header table to make sure the resize handle is aligned on the right
      if (this.hasHeader) updateFirstHeaderColInnerDiv = true;
    }

    if (_hasVerticScrollbar){
      // adjust right header scrollcontainer width
      if (this.hasHeader && _SC.offsetWidth >= treeCollection.settings.scrollBarHeight){
        _SCHeader.style.width = treeSafeSubtraction(_SCHeader.parentNode.offsetWidth, treeCollection.settings.scrollBarHeight) + "px";
        //if we work on left container: we now care for the col width of the hierarchy header column here
        if (updateFirstHeaderColInnerDiv) this.updateFirstHeaderColInnerDivWidth( treeSafeSubtraction(_SC.offsetWidth, treeCollection.settings.scrollBarHeight) );
      }

      //we know that we have a vertical scrollbar: decrease width of filling column
      //make last filling column narrower

      var gapForLastCol = this.SCR.offsetWidth - this.NTR.offsetWidth; // can be < 0
      if ( this.splitted && gapForLastCol > 0 && gapForLastCol <= treeCollection.settings.scrollBarHeight){
          this.resizeLastColumn( -(treeCollection.settings.scrollBarHeight + ((its_ua.ie55up)?-1:0)) );
      }
    }
    else if (this.hasHeader){
        //there is no vertical scrollbar, so we should resize everything accordingly

        // adjust right header scrollcontainer width
        if (_SC.offsetWidth >= treeCollection.settings.scrollBarHeight){
          _SCHeader.style.width = _SCHeader.parentNode.offsetWidth + "px";
        }
        //in splitted trees care about width of last column: make it wider
        if (this.splitted && _SCVisibility != "hidden"){
          //increase width of filling column and right header scrollcontainer
          //make last filling column wider
          var diff = this.SCR.parentNode.offsetWidth - this.NTR.offsetWidth;
          if (diff >= treeCollection.settings.scrollBarHeight)
            this.resizeLastColumn( treeCollection.settings.scrollBarHeight + ((its_ua.ie55up)?-1:0) );
          else if (diff >= 1){
            //this is to fit the tree in perfectly without creating a horizontal scrollbar without need (example: SAPCOLUMN_TREE_CONTOL_DEMO)
            this.resizeLastColumn( diff -1 );
          }
          else if (diff < 0){
            //this is to have padding on the right side of the last column (example: BCALV_TREE_VERIFY)
            //otherwise right aligned content is being cut off
            this.resizeLastColumn( 2 );
          }
        }
    }
  }

  /**
   *   resizeLastColumn
   *   (amount is a positive or negative pixel value, does only work on right container of splitted)
   */

    this.resizeLastColumn = function( amount ){

        var
          columnAmount = amount + this.lastColumn.offsetWidth,
          tableAmount  = amount + this.NTR.offsetWidth;

        if (columnAmount > 0 && tableAmount > 0){
            //node area
            this.lastColumn.style.width = columnAmount + "px";
            this.NTR.style.width        = tableAmount + "px";

            //header area
            this.lastHeaderColumn.style.width = columnAmount + "px";
            this.HTR.style.width              = tableAmount + "px";
            this.HSCR.style.width             = this.SCR.style.width;
        }
    }


  /**
   *   scrollBarChecks
   */

  this.scrollBarChecks = function(){
    if (its_ua.gecko)
      this.toggleHorizScrollbarInLeftContInMozilla();
    this.careForVertScrollBarOnLastContainer();
    if (this.splitted && this.SCR.style.visibility != "hidden"){
      this.resizeContainersInCaseOfUnevenHorizScrollbars();
    }
  }


  /**
   *   resizeRightScrollContainerIfAlone
   */

  this.resizeRightScrollContainerIfAlone = function(){

    if (!this.splitted){
      var
        safetyOffset = 0,
        maxCellWidth,
        newWidth;

      //he.pi there is no left scrollcontainer, the right scrollcontainer can be set to full width
      //CAUTION: Bug in Mozilla webgui coding? treeBorderDivParent width and height are only 20!!!!
      this.MT.style.width = this.TB.offsetWidth + "px";
      this.MT.style.height = this.TB.offsetHeight + "px";
      newWidth = treeSafeSubtraction( this.TB.offsetWidth, safetyOffset) + "px";
      if (this.hasNodes){
        this.MCRCell.style.width = newWidth; // info: a left cell does not exist in this case
        this.SCR.style.width     = newWidth;
      }
      if (this.hasHeader){
        this.HSCR.style.width    = newWidth;
        this.HTR.style.width     = newWidth;
        this.getfirstHeaderColInnerDiv().style.width = newWidth;
      }
      //display horizontal scrollbar? check if node table is wider than scrollContainer

      if ( this.singleColumnTreeMaxCellWidth === 0){
        maxCellWidth = this.getFirstColumnContentMaxWidth();
      }
      else{
        maxCellWidth = this.singleColumnTreeMaxCellWidth;
      }
      if (this.NTR.offsetWidth < maxCellWidth){
        //turn on scrollbar...
        this.NTR.style.width = maxCellWidth;
      }
      else if (this.SCR.offsetWidth > this.NTR.offsetWidth){
        this.NTR.style.width = "100%"; // this.SCR.offsetWidth;
      }

    }
  }


  /**
   *   getFirstColumnContentMaxWidth (only called by resizeRightScrollContainerIfAlone)
   */

  this.getFirstColumnContentMaxWidth = function(){

    this.dbgTStart("calcMaxColumnContentWidth");

    var maxCellWidth = 0,
      paddingSide,
      currentCellInlay,
      currentWidth,
      NTRows = this.NTR.rows,
      NTRowsLength = NTRows.length;

    //rtl aware padding check
    if (treeCollection.settings.rtlMode === "0") paddingSide= "paddingLeft";
    else paddingSide= "paddingRight";

    for (var z=0; z < NTRowsLength; z++){
      currentCellInlay = dom_getChildNodeByIndex(dom_getChildNodeByIndex(NTRows[z], 0), 0) ;
      if (currentCellInlay === null)
        break; //necessary for firefox when optimizetreesize is called onload
      currentWidth = currentCellInlay.offsetWidth + parseInt(currentCellInlay.parentNode.style[paddingSide]);
      if ( currentWidth > maxCellWidth)
        maxCellWidth = currentWidth;
    }
    //this.addDbgMsg("end of calcMaxColumnContentWidth, paddingSide:"+paddingSide+" result:" + maxCellWidth);
    this.dbgTStop("calcMaxColumnContentWidth");

    this.singleColumnTreeMaxCellWidth = maxCellWidth;
    return maxCellWidth + 10; //plus 10 safety buffer
  }

  /**
   *   setScrollContainerDimensions
   */

  this.setScrollContainerDimensions = function(){

    var headerHeight = 0;

    this.addDbgMsg("--- start of setScrollContainerDimensions ---");
    //get header datas if header exists

    if (this.HSCR){
      headerHeight = this.HSCR.offsetHeight;
    }

    //if tree is inside of a docker or splitter container we adjust width of containers using javascript

    var restHeight = this.TB.offsetHeight;
    var DS_ResizeEnabled = false;

    if (this.DS_isInside){
      if (this.DS_Cont.offsetWidth != this.TB.offsetWidth){
        //tree is too wide for container, we have to make it narrower
        this.TB.style.width = this.DS_Cont.offsetWidth + "px"; //this line is to avoid ugly design when border div is not resized by docker function
        DS_ResizeEnabled = true;
      }

      if (this.TB.offsetHeight < this.DS_Cont.offsetHeight){
        restHeight = treeSafeSubtraction(this.DS_Cont.offsetHeight, this.treeTop); //he.pi 20080724 fix for hidden horizontal scrollbar
      }
      this.TB.style.height = treeSafeSubtraction( this.DS_Cont.offsetHeight, this.treeTop) + "px"; //treeTop is from backend!
    }

    this.BGDiv.style.width = this.TB.offsetWidth + "px";
    this.BGDiv.style.height = this.TB.offsetHeight + "px";

    //calculate new height
    var newHeight = treeSafeSubtraction(restHeight, headerHeight +4 ); // 4... well... arbitrary

    if (this.hasNodes){
      //set height of right scrollcontainer
      this.SCR.style.height = newHeight + "px";
      if (this.splitted){
        this.resizesplitted(newHeight, DS_ResizeEnabled);
      }
      else{
        this.resizeRightScrollContainerIfAlone();
      }
    }
    this.addDbgMsg("--- end of setScrollContainerDimensions ---");
    if (treeCollection.settings.inDebugMode) this.resizeDebugDiv();
  }

  /**
   *   resizeScrContWidthIfInDockSplitCont
   *
   *   if the tree is inside of a docker or splitter container,
   *   it is probable that the visible space reserved for the tree
   *   can be changed by the user using the sash
   *   and we have to react to this
   */

  this.resizeScrContWidthIfInDockSplitCont = function( availableWidth ){

    var safetyArea = 0;
    if (its_ua.ie55up) safetyArea += 8; // he.pi 20060306 this does not seem to be necessary for ie in se80
    // security check: some containers have strange widths (zero! se80, tree 135), also check if container is wide enough
    if (availableWidth - safetyArea < 0)
      return;
    //we have to find out if left scrollcontainer fit's into the remaining space
    if (this.SCL.offsetWidth > availableWidth){
      //we must resize left scrollcontainer because it is wider as the container
      this.addDbgMsg("we must resize left scrollcontainer because it is wider as the container");
      this.SCL.style.width = treeSafeSubtraction(availableWidth, safetyArea) + "px";
      this.SCL.className = "tree_node_scrollcontainer_left_force_scroll"; // enable vertical scrollbar
    }
    else{
      this.addDbgMsg("left scrollcontainer fits into remaining space!!! ");
    }
    //is left scrollcontainer smaller than it should be? (because it may have been squeezed before...)
    //if it is smaller than the width of the first column we have to make it wider
    if (this.SCL_width <= availableWidth){
      this.addDbgMsg("we have enough space to set the left scrcont to its original width");

      this.MCL.style.width = this.SCL_width + "px";
      this.MCR.style.width = treeSafeSubtraction( availableWidth, this.SCL_width) + "px";
      this.MT.style.width  = availableWidth + "px";
    }
    else{
      //we use all space we can get for left scrollcontainer, but it will be narrower as original size
      this.addDbgMsg("we use all space we can get, but left scrollcontainer will be smaller as originally planned");
      this.MCL.style.width = this.SCL.style.width;
      this.MCR.style.width = treeSafeSubtraction( availableWidth, this.SCL.offsetWidth) + "px";
      this.MT.style.width  = availableWidth + "px";
      this.SCL.style.width = treeSafeSubtraction( availableWidth, safetyArea) + "px";
      //set left node table to original width if its width was increased before
      //(this should prevent useless horizontal scrollbar to come up in se80 in left scrollcont)
      if (this.NTL.offsetWidth > this.SCL_width){
        this.addDbgMsg("left node table was set to original width because it is too wide");
        this.NTL.style.width = this.SCL_width + "px";
      }
    }
    //adjust width of right scrollcontainer (and surrounding meta table) according to remaining space
    var remWidthForRightCont = availableWidth - this.SCL.offsetWidth - treeCollection.settings.minRightContainerWidth;
    if (remWidthForRightCont >= 0){
      this.addDbgMsg("right scrollcontainer can remain visible ( available width: " + remWidthForRightCont + ")");

      this.MCL.style.width     = treeSafeSubtraction( availableWidth, this.SCR.offsetWidth ) + "px";
      this.MCLCell.style.width = this.MCL.style.width;
      this.MCR.style.width     = this.SCR.style.width;
      this.MCRCell.style.width = this.SCR.style.width;
      this.MT.style.width      = availableWidth + "px";

      this.SCR.style.width = treeSafeSubtraction( availableWidth, this.SCL.offsetWidth) + "px";
    }
    else{
      //right scrollcontainer is visible but smaller as minimal width
      //that means we don't see the vertical scrollbar of right scrollcontainer, but we need a scrollbar
      //make right scrollcontainer invisible
      this.SCL.className = "tree_node_scrollcontainer_left_force_scroll"; // enable vertical scrollbar
      //increase width of left scrollcontainer to fill whole space and make right scrollcontainer invisible
      this.SCR.style.visibility  = "hidden";
      this.HSCR.style.visibility = "hidden";
      var newLeftScrContWidth    = treeSafeSubtraction( availableWidth, safetyArea );
      this.MCL.style.width       = newLeftScrContWidth;
      this.MCLCell.style.width   = newLeftScrContWidth;
      this.MCR.style.width       = "0px";
      this.MCRCell.style.width   = "0px";
      this.MT.style.width        = newLeftScrContWidth;
      this.SCL.style.width       = newLeftScrContWidth;
      //also resize innerDiv in left header table to make sure the resize handle is aligned on the right
      this.updateFirstHeaderColInnerDivWidth(newLeftScrContWidth);

      this.addDbgMsg("right scrollcontainer is now hidden / left scrcont width was increased if necessary");
    }
    this.HTL.style.width = this.SCL.offsetWidth + "px";
  }

  /**
   *   getfirstHeaderColInnerDiv
   */

      this.getfirstHeaderColInnerDiv = function(){
        var leftHeadercol;
        if (this.splitted)
          leftHeadercol = this.HTL.rows[0].firstChild;
        else
          leftHeadercol = this.HTR.rows[0].firstChild;
        while (leftHeadercol.tagName != "TD" && leftHeadercol.nextSibling)
          leftHeadercol = leftHeadercol.nextSibling;
        //get innerDiv element
        var innerDiv = leftHeadercol.firstChild;
        while (innerDiv.tagName != "DIV" && innerDiv.nextSibling)
          innerDiv = innerDiv.nextSibling;
        return innerDiv;
      }

  /**
   *   updateFirstHeaderColInnerDivWidth
   */

    this.updateFirstHeaderColInnerDivWidth = function( newValue ){
        this.getfirstHeaderColInnerDiv().style.width = treeSafeSubtraction(newValue, treeCollection.settings.innerDivOffset - 1 ); //compare template: colresize_area_width + 1;
    }

    /**
     *   resizesplitted
     */

  this.resizesplitted = function(newHeight, DS_ResizeEnabled){

    if (its_ua.ie55up){
      offsetIE = treeCollection.settings.scrollBarHeight; //MSIE only
    }
    else{
      offsetIE = 0;
    }


    //right container might be hidden from last time, we make it visible again
    this.SCR.style.visibility = "visible";
    if (this.hasHeader){
      this.HSCR.style.visibility = "visible";
    }

    //disable vertical scrollbar on left scrollcontainer that might be enabled
    if (this.SCL.className != "tree_node_scrollcontainer_left_noscroll"){ //mozilla only gets ..._noscroll
      this.SCL.className = "tree_node_scrollcontainer_left";
    }

    // if the two meta table cells are wider than the treeborderdiv correct this:
    //take away the width from right meta table cell and right scrollcontainer, left scrollcontainer stays as it is

    //********************************
    // CORRECT WIDTH if necessary
    //********************************

    //check if dimensions are ok
    if (this.MCLCell.offsetWidth + this.MCRCell.offsetWidth != this.MT.offsetWidth){
      this.MCLCell.style.width = this.MCLCell.offsetWidth + "px";
      this.MCL.style.width = this.MCLCell.offsetWidth + "px";
      this.MCR.style.width = this.MCRCell.offsetWidth + "px";
    }

    if (this.MT.offsetWidth > this.TB.offsetWidth){

      newWidth = treeSafeSubtraction( this.TB.offsetWidth, this.MCL.offsetWidth) ;//- treeCollection.settings.scrollBarHeight;
      this.HSCR.style.width = newWidth + "px";
      this.SCR.style.width = this.HSCR.style.width;

     //we want right column to be resized even if there is no space for it
      if (newWidth > 0){
        this.MCR.style.width = treeSafeSubtraction( this.TB.offsetWidth, this.MCL.offsetWidth) + "px";
        this.MT.style.width = this.TB.offsetWidth + "px";
      }
      else{
        this.addDbgMsg("right meta column is set to 0 now.");
        this.MCR.style.width = "0px";
        this.MT.style.width = this.MCL.offsetWidth + "px";
      }
    }
    else if (this.TB.offsetWidth >= this.SCL_width){
      this.addDbgMsg("meta table cells are too small ");
      //check if available area is wide enough to size left column to full size

      rightWidth = treeSafeSubtraction(this.TB.offsetWidth, this.SCL_width) + "px";
      leftWidth  = this.SCL_width + "px";

      this.MT.style.width            = this.TB.offsetWidth + "px";

      this.MCLCell.style.width   = leftWidth;
      this.MCL.style.width       = leftWidth;
      this.HTL.style.width       = leftWidth;
      this.SCL.style.width       = leftWidth;

      //also resize innerDiv in left header table to make sure the resize handle is aligned on the right
      this.updateFirstHeaderColInnerDivWidth(this.HTL.offsetWidth);

      this.MCRCell.style.width  = rightWidth;
      this.MCR.style.width      = rightWidth;
      this.HTR.style.width      = rightWidth;
      this.HSCR.style.width     = rightWidth;
      this.SCR.style.width      = rightWidth;
    }
    else{
      this.addDbgMsg("widths of scrollcont and metacells were ok and weren't changed");
    }

    //********************************
    // CORRECT HEIGHT if necessary
    //********************************

    if (newHeight === null || newHeight < offsetIE)
      newHeight = offsetIE;
    //set height of left scrollcontainer (right scrollcontainer height was changed before)
    this.SCL.style.height = newHeight + "px";
    this.MT.style.height   = treeSafeSubtraction (newHeight, offsetIE) + "px"; //IE for ppose

    if (this.nodeHeightIndication === 0 || this.syncRowHeightsNeeded())
      this.syncRowHeights(); //syncRowHeights should be called before we call careForVertScrollBarOnLastContainer

    //********************************
    // End of HEIGHT CORRECTION
    //********************************

    //sync vertical scroll position between scroll containers (this should happen after heights were corrected)
    this.SCR.scrollTop = this.SCL.scrollTop;
    this.SCL.style.width = this.SCL_width + "px";

    //additional check for msie where first check is not enough
    if (DS_ResizeEnabled === false && this.DS_isInside && (this.DS_Cont.offsetWidth < this.SCL.offsetWidth + this.SCR.offsetWidth)){
      //tree is too wide for container, we have to make it narrower
      DS_ResizeEnabled = true;
    }

    // resize widths of scrollcontainers if surrounding splitter / docker container has different size
    if (DS_ResizeEnabled && this.hasNodes){
      this.resizeScrContWidthIfInDockSplitCont( this.DS_Cont.offsetWidth );
    }
    else{
      //adjust widths of scrollcontainers: if they are narrower than their parents (meta table cells)
      //the scrollcontainers are set to the same widths
      //(this is necessary after widths were adjusted by js before, to have enough space for scrollbars)

      if (this.SCL.offsetWidth < this.SCL.parentNode.offsetWidth){
        this.SCL.style.width = this.SCL.parentNode.offsetWidth + "px";
        this.HTL.style.width = this.SCL.parentNode.offsetWidth + "px";
      }
      if (this.SCR.offsetWidth < this.SCR.parentNode.offsetWidth){
        this.SCR.style.width = this.SCR.parentNode.offsetWidth + "px";
        this.HSCR.style.width = this.SCR.parentNode.offsetWidth + "px";
      }
    }

    if (this.SCR.style.visibility != "hidden"){
      //if right scrollcontainer is too narrow to display scrollbars increase widths of containers to minimal possible width
      //we take away from width of left scrollcontainer and give to width of right scrollcontainer

      var diff = treeCollection.settings.minRightContainerWidth - this.SCR.offsetWidth; // can be < 0
      var newLeftWidth = treeSafeSubtraction( this.SCL.offsetWidth, diff);

      if (diff > 0 &&  newLeftWidth >= treeCollection.settings.minRightContainerWidth){
        //resize scrollcontainers

        //also resize innerDiv in left header table to make sure the resize handle is aligned on the right
        this.updateFirstHeaderColInnerDivWidth(newLeftWidth); //compare template: colresize_area_width + 1;

        this.SCL.style.width     = newLeftWidth + "px";
        this.HTL.style.width     = newLeftWidth + "px";
        this.MCL.style.width     = newLeftWidth; //we shouldn't use style and px here because this is a col-tag
        this.MCLCell.style.width = newLeftWidth + "px"; // this is mandatory

        this.SCR.style.width     = treeCollection.settings.minRightContainerWidth + "px";
        this.HSCR.width          = treeCollection.settings.minRightContainerWidth; //we don't use style and px here because this is a col-tag
        this.MCR.style.width     = treeCollection.settings.minRightContainerWidth + "px";
        this.MCRCell.style.width = treeCollection.settings.minRightContainerWidth + "px"; // this is mandatory

      }
      //adjust right node + header table width (and width of last filling column)
      //if right scrollcontainer is wider or smaller as the right main table
      safetyArea = 0;
      if (this.TB.offsetWidth - this.MCL.offsetWidth >0){
        this.MCR.style.width = this.TB.offsetWidth - this.MCL.offsetWidth + "px"; //moz needs +1 for dwdm, what about ie?
        this.MT.style.width = this.TB.offsetWidth + "px";
      }

      diff = this.SCR.offsetWidth - this.NTR.offsetWidth - treeCollection.settings.scrollBarHeight;
      if (diff !== 0){
        this.addDbgMsg("diff != 0");
        //hack to prevent vert scrollbar to be displayed completely if docking sash moved to left (dwdm)
        safetyArea = 1;
        if (diff < -treeCollection.settings.scrollBarHeight){
          safetyArea += 1;
          this.addDbgMsg("safetyArea + 1 ");
        }
        var newLastColumnWidth = treeSafeSubtraction( this.lastColumn.offsetWidth + diff, safetyArea);
        this.lastColumn.style.width = newLastColumnWidth + "px";
        this.addDbgMsg("lastColumn width = " + newLastColumnWidth + " / safety area = " + safetyArea);

        var newNTWidth = treeSafeSubtraction( this.SCR.offsetWidth, treeCollection.settings.scrollBarHeight + safetyArea);

        this.NTR.style.width = newNTWidth + "px";
        this.lastHeaderColumn.style.width = newLastColumnWidth + "px";
        this.HTR.style.width = newNTWidth + "px";
      }

      this.scrollBarChecks();


    } //endif this.SCR.style.visibility != "hidden"
    else{
      this.careForVertScrollBarOnLastContainer();
    }

    //increase width of left node table if smaller as left scrollcontainer (needed for se80)
    //he.pi 20060303 this has to be at the end of all operations with this.SCL.offsetWidth
    if (wgu_parseIntelligent2( this.NTL, "w") < wgu_parseIntelligent2( this.SCL, "w")){
       if (its_ua.gecko) mozOffset = -1;
       else mozOffset = 0;
       this.NTL.style.width = this.SCL.offsetWidth + mozOffset + "px"; // -1 here was no good for ie
    }
  }

  /**
   *   copyNodeAttributes (sourceNode, targetNode)
   */

  this.copyNodeAttributes = function(sourceNode, targetNode){
    for (var attr = 0; attr < sourceNode.attributes.length; attr++){
      targetNode.setAttribute( sourceNode.attributes[attr].name, sourceNode.attributes[attr].nodeValue );
    }
  }

  /**
   *  getNextNode
   */

  this.getNextNode = function(currentNode){

    while (currentNode.nextSibling){
      currentNode = currentNode.nextSibling;
      if (currentNode.nodeType == 1 && currentNode.tagName == "TR" ){
        return currentNode;
      }
    }
    return false;
  }

    /**
     *   getOppositeId
     */

  this.getOppositeId = function (id){
    if (id.substring(id.length-1) == "r")
      id = id.substr(0, id.length-1) + "l";
    else
      id = id.substr(0, id.length-1) + "r";
    return id;
  }

    /**
     *   pasteNewTreeDataRows_classic
     *   creating new rows in node table manually and copy cells and cell attributes one by one to visible tree
     *   this was once designed to work in ie 6 and ff 2
     */

  this.pasteNewTreeDataRows_classic = function( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset ){
    this.dbgTStart("pasteNewTreeDataRows_classic");
    var
      oldNTBody = null,
      NTChild = oldNT.firstChild,  //only needed for "get body of old table"
      NLRegEx = /ColumnTreeNodeLevel(\d)/,
      R,
      cells,
      numberOfCells,
      copiedRows = 0,
      NN = newTreeDoc.getElementById(this.ECData.rowid),
      oldTreeExpandedNode = document.getElementById(this.ECData.rowid),
      oldTreeHourglassRow = this.getNextNode(oldTreeExpandedNode),
      repaintNodeSelection = false,
      z;

    //get body of old table
    while( NTChild && oldNTBody === null){
      oldNTBody = (NTChild.tagName == "TBODY") ? NTChild : null;
      NTChild = NTChild.nextSibling;
    }

    //check if node was selected before and store this info
    if (this.isNodeSelected( oldTreeExpandedNode )){
        repaintNodeSelection = oldTreeExpandedNode.id;
    }

    //delete hourglass row
    oldNTBody.removeChild( oldTreeHourglassRow );

    if (numberOfNewNodes > 0){

      //delete expanded node
      oldNTBody.removeChild( oldTreeExpandedNode );

      //update tree row colors if necessary
      if (nodeLevelOffset !== 0){
        var oldNTRows = oldNT.rows;
        for (z = 0; z < oldNTRows.length ; z++){
            var currentRow = oldNTRows[z];
            NLRegEx.exec(currentRow.className);
            var currentNodeLevel = RegExp.$1;
            var newNodeLevel = parseInt(RegExp.$1) + nodeLevelOffset;
            if (newNodeLevel < 1) newNodeLevel = 1;
            else if (newNodeLevel > 4) newNodeLevel = 4;
            oldNTRows[z].className = currentRow.className.replace( NLRegEx, treeCollection.settings.suffixes.NODELEVEL_CLASS + newNodeLevel );
        }
      }

      this.dbgTAverageInit("PASTECELLS");
      while ( copiedRows < numberOfNewNodes ){
        cells = NN.cells;
        numberOfCells = cells.length;
        R = oldNT.insertRow( this.ECData.nodeRowNumber + copiedRows); //create new TR node in old tree
        if (its_ua.gecko)
          this.copyNodeAttributes(NN, R);
        else{
          //in case of msie we can't use copyNodeAttributes because it will copy all default attributes
          //and slow things down.
          // tree_state, tree_key, tree_level, tree_class, id, class, abapddid
          R.className = NN.className;
          R.setAttribute( "id"         , NN.getAttribute("id"));
          R.setAttribute( "tree_state" , NN.getAttribute("tree_state"));
          R.setAttribute( "tree_key"   , NN.getAttribute("tree_key"));
          R.setAttribute( "tree_level" , NN.getAttribute("tree_level"));
          R.setAttribute( "tree_class" , NN.getAttribute("tree_class"));
          if (NN.getAttribute("abapddid") != null)
            R.setAttribute( "abapddid"   , NN.getAttribute("abapddid"));
        }

        for (z = 0; z < numberOfCells; z++){
          this.dbgTAverageStart("PASTECELLS");
          var
            C = R.insertCell(z),
            currCell = NN.cells[z];
          if (its_ua.gecko){
            this.copyNodeAttributes(currCell, C);
          }
          else{
            //nowrap, style, class
            C.setAttribute( "nowrap", currCell.getAttribute("nowrap"));
            C.style.cssText = currCell.style.cssText;
            C.className = currCell.className;
          }
          C.innerHTML = currCell.innerHTML;

          this.dbgTAverageStop("PASTECELLS");
        }

        NN = this.getNextNode(NN);
        copiedRows++;
      }
      if (repaintNodeSelection !== false){
        this.markNodeAsSelected( document.getElementById( repaintNodeSelection), true );
      }
    }
    this.dbgTAverageResults("PASTECELLS");
    this.dbgTStop("pasteNewTreeDataRows_classic");
  }

    /**
     *   pasteNewTreeDataRows
     *   Note: This approach doesn't seem to work with Internet Explorer 6 and 7 (insertBefore causes javascript error)
     */

  this.pasteNewTreeDataRows = function( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset ){
    this.dbgTStart("pasteNewTreeDataRows");
    var
      oldNTBody = null,
      NTChild = oldNT.firstChild,  //only needed for "get body of old table"
      NLRegEx = /ColumnTreeNodeLevel(\d)/,
      R,
      cells,
      numberOfCells,
      copiedRows = 0,
      NN = newTreeDoc.getElementById(this.ECData.rowid),
      oldTreeExpandedNode = document.getElementById(this.ECData.rowid),
      oldTreeHourglassRow = this.getNextNode(oldTreeExpandedNode),
      repaintNodeSelection = false,
      z;

    //get body of old table
    while( NTChild && oldNTBody === null){
      oldNTBody = (NTChild.tagName == "TBODY") ? NTChild : null;
      NTChild = NTChild.nextSibling;
    }

    //check if node was selected before and store this info
    if (this.isNodeSelected( oldTreeExpandedNode )){
        repaintNodeSelection = oldTreeExpandedNode.id;
    }

    //delete hourglass row
    oldNTBody.removeChild( oldTreeHourglassRow );

    if (numberOfNewNodes > 0){

      //delete expanded node
      oldNTBody.removeChild( oldTreeExpandedNode );

      //update tree row colors if necessary
      if (nodeLevelOffset !== 0){
        var oldNTRows = oldNT.rows;
        for (z = 0; z < oldNTRows.length ; z++){
            var currentRow = oldNTRows[z];
            NLRegEx.exec(currentRow.className);
            var currentNodeLevel = RegExp.$1;
            var newNodeLevel = parseInt(RegExp.$1) + nodeLevelOffset;
            if (newNodeLevel < 1) newNodeLevel = 1;
            else if (newNodeLevel > 4) newNodeLevel = 4;
            oldNTRows[z].className = currentRow.className.replace( NLRegEx, treeCollection.settings.suffixes.NODELEVEL_CLASS + newNodeLevel );
        }
      }

      //this.addDbgMsg("pasteNewTreeDataRows - begin copy rows");

      while ( copiedRows < numberOfNewNodes ){

        var hook = this.ECData.nodeRowNumber + copiedRows;
        if (hook < oldNT.rows.length){
            oldNTBody.insertBefore( NN.cloneNode(true), oldNT.rows[hook]);
        }
        else if (hook == oldNT.rows.length) {
            oldNTBody.appendChild( NN.cloneNode(true) );
        }

        //this.addDbgMsg("pasteNewTreeDataRows - end copy cells");

        NN = this.getNextNode(NN);
        copiedRows++;
      }
      //this.addDbgMsg("pasteNewTreeDataRows - end copy rows");

      if (repaintNodeSelection !== false){
        this.markNodeAsSelected( document.getElementById( repaintNodeSelection), true );
      }
    }
    this.dbgTStop("pasteNewTreeDataRows");
  }

    /**
     *   pasteNewTreeDataRows_fullfragment
     *   replaces the full contents of the scroll containers, uses document fragment to copy all nodes to.
     *   Note: This method only works if the complete tree data is available within the data request
     */
/*
  this.pasteNewTreeDataRows_fullfragment = function( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset ){
    this.dbgTStart("pasteNewTreeDataRows_fullfragment");

    //work on an invisible representation of node table
    var tempNTFragment = document.createDocumentFragment();
    tempNTFragment.appendChild( oldNT.cloneNode(true) );
    var tempNT = tempNTFragment.firstChild;

    var
      tempNTBody = null,
      NTChild = tempNT.firstChild,  //only needed for "get body of old table"
      NLRegEx = /ColumnTreeNodeLevel(\d)/,
      R,
      cells,
      numberOfCells,
      copiedRows = 0,
      NN = newTreeDoc.getElementById(this.ECData.rowid),
      oldTreeExpandedNode = document.getElementById(this.ECData.rowid),
      oldTreeHourglassRow = this.getNextNode(oldTreeExpandedNode),
      repaintNodeSelection = false,
      z;

    //get body of old table
    while( NTChild && tempNTBody === null){
      tempNTBody = (NTChild.tagName == "TBODY") ? NTChild : null;
      NTChild = NTChild.nextSibling;
    }

    //check if node was selected before and store this info
    if (this.isNodeSelected( oldTreeExpandedNode )){
        repaintNodeSelection = oldTreeExpandedNode.id;
    }

    //delete hourglass row
    tempNTBody.removeChild( tempNT.rows[this.ECData.nodeRowNumber + 1] );

    if (numberOfNewNodes > 0){

      //delete expanded node
      tempNTBody.removeChild( tempNT.rows[this.ECData.nodeRowNumber ] );

      //update tree row colors if necessary
      if (nodeLevelOffset !== 0){
        var tempNTRows = tempNT.rows;
        for (z = 0; z < tempNTRows.length ; z++){
            var currentRow = tempNTRows[z];
            NLRegEx.exec(currentRow.className);
            var currentNodeLevel = RegExp.$1;
            var newNodeLevel = parseInt(RegExp.$1) + nodeLevelOffset;
            if (newNodeLevel < 1) newNodeLevel = 1;
            else if (newNodeLevel > 4) newNodeLevel = 4;
            tempNTRows[z].className = currentRow.className.replace( NLRegEx, treeCollection.settings.suffixes.NODELEVEL_CLASS + newNodeLevel );
        }
      }

      //this.addDbgMsg("pasteNewTreeDataRows - begin copy rows");

      while ( copiedRows < numberOfNewNodes ){

        //FIXME: We need appendChild for last node in tree!
        //tempNTBody.appendChild( NN.cloneNode(true) );
        tempNTBody.insertBefore( NN.cloneNode(true), tempNT.rows[this.ECData.nodeRowNumber + copiedRows]);

        //this.addDbgMsg("pasteNewTreeDataRows_fullfragment - end copy cells");

        NN = this.getNextNode(NN);
        copiedRows++;
      }
      //this.addDbgMsg("pasteNewTreeDataRows_fullfragment - end copy rows");
      oldNT.parentNode.replaceChild(tempNT, oldNT);
      tempNTFragment = null;

      if (repaintNodeSelection !== false){
        this.markNodeAsSelected( document.getElementById( repaintNodeSelection), true );
      }
    }
    this.dbgTStop("pasteNewTreeDataRows_fullfragment");
  }
*/

  /**
   *   pasteNewTreeData_replaceHeaders
   */

  this.pasteNewTreeData_replaceHeaders = function( newTreeDoc ){
    //work on an invisible representation of tree header tables
    if (!its_ua.ie7 && !its_ua.ie6){
      var tempHeaderFragment = document.createDocumentFragment();
      tempHeaderFragment.appendChild( newTreeDoc.getElementById( treeCollection.settings.suffixes.RIGHT_HEADER_TABLE + this.id) );
      this.HTR.parentNode.replaceChild( tempHeaderFragment.firstChild, this.HTR );
      //now refresh pointer after replace
      this.HTR = document.getElementById( treeCollection.settings.suffixes.RIGHT_HEADER_TABLE + this.id );

      if (this.splitted){
        tempHeaderFragment.appendChild( newTreeDoc.getElementById( treeCollection.settings.suffixes.LEFT_HEADER_TABLE + this.id) );
        this.HTL.parentNode.replaceChild( tempHeaderFragment.firstChild, this.HTL );
        //now refresh pointer after replace
        this.HTL = document.getElementById( treeCollection.settings.suffixes.LEFT_HEADER_TABLE + this.id );
      }
      tempHeaderFragment = null;
    }
  }

 /**
  *   pasteNewTreeDataRows_redirect
  */

  this.pasteNewTreeDataRows_redirect = function( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset ){
    if (its_ua.ie6 || its_ua.ie7)
      this.pasteNewTreeDataRows_classic( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset );
    else
      this.pasteNewTreeDataRows( newTreeDoc, newNT, oldNT, numberOfNewNodes, nodeLevelOffset );
  }

  /**
   *   pasteNewTreeData
   *   this is called from iframe that provides the loaded tree data
   */

  this.pasteNewTreeData = function( newTreejsName){

    var overAllTimeNeeded = this.dbgTStop("expClickPostURL");
    this.dbgTStart("PasteNewTreeData");

    if (!this.nodeIdBelongsToLeftContainer(this.ECData.rowid)){
      this.ECData.rowid = this.getOppositeId( this.ECData.rowid );
      if (this.ECData.nextNodeId)
        this.ECData.nextNodeId = this.getOppositeId( this.ECData.nextNodeId );
      this.addDbgMsg("this.ECData.id's were changed from  right to left");
    }
    else{
      this.addDbgMsg("this.ECData.rowid is on left container : " + this.ECData.rowid + " / " + this.ECData.nextNodeId);
    }

    var
      treeDataIframe            = (typeof wguObjFrame === 'function') ? new wguObjFrame("treeData") : new its_accessIframe("treeData"),
      newTreeDoc                = treeDataIframe.doc,
      startNode                 = newTreeDoc.getElementById(this.ECData.rowid),
      endNode                   = newTreeDoc.getElementById(this.ECData.nextNodeId),
      currentNode               = null,
      numberOfNewNodes          = 0,
      nodesGainedpercentage     = null,
      newNTRight     = newTreeDoc.getElementById( treeCollection.settings.suffixes.RIGHT_MAINTABLE + this.id),
      newNTRightRows = newNTRight.rows,
      newTreeNumberOfRows       = newNTRightRows.length,
      NLRegEx                   = /ColumnTreeNodeLevel(\d)/;

    if (this.splitted){
      var newNTLeft = newTreeDoc.getElementById( treeCollection.settings.suffixes.LEFT_MAINTABLE + this.id);
    }

    //try to preserve the scrolltop position

    if (this.hasNodes)
      scrollTopBeforePaste = this.SCR.scrollTop;
    else
      scrollTopBeforePaste = 0;

    //determine how many new nodes the tree has gained

    //count number of rows to be inserted
    //endNode can be null if expanderClickData.rowid was the last line in the tree

    currentNode = startNode;
    while (currentNode){
      if (currentNode.nodeType == 1 && currentNode.tagName == "TR" ){
        //this.addDbgMsg (currentNode.id + " / " + endNode.id);
        numberOfNewNodes++;
      }
      currentNode = currentNode.nextSibling;
      if (endNode && currentNode == endNode) break;
    }

    if (endNode  && currentNode != endNode){
      this.addDbgMsg("<b>ERROR</b>: nodeid " + this.ECData.nextNodeId + " was not found in newTreeDoc!");
      return;
    }

    if (numberOfNewNodes > 0){
      this.hasNodes = true;
      //calculate the percentage of how much content the tree has gained
      if (this.nodeCount > 0){
        nodesGainedpercentage = numberOfNewNodes * 100 / this.nodeCount;
      }
      this.nodeCount += numberOfNewNodes -1; // this calculation needs -1 because the parent node has to be redrawn, but is replaced and not new!!!
    }


    //check if tree row colors have to be updated
    NLRegEx.exec(startNode.className);
    newTreeStartClassNodeLevel = RegExp.$1;
    NLRegEx.exec(document.getElementById(this.ECData.rowid).className);
    oldTreeStartClassNodeLevel = RegExp.$1;
    this.addDbgMsg("nodeLevels new/old = " + newTreeStartClassNodeLevel + "/" + oldTreeStartClassNodeLevel);
    var nodeLevelOffset = newTreeStartClassNodeLevel - oldTreeStartClassNodeLevel;
    var focusBackupId = null;
    this.addDbgMsg("pastenewtreedata: focus is now being backupped.");
    if (this.elementFocus && this.elementFocus.id)
        focusBackupId = this.elementFocus.id;
    else
      this.addDbgMsg("pastenewtreedata: focus backup problem - id not found.");

    if (this.hasHeader){
      //replace header with new header
      this.pasteNewTreeData_replaceHeaders( newTreeDoc );

    }

      if (this.splitted){
        // care for right node table
        this.ECData.rowid = this.getOppositeId( this.ECData.rowid );
        //this.ECData.nextNodeId = this.getOppositeId( this.ECData.nextNodeId );
        this.addDbgMsg('pasteNewTreeData : right node table' );
        this.pasteNewTreeDataRows_redirect(newTreeDoc, newNTRight, this.NTR, numberOfNewNodes, nodeLevelOffset);
        // care for left node table
        this.ECData.rowid = this.getOppositeId( this.ECData.rowid );
        //this.ECData.nextNodeId = this.getOppositeId( this.ECData.nextNodeId );
        this.addDbgMsg('pasteNewTreeData : left node table' );
        this.pasteNewTreeDataRows_redirect(newTreeDoc, newNTLeft, this.NTL, numberOfNewNodes, nodeLevelOffset);
      }
      else{
        // care for right node table
        this.addDbgMsg('pasteNewTreeData : single node table' );
        this.pasteNewTreeDataRows_redirect(newTreeDoc, newNTRight, this.NTR, numberOfNewNodes, nodeLevelOffset);
      }

      //this.NTR and this.NTL now may point to a non-existant node, refresh them
      this.isInitial = true;
      this.init();

      if (this.nodeHeightIndication === 0 || this.syncRowHeightsNeeded())
        this.syncRowHeights();
      this.scrollBarChecks();//in case adding new rows might trigger a vertical scroll bar we have to resize last column

    /* since latest performance optimization, pasteWholeTree can't be true any more
       this is the old pasteWholeTree handling
    else{

      // pasteWholeTree is true

      //preparations for restoring node selection on init
      if (typeof this.MT.selectedRowsList !== 'undefined'){
        this.rowSelectOnInit = new Array();
        for (z = 0; z < this.MT.selectedRowsList.length; z++){
            this.registerSelectedRow( this.MT.selectedRowsList[z].getAttribute('tree_key') );
            this.addDbgMsg('pasteNewTreeData : restore selected tree node ' + this.MT.selectedRowsList[z].id );
        }
      }
      else{
        this.addDbgMsg('pasteNewTreeData : no selected tree nodes to restore');
      }
      //preparations for restoring item selection on init
      if ( typeof this.MT.selection === 'object' ){
        this.registerSelectedItemName( this.MT.selection.key + "::" + this.MT.selection.item );
        this.addDbgMsg('pasteNewTreeData : selected tree item restored');
      }
      else{
        this.addDbgMsg('pasteNewTreeData : no selected tree item to restore');
      }

      this.clearHiddenLists(); //clear collapsewithdata information because it is now obsolete (in case of pasteWholeTree)
      //he.pi 20050114 crossbrowser: W3C replaceChild does not work correctly within IE in our case - don't know why
      //firefox 3 requires importNode, see http://developer.mozilla.org/en/docs/Gecko_1.9_Changes_affecting_websites#WRONG_DOCUMENT_ERR
      var newNTRightImported = its_ua.gecko ? document.importNode(newNTRight, true) : newNTRight;
      if (its_ua.ie6 || its_ua.ie7)
        this.NTR.outerHTML = newNTRight.outerHTML;
      else{
        this.NTR.parentNode.replaceChild( newNTRightImported, this.NTR);
        //now refresh pointer after replace
        this.NTR  = document.getElementById( treeCollection.settings.suffixes.RIGHT_MAINTABLE + this.id );
      }
      if (this.splitted){
        //firefox 3 requires importNode, see http://developer.mozilla.org/en/docs/Gecko_1.9_Changes_affecting_websites#WRONG_DOCUMENT_ERR
        var newNTLeftImported = its_ua.gecko ? document.importNode(newNTLeft, true) : newNTLeft;
        if (its_ua.ie6 || its_ua.ie7)
          this.NTL.outerHTML = newNTLeft.outerHTML;
        else{
          this.NTL.parentNode.replaceChild( newNTLeftImported, this.NTL);
          //now refresh pointer after replace
          this.NTL = document.getElementById( treeCollection.settings.suffixes.LEFT_MAINTABLE + this.id);¶
        }
      }

      // refresh init and selection after pasting whole tree
      this.isInitial = true;
      this.init();
      this.DS_OldDim = null; // to force optimizeTreeSize to be executed
      this.optimizeTreeSize();

      //restore ScrollTop
      if (this.hasNodes){
      this.SCR.scrollTop = scrollTopBeforePaste;
      if (this.splitted)
        this.SCL.scrollTop = scrollTopBeforePaste;
      }
    }
    */

    //restore focussed element, works even after whole tree has been replace
    if (focusBackupId !== null)
        this.elementFocus = document.getElementById(focusBackupId);
    this.setFocusOnClosestElementWithTabindex();

    window.webguiResetForm();

    this.jsName = newTreejsName;

    // treeClearHiddenFields
    //he.pi topnodekey field is not included here! is that correct????

/*
    for (formField in this.formfields){
      this.formfields[formField].value = "";
    }
*/
    //this.addDbgMsg("pasteNewTreeData: triggering webguisetavailable");
    //if (webguiIsBusy) //this if clause doesn't work in FF, so let's leave it away
    //  webguiSetAvailable();

    var expanderClickURLTimeNeeded = overAllTimeNeeded;
    overAllTimeNeeded += this.dbgTStop("PasteNewTreeData");

    treeCollection.settings.inDebugMode ? this.addDbgMsg(
      "PasteNewTreeData statistics:" +
      "<br>numberOfNodes : " + (this.nodeCount - numberOfNewNodes) + " + <b>" + numberOfNewNodes + "</b> = " + this.nodeCount +
      " (" + parseInt(nodesGainedpercentage + 0.5) + "%)" +
      "<br>expanderClickURLTimeNeeded = <b>" + expanderClickURLTimeNeeded + "ms</b>" +
      "<br>overAllTimeNeeded for expand = <b>" + overAllTimeNeeded + "ms</b>" +
      "<br>" + (this.formfields.reExpandedCollapsedNodes ?
          "locally reExpandedCollapsedNodes: <span style=\"font-family:monospace;\">'" + this.formfields.reExpandedCollapsedNodes.value + "'</span>" :
          "form field reExpandedCollapsedNodes does not exist"
      ) +
      "<br>" + (this.formfields.collapsedNodes ?
          "locally collapsedNodes: <span style=\"font-family:monospace;\">'" + this.formfields.collapsedNodes.value + "'</span>" :
          "form field collapsedNodes does not exist"
      )
    ):null;

  }

   /**
    *   Scrolls the tree vertically to make the TopNodeKey visible.
    *   This is called by onload function.
    *   We care for the case that topnodekeyitem was not set in context when
    *   showing a tree for the first time (this would mean an error in itscoltreei.cpp !
    *   (this is a potential fix for pz26_new)
    */

    this.scrollToTopNodeKey = function(){
        if (this.hasNodes){
            if (this.topNodeKeyItem === "" || this.topNodeKeyItem === null || document.getElementById(this.topNodeKeyItem) === null){
                this.setTopNodeKey();
            }

            if (this.topNodeKeyItem){
                var tnk = document.getElementById(this.topNodeKeyItem);
                if (tnk) {
                    this.addDbgMsg("TOPNODEKEY: scrollToTopNodeKey is scrolling to position:" + tnk.offsetTop);
                    this.SCR.scrollTop = tnk.offsetTop;
                    if (this.SCL) this.SCL.scrollTop = tnk.offsetTop;
                    this.setTopNodeKey(); //dangerous if finalsizehandler is called several times, will overwrite value
                    this.topNodeKeyWasPreserved = true;
                }
                else{
                    this.addDbgMsg("TOPNODEKEY: scrollToTopNodeKey, error: this.topNodeKeyItem = '" + this.topNodeKeyItem + "' is undefined.");
                }
            }
        }
    }


  /**
   *   setFocusOnClosestElementWithTabindex
   */

   this.setFocusOnClosestElementWithTabindex = function(){
      this.addDbgMsg("setFocusOnClosestElementWithTabindex - begin");

      //nodeType check prevents errors while clicking on items in right container
      if (this.elementFocus && this.elementFocus.nodeType == 1){
        this.addDbgMsg('setFocusOnClosestElementWithTabindex : trying to set focus correctly.');
        var oldFocusElement = this.elementFocus;
        while (
                (this.elementFocus) &&
                (this.elementFocus.nodeType == 9) &&
                (typeof this.elementFocus.getAttribute('tabindex') == 'object') &&
                (this.elementFocus.getAttribute('tabindex') == null)
        ){
          this.elementFocus = this.elementFocus.parentNode;
        }
        if (this.elementFocus && (typeof this.elementFocus.getAttribute('tabindex') == 'object')){
          this.addDbgMsg('setFocusOnClosestElementWithTabindex : yes, setting focus: ' + this.elementFocus.id);
          dom_focus( this.elementFocus );
        }
        else{
          this.elementFocus = oldFocusElement;
        }
      }
      else{
        this.addDbgMsg('setFocusOnClosestElementWithTabindex : elementFocus ist undefined.');
      }
      this.addDbgMsg("setFocusOnClosestElementWithTabindex - end");
    }

  /**
   *   Mouse event handlers
   */

  /**
   *   onMouseOver
   */

  this.onMouseOver = function(event){
    //only execute code below if in msie + drag drop is not active
    if (its_ua.ie55up && wguDDManager.isActive() === false){
      var
        iEvent = new its_event(event),
        element = this.getElement(iEvent.target);
      this.bufferedCursorDesign = false;
      //currentStyle is msie's way to do the trick until msie 9 that supports getComputedStyle
      if (typeof element.currentStyle != 'undefined'){
        this.bufferedCursorDesign = element.currentStyle['cursor'];
      }
      if ( this.bufferedCursorDesign !== false){
        if ( this.bufferedCursorDesign === "inherit"){
          element.style.cursor = "default";
        }
      }
      iEvent.stopPropagation();
      return false;
    }
  }

  /**
   *   onMouseOut
   */

  this.onMouseOut = function(event){
    //only execute code below if in msie + drag drop is not active
    if (its_ua.ie55up && this.bufferedCursorDesign !== false ){
      var
        iEvent = new its_event(event),
        element = this.getElement(iEvent.target);
      element.style.cursor = this.bufferedCursorDesign; // which should be "inherit" in most cases
      this.bufferedCursorDesign = false;
      iEvent.stopPropagation();
      return false;
    }
  }

  /**
   *   onMouseDown
   */

  this.onMouseDown = function(event){

    //clear values, they are now out of date
    this.deselectOnMouseClickInfo = null;

    var iEvent = new its_event(event);

    if (!webguiIsActive())
    {
      iEvent.stopPropagation();
      return;
    }

    if (typeof(wgu_fMgr) === 'object')
    {
        wgu_fMgr.unsetFocus();
    }

    var
      element = this.getElement(iEvent.target),
      row = this.getRow(element);

    if (element && row)
    {
      var
        elemTreeClass = element.getAttribute("tree_class");

      //WebGUISetControlFocus( this.controlId );
      webguiSaveFocus(new webguiFocusObj(WEBGUI_FOCUS_TYPE_TREE, this))

      //change focus to the element the user has clicked on
      //but ignore clicks on expander and node
      if (elemTreeClass != "Expander" && elemTreeClass != "Node"){
        this.elementFocus = element;
        this.setFocusOnClosestElementWithTabindex();
        //deselect selected columns
        this.deselectCols();
      }
      if ( this.isItemDisabledForSelection( element ) || (this.isNodeDisabledForSelection( row ) && elemTreeClass != "Expander") )
      {
          iEvent.stopPropagation();
          return false;
      }

      //collect mousedown event data in array CE
      var CE ={
        'element'   : element,
        'row'       : row,
        'key'       : row.getAttribute('tree_key'),
        'item'      : element.getAttribute('tree_item'),
        'new_check' : element.getAttribute('tree_new_check'),
        'event'     : iEvent,
        'onFolder'  : false,
        'ignoreItems' : false,
        'keyPressed': {
          'ctrl'  : iEvent.ctrlKey,
          'shift' : iEvent.shiftKey
        }
      };

      var stopProp = true;
      //check if node is draggable and pass event to drag drop manager
      //we don't know here if the node is draggable or only droppable yet
      //this will be decided in dragstart
      var dragAware = CE.row.getAttribute('abapddid') && wguDDManager;
      switch (elemTreeClass) {
        case 'ButtonItem':
        case 'LinkItem':
        case 'TextItem':

          this.reconsiderSelectionOnMouseDown( CE );
          if (dragAware)
            wguDDManager.dragstart(CE.row, event, this.id, CE.row.getAttribute("tree_key"));
          break;

        case "CheckboxItem":
          //sap gui for windows fires status change of checkbox on mousedown event, we imitate this here
          this.reconsiderSelectionOnMouseDown( CE );
          if ( CE.event.type != "focus" && CE.element.getAttribute('tree_item_nonedit') != "X" ){
            this.postURL("OnCheckBoxChange", escape( CE.key ), escape( CE.item ), "&checked=" + escape( CE.new_check ));
          }
          break;

        case "Folder":
          CE.ignoreItems = true;
          this.reconsiderSelectionOnMouseDown( CE );
          if (dragAware) wguDDManager.dragstart(CE.row, event, this.id, CE.row.getAttribute("tree_key"));
          break;

        case "Expander":
          this.expanderClickWrapper( CE.element, CE.row );
          break;

        default:
          stopProp = false;
      }

/* this seems to be wrong in case of the presence of an open context menu that should be closed on mousedown
      if (stopProp){
        iEvent.stopPropagation();
        return false;
      }
*/
    }
    else if (this.hasHeader){
      //case of mousedown on tree header
      this.headerMouseDown(event);
    }
    return true;
  }

  /**
   *   onClick
   */

  this.onClick = function(event){

    var iEvent = new its_event(event);

    if (!webguiIsActive())
    {
      iEvent.stopPropagation();
      return;
    }

    //now deselect the elements that were tagged for deselection during onmousedown
    if (this.deselectOnMouseClickInfo !== null)
      this.deselectOnMouseClick();

    var
      element = this.getElement(iEvent.target),
      row = this.getRow(element);

    if (element && row)
    {
      var elemTreeClass = element.getAttribute("tree_class");
      if ( this.isItemDisabledForSelection( element ) || (this.isNodeDisabledForSelection( row ) && elemTreeClass != "Expander") )
      {
          iEvent.stopPropagation();
          return false;
      }

      var earlyReturn = false;

      switch (elemTreeClass) {
        case "TextItem":
        case "CheckboxItem":
        case "Folder":
          //this.addDbgMsg('end of onclick handling (interesting to know for setting focus after expand operation)');
          earlyReturn = true;
          break;
        case "Expander":
          if (this.repeatSetFocusOnLateMouseClick){
              this.setFocusOnClosestElementWithTabindex();
              this.repeatSetFocusOnLateMouseClick = false;
          }
          //nothing, don't delete this
          earlyReturn = true;
          break;
        case "Node":
          //restore the focus on the old focusfield, focus shouldn't get lost for the sake of keyboard navigation
          this.setFocusOnClosestElementWithTabindex();
          earlyReturn = true;
          break;
      }

      if (  earlyReturn )
      {
          iEvent.stopPropagation();
          return false;
      }
      else if ( iEvent.type != "focus" && elemTreeClass == 'ButtonItem' || elemTreeClass == 'LinkItem' )
      {
          var
            key  = escape( row.getAttribute('tree_key') ),
            item = escape( element.getAttribute('tree_item') );
          switch (elemTreeClass) {
            case 'ButtonItem':
              if ( this.events.onButtonClick ) this.postURL( "OnButtonClick", key, item );
              iEvent.stopPropagation();
              break;
            case 'LinkItem':
              if ( this.events.onLinkClick ) this.postURL( "OnLinkClick", key, item );
              iEvent.cancel(); //cancel because otherwise ie6 cares for href attribute and causes problem
              break;
          }
          return false;
      }
    }
    // was onclick event on one of the dom elements belonging to the tree header?
    else if ( iEvent.type != "focus" && iEvent.target && iEvent.target.className && iEvent.target.className.substr(0,16) == "ColumnTreeHeader" ){
      this.headerClick( iEvent );
      iEvent.stopPropagation();
      return false;
    }
    else{
      //tree background
      this.setFocusOnClosestElementWithTabindex();
    }

    return true;
  }

 /**
  *   headerMouseDown
  */

  this.headerMouseDown = function(event){
    var myevent = new its_event(event);
    //was click on header column on column resize area?
    if (myevent.target.className == "treeColResizeArea"){
      this.colResize = new its_treeColResizeManager(myevent, thisTree);
    }
  }

    /**
     *   headerClick
     */

    this.headerClick = function( iEvent ){

      if ( iEvent.target.className == "ColumnTreeHeaderWrapperDiv" && iEvent.target.parentNode )
        iEvent.target = iEvent.target.parentNode;
      else if (
        (iEvent.target.className == "ColumnTreeHeaderActiveLinkImage" || iEvent.target.className == "ColumnTreeHeaderActiveLink") &&
        iEvent.target.parentNode &&
        iEvent.target.parentNode.parentNode
      ){
        iEvent.target = iEvent.target.parentNode.parentNode;
      }
      if (iEvent.target.tagName == "TD"){
        var hierarchyHeaderClicked = iEvent.target.parentNode.parentNode.parentNode.id.search(/tree_header_table_left_/) > -1;
        this.addDbgMsg("hierarchyHeaderClicked :" + iEvent.target.parentNode.parentNode.id + " " + hierarchyHeaderClicked );
        var
            element    = iEvent.target,
            headerNo   = (hierarchyHeaderClicked || !this.splitted) ? 1 : element.cellIndex + 2,
            headerName = element.getAttribute("tree_headername"),
            selectableInfo = element.getAttribute("tree_headerselectable"),
            selectable = (headerNo > 1 && typeof selectableInfo === 'string' && selectableInfo != "") ? true : false,
            clickable  = this.events.onHeaderClick;

        if ( selectable ){
            //get rid of any current selections
            this.addDbgMsg("header is being selected now");
            this.deselectAllNodesAndItems();
            this.selectHeader( headerNo, iEvent.ctrlKey );
        }
        else{
            this.addDbgMsg("this header is not selectable");
        }
        if ( clickable && clickable !== "" ){
            this.postURL("OnHeaderClick", "", "", "headerNo=" + escape(headerNo) + "&header=" + escape(headerName));
        }
      }
      else{
        this.addDbgMsg("header click handling stopped: couldn't find td tag.");
      }
  }

    /**
     *   postURL
     */

    this.postURL = function(event, key, item, params, isDataEvent, dataTarget){
        this.dbgTStart("postURL");
        var theParams = "",
            mainWindow = getMainWindow();

        if (key)    theParams += "key=" + key;
        if (item)   theParams += "&item=" + item;
        if (params) theParams += params;
        this.addDbgMsg("postURL: event: " + event + " / " + theParams + "/ target: " + dataTarget + " / isDataEvent = " + isDataEvent);
        if (isDataEvent){
            //this.addDbgMsg("postUrl: dataEvent, triggering webguisetbusy");
            mainWindow.webguiRaiseDataEvent(this.controlId, event, theParams, dataTarget);
            webguiRefreshPage = true;
            //webguiSetBusy();
        }
        else
            mainWindow.raiseEvent(this.controlId, event, theParams);
        this.dbgTStop("postURL");
    }

    /**
     *   ----------------------------- Selection ----------------------------------
     */

    /**
     *   selectColumn
     */

  this.selectColumn = function(colNumber, color)
  {
    //empty tree? caution: empty tree has no NTR
    if (this.hasNodes)
    {
        var rows = this.NTR.rows;
        var numRows = rows.length;
        colNumber = colNumber -1;

        this.addDbgMsg('selecting column: changing ' + numRows + ' rows');

        for(var i=0; i<numRows; i++)
        {
          if( rows[i].cells[colNumber])
            rows[i].cells[colNumber].style.backgroundColor = color;
        }
    }
  }

  /**
   *   deselectCols
   */

  this.deselectCols = function (){
    if( this.MT.selectedColumns ){
      var numCols = this.MT.selectedColumns.length;

      for(var i=0; i<numCols; i++)
      {
        this.selectColumn( this.MT.selectedColumns[i]-1, "");
      }

      this.MT.selectedColumns.length = 0;
      this.formfields.selectedColumns.value = "";
    }
  }

    /**
     *   selectHeader
     */

  this.selectHeader = function(headerNo, multiSelect){

    // need to add this column's name to the selected columns list
    if (!this.MT.selectedColumns)
      this.MT.selectedColumns = new Array();

    var found = false;
    var numCols = this.MT.selectedColumns.length;

    for(var i=0; i<numCols; i++){
      if(this.MT.selectedColumns[i]==headerNo){
        found=true;
        this.MT.selectedColumns[i] = this.MT.selectedColumns[numCols-1];
        this.MT.selectedColumns.length--;
        break;
      }
    }

    if(found === true){
      //if the control key is down then multiple selections of the headers should be done
      var oldList = this.formfields.selectedColumns.value;
      var value=headerNo + ":";
      var index=oldList.indexOf(value);

      if(index!=-1){
        var newList = oldList.substring(0, index) + oldList.substring(index + value.length);
        this.formfields.selectedColumns.value = newList;
      }
      this.selectColumn( headerNo - 1, "" );
    }
    else{
      if(multiSelect === false)
        this.deselectCols();

      this.selectColumn( headerNo - 1, treeCollection.settings.selection_bg_color );
      this.MT.selectedColumns[this.MT.selectedColumns.length]=headerNo;
      this.formfields.selectedColumns.value += headerNo + ":";
    }
  }

  /**
   *   checks if an item or nodes are selected
   *   columns / header etc. are not yet part of this method
   *   returns true if this is the case
   */

    this.isAnythingSelected = function(){
        return ( typeof this.MT.selection === 'object' ) || ( this.getNumberOfSelectedNodes() > 0);
    }

  /**
   *   checks if a node or more than one nodes are selected
   *   returns true if this is the case
   */

    this.getNumberOfSelectedNodes = function(){
        var nosn = 0;
        if (typeof this.MT.selectedRowsList === 'object')
            nosn = this.MT.selectedRowsList.length;
        return nosn;
    }

  /**
   *   checks if a node is selected
   *   returns true if this is the case
   */
    this.isNodeSelected = function( node ){
        var
            nosn = this.getNumberOfSelectedNodes(),
            retVal = false;
        if ( nosn > 0 ){
            for( var z = 0; z < nosn; z++){
                if ( this.MT.selectedRowsList[z].getAttribute('tree_key') === node.getAttribute('tree_key')){
                    retVal = true;
                    break;
                }
            }
        }
        return retVal;
    }

  /**
   *   checks if an item is selected
   *   returns true if this is the case
   */
    this.isItemSelected = function( CE ){
        var
            retVal = false;
        if (
            this.selectModeDetails.isSingleItemEnabled &&
            typeof this.MT.selection === "object" &&
            this.MT.selection.element === CE.element &&
            this.MT.selection.key === CE.key &&
            this.MT.selection.item === CE.item
        ){
            retVal = true;
        }
        return retVal;
    }

  /**
   * here we decide if an item should be selected or the full node
   * in case of a selection without multiselect we also deselect the currently
   * selected stuff
   * if an item or node is already selected and should therefore be deselected,
   * this has to be postponed to the moment the mouseclick event is fired
   * (on release of mouse button).
   * we don't do deselection on mousedown!
   * the mouseclick event might not even be fired in case of a drag'n'drop operation
   *
   * expected structure of CE JSON object (incomplete):
   *  var CE ={
   *     'element'  : element,
   *     'row'      : row,
   *     'key'      : row.getAttribute('tree_key'),
   *     'item'     : element.getAttribute('tree_item'),
   *     'new_check': element.getAttribute('tree_new_check'),
   *     'event'    : iEvent,
   *    'ignoreItems' : false,
   *     'keyPressed'
   *   };
   *
   */
  this.reconsiderSelectionOnMouseDown = function( CE )
  {
    //clear deselectOnMouseClickInfo, the values are now out of date
    this.deselectOnMouseClickInfo = null;
    this.selectionHasChanged = false;

    var
        dbgMsgPrefix = 'reconsiderSelectionOnMouseDown: ',
        itemMatch = CE.ignoreItems ? false : this.isItemSelected( CE ),
        nodeMatch = this.isNodeSelected( CE.row );
        //this.addDbgMsg( dbgMsgPrefix + ' itemMatch=' + itemMatch + ' nodeMatch=' + nodeMatch );

    //determine if we already have a selected item or node
    if (this.isAnythingSelected()){
        //this.addDbgMsg( dbgMsgPrefix + 'At least one element is already selected.' );
        //is it possible that the same item or node was clicked on again with ctrl pressed with the purpose to deslect it?
        if ( itemMatch || nodeMatch ){
            if (CE.keyPressed.ctrl){
                //let's check if we are looking for a node or an item
                //we are looking at items first
                if (!CE.ignoreItems && itemMatch) {
                    //this.addDbgMsg( dbgMsgPrefix + 'Tagging item for deselection on mouseclick (later).' );
                    this.deselectOnMouseClickInfo = {'type': 'item'};
                }
                //now we are looking at the node: is it already selected?
                if (nodeMatch){
                    if (this.isItemSelectionNowPossible( CE )){
                        this.markNodeAsDeselected( CE.row );
                        //item get's selected now (on mousedown) - and deselected on click, like in wingui
                        this.selectItem( CE );
                        this.deselectOnMouseClickInfo = {'type': 'item'};
                    }
                    else{
                        //this.addDbgMsg( dbgMsgPrefix + 'Tagging node for deselection on mouseclick (later).' );
                        this.deselectOnMouseClickInfo = { 'type': 'node', 'details': CE.row };
                    }
                }
            }
            else if (nodeMatch && !itemMatch){
                if (( CE.ignoreItems || !this.selectModeDetails.isSingleItemEnabled ) && this.selectModeDetails.isMultiEnabled){
                    //either mouse down on node icon (folder) or mouse down on any point of the node if single selection is not allowed
                    //this.addDbgMsg( dbgMsgPrefix + 'Tagging node for remaining the only selected element on mouseclick (later).' );
                    this.deselectOnMouseClickInfo = { 'type': 'everything_except_for_node', 'details': CE.row };
                }
                else if (this.isItemSelectionNowPossible( CE )) {
                    if (this.getNumberOfSelectedNodes() > 1){
                        //this.addDbgMsg( dbgMsgPrefix + 'Deselecting node in favour of selecting an item of the node instead. - postpone selection change to mouse up' );
                        this.deselectOnMouseClickInfo = { 'type': 'everything_except_for_item', 'details': CE };
                    }
                    else{
                        //this.addDbgMsg( dbgMsgPrefix + 'Deselecting node in favour of selecting an item of the node instead.' );
                        this.markNodeAsDeselected( CE.row );
                        nodeMatch = false;
                        //item will be also selected (see code further down)
                    }
                }
            }
        }
        //now we are done with checking if the same item or node was already selected

        if ( !itemMatch && !nodeMatch ){
            //are we allowed to select multiple elements?
            if (this.selectModeDetails.isMultiEnabled){
                //is only the control key pressed to confirm the purpose of multi selection?
                if (!this.isNodeDisabledForSelection( CE.row ) && CE.keyPressed.ctrl && !CE.keyPressed.shift){
                    //check if an item is selected, if so: deselect the item, select the surrounding node instead
                    if (typeof this.MT.selection === "object"){
                        var node = this.getRow( this.MT.selection.element );
                        this.deselectItem();
                        this.markNodeAsSelected( node );
                    }
                    //this.addDbgMsg( dbgMsgPrefix + '  multinode selection allowed + ctrl pressed: add this node to selection');
                    this.markNodeAsSelected( CE.row );
                }
                else if (!this.isNodeDisabledForSelection( CE.row ) &&  CE.keyPressed.shift  && !CE.keyPressed.ctrl){
                    //if shift key is pressed, check for already selected elements
                    this.addDbgMsg( dbgMsgPrefix + '  multi+shift');
                    var lsn = this.getLastSelectedNode();
                    if (lsn === false && this.selectModeDetails.isSingleItemEnabled && typeof this.MT.selection === "object" ){
                        //if there is no node selected, check for an selected item, if there is one, turn it into a selected node
                        //this.addDbgMsg( dbgMsgPrefix + '  multi+shift - an item is already selected');
                        var lsn = this.getRow( this.MT.selection.element );
                        if ( !this.isNodeDisabledForSelection( lsn ) ){
                            this.deselectItem();
                            this.markNodeAsSelected( lsn );
                        }
                        else{
                          lsn = false;
                        }
                    }
                    if (lsn !== false){
                        this.selectNodeRage( lsn.rowIndex, CE.row.rowIndex );
                    }
                }
                else{
                    //if no special key is pressed, deselect all currently selected nodes
                    //this.addDbgMsg( dbgMsgPrefix + '  deselect all currently selected elements, since no special key was pressed');
                    this.deselectAllNodesAndItems();
                    //the missing selection will take place further down
                }
            }
            else{
                ////this.addDbgMsg( dbgMsgPrefix + ' not multi / implement something');
                this.deselectAllNodesAndItems();
                //the selection will take place further down
            }
        }
    }

    //select single node or item, prerequisite: nothing is selected at all at this time (even it if was further above)
    if (!itemMatch && !nodeMatch && !this.isAnythingSelected()){
        //this.addDbgMsg( dbgMsgPrefix + 'currently, nothing is selected.' );
        //FIXME: add check: is selection allowed at all???
        if (this.isItemSelectionNowPossible( CE )){
            //select the item
            this.selectItem( CE );
        }
        else if (!this.isNodeDisabledForSelection( CE.row )){
            //this.addDbgMsg( dbgMsgPrefix + 'item selection is not allowed, select node instead.' );
            //select the node
            this.markNodeAsSelected( CE.row );
        }
    }
    //this.traceSelectedNodesList();

    //onselectionchange
    if (this.events.onSelectionChange && this.selectionHasChanged){
      this.selectionHasChanged = false;
      this.postURL("OnSelectionChange", escape(CE.key), "");
    }

  }

  /**
   *   checks multiple conf options to ensure that item selection is (im)possible
   *   returns true or false
   */
    this.isItemSelectionNowPossible = function( CE ){
        return this.selectModeDetails.isSingleItemEnabled && !CE.ignoreItems && !this.isItemDisabledForSelection( CE.element );
    }

  /**
   *   this is called at onclick to deselect the elements
   *   that were marked for deselection on mouse down
   */
    this.deselectOnMouseClick = function(){
        if (this.deselectOnMouseClickInfo !== null){
            //this.addDbgMsg( "deselectOnMouseClick: We will deselect element '" + this.deselectOnMouseClickInfo.type + "'." );
            switch (this.deselectOnMouseClickInfo.type) {
                case 'item':
                    this.deselectItem();
                    break;
                case 'node':
                    this.markNodeAsDeselected( this.deselectOnMouseClickInfo.details );
                    break;
                case 'everything_except_for_node':
                    this.deselectAllNodesAndItems();
                    this.markNodeAsSelected( this.deselectOnMouseClickInfo.details );
                    break;
                case 'everything_except_for_item':
                    this.deselectAllNodesAndItems();
                    this.selectItem( this.deselectOnMouseClickInfo.details );
                    break;
                default:
            }
        }
        else{
            //this.addDbgMsg( 'deselectOnMouseClick: Nothing to deselect.' );
        }
    }

    /*
     * trace selected nodes List
     * this method is only useful for debugging
     *

    this.traceSelectedNodesList = function(){
        var liste = "";
        for (var z=0; z < this.MT.selectedRowsList.length; z++){
            liste += this.MT.selectedRowsList[z].id + ", ";
        }
        //this.addDbgMsg( 'traceSelectedNodesList: 1) formfield: ' + this.formfields.selectedNodes.value );
        //this.addDbgMsg( 'traceSelectedNodesList: 2) array contents: ' + liste );
    }
    */

    /*
     * returns true if node is disabled for selection, otherwise false
     */

    this.isNodeDisabledForSelection = function( node ){
        return (node.getAttribute('tree_node_disabled') == "X");
    }

    /*
     * returns true if item is disabled for selection, otherwise false
     */

    this.isItemDisabledForSelection = function( item ){
        return (item.getAttribute('tree_item_disabled') == "X");
    }

  /**
   *   selectItem
   *   does visible and invisible stuff (formfields)
   */
    this.selectItem = function( CE ){
        //this.addDbgMsg( "selectItem2: selecting item '" + CE.item + "' (obviously...)." );
        this.changeElementSelection( CE.element, true);
        this.MT.selection  = {
            'element' : CE.element,
            'key'     : CE.key,
            'item'    : CE.item
        }
        this.formfields.selectedItemsKey.value  = this.MT.selection.key;
        this.formfields.selectedItemsName.value = this.MT.selection.item;
        //flag for backend that there is a selection present
        this.formfields.selected.value = "1";
    }

  /**
   *   deselectItem
   *   does visible and invisible stuff (formfields)
   */
    this.deselectItem = function(){
        if (typeof this.MT.selection === 'object' && typeof this.MT.selection.element === 'object'){
            this.changeElementSelection( this.MT.selection.element, false); //visually unmark item
            this.MT.selection  = false;
            this.formfields.selectedItemsKey.value  = "";
            this.formfields.selectedItemsName.value = "";
            //this.addDbgMsg( "deselectItem: deselecting item - success" )
        }
        else{
            //this.addDbgMsg( "deselectItem: error: no item selected or corrupt item info")
        }
        //update flag for backend regarding the presence of a selection
        if (!this.isAnythingSelected()) this.formfields.selected.value = "";

    }

  /**
   *  deselects all selected nodes
   */

  this.deselectAllSelectedNodes = function()
  {
    if (typeof this.MT.selectedRowsList === 'object'){
      //this.addDbgMsg( "deselectAllSelectedNodes: We deselect all nodes now." );
      for (var z=0; z < this.MT.selectedRowsList.length; z++){
        this.setVisualNodeSelectionStatus( this.MT.selectedRowsList[z], false );
      }
      this.formfields.selectedNodes.value = "";
      this.MT.selectedRowsList = new Array();
      //update flag for backend regarding the presence of a selection
      if (!this.isAnythingSelected()) this.formfields.selected.value = "";
    }
    else{
      //this.addDbgMsg( "deselectAllSelectedNodes: error: this.MT.selectedRowsList is not an object" );
    }
  }

  /**
   * selectNodeRage
   */
    this.selectNodeRage = function( range_begin, range_end ){
        //get rowIndex values of lsn and CE.row, sort index values by size
        var direction = range_begin - range_end;
        if (direction > 0 ){
            //range_begin is below range_end: swap them
            var temp = range_begin - 1;
            range_begin = range_end;
            range_end = temp;
        }
        else if (direction == 0){
            //this.addDbgMsg( dbgMsgPrefix + '  range is zero, no range is defined');
        }
        else{
            range_begin += 1;
        }
        //this.addDbgMsg( dbgMsgPrefix + '  range_begin: ' + range_begin + ' range_end: ' + range_end);
        var node = null;
        for ( z = range_begin; z <= range_end; z++){
            if (!this.isNodeSelected( node = this.NTR.rows[z] ))
                this.markNodeAsSelected( node );
            //debug: this.NTR.rows[z].style.backgroundColor = 'red';
        }
    }

  /**
   * markNodeAsSelected_byName
   */

  this.markNodeAsSelected_byName = function ( nodeId )
  {
    var
        elementName = treeCollection.settings.prefix + this.id + "::" + nodeId,
        node = document.getElementById(elementName + "::l");
    if (node){
      this.markNodeAsSelected( node );
    }
  }

  /**
   * visually marks node as selected. also adds node id to list of selected nodes.
   * this method doesn't care about why a node needs to be selected
   * (mouse event, collapse, initial rendering, etc.).
   * or if multiselection is allowed
   * it also doesn't check if the node is already selected.
   */
  this.markNodeAsSelected = function( node )
  {
    //this.addDbgMsg( "markNodeAsSelected: node with id '" + node.id + "' is being selected." );
    //visually indicate selection:
    if (!this.hideSelection)
    {
        this.setVisualNodeSelectionStatus( node, true );
    }
    this.addNodeToSelectedNodesFormfield( node );
    //todo: find out what "hide selection" means... only hidden or not selected at all???
  }

  /**
   * visually marks node as deselected. also removes node id from list of selected nodes.
   * this method doesn't care about why a node needs to be deselected
   * (mouse event, collapse, initial rendering, etc.).
   * it also doesn't check if the node is selected.
   */
  this.markNodeAsDeselected = function( node )
  {
    //this.addDbgMsg( "markNodeAsDeselected: node '" + node.id + "' is being deselected." );
    //visually indicate selection:
    if (!this.hideSelection)
    {
        this.setVisualNodeSelectionStatus( node, false );
    }
    this.removeNodeFromSelectedNodesFormfield( node );
    //todo: find out what "hide selection" means... only hidden or not selected at all???
  }

  /**
   *   deselect all currently selected nodes and items
   */
    this.deselectAllNodesAndItems = function(){
        //deselect all currently selected nodes and items
        if (typeof this.MT.selection === "object") this.deselectItem();
        //else //this.addDbgMsg( "deselectAllNodesAndItems: no item to deselect" );
        if (this.getNumberOfSelectedNodes() > 0) this.deselectAllSelectedNodes();
        //else //this.addDbgMsg( "deselectAllNodesAndItems: no nodes to deselect" );
        //debug
        //if (this.isAnythingSelected())
        //    //this.addDbgMsg( "deselectAllNodesAndItems: error! isAnythingSelected still indicates selection" );

    }

  /**
   * update the visual status of a node regarding being selected/deselected
   * visually marks node as selected or deselected
   * takes care of splitted display issues
   * @node dom-element of the node
   * @mode boolean true = select, false = deselect
   */
  this.setVisualNodeSelectionStatus  = function( node, mode )
  {
    //this.addDbgMsg( "setVisualNodeSelectionStatus: enter" );
    var
      belongsToLeftContainer = this.nodeIdBelongsToLeftContainer( node.id ),
      nodeIdBaseName = node.id.substring(0,node.id.length - 1),
      firstNodePart = node;
    if (!belongsToLeftContainer){
      firstNodePart = document.getElementById( nodeIdBaseName + "l");
      belongsToLeftContainer = true;
    }
    //care for first tree container (it is correct to use document.getElementById AGAIN here)
    //this.addDbgMsg( "setVisualNodeSelectionStatus: first container: " +  firstNodePart.id);
    this.changeElementSelection(document.getElementById( nodeIdBaseName + "l"), mode);
    //if present, care for second tree container
    if ( belongsToLeftContainer && this.NTL ){
      //this.addDbgMsg( "setVisualNodeSelectionStatus: second  container: " +  nodeIdBaseName + "r");
      this.changeElementSelection( document.getElementById( nodeIdBaseName + "r"), mode );
    }
  }

  /**
   * addNodeToSelectedNodesFormfield
   * caution: in case of single node selection mode we don't format the string at all!
   */

  this.addNodeToSelectedNodesFormfield = function( node )
  {
    if (this.selectModeDetails.isMultiEnabled){
       //to do: call method addNodeToHiddenFieldList instead here to save some lines of code
        var formattedNodeKey = formatString( node.getAttribute('tree_key'), "\\") + "\\;";
        //check if node is already present in formfield selectedNodes
        if (this.formfields.selectedNodes.value.indexOf(formattedNodeKey) == -1){
          this.formfields.selectedNodes.value += formattedNodeKey;
          //this.addDbgMsg("addNodeToSelectedNodesFormfield: adding node to selectedRowsList and formfield: '" + this.formfields.selectedNodes.value +"'");
          // we also need to add this node's index to the selected nodes list
          if (typeof this.MT.selectedRowsList === 'undefined')
              this.MT.selectedRowsList = new Array();
          this.MT.selectedRowsList.push( node );
          //update flag for backend regarding the presence of a selection
          this.formfields.selected.value = "1";
        }
        else{
            //this.addDbgMsg('addNodeToSelectedNodesFormfield: doing nothing - node is already present in formfield');
        }
    }
    else{
        //this.addDbgMsg('addNodeToSelectedNodesFormfield: single node selection, overwriting selection form field');
        this.formfields.selectedNodes.value = node.getAttribute('tree_key');
        //update flag for backend regarding the presence of a selection
        this.formfields.selected.value = "1";
        // we also need to add this node's index to the selected nodes list
        this.MT.selectedRowsList = new Array();
        this.MT.selectedRowsList.push( node );
    }
  }

  /**
   * removeNodeFromSelectedNodesFormfield
   */

  this.removeNodeFromSelectedNodesFormfield = function( node )
  {
    if (this.selectModeDetails.isMultiEnabled){
       //to do: call method removeNodeFromHiddenFieldList instead here to save some lines of code
        var
          oldList          = this.formfields.selectedNodes.value,
          formattedNodeKey = formatString( node.getAttribute('tree_key'), "\\") + "\\;",
          index            = oldList.indexOf(formattedNodeKey);

        if (index != -1)  //then on list.  so need to remove it.
        {
          this.formfields.selectedNodes.value =
            oldList.substring(0, index) +
            oldList.substring(index + formattedNodeKey.length);

          if (typeof this.MT.selectedRowsList === 'object' && this.MT.selectedRowsList.length > 0){

              //delete node from selectionList
              var hit = false;
              for (var i=0; i< this.MT.selectedRowsList.length; i++)
              {
                if (this.MT.selectedRowsList[i] === node)
                {
                  hit = i;
                  break;
                }
              }
              if (hit !== false){
                  //this.addDbgMsg('removeNodeFromSelectedNodesFormfield: found node to be removed in selectedRowsList');
                  for (var i = hit; i < this.MT.selectedRowsList.length; i++){
                      this.MT.selectedRowsList[ i ] = this.MT.selectedRowsList[ i + 1 ];
                  }
                  this.MT.selectedRowsList.pop();
              }
              else{
                  //this.addDbgMsg('removeNodeFromSelectedNodesFormfield: node to be removed in selectedRowsList WAS NOT FOUND');
              }
              //update flag for backend regarding the presence of a selection
              if (!this.isAnythingSelected()) this.formfields.selected.value = "";
          }
          else{
              //this.addDbgMsg('removeNodeFromSelectedNodesFormfield: this.MT.selectedRowsList seems to be empty: ' + typeof this.MT.selectedRowsList + " " + this.MT.selectedRowsList.length);
          }
        }
        else{
            //this.addDbgMsg('removeNodeFromSelectedNodesFormfield: node is not part of string formfields.selectedNodes!');
        }
    }
    else{
        //this.addDbgMsg('removeNodeFromSelectedNodesFormfield: single node deselection, clearing selection form field');
        this.formfields.selectedNodes.value = "";
        // we also need to add this node's index to the selected nodes list
        this.MT.selectedRowsList = new Array();
        //update flag for backend regarding the presence of a selection
        if (!this.isAnythingSelected()) this.formfields.selected.value = "";
    }
  }


  /**
   *   returns the dom element of the last selected node
   */

    this.getLastSelectedNode = function(){
        var retVal =  false;
        if (this.getNumberOfSelectedNodes() > 0)
            retVal =  this.MT.selectedRowsList[ this.MT.selectedRowsList.length - 1];
        return retVal;
    }

  /**
   *   change the selection status of an element
   *   todo: consider to rewrite this to use css classes
   */

  this.changeElementSelection = function(element, mode)
  {
    var color = mode ? treeCollection.settings.selection_bg_color : '';
    //this.addDbgMsg('selectElement: updating visual selection status of element :'+ element.id);
    if (element && element.style)
    {
      element.style.backgroundColor = color;
      if (mode)
        element.style.color = treeCollection.settings.selection_textcolor;
      else
        element.style.color = '';
      this.selectionHasChanged = true;
    }
  }

  /**
   *   registerSelectedItemName
   *   (register itemname to select it during init of tree)
   */

  this.registerSelectedItemName = function(itemName){
    this.itemToSelectOnInit = itemName;
  }

  /**
   *   registerSelectedColNumber
   *   (register column to select it during init of tree)
   */

    this.registerSelectedColNumber = function(colID){
      this.colNumberSelectOnInit.push(colID);
    }

  /**
   *   registerSelectedRow
   *   (register row name to select it during init of tree)
   */

  this.registerSelectedRow = function(rowID){
    //this debug statement if fired too early to be seen in in-built js trace, tree is not initialized yet
    //this.addDbgMsg('registerSelectedRow: adding node to list of nodes to be selected on init');
    this.rowSelectOnInit.push( rowID );
  }

    /**
     *   ------------------------------------- Key Press Handlers ------------------------------------------
     */

    /**
     *  only cares for arrow keys
     */

  this.keyDown = function(e)
  {
    //filter out non-ARROW keys
    if(e.keyCode >= 37 && e.keyCode <= 40)
    {
        if (this.elementFocus)
        {
          var row = this.getRow(this.elementFocus);
          if (row)
          {
            var event = new its_event(e);
            //UP ARROW (38) / DOWN ARROW (40)
            if ( event.keyCode % 2 == 0 )
            {
              var
                offset = (event.keyCode == 38) ? -1 : 1,
                adjacantNode = treeNodeGetNeighbour(row, offset);
              if ( adjacantNode === 0) return true;
              var folder = this.treeGetFolder(adjacantNode);
              if (folder === false) return true;
              this.elementFocus = folder.parentNode;
              dom_focus( this.elementFocus );
              if (!this.isNodeDisabledForSelection(adjacantNode)){
                if (!this.selectModeDetails.isMultiEnabled || !event.shiftKey){
                  this.deselectAllNodesAndItems();
                  this.markNodeAsSelected( adjacantNode );
                }
                else if (!this.isNodeSelected( adjacantNode ) && event.shiftKey){
                  this.markNodeAsSelected( adjacantNode );
                }
              }
              event.cancel();
            }
            //LEFT ARROW (37) or RIGHT ARROW (39) should only work on nodes with expanders
            else if ( row.getAttribute("tree_state") )
            {
              if ( ( event.keyCode == 37 ) == ( row.getAttribute("tree_state") == "expanded") )
                this.expanderClickWrapper(this.elementFocus, row);
            }

          }
          return false;
        }
    }
    else
    {
      return true;
    }
  }

    /**
     *   keyPress
     */

  this.keyPress = function(event)
  {
    var tree = this.MT;

    //he.pi 20050111 crossbrowser target/srcElement
/*    if (event.target) tree = event.target;
    else if (event.srcElement) tree = event.srcElement;
*/
    if (tree && tree.getAttribute("treeFocus"))
    {
      var
        element = this.getElement(tree.getAttribute("treeFocus")),
        row = this.getRow(tree.getAttribute("treeFocus"));

      if (element && row)
      {
        if (element.getAttribute("treeClass") == "Folder")
        {
          this.nodeKeyPress(row.tree_key);

          if (event)
            event.cancelBubble = true;
          return false;
        }
        else if (element.getAttribute("tree_item"))
        {
          this.itemKeyPress(row.getAttribute("tree_key"), element.getAttribute("tree_item"));

          if (event)
            event.cancelBubble = true;
          return false;
        }
      }
    }

    return true;
  }

  /**
   *   itemKeyPress
   */

  this.itemKeyPress = function(key, item){
    var param = "&keyChar=" + escape(event.keyCode);
    if (this.events.onItemKeyPress)
      this.postURL("OnItemKeyPress", escape(key), escape(item), param);
  }

  /**
   *   nodeKeyPress
   */

  this.nodeKeyPress = function(key){
    var param = "&keyChar=" + escape(event.keyCode);
    if (this.events.onNodeKeyPress)
      this.postURL("OnNodeKeyPress", escape(key), "", param);
  }

  /**
   *   ------------------------------------- DblClick Handlers ------------------------------------------
   */

  /**
   *   folderDblClick
   */

  this.folderDblClick = function(element, key){
    if (this.events.onNodeDoubleClick)
      this.postURL("OnNodeDoubleClick", escape(key), "");
  }

  /**
   *   textItemDblClick
   */

  this.textItemDblClick = function(element, key, item){
    if (this.events.onItemDoubleClick)
      this.postURL("OnItemDoubleClick", escape(key), escape(item));
    else if (this.events.onNodeDoubleClick && item === null){
      //double click should only bubble from item to node if item is undefined
      //tested with SE80 tree (Repository Browser, WEBGUI, Mime list)
      this.postURL("OnNodeDoubleClick", escape(key), "");
    }
  }

  /**
   *   double click
   */

  this.dblClick = function(event)
  {
    var
      srcElement,
      element,
      row,
      tree,
      treeClass;

    var iEvent = new its_event(event);

    // was double click event on one of the dom elements belonging to the tree header?
    if ( iEvent.target && iEvent.target.className && (iEvent.target.className.substr(0,16) == "ColumnTreeHeader" || iEvent.target.className == "treeColResizeArea")){
      this.headerDblClick( iEvent );
      iEvent.stopPropagation();
      return false;
    }

    //was double click on a tree node / item?
    element = this.getElement(iEvent.target);
    row = this.getRow(element);

    if (!element || !row){
      iEvent.stopPropagation();
      return true;
    }

    treeClass = element.getAttribute('tree_class');

    if ((treeClass == 'CheckboxItem' && element.getAttribute('tree_item_nonedit') == "X") || this.isItemDisabledForSelection( element ) || this.isNodeDisabledForSelection( row )){
        iEvent.stopPropagation();
        return false;
    }

    // when in singlenode select mode, then text items behave like Folder items for double clicks.
    if ( this.selectMode == "singlenode" && treeClass == 'TextItem' )
      treeClass = 'Folder';

    if (treeClass == 'TextItem'){
      this.textItemDblClick(element, row.getAttribute('tree_key'), element.getAttribute('tree_item'));
      iEvent.stopPropagation();
      return false;
    }
    else if (treeClass == 'Folder'){
      this.folderDblClick(element, row.getAttribute('tree_key'));
      iEvent.stopPropagation();
      return false;
    }

    return true;
  }

  /**
   *   onContextMenu
   *   the selection of the item/node has already taken place on mousedown, so we can skip it here
   *   eventName can be OnContextMenuHeader, OnContextMenuItem, OnContextMenuNode
   *   headerNo, name only need to be provided in case of OnContextMenuHeader
   */

    this.onContextMenu = function( rawEvent, eventName, headerNo, name){
        var
            dataProvdided = false,
            myevent       = new its_event(rawEvent),
            row           = null,
            rowKey        = '';

        switch (eventName)
        {
            case "OnContextMenuHeader":
                if (headerNo != '' && name != '') dataProvdided = true;
                break;
            case "OnContextMenuItem":
            case "OnContextMenuNode":
                var
                    eSrcElement = (rawEvent.originalTarget)? rawEvent.originalTarget : myevent.target, //if moz use originalTarget
                    element = this.getElement(eSrcElement);

                row = this.getRow(element);
                if (row && row.getAttribute('tree_key'))
                {
                    rowKey = row.getAttribute('tree_key');
                    dataProvdided = true;
                }
                break;
        }

        if ( dataProvdided )
        {
            var params = "";
            switch (eventName) {
                case "OnContextMenuHeader":
                    params = "headerNo=" + escape(headerNo) + "&header=" + escape(name);
                    break;
                case "OnContextMenuNode":
                    params = "key=" + escape(rowKey);
                    break;
                case "OnContextMenuItem":
                    params = "key=" + escape(rowKey) + "&colname=" + escape(this.MT.selection.item);
                    break;
            }

            this.addDbgMsg( 'onContextMenu: ' + eventName + " - " + params );

            //he.pi 20071009 due to change of webguiDoControlContextMenu implementation in 6.20 we need to have two cases
            if (treeCollection.settings.noCTLinkClassChangeNecessary != "true")
              webguiDoControlContextMenu( this.controlId, eventName, params, myevent.clientX, myevent.clientY );
            else
              webguiDoControlContextMenu( rawEvent, this.controlId, eventName, 'false', params );
            myevent.cancel();
        }
        return true;
    }

}// end of its_treeManager class definition


/************************************************************************************
 * **********************************************************************************
 * * *   object its_treeColResizeManager
 * * **********************************************************************************
 ************************************************************************************/

function its_treeColResizeManager(mouseDownEvent, theTreeObject){
  //for constructor see end of class

  /**
   *   public method headerColResizeUpdateDOM
   */

  this.headerColResizeUpdateDOM = function(){
    //T.addDbgMsg('colResizeManager: start of method headerColResizeUpdateDOM');
    var
      colWidthChange = currentMouseXPos - mouseDownXPos,
      xVars                     = {'newColWidth'          : (colWidthChange  + currentColWidth),
                                   'isFirstColumnResized' : (headerTable.id.search(/left/) != -1),
                                   'MTWidth'              : T.MT.offsetWidth
                                  },
      scrContLeftWidth          = T.SCL ? T.SCL.offsetWidth : currentColWidth, //in case of a nodeless tree there is no left scroll container, here we take currentColWidth
      safetyPadding             = (xVars.MTWidth > treeCollection.settings.minRightContainerWidth) ? treeCollection.settings.minRightContainerWidth : xVars.MTWidth,
      isFirstColumnWidthIllegal = (xVars.isFirstColumnResized && (xVars.newColWidth >= (xVars.MTWidth - safetyPadding))),
      maxCutOffNecessary        = false;

    //if we are in a dockersplitter and the hierarchy column fills the whole width
    //we can't increase the width of the hierarchy column
    if (xVars.isFirstColumnResized && T.DS_isInside){
      if (T.hasNodes && T.SCR.style.visibility == "hidden"){
        if (xVars.newColWidth >= scrContLeftWidth - 16){
          if (colWidthChange >= 0){
            xVars.newColWidth = scrContLeftWidth - 16;
          }
          else{
            T.SCR.style.visibility  = "visible";
            T.HSCR.style.visibility = "visible";
          }
        }
      }
      else if (isFirstColumnWidthIllegal){
        maxCutOffNecessary = true;
      }
    }
    else if (isFirstColumnWidthIllegal){
      maxCutOffNecessary = true;
    }

    //hierarchy column should not be allowed to be wider than the tree container
    if (maxCutOffNecessary){
      //T.addDbgMsg('colResizeManager: headerColResizeUpdateDOM: maxCutOffNecessary');
      xVars.newColWidth = xVars.MTWidth - safetyPadding; //set newColWidth to max value
      if (xVars.newColWidth < 0) xVars.newColWidth = 0;
      colWidthChange = xVars.newColWidth - currentColWidth; //is allowed to be smaller than zero
      if (colWidthChange < 0) colWidthChange = 0;
    }

    if (colWidthChange !== 0 && ((currentColWidth + colWidthChange) > 3)){  //minimum col width is 3 pixel
      colResizer.resize( xVars );
      currentColNewWidth = xVars.newColWidth; // this has to be updated to be used in post on mouseup
    }
    else{
        //T.addDbgMsg('colResizeManager: headerColResizeUpdateDOM: resize not allowed. colWidthChange=' + colWidthChange);
    }
    delete(xVars);
  }

  /**
   *   public method headerColResizeMouseMove
   */

  this.headerColResizeMouseMove = function(event){
    //T.addDbgMsg('colResizeManager: start of method headerColResizeMouseMove');
    var ievent = new its_event(event);
    currentMouseXPos = ievent.pageX;
    ievent.cancel();
    ievent = null; // delete event
    treeCollection.globalResizeTimer.keepAlive();
  }

  /**
   *   public method headerColResizeMouseUp
   */

  this.headerColResizeMouseUp = function(event){
    //T.addDbgMsg('colResizeManager: start of method headerColResizeMouseUp');
    var ievent = new its_event(event);
    currentMouseXPos = ievent.pageX;
    ievent.cancel();
    ievent = null; // delete event
    this.headerColResizeUpdateDOM();
    its_eMgr.unregisterEvent(T.MT, "mousemove", fMouseMove);
    its_eMgr.unregisterEvent(document.body, "mouseup", fMouseUp);
    delete thisColResizeObject;
    //disable roundtrip after resize as long as the correct kernel patch is not available!!!
    if (T.sendPostAfterColResize && currentColNewWidth != currentColWidth ){
      var params = "colindex=" + currentColIndexNumber + "&width=" + currentColNewWidth;
      //key & item & params are "", isDataEvent = false, dataTarget is ""
      T.postURL( "OnColumnResize", "", "", params, false, "");
    }

  }

  /**
   *   private method getHeaderTable
   */

  var getHeaderTable = function(headerTr){
    var headerTable = headerTr.parentNode; //could be table, could be table section
    while (headerTable.tagName != "TABLE"){
      headerTable = headerTable.parentNode;
    }
    return headerTable;
  };


  /**
   *   constructor
   */

  var
    T                     = theTreeObject,
    thisColResizeObject   = this,
    currentCol            = mouseDownEvent.target.parentNode,
    headerTable           = getHeaderTable(currentCol.parentNode),
    currentMouseXPos      = null,
    mouseDownXPos         = mouseDownEvent.pageX,
    currentColWidth       = currentCol.offsetWidth,
    currentColNewWidth    = currentColWidth,
    colResizer            = new its_treeColResizer( T, currentCol, headerTable ),
    currentColIndexNumber = colResizer.getCurrentColIndexNumber(),
    fMouseUp              = function(event){thisColResizeObject.headerColResizeMouseUp(event);},
    fMouseMove            = function(event){thisColResizeObject.headerColResizeMouseMove(event);};

  //set global helper variables
  treeCollection.globalColResizeObj = this;
  treeCollection.globalResizeTimer = new timerSession(10, "treeCollection.globalResizeTimer", "treeCollection.globalColResizeObj.headerColResizeUpdateDOM()");

  //register mouseup event on whole tree
  its_eMgr.registerEvent(document.body, "mouseup", fMouseUp);
  //register mousemove event on whole tree
  its_eMgr.registerEvent(T.MT, "mousemove", fMouseMove);

} // end of its_treeColResizeManager class definition


/************************************************************************************
 * **********************************************************************************
 * * *   object its_treeColResizer
 * * **********************************************************************************
 ************************************************************************************/


function its_treeColResizer(theTreeObject, theCurrentCol, headerTable){

  /**
   *   init
   */

  var init = function(){
    //T.addDbgMsg('colResize: start of method init');
    HHeightLessInPx = T.MT.offsetHeight - T.HSCR.offsetHeight;
    if ( HHeightLessInPx < 0) HHeightLessInPx = 0;
    HHeightLessInPx += "px";

    //get innerDiv element
    innerDiv = currentCol.childNodes[0];
    while (innerDiv.tagName != "DIV" && innerDiv.nextSibling)
      innerDiv = innerDiv.nextSibling;
    //find out column number of col to be resized
    columnIndex = 1;
    var currentColumn = currentCol;
    while (currentColumn.previousSibling){
      currentColumn = currentColumn.previousSibling;
      if (currentColumn.tagName == "TD") columnIndex++;
    }
    //also find correct colgroup col
    colWidthToWorkOn = getColWidthToWorkOn(headerTable, columnIndex);
    //get corresponding node table (left/right)
    currentColIndexNumber = columnIndex;
    if (headerTable.id.search(/right/) != -1){
      NT = T.NTR;
      currentColIndexNumber++;
    }
    else if (headerTable.id.search(/left/) != -1)
      NT = T.NTL;
    currentColIndexNumber--;
    //get corresponding node table colgroup col
    if (T.hasNodes){
      NTColWidthToWorkOn = getColWidthToWorkOn(NT, columnIndex);
    }
    initialized = true;
  }

    /**
     *   private method getColgroupElement
     */

  var getColgroupElement = function(tableElement){
    var colGroup = tableElement.childNodes[0];
    while (colGroup.tagName != "COLGROUP" && colGroup.nextSibling)
      colGroup = colGroup.nextSibling;
    return colGroup;
  }

    /**
     *   private method getColWidthToWorkOn
     */

  var getColWidthToWorkOn = function(tableElement, columnNumber){
    var colWidthToWorkOn = 0;
    var colCount = 0;
    var currentColWidth = getColgroupElement(tableElement).firstChild;
    while (currentColWidth.nextSibling){
      if (currentColWidth.tagName == "COL"){
        colCount++;
        if (colCount == columnNumber){
          colWidthToWorkOn = currentColWidth;
          break;
        }
      }
      currentColWidth = currentColWidth.nextSibling;
    }
    return colWidthToWorkOn;
  }



 /**
   *   public method resize
   *   Resizes the column/container-dom elements of the tree
   *   according to the new column width chosen by the user.
   */

    this.resize = function (resPars){
        //T.addDbgMsg('colResize: start of method resize');
        var colWidthChange  = resPars.newColWidth - currentCol.offsetWidth,
            newColWidthInPx = resPars.newColWidth + "px";

    //resize node table columns
    if (T.hasNodes){
        NT.style.width           = NT.offsetWidth + colWidthChange;
        NTColWidthToWorkOn.width = newColWidthInPx;
    }
    //now resize header table columns
    headerTable.style.width = headerTable.offsetWidth + colWidthChange;
    currentCol.style.width  = newColWidthInPx;
    innerDiv.style.width    = resPars.newColWidth - treeCollection.settings.innerDivOffset + "px"; // compare template: colresize_area_width + 1;
    colWidthToWorkOn.width  = resPars.newColWidth; //col tag

    //was resize in left node table? then resize scrollcontainers and meta table cells
    if (resPars.isFirstColumnResized){
      var remainingWidthInPx = resPars.MTWidth - resPars.newColWidth + "px";
      if ( colWidthChange > 0 ){

        //firstly decrease right part's width, than increase left part's width
        T.MCR.style.width      = remainingWidthInPx; //this is a col tag
        T.HSCR.style.width     = remainingWidthInPx;

        if (T.hasNodes){

            T.SCR.style.width     = remainingWidthInPx;
            T.SCR.style.height    = HHeightLessInPx;

            T.MCLCell.style.width = newColWidthInPx;
            T.SCL_width           = newColWidthInPx;
            T.SCL.style.width     = newColWidthInPx;
            T.SCL.style.height    = HHeightLessInPx;
        }
        T.MCL.style.width         = newColWidthInPx;  //this is a col tag
      }
      else{
        //firstly decrease left part's width, than increase right part's width
        T.MCL.style.width         = newColWidthInPx; //this is a col tag

        if (T.hasNodes){
            T.MCLCell.style.width  = newColWidthInPx;
            T.SCL_width            = newColWidthInPx;
            T.SCL.style.width      = newColWidthInPx;
            T.SCL.style.height     = HHeightLessInPx;
            T.SCR.style.width      = remainingWidthInPx;
            T.SCR.style.height     = HHeightLessInPx;
        }

        T.HSCR.style.width = remainingWidthInPx;
        T.MCR.style.width  = remainingWidthInPx; //this is a col tag

      }
      // scrollBarChecks are only necessary if hierarchy column was resized
      if (T.hasNodes){
        T.scrollBarChecks();
      }
    }

    /* todo:
       a) if tables are smaller than before increase width of last column to maximum
       b) if tables are wider than before decrease last column to minimum
    */
  }

  /**
   *   public method getCurrentColIndexNumber
   */

  this.getCurrentColIndexNumber = function(){
    return currentColIndexNumber;
  }

    /**
     *   constructor
     */
    var
      T = theTreeObject,
      currentCol = theCurrentCol,
      HHeightLessInPx = "",
      innerDiv = null,
      columnIndex = null,
      colWidthToWorkOn = null,
      NT = null,
      NTColWidthToWorkOn = null,
      initialized = false,
      currentColIndexNumber = null;

    init();
}

/**
 *    object timerSession
 *    sessionTimeout = milliseconds to keep the session alive
 */

function timerSession(sessionTimeout, callerObj, callBackOnSessionTimeout){

  var timer,
      startTime,
      lastSignOfLive,
      hasRunOut = true,
      callBackFunc = callerObj + ".checkIfStillAlive()";

    var reset = function(){
      timer = new Date();
      startTime = timer.getTime();
      lastSignOfLive = startTime;
      hasRunOut = false;
  }

  this.keepAlive = function(){
      if (!hasRunOut){
          timer = new Date();
          lastSignOfLive = timer.getTime();
          window.setTimeout(callBackFunc, sessionTimeout);
      }
      else{
          eval(callBackOnSessionTimeout);
          reset();
      }
  }

  this.checkIfStillAlive = function(){
    if (!hasRunOut){
      timer = new Date();
      var now = timer.getTime();
      var calc = lastSignOfLive <= now - sessionTimeout;
      if (calc){
        //session is dead
        hasRunOut = true;
        eval(callBackOnSessionTimeout);
      }
    }
  }
}