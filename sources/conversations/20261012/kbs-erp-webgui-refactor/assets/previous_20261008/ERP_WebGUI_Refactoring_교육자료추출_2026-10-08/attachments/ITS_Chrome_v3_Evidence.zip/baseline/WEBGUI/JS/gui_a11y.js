////////////////////////////////////////////////////////////////////////////////
////////////////////////////// ACCESSIBILITY ///////////////////////////////
////////////////////////////////////////////////////////////////////////////////


//
// a11y_resetTab(
//
function a11y_resetTab()
{
  var first = document.getElementsByName("firstFocusElement");

  if (first && first.length)
    dom_focus(first[0]);
}

//
// a11y_checkAltControlTab(
//
function a11y_checkAltControlTab()
{

}

//
// A11YSETALBBID(id)
//
function a11ySetAltBId(id)
{
  a11yAltB = id;
}

//
// A11YGETALTBID()
//
function a11yGetAltBId()
{
  return a11yAltB;
}

//
// DO AREA END ON KEY DOWN
//
function doAreaEndOnKeyDown()
{
  a11yLastKey=event.keyCode;
}

//
// DO AREA BEGIN ON KEY DOWN
//
function doAreaBeginOnKeyDown(id)
{
  var myId = event.srcElement.id;
  a11yLastKey=event.keyCode;

  if (a11yLastKey == 9) // tab
  {
    if (event.shiftKey==true) // backward
        a11ySetAltBId("");
    else                      // forward
        a11ySetAltBId(myId);
  }
  else if (event.altKey && a11yLastKey == 66) // Alt + b
  {
    a11ySetAltBId("");
  }
  else if ((event.keyCode == 83) && (id != ""))
  {
    var next = document.getElementById(id);

    if (next)
    {
      webguiSetFocus(id);
    }
    else
      alert("couldn't get " + id);
  }
}

//
// DO AREA BEGIN ON FOCUS
//
function doAreaBeginOnFocus(id)
{
  var altB = a11yGetAltBId();
  var myId = event.srcElement.id;

  window.status=event.srcElement.alt;
  if (altB) // id already set
  {
    if (altB == myId)
    {
      if (event.altKey && a11yLastKey == 90) // Alt + z
      {
        a11ySetAltBId(myId);
      }
      else if (event.altKey && a11yLastKey == 66) // Alt + b
      {
        a11ySetAltBId("");
      }
      else if (a11yLastKey == 9) // tab
      {
        if (event.shiftKey==true) // backward
          a11ySetAltBId("");
        else                      // forward
          a11ySetAltBId(myId);
      }
    }
    else // Id set, not this one
    {
      if (event.altKey) // can't check event.keyCode unfortunately, as it's always 0 here
      {
        var a11y_b = document.getElementById(altB);
        if (a11y_b)
          dom_focus(a11y_b);
      }
    }
  }
}

//
// DO AREA END ON BLUR
//
function doAreaEndOnBlur(id)
{
  window.status="";
  if (a11yLastKey == 9) // tab
    a11ySetAltBId("");
}

//
// A11Y_CHECK() - checks for arrow navigation
//
function a11y_Check()
{
  if (event.srcElement.tagName != "SELECT") // don't do it on drop down boxes
  {
    if (event.keyCode==40) // down
    {
      return a11y_check_DownArrow();
    }
    else if (event.keyCode==38) // up
    {
      return a11y_check_UpArrow();
    }
  }
  return "";
}

//
// A11Y_CHECK_GETPARENTINFO
//
function a11y_check_getParentInfo(obj,params)
{
  var o = obj;
  while (o.tagName != "TD")
    o = o.parentNode;
  params[0] = o.cellIndex;
  params[1] = o.parentNode.rowIndex;
  var tbl = o;
  while (tbl.tagName != "TABLE")
    tbl = tbl.parentNode;
  params[2]=tbl;
}

//
// A11Y_REMOVE_ROWLABEL
//
function a11y_remove_rowLabel()
{
  var labelText, i = 0;
  var o = event.srcElement;
  o.onblur="";
  while (o.tagName != "TD")
    o = o.parentNode;
  var kids = o.children;
  for (i=0;i < kids.length; i++)
  {
    if (kids(i).tagName == "LABEL")
    {
      labelText = kids(i).innerText.split(a11y_firstRow);
      kids(i).innerText = (labelText.length == 1) ? labelText[0].split(a11y_lastRow)[1] : labelText[1];
      return;
/*    if (labelText.indexOf(a11y_lastRow) != -1) labelText = labelText.slice(a11y_lastRow.length);
    else if (labelText.indexOf(a11y_firstRow) != -1) labelText = labelText.slice(a11y_firstRow.length); */
    }
  }
  if (kids.length == 0)
  {
    labelText = o.title.split(a11y_firstRow);
    o.title= (labelText.length == 1) ? labelText[0].split(a11y_lastRow)[1] : labelText[1];
  }
}


//
// A11Y_CHECK_DOWNARROW_LASTTD
//
function a11y_check_DownArrow_LastTD(lastTD,numRows)
{
  var child;
  for (i = 0; i < lastTD.children.length; i++)
  {
    child = lastTD.children(i);
    if (child.tagName == "LABEL")
    {
      if (child.innerText.indexOf(a11y_lastRow) == -1)
        child.innerText = a11y_lastRow + " " + child.innerText;
    }
    else if (child.tagName == "INPUT")
      child.onblur=a11y_remove_rowLabel;
  } // end for
  if (lastTD.children.length == 0) // just the TD mam
  {
    lastTD.title = a11y_lastRow + " " + lastTD.title;
    lastTD.onblur= a11y_remove_rowLabel;
  }
}

//
// A11Y_CHECK_UPARROW_FIRSTTD
//
function a11y_check_UpArrow_FirstTD(firstTD,numRows)
{
  var child;
  for (i = 0; i < firstTD.children.length; i++)
  {
    child = firstTD.children(i);
    if (child.tagName == "LABEL")
    {
      if (child.innerText.indexOf(a11y_firstRow) == -1)
        child.innerText = a11y_firstRow + " " + child.innerText;
    }
    else if (child.tagName == "INPUT")
      child.onblur=a11y_remove_rowLabel;
  } // end for
  if (firstTD.children.length == 0) //if label found
  {
    firstTD.title = a11y_firstRow + " " + firstTD.title;
    firstTD.onblur= a11y_remove_rowLabel;
  }

}

//
// A11Y_CHECK_SETFOCUS
//
function a11y_check_SetFocus(nextTD)
{
  if (nextTD == null)
    return;
  var i;
  for (i = 0; i < nextTD.children.length; i++)
  {
    if (nextTD.children(i).tagName == "INPUT" || nextTD.children(i).tagName == "SELECT")
    {
      if ((nextTD.children(i).type != "checkbox") && (nextTD.children(i).type != "hidden"))
      {
        dom_focus(nextTD.children(i));
        break;
      }
      else
        nextTD.click();
    }
  }
  if (i == nextTD.children.length)
  {
    try { // might get a "cannot move focus to... error
      dom_focus(nextTD); // firstChild.click() raised an error with non-editable ALV Grids (?)
    } catch(err) {//      alert("caught in a11y_check_SetFocus: " + err.message());
      nextTD.click();
    }
  }
}

//
// A11Y_CHECK_DOWNARROW
//
function a11y_check_DownArrow()
{
  var cI,rI,tbl,nextTD,lastTD;
  var params = new Array(3);
  a11y_check_getParentInfo(event.srcElement,params);
  cI = params[0];
  rI = params[1];
  tbl = params[2];

  if (rI != tbl.rows.length - 1)
  {
    nextTD = tbl.rows(rI + 1).cells(cI);
    // test for 2nd row from bottom to change its label to read "last row"
    if (rI == tbl.rows.length - (((tbl.className == "webguiInnerTCView") ? 3 : 2))) /* -3 for [table] controls with footers */
    {
      lastTD = tbl.rows(tbl.rows.length - (((tbl.className == "webguiInnerTCView") ? 2 : 1))).cells(cI);
      a11y_check_DownArrow_LastTD(lastTD,tbl.rows.length);
    }
    a11y_check_SetFocus(nextTD);
  }
  else //     event.cancelBubble =true; event.returnValue = false;
    return "down"; // nextTD = tbl.rows(1).cells(cI); // would be for looping, but probably not the best idea
}

//
// A11Y_CHECK_UPARROW
//
function a11y_check_UpArrow()
{
  var cI,rI,tbl,nextTD,firstTD;
  var params = new Array(3);
  a11y_check_getParentInfo(event.srcElement,params);
  cI = params[0];
  rI = params[1];
  tbl = params[2];

  if (rI != 0)
  {
    prevTD = tbl.rows(rI - 1).cells(cI);
    // test for 2nd row from top (second row) to change its lable to read "first row"
    // test for HEADER ROW!!!!!!
    if (rI == 2) // if second row
    {
      firstTD = tbl.rows(1).cells(cI);
      a11y_check_UpArrow_FirstTD(firstTD,tbl.rows.length);
    }
    a11y_check_SetFocus(prevTD);
  }
  else
    return "up";
}
