var gCurrentMenu;


function Hilight ( in_event )
{
  if (null != in_event)
  {
    e = (null != in_event.srcElement) ? in_event.srcElement : in_event.target;

    if (null != e)
    {
      if (e.className   == "NewMenuItemFont"
         || e.className == "NewMenuArrow"
         || e.className == "NewMenuArrowNone"
         || e.className == "NewMenuCheck"
         || e.className == "NewMenuCheckNone"
         )
        e = MenuItemFindParentDiv(e);

      if (null != e)
      {
        if (null == e.oldclassName)
          e.oldclassName = e.className;

        e.className = "NewMenuItemHilited";

        if (gCurrentMenu != e)
        {
          Lowlight(gCurrentMenu);
          parent.CloseMenus(Number(document.getElementById("scrollDIV").getAttribute("DEPTH"))+1);
        }
        gCurrentMenu = e;

        if ("focus" != in_event.type)
        {
          dom_focus(e);
        }
      }
    }
  }
} // Hilight()
Hilight.cnt = 0;


function HilightDisabled ( event )
{
  var s;
  var e;

  if (event.target) e = event.target;
  else if (event.srcElement) e = event.srcElement;

  if (  e.className == "NewMenuItemFontDisabled"
     || e.className == "NewMenuArrow"
     || e.className == "NewMenuArrowNone"
     || e.className == "NewMenuCheck"
     || e.className == "NewMenuCheckNone"
     )
    e = MenuItemFindParentDiv(e);

  if (null != e)
  {
    s = e.style;

    if (null == e.oldclassName)
      e.oldclassName = e.className;

    e.className = "NewMenuItemDisabledHilited";

    if (gCurrentMenu!=e)
    {
      Lowlight(gCurrentMenu);
      parent.CloseMenus(Number(document.getElementById("scrollDIV").getAttribute("DEPTH"))+1);
    }
    gCurrentMenu = e;
  }
} // HilightDisabled()


function Lowlight ( e )
{
  var s;

  if (null != e)
  {
    if (e.className == "NewMenuItemFont"
        || e.className =="NewMenuArrow"
        || e.className =="NewMenuArrowNone"
        || e.className == "NewMenuCheck"
        || e.className == "NewMenuCheckNone"
       )
      e = MenuItemFindParentDiv(e);

    if (null != e)
    {
      s = e.style;
      e.className = e.oldclassName; // "NewMenuItemEnabled";
    }
  }
} // Lowlight()


function Action ( cmd, event )
{
  DoMenuClick(cmd, event);
  parent.CloseMenus(0);
} // Action()


function ShowSubMenu ( cmd, event )
{
  var e,
      thisLevel, menuFrame,
      expand
      ;

  if (event.srcElement) e = event.srcElement;
  else if (event.target) e = event.target;

  Hilight(event);
  expand = (e.getAttribute("dontexpand") != 1);

  e.setAttribute("dontexpand",-1);
  if (e.className == "NewMenuItemFont"
      || e.className =="NewMenuArrow"
      || e.className =="NewMenuArrowNone"
      || e.className == "NewMenuCheck"
      || e.className == "NewMenuCheckNone"
     )
    e = MenuItemFindParentDiv(e);

  if (e)
  {
    thisLevel = parseInt(document.getElementById("scrollDIV").getAttribute("DEPTH"));
    menuFrame = parent.document.getElementById("MenuFrame"+ thisLevel);
    if (menuFrame)
      menuFrame.keyNavIndex = parseInt(e.getAttribute("VPOS"));

    if (expand)
    {
      parent.OpenMenu(cmd, e.getAttribute("VPOS"), event);
    }
  }
} // ShowSubMenu()


function DoMenuClick ( idx, event )
{
  var i;
  var j;
  var s = "";
  if (idx.substr(0,1)=="F")
  {
    // function menu
    parent.webguiRaiseFKey(idx.substr(1));
  }
  else
  if ( idx.substr(0,1)=="J" )
  {
    // other Menu;
    eval("parent."+idx.substr(1,idx.length-1));
  }
  else
  {
    parent.webguiRaiseSelectMenuItem(idx);
  }
} // DoMenuClick()


function MenuItemFindParentDiv ( element )
{
  var parentDIV = element.parentNode;
  while (parentDIV)
  {
    if (parentDIV.tagName == "DIV")
      return parentDIV;
    else
      parentDIV = parentDIV.parentNode;
  }
  return null;
} // MenuItemFindParentDiv()



////////////////////////////////////////////////////////////////////////////////
//
// keyNavDown
//
////////////////////////////////////////////////////////////////////////////////
function keyNavDown(currentNavIdx, scrollDIV, menuFrame, event)
{
  if (currentNavIdx == scrollDIV.childNodes.length-1)
    newNavIdx = 0;
  else
    newNavIdx = currentNavIdx + 1;

  while (scrollDIV.childNodes[newNavIdx].className == "NewMenuSeparator")
  {
    if (newNavIdx == scrollDIV.childNodes.length-1)
      newNavIdx = 0
    else
      newNavIdx++;
  }
  menuFrame.keyNavIndex = newNavIdx;
  dom_focus(scrollDIV.childNodes[newNavIdx]);
}

////////////////////////////////////////////////////////////////////////////////
//
// keyNavUp
//
////////////////////////////////////////////////////////////////////////////////
function keyNavUp(currentNavIdx, scrollDIV, menuFrame, event)
{
  if (currentNavIdx == 0)
    newNavIdx = scrollDIV.childNodes.length - 1;
  else
    newNavIdx = currentNavIdx - 1;

  while (scrollDIV.childNodes[newNavIdx].className == "NewMenuSeparator")
  {
    if (newNavIdx == 0)
      newNavIdx = scrollDIV.childNodes.length - 1;
    else
      newNavIdx--;
  }

  menuFrame.keyNavIndex = newNavIdx;
  dom_focus(scrollDIV.childNodes[newNavIdx]);

}

////////////////////////////////////////////////////////////////////////////////
//
// keyNavLeft / Esc
//
////////////////////////////////////////////////////////////////////////////////
function keyNavLeft(currentLevel, event)
{
  var parentMenuFrame,
      parentScrollDIV,
      menu
      ;
  if (0 < currentLevel)
  {
    parent.CloseMenus(currentLevel);
    parentMenuFrame = parent.document.getElementById("MenuFrame"+(currentLevel-1));
    if (null != parentMenuFrame)
    {
      parentScrollDIV = parentMenuFrame.contentWindow.document.getElementById("scrollDIV");
      if (parentScrollDIV)
        dom_focus(parentScrollDIV.childNodes[parentMenuFrame.keyNavIndex]);
    }
  }
  else
  {
    parent.CloseMenus(0);
    menu = parent.document.getElementById("NewMenuslBar");
    if (null != menu)
    {
      try {
        var firstChild = menu.firstChild;
        dom_focus(firstChild);
      } catch(exception) { status = " caught exception : " + exception.message; }
    }
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// keyNavRight
//
////////////////////////////////////////////////////////////////////////////////
function keyNavRight(currentMenuEntry, currentLevel, event)
{
  var submenuAr = currentMenuEntry.getAttribute("showsubmenu"),
      nextMenuFrame,
      nextScrollDIV
      ;
  if (null != submenuAr)
  {
    ShowSubMenu(submenuAr, event);
    nextMenuFrame = parent.document.getElementById("MenuFrame"+(currentLevel+1));
    if (null != nextMenuFrame)
    {
      nextScrollDIV = nextMenuFrame.contentWindow.document.getElementById("scrollDIV");
      if (nextScrollDIV)
      {
        dom_focus(nextScrollDIV.childNodes[nextMenuFrame.keyNavIndex]);
      }
    }
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// keyNavEnter
//
////////////////////////////////////////////////////////////////////////////////
function keyNavEnter(currentMenuEntry, in_event)
{
  var target, actionAr;

  if (null != in_event)
  {
    in_event.cancelBubble = true;
    if (null != in_event.stopPropagation) in_event.stopPropagation();

    if (null != parent.webguiTSPulldownMenu)
    {
      target = (null != in_event.srcElement) ? in_event.srcElement : in_event.target;
      if (null != target && target.className == "NewMenuItemHilited")
        target.click();
    }
    else
    {
      actionAr = currentMenuEntry.getAttribute("Action");
      if (null != actionAr)
        Action(actionAr, event);
    }
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// kevNavMenu
//
////////////////////////////////////////////////////////////////////////////////
function keyNavMenu ( in_event )
{
  var newNavIdx,
      ev, scrollDIV, menuFrame,
      currentLevel, currentMenuEntry, currentNavIdx
      ;

  ev = (null == in_event) ? in_event = window.event : in_event;
  if (null != ev)
  {
    src = (null == ev.srcElement) ? ev.target : ev.srcElement;
    if (src)
    {
      currentMenuEntry = src;
      scrollDIV     = document.getElementById("scrollDIV");
      currentLevel  = (null != scrollDIV) ? parseInt(scrollDIV.getAttribute("DEPTH")) : -1;
      menuFrame     = (isNaN(currentLevel)) ? null : parent.document.getElementById("MenuFrame"+currentLevel);
      currentNavIdx = (null != menuFrame) ? parseInt(menuFrame.keyNavIndex) : null;
      if (isNaN(currentNavIdx)) currentNavIdx = parseInt(self.keyNavIndex);

      if (scrollDIV && currentNavIdx >= 0)
      {
        // 40 down  arrow
        // 39 right arrow
        // 38 up    arrow
        // 37 left  arrow
        // 27 escape

        switch (ev.keyCode)
        {
          case 40 : keyNavDown(currentNavIdx, scrollDIV, menuFrame, ev); break;
          case 38 : keyNavUp(currentNavIdx, scrollDIV, menuFrame, ev);   break;
          case 39 : keyNavRight(currentMenuEntry, currentLevel, ev);     break;
          case 37 :
          case 27 : keyNavLeft(currentLevel, ev);                        break;
          case 13 : keyNavEnter(currentMenuEntry, ev);                   break;
          case  9 : keyNavTab(ev);
                    if (null != ev.preventDefault) { ev.preventDefault(); ev.stopPropagation(); }
                    else                           { ev.cancelBubble; ev.returnValue = false;   }
                    break;
          default : parent.webguiDoKeyDown(ev);                          break;
        }
        if (null != (currentNavIdx = (null != menuFrame) ? parseInt(menuFrame.keyNavIndex) : null))
        {
          dom_focus(scrollDIV.childNodes[currentNavIdx]);
        }
      }
    }
  }
} // keyNavMenu()


function keyNavTab(event)
{
  // to do
}


// abp 07.08.2003 - also in generator.js
function getAttributeRecursive(obj, attrib)
{
  if (obj.getAttribute(attrib) != 0)
    return obj;
  else if (obj.childNodes)
  {
    var temp;
    for (var i = 0; i < obj.childNodes.length; i++)
    {
      temp = getAttributeRecursive(obj.childNodes[i], attrib);
      if (temp)
      {
        return temp;
      }
    }
    return null;
  }
  else
    return null;
}
