var CAL_SELECTIONMODE_WEEK = 2,
  CAL_SELECTIONMODE_MONTH = 4,
  // Keep dynamic selection/month reset colors aligned with calendar.css.
  CAL_BGCOLOR_SELECTION = "#D6E6F5",
  CAL_BGCOLOR_M0 = "#FFFFFF",
  CAL_BGCOLOR_M1 = "#F0F3F6",
  CAL_A11Y_SELECTED_TEXT = "",
  CAL_A11Y_DTP_DAY = "Calendar DatePicker Day",
  CAL_A11Y_DTP_MONTH = "Calendar DatePicker Month",
  CAL_A11Y_DTP_YEAR = "Calendar DatePicker Year",
  CAL_A11Y_ON = false,
  CAL_A11Y_TITLE = "",
  CAL_MIN_MONTH = "010101",
  CAL_MIN_DATE = "01010101";

function calendarStopPropagation(event)
{
  if ( its_ua.ie55up )
    event.cancelBubble = true;
  else
    event.stopPropagation();
}

function calendarGetPrefix(id)
{
 return id+"x";
}

function calendarGetWebGuiWindow()
{
 var webGuiWindow = self;
 while( webGuiWindow != null && webGuiWindow != webGuiWindow.parent && webGuiWindow.document.webguiform == null )
  webGuiWindow = webGuiWindow.parent;
 return webGuiWindow;
}

function calendarGetNextDay(calId, date)
{
 if( date != null && date.length == 8 )
 {
  var idPrefix = calendarGetPrefix(calId);
  var year = date.slice(0,4);
  var month = date.slice(4,6);
  var day = 0;

  if( date.charAt(6) == '0' )
   day = parseInt(date.slice(7,8)) + 1;
  else
   day = parseInt(date.slice(6,8)) + 1;

  date = year + month + (day < 10 ? "0"+day : day);
  if( document.getElementById(idPrefix + date) == null )
  {
   if( date.charAt(4) == '0' )
    month = parseInt(date.slice(5,6));
   else
    month = parseInt(date.slice(4,6));
   var bDayInRange = false;
   var lastDay = document.getElementById(calId).getAttribute('LastVisibleDate');
   do
   {
    if( month == "12" && day >= 31 )
    {
   if( year == "9999" )
   return null;

     year = new String(parseInt(year)+1);
     month = 1;
     day = 0;
    }
    else if( day >= 31 )
    {
     if( date.charAt(4) == '0' )
      month = parseInt(date.slice(5,6))+1;
     else
      month = parseInt(date.slice(4,6))+1;
     day = 0;
    }
    day++;
    date = year + (month < 10 ? "0"+month : month) + (day < 10 ? "0"+day : day);

    if( document.getElementById(idPrefix + date) != null )
     bDayInRange = true;
   }
   while( date < lastDay && !bDayInRange );
   if( !bDayInRange )
    return null;
  }
  return date;
 }
 return null;
}

function calendarGetPreviousDay(calId, date)
{
 if( date != null && date.length == 8 )
 {
  var idPrefix = calendarGetPrefix(calId);
  var year = date.slice(0,4);
  var month = date.slice(4,6);
  var day = 0;

  if( date.charAt(6) == '0' )
   day = parseInt(date.slice(7,8)) - 1;
  else
   day = parseInt(date.slice(6,8)) - 1;

  date = year + month + (day < 10 ? "0"+day : day);
  if( document.getElementById(idPrefix + date) == null )
  {
   var bDayInRange = false;
   var firstDay = document.getElementById(calId).getAttribute('FirstVisibleDate');
   if( date.charAt(4) == '0' )
    month = parseInt(date.slice(5,6));
   else
    month = parseInt(date.slice(4,6));

   do
   {
    if( month == 1 && day <= 1 )
    {
     year = parseInt(year)-1;
     month = 12;
     day = 32;
    }
    else if( day <= 1 )
    {
     if( date.charAt(4) == '0' )
      month = parseInt(date.slice(5,6))-1;
     else
      month = parseInt(date.slice(4,6))-1;
     day = 32;
    }
    day--;
    date = year + (month < 10 ? "0"+month : month) + (day < 10 ? "0"+day : day);
    if( document.getElementById(idPrefix + date) != null )
     bDayInRange = true;
   }
   while( date > firstDay && !bDayInRange );
   if( !bDayInRange )
    return null;
  }
  return date;
 }
 return null;
}


function calendarClickReload(calId, bAppend, date)
{

 //in accessibility mode we do not allow silent reload events,
 //otherwise the tab order hierarchy will get inconsistent
 if( document.getElementById(calId).getAttribute('EvInfoRequest')
  || (CAL_A11Y_ON && !document.getElementById(calId).getAttribute('DisplayModePopup')) )
 {
  if( date == null )
   calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReload", "bAppend=" + bAppend + "&bSilent=0");
  else
   calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReloadByDate", "strDate=" + date + "&bSilent=0");
 }
 else
 {
  if( document.getElementById(calId).getAttribute('DisplayModePopup') )
  {
   document.getElementById(calId + "CONT").style.visibility = "hidden";
   if( date == null )
    calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReload", "bAppend=" + bAppend + "&bSilent=1", true, calId + "Popup");
   else
    calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReloadByDate", "strDate=" + date + "&bSilent=1", true, calId + "Popup");
  }
  else
  {
   if( date == null )
    calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReload", "bAppend=" + bAppend + "&bSilent=1", true, "calendarData");
   else
    calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "OnReloadByDate", "strDate=" + date + "&bSilent=1", true, "calendarData");
  }
 }

 return false; //stop default action
}

function calendarSetSelection(calId, fromDate, toDate, bMultiRangeSel)
{
 if( fromDate != null && toDate != null && fromDate.length == 8 && toDate.length == 8 )
 {
  //check if selection belongs to year 10000
  var yearFrom = fromDate.slice(0,4);
  var yearTo = toDate.slice(0,4);
  if( yearFrom == "0000" || yearTo == "0000" )
   return false;

  if( fromDate > toDate )
  {
   var tmp = fromDate;
   fromDate = toDate;
   toDate = tmp;
  }

  var thisCal=eval("document.getElementById('" + calId + "')");

  if ((fromDate >= thisCal.getAttribute('FirstVisibleDate') || toDate >= thisCal.getAttribute('FirstVisibleDate')) &&
   (fromDate <= thisCal.getAttribute('LastVisibleDate') || toDate <= thisCal.getAttribute('LastVisibleDate')))
  {
   var idPrefix = calendarGetPrefix(calId);
   var el = null;
   var date = fromDate;
   var selRange = thisCal.getAttribute("SelectedRange");
   var newSelRange = new Array();
   while( date != null && date <= toDate )
   {
    el = document.getElementById(idPrefix + date);

    if( el != null )
    {
     if( el.tagName == "DIV" )
      el = calendarGetParent(el);
    }
    if( el != null )
    {
     el.style.backgroundColor = CAL_BGCOLOR_SELECTION;
     if( bMultiRangeSel )
      // This local array is not published until the loop finishes; avoid repeated copies.
      newSelRange.push(date);
     if( CAL_A11Y_ON )
       el.title = el.innerHTML + CAL_A11Y_SELECTED_TEXT;
    }
    date = calendarGetNextDay(calId, date);
   }
   if( bMultiRangeSel )
   {
    //save selection only in multiRangeSelection mode
    if( toDate < selRange[0] )
    {
     //insert at beginning
     thisCal.setAttribute("SelectedRange", newSelRange.concat(selRange));
    }
    else
    {
     thisCal.setAttribute("SelectedRange", selRange.concat(newSelRange));
    }
   }
  }
  return true;
 }
 return false;
}


//clears the selection in the specified range and updates the local cache
function calendarClearSelection(calId, fromDate, toDate, bMultiRangeSel)
{
 if( fromDate != null && toDate != null && fromDate.length == 8 && toDate.length == 8 )
 {
  if( fromDate > toDate )
  {
   var tmp = fromDate;
   fromDate = toDate;
   toDate = tmp;
  }
  var thisCal = eval("document.getElementById('" + calId + "')");

  if ((fromDate >= thisCal.getAttribute('FirstVisibleDate') || toDate >= thisCal.getAttribute('FirstVisibleDate')) &&
    (fromDate <= thisCal.getAttribute('LastVisibleDate') || toDate <= thisCal.getAttribute('LastVisibleDate')))
  {
   var idPrefix = calendarGetPrefix(calId);
   var el = null;
   var date = fromDate;
   var selRange = thisCal.getAttribute('SelectedRange');
   var newSelRange = null;
   var removed = 0;

   while(date != null && date <= toDate)
   {
    el = document.getElementById(idPrefix + date);
    if( el != null )
    {
     if( el.tagName == "DIV" )
      el = calendarGetParent(el);
    }
    if( el != null )
    {
     var className = el.className;
     if( className != null )
     {
      //restore backgroundcolor
      if( className.search("M0") != -1 )
       el.style.backgroundColor = CAL_BGCOLOR_M0;
      else if( className.search("M1") != -1 )
       el.style.backgroundColor = CAL_BGCOLOR_M1;

      if( CAL_A11Y_ON )
       el.title = "";
     }
     if( bMultiRangeSel )
     {
      //mark day for deletion
      removed++;
      for( var i=0, j=0; i < selRange.length; i++)
      {
       if( selRange[i] == date )
       {
        selRange[i] = null;
        break;
       }
      }
     }
    }
    date = calendarGetNextDay(calId, date);
   }
   if( removed > 0 )
   {
    //store the remainder
    newSelRange = new Array( selRange.length - removed );
    for( var i=0, j=0; i < selRange.length; i++)
    {
     if( selRange[i] != null )
      newSelRange[j++] = selRange[i];
    }
    document.thisCal.setAttribute("SelectedRange", newSelRange);
   }
  }
 }
}

//calculate column width in fit mode
function calendarOnResize(calId, calContId, calScrlId)
{
 var navTop = 0, popupBtnWidth = 16, dtpwidth, scrollbarWidth = 0;
 var calCont = document.getElementById(calContId);
 if (calCont == null)
  return false;
 var calDtp = document.getElementById(calId+ "dtpicker");
 var calPopupBtn = document.getElementById(calId+ "PopupButton");
 var navScrl = document.getElementById(calScrlId);
 var nav = document.getElementById(calId);
 if (calDtp)
 {
  if ( calPopupBtn )
  {
   if ( its_ua.ie55up )
    dtpwidth = calCont.offsetWidth - 16;
   else
    dtpwidth = calCont.offsetWidth - 18;
  }
  else
   dtpwidth = calCont.offsetWidth - 2;
  if (nav == null)
   calDtp.style.width = dtpwidth;
  navTop = 20;
 } else {
  if ( calCont.offsetWidth > 16)
   popupBtnWidth = calCont.offsetWidth;
 }
 if (calPopupBtn)
  calPopupBtn.style.width = popupBtnWidth;

 if (nav == null)
  return false;
 var navoffsetWidth = nav.offsetWidth;
 navScrl.style.height = calCont.offsetHeight - navTop - 2;
 if ( navScrl.offsetHeight < nav.offsetHeight )
  scrollbarWidth = 16;
 if ( (navoffsetWidth + scrollbarWidth > calCont.offsetWidth - 2) || (nav.getAttribute('DisplayModeFit') && !nav.getAttribute('DisplayModeHorizontal')))
  navScrl.style.width = calCont.offsetWidth -  2;
 else
  navScrl.style.width = navoffsetWidth + scrollbarWidth;
 if (nav.align != nav.getAttribute('DisplayModeAlign'))
  nav.align = nav.getAttribute('DisplayModeAlign');
 if (!its_ua.ie55up && !nav.getAttribute('DisplayModeHorizontal') && (navoffsetWidth + scrollbarWidth > calCont.offsetWidth - 2))
 {
  if (nav.getAttribute('DisplayModeAlign') == "right")
   nav.align = "left";
  else
   nav.align = "right";
 }



 if (nav.getAttribute('DisplayModeFit'))
 {
  if( nav.getAttribute('DisplayModeHorizontal'))
  {
   var contHeight = calendarGetContainerHeight(navScrl, nav);
   var rows = nav.rows;
   var rowCnt = rows.length, row0Height;

   if( rowCnt > 1)
   {
    var i, rowHeight = contHeight/rowCnt;
    for( i=1; i < rowCnt; i++)
     rows[i].cells[0].style.height = rowHeight;
    row0Height = contHeight - (rows[1].cells[0].offsetHeight*(rowCnt-1));
    if (row0Height > 0)
     rows[0].cells[0].style.height = row0Height;
    else
     rows[0].cells[0].style.height = rowHeight;
   }
  }
  else
  {
   var contWidth = calendarGetContainerWidth(navScrl, nav);
   var cells = nav.rows[0].cells;
   var colCnt = cells.length, col0Width;

   if( colCnt > 1)
   {
    var i, colWidth = (contWidth)/(colCnt+1);
    for( i=1; i < colCnt; i++)
     cells[i].style.width = colWidth;
    col0Width = contWidth - (cells[1].offsetWidth*(colCnt-1));
    if ( col0Width > colWidth)
     cells[0].style.width =  col0Width;
    else
     cells[0].style.width =  2  * colWidth;
   }
  }
 }
}

//saves the scroll position in hidden fields of webGui document (in N6 no onscroll-Event yet (Release 1))
function calendarSaveScrollPosition(event)
{
        if ( its_ua.ie55up )
          calScrl = event.srcElement;
        else
          calScrl = event.currentTarget;

 var mainWindow = calendarGetWebGuiWindow();
 if( mainWindow != null && calScrl != null)
        {
          // substract "Scrl" from Container id to get the calendar id
          calId = calScrl.id.slice(0,-4);

   mainWindow.document.getElementById(calId + "ScrollTop").value = calScrl.scrollTop;
   mainWindow.document.getElementById(calId + "ScrollLeft").value = calScrl.scrollLeft;
 }
}

//saves the selection date in hidden fields of webGui document
//ONLY overwrite selection date if not null
function calendarSaveSelection(calId, dateFrom, dateTo)
{
 var mainWindow = calendarGetWebGuiWindow();
 if( mainWindow != null )
 {
  if( dateFrom != null )
   mainWindow.document.getElementById(calId  + "FirstSelDate").value = dateFrom;
  if( dateTo != null )
   mainWindow.document.getElementById(calId + "LastSelDate").value = dateTo;
 }
}

function calendarCancelEvent(event)
{
 if ( its_ua.ie55up ) {
      event.returnValue = false;
      event.cancelBubble = true;
   } else if ( its_ua.gecko ) {
      event.preventDefault();
      event.stopPropagation();
 }
}

function calendarGetKeyCode(event){
    var keyCode = 0;
    if ( its_ua.ie55up )
        keyCode = event.keyCode;
    else if ( its_ua.gecko )
        keyCode = event.charCode;
    return keyCode;
}

function calendarSetFocusStyle(calId, focusDate)
{
 var nav = document.getElementById(calId);
 if (nav.FocusDateSaved) {
  var el = document.getElementById(nav.FocusDateSaved);
  if( el != null ) {
   if( el.tagName == "DIV" )
    el = el.offsetParent;
   el.className = nav.FocusClassSaved;
  }
 }
 var el = document.getElementById(focusDate);
 if( el != null ) {
  if( el.tagName == "DIV" )
   el = el.offsetParent;
  nav.FocusClassSaved = el.className;
  nav.FocusDateSaved = focusDate;
  el.className = nav.FocusClassSaved + " CalF";
 }

}

function calendarMakeDateVisible(calId, date)
{
 var reloadDate = null;
 var append;

 var focusDate = calendarGetPrefix(calId) + date;
 var el = document.getElementById(focusDate);
 if( el != null ) {
  if( el.tagName == "DIV" )
   el = el.offsetParent;
 }
 if( el != null ) {
  if (document.getElementById(calId).getAttribute('DisplayModeHorizontal')) {
   var elLeft = el.offsetLeft;
   var calWidth = document.getElementById(calId + 'SCRL').offsetWidth;
   var calscrlLeft = document.getElementById(calId + 'SCRL').scrollLeft;
   if ( elLeft < calscrlLeft)
    document.getElementById(calId + 'SCRL').scrollLeft = elLeft;
   else if ( (elLeft - calscrlLeft + 19) > calWidth)
    document.getElementById(calId + 'SCRL').scrollLeft = elLeft + 19 - calWidth;
  }
  else {
   var elTop = el.offsetTop;
   var calHeight = document.getElementById(calId + 'SCRL').offsetHeight;
   var calscrlTop = document.getElementById(calId + 'SCRL').scrollTop;
   if ( elTop < calscrlTop)
    document.getElementById(calId + 'SCRL').scrollTop = elTop;
   else if ( (elTop - calscrlTop + 19) > calHeight)
    document.getElementById(calId + 'SCRL').scrollTop = elTop + 19 - calHeight;
  }
 }
 else {
  var firstvisDate = document.getElementById(calId).getAttribute('FirstVisibleDate');
  var lastvisDate = document.getElementById(calId).getAttribute('LastVisibleDate');
  var firstvisDateInt = parseInt(firstvisDate,10);
  var lastvisDateInt = parseInt(lastvisDate,10);
  var reloadDateInt = parseInt(date,10);
  if (reloadDateInt > lastvisDateInt && reloadDateInt < (lastvisDateInt + 10000))
   append = 1;
  else if (reloadDateInt < firstvisDateInt && reloadDateInt > (firstvisDateInt - 10000))
   append = 0;
  else {
   reloadDate = date;
  }
  if (reloadDate == null)
   document.getElementById(calId  + "DtpFocus").value = date;
        var dtp = document.getElementById(calId + "dtpicker");
  document.getElementById(calId  + "DtpFocusField").value = dtp.focusEl.id;
  calendarClickReload(calId, append, reloadDate);
  document.getElementById(calId  + "DtpFocusField").value = "";
  document.getElementById(calId  + "DtpFocus").value = "";
 }

}


//new datepicker functions

function calendarDtpParseFormatString(calId, DTFormat)
{
 var dtp = document.getElementById(calId + "dtpicker");
 var datepos = new Array(0,0,0);
 var datein = new Array(false, false,false);
 var isin = false, inpos, inposold, pos = 1, inposProve, str = "", char = "", match = "DMY";
 var separator = "/", separatorFound = false, firstFound = false, charOld = "", prove = false, strProve = "";
 var dtpformat = DTFormat.toUpperCase() + ".";
 for (var i = 0; i < dtpformat.length; i++) {
  char = dtpformat.charAt(i);
  inpos = match.indexOf(char);
  if (inpos > -1) {
   if (char == charOld)
    str = str + char;
   else {
    charOld = char;
    if (isin == true) {
     prove = true;
     inposProve = inposold;
     strProve = str;
    }
    str = char;
    isin = true;
   }
   inposold = inpos;

  } else {
   if (isin == true) {
    prove = true;
    inposProve = inposold;
    strProve = str;
    isin = false;
    charOld = "";
   }
   if (separatorFound == false && i < (dtpformat.length - 1))
    separator = char;
  }

  if (prove == true) {
   if (strProve.length <= 2 || strProve.charAt(0) == "Y")
    if (firstFound == true)
     separatorFound = true;
    else
     firstFound = true
   else
    firstFound = false;
   if (strProve.length <= 2 && datein[inposProve] == false) {
    if (datepos[inposProve] != 0) {
     for (var j = 0; j <= 2; j++)
      if (datepos[j] > datepos[inposProve])
       datepos[j] = datepos[j] - 1;
     pos = pos - 1;
    }
    datepos[inposProve] = pos;
    datein[inposProve] = true;
    pos = pos + 1;
   } else if (datepos[inposProve] == 0) {
    datepos[inposProve] = pos;
    pos = pos + 1;
   }
   prove = false;
  }
 }
 if (datepos[0] != 0 && datepos[1] != 0 && datepos[2] != 0) {
  dtp.dayFieldId = calId + "dtpinp" + (datepos[0]).toString();
  dtp.monthFieldId = calId + "dtpinp" + (datepos[1]).toString();
  dtp.yearFieldId = calId + "dtpinp" + (datepos[2]).toString();
  dtp.separator = separator;

 } else {
  dtp.dayFieldId = calId + "dtpinp2";
  dtp.monthFieldId = calId + "dtpinp1";
  dtp.yearFieldId = calId + "dtpinp3";
  dtp.separator = "/";
 }
 if( CAL_A11Y_ON ) {
  document.getElementById(dtp.dayFieldId).title = CAL_A11Y_DTP_DAY;
  document.getElementById(dtp.monthFieldId).title = CAL_A11Y_DTP_MONTH;
  document.getElementById(dtp.yearFieldId).title = CAL_A11Y_DTP_YEAR;
 }
}

function calendarDtpSetDate(calId, year, month, day, setfocus, save, sync, focusstyle)
{
 if (year != Number.NaN && month != Number.NaN && day != Number.NaN ) {
  if ( calendarDtpProveDate(calId, year, month, day, true) ) {
   var dtp = document.getElementById(calId + "dtpicker");
   var dtpDay = document.getElementById(dtp.dayFieldId);
   if (day < 10)
    dtpDay.value = "0" + day.toString();
   else
    dtpDay.value = day.toString();
   var dtpMonth = document.getElementById(dtp.monthFieldId);
   if (month < 10)
    dtpMonth.value = "0" + month.toString();
   else
    dtpMonth.value = month.toString();
   var dtpYear = document.getElementById(dtp.yearFieldId);
   if (year < 1000)
    dtpYear.value = "0" + year.toString();
   else
    dtpYear.value = year.toString();
   var date = dtpYear.value + dtpMonth.value + dtpDay.value;
   document.getElementById(calId  + "DtpDate").value = date;
   if (save) {
    dtp.daySaved = day;
    dtp.monthSaved = month;
    dtp.yearSaved = year;
   }
   if (sync && dtp.getAttribute('DisplayModeNavigator')) {
    calendarMakeDateVisible(calId, date)
   }
   if (focusstyle && dtp.getAttribute('DisplayModeNavigator')) {
    calendarSetFocusStyle(calId, calendarGetPrefix(calId) + date);
   }
   if (setfocus && dtp.focusEl)
    dom_select(dtp.focusEl);
  }
 }
}

function calendarDtpGetDays(year, month)
{
 var maxdays = 31;
 if (month == 4 || month == 6 ||month == 9 ||month == 11)
  maxdays = 30;
 else {
  if (month == 2) {
   maxdays = 28;
   if (year%4 == 0 && year%100 != 0 || year%400 == 0)
    maxdays = 29;
  }
 }
 return maxdays;
}

function calendarDtpProveDate(calId, year, month, day, withday)
{
 var dtp = document.getElementById(calId + "dtpicker");
 if (year < dtp.yearBegin || year > dtp.yearEnd)
  return false;
 if (month < 1 || month > 12)
  return false;
 if (withday) {
  var maxdays = calendarDtpGetDays(year, month);
  if (day < 1 || day > maxdays)
   return false;
 }
 return true;
}

function calendarDtpSimulateArrow(calId, id, right)
{
 var newfocusEl = "";
 if (right) {
  if (id == (calId + "dtpinp1"))
   newfocusEl = calId + "dtpinp2";
  else if (id == (calId + "dtpinp2"))
   newfocusEl = calId + "dtpinp3";
  else
   newfocusEl = calId + "dtpinp1";
 } else {
  if (id == (calId + "dtpinp1"))
   newfocusEl = calId + "dtpinp3";
  else if (id == (calId + "dtpinp2"))
   newfocusEl = calId + "dtpinp1";
  else
   newfocusEl = calId + "dtpinp2";
 }
 el = document.getElementById(newfocusEl);
 dom_focus(el);
}

function calendarDtpSimulateTab(calId, id, shiftKey)
{
 var dtp = document.getElementById(calId + "dtpicker");
 if (shiftKey == true) {
  el = document.getElementById(calId + "dtpinp1");
  dom_focus(el);
 } else {
  if ( its_ua.ie55up ) {
   elinput = document.getElementById(id);
   oTextRange = elinput.createTextRange();
   oTextRange.moveStart("character", 0);
   oTextRange.collapse();
   oTextRange.moveEnd("character", 0);
   dom_select(oTextRange);
  }
  el = document.getElementById(calId + "dtpbuttondown");
  dtp.noFocusForButtonDown = true;
  dom_focus(el);
 }

}

function calendarDtpSimulateUpdown(calId, id, up)
{
 var dtp = document.getElementById(calId + "dtpicker");
 var day = parseInt(document.getElementById(dtp.dayFieldId).value,10);
 var month = parseInt(document.getElementById(dtp.monthFieldId).value,10);
 var year = parseInt(document.getElementById(dtp.yearFieldId).value,10);
 var maxDays = 0;
 if (up == true) {
  //up
  if (id ==  (dtp.dayFieldId)) {
   day = day + 1;
  } else { if (id ==  (dtp.monthFieldId)) {
   month = (month == 12) ? 1 : month + 1;
  } else {
   year = (year == dtp.yearEnd) ? dtp.yearEnd : year + 1;
  }}
  maxDays = calendarDtpGetDays(year, month);
  if (id ==  (dtp.dayFieldId) && day > maxDays)
   day = 1;
  else
   day = (day > maxDays) ? maxDays : day;
 } else {
  //down
  if (id ==  (dtp.dayFieldId)) {
   day = day - 1;
  } else { if (id ==  (dtp.monthFieldId)) {
   month = (month == 1) ? 12 : month - 1;
  } else {
   year = (year == dtp.yearBegin) ? dtp.yearBegin : year - 1;
  }}
  maxDays = calendarDtpGetDays(year, month);
  day = (day > maxDays || day < 1) ? maxDays : day;
 }
 calendarDtpSetDate(calId, year, month, day, true, true, true, true);
}

function calendarDtpkeyup(calId, id)
{
 var dtp = document.getElementById(calId + "dtpicker");
 if (dtp.focusEl)
  dom_select(dtp.focusEl);
}

function calendarDtpkeydown(calId, id, event)
{
 var keyCode = event.keyCode;
 if (keyCode == 9) {
  calendarDtpSimulateTab(calId, id, event.shiftKey);
 } else if (keyCode == 37 || keyCode == 39) {
  calendarDtpSimulateArrow(calId, id, (keyCode == 39));
 } else if (keyCode == 38 || keyCode == 40) {
  calendarDtpSimulateUpdown(calId, id, (keyCode == 38));
 } else if (!((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105))) {
  calendarCancelEvent(event);
 }
}

function calendarDtpkeypress(calId, id, event)
{
 var dtp = document.getElementById(calId + "dtpicker");
 var daytemp = document.getElementById(dtp.dayFieldId).value;
 var monthtemp = document.getElementById(dtp.monthFieldId).value;
 var yeartemp = document.getElementById(dtp.yearFieldId).value;
 var daynew = parseInt(daytemp,10);
 var monthnew = parseInt(monthtemp,10);
 var yearnew = parseInt(yeartemp,10);
 var valid = false;
 var keyCode = calendarGetKeyCode(event);
 if (event.keyCode == 9)
  return true;
 if (keyCode < 48 || keyCode > 57) {
  calendarCancelEvent(event);
 } else {
  var digit = keyCode - 48;
   if (id ==  (dtp.dayFieldId)) {
    daytemp = daytemp + digit.toString();
    if ((daytemp.length <= 2 && calendarDtpProveDate(calId, yearnew, monthnew, parseInt(daytemp,10), true)) || daytemp == "00") {
     if (daytemp == "00")
      daynew = dtp.daySaved;
     else
      daynew = parseInt(daytemp,10);
     valid = true;
    }
   } else if (id ==  (dtp.monthFieldId)) {
    monthtemp = monthtemp + digit.toString();
    if ((monthtemp.length <= 2 && calendarDtpProveDate(calId, yearnew, parseInt(monthtemp,10), daynew, false)) || monthtemp == "00") {
     if (monthtemp == "00")
      monthnew = dtp.monthSaved;
     else
      monthnew = parseInt(monthtemp,10);
     valid = true;
    }
   } else {
    yeartemp = yeartemp + digit.toString();
    if (yeartemp.length < 4) {
     calendarCancelEvent(event);
     document.getElementById(dtp.yearFieldId).value = yeartemp;
    } else

     if (yeartemp.length == 4 ) {
      if (yeartemp == "0000" || !calendarDtpProveDate(calId, parseInt(yeartemp,10), monthnew, daynew, false))
       yearnew = dtp.yearSaved;
      else
       yearnew = parseInt(yeartemp,10);
      valid = true;
     }
   }
  if (valid) {
   calendarCancelEvent(event);
   var maxdays = calendarDtpGetDays(yearnew, monthnew);
   if (daynew > maxdays)
    daynew = maxdays;
   calendarDtpSetDate(calId, yearnew, monthnew, daynew, false, true, true, true);
  }
  dom_select(dtp.focusEl);
 }
}

function calendarDtpclick(calId, id)
{
 var dtp = document.getElementById(calId + "dtpicker");
 if (id == (calId + "dtpbuttonup"))
  calendarDtpSimulateUpdown(calId, dtp.focusEl.id, true);
 else {
  if (id == (calId + "dtpbuttondown"))
   calendarDtpSimulateUpdown(calId, dtp.focusEl.id, false);
  else {
   dtp.focusEl = document.getElementById(id);
   dom_select(dtp.focusEl);
  }
 }
}

function calendarDtpfocusfield(calId, id)
{
 var el;
 if ( id.indexOf("dtpinp1") > -1)
   el = document.getElementById(calId + "dtpinp1");
 else {
  if ( id.indexOf("dtpinp2") > -1)
   el = document.getElementById(calId + "dtpinp2");
  else {
   if ( id.indexOf("dtpinp3") > -1)
     el = document.getElementById(calId + "dtpinp3");
  }
 }
 if (el) {
  try {
   dom_focus(el);
  } catch (e) {};
 }
}

function calendarDtpfocus(calId, id)
{
 var dtp = document.getElementById(calId + "dtpicker");
 if (!dtp.noFocusForButtonDown) {
  if (id == (calId + "dtpbuttondown")) {
   if (!dtp.focusEl)
    dtp.focusEl = document.getElementById(calId + "dtpinp1");
   dom_focus(dtp.focusEl);
  } else {
   dtp.focusEl = document.getElementById(id);
   dom_select(dtp.focusEl);
  }
 } else
  dtp.noFocusForButtonDown = false;
}

function calendarDtplostfocus(calId, id)
{
 var dtp = document.getElementById(calId + "dtpicker");
 var daytemp = document.getElementById(dtp.dayFieldId).value;
 var monthtemp = document.getElementById(dtp.monthFieldId).value;
 var yeartemp = document.getElementById(dtp.yearFieldId).value;
 var daytempInt = parseInt(daytemp,10);
 var monthtempInt = parseInt(monthtemp,10);
 var yeartempInt = parseInt(yeartemp,10);
 if (daytempInt != dtp.daySaved || daytemp.length < 2 || monthtempInt != dtp.monthSaved || monthtemp.length < 2 || yeartempInt != dtp.yearSaved || yeartemp.length < 4)
 {
  if (id ==  dtp.dayFieldId && (daytempInt == 0 || isNaN(daytempInt) ) )
   daytempInt = dtp.daySaved;
  else if (id ==  dtp.monthFieldId && (monthtempInt == 0 || isNaN(monthtempInt) ) )
   monthtempInt = dtp.monthSaved;
  else if (yeartempInt < dtp.yearBegin || isNaN(yeartempInt) )
   yeartempInt = dtp.yearSaved;
  var maxdays = calendarDtpGetDays(yeartempInt, monthtempInt);
  if (daytempInt > maxdays)
   daytempInt = maxdays;
  calendarDtpSetDate(calId, yeartempInt, monthtempInt, daytempInt, false, true, true, true);
 }
}

function calendarDtpInit(calId, dtpFormat, dtpDate, yBegin, yEnd, focusField)
{
 var dtp = document.getElementById(calId + "dtpicker");
 calendarDtpParseFormatString(calId, dtpFormat);
 var el = document.getElementById(dtp.yearFieldId);
 el.maxLength = 4;
 el.style.width = 32;
 document.getElementById(calId + "dtplbl1").innerHTML = dtp.separator;
 document.getElementById(calId + "dtplbl2").innerHTML = dtp.separator;
 dtp.yearBegin = parseInt(yBegin,10);
 dtp.yearEnd = parseInt(yEnd,10);
 var year=parseInt(dtpDate.substring(0,4),10);
 var month=parseInt(dtpDate.substring(4,6),10);
 var day=parseInt(dtpDate.substring(6,8),10);
 calendarDtpSetDate(calId, year, month, day, false, true, false, false);
 if ( focusField.indexOf("dtpinp2") > -1)
   dtp.focusEl = document.getElementById(calId + "dtpinp2");
 else {
  if ( focusField.indexOf("dtpinp3") > -1)
   dtp.focusEl = document.getElementById(calId + "dtpinp3");
  else
    dtp.focusEl = document.getElementById(calId + "dtpinp1");
 }
 dtp.noFocusForButtonDown = false;
}

/* --------------------------------------------------------------------------------------------

     the following code was moved from obsolete d_calender.js by he.pi 20050120

   -------------------------------------------------------------------------------------------- */

var a11yCalendarLastActiveElement;
var gcntTop;
var gcntLeft;

function calendarPostUrl(controlid, event, params, isDataEvent, dataTarget)
{
 var
  theParams = "",
  mainWindow = calendarGetWebGuiWindow();

 if( params )
  theParams += params;

 if( mainWindow != null )
 {
  if( isDataEvent )
  {
   if (!mainWindow.calendarDataIFRAMEcreated)
    mainWindow.controlCreateDataIFRAME('calendarData', 'display:none;', 'calendar', '');

   mainWindow.webguiRaiseDataEvent(controlid, event, theParams, dataTarget);
  }
  else
   mainWindow.raiseEvent(controlid, event, theParams);
 }
}

function calendarClick(calId, calPopupId, calContId, event)
{
 var cell = null;
 var params = null;
        if ( its_ua.ie55up )
          cell = event.srcElement;
        else
          cell = event.target;


 if( calId != null && cell != null )
 {

  calendarStopPropagation(event);

  //use the length of the date part from a given id in order to distinguish
  //if a day, a week, or a month has been selected
  var id = cell.id;
  if( id != null )
  {
   var date = id.slice(id.lastIndexOf("x")+1);
   var idPrefix = calendarGetPrefix(calId);

   if( date != null )
   {
    if( (document.getElementById(calId).getAttribute('IsSelModeMonth') && date.length == 6 && date >= CAL_MIN_MONTH) ||
      (document.getElementById(calId).getAttribute('IsSelModeWeek') && date.length == 10 && date >= CAL_MIN_DATE) ||
      (document.getElementById(calId).getAttribute('IsSelModeDay') && date.length == 8 && date >= CAL_MIN_DATE) ||
      (document.getElementById(calId).getAttribute('IsSelModeInterval') && date.length == 8 && date >= CAL_MIN_DATE) )
    {
     var firstSelDate = document.getElementById(calId).getAttribute('LocalFirstSelDate');
     var lastSelDate = document.getElementById(calId).getAttribute('LocalLastSelDate');

     params = "strDateBegin=" + date + "&strDateEnd=" + date;

     if( date.length == 6 )
     {
      //month selected
      //!!! do not change order !!!
      if( document.getElementById(calId).getAttribute('IsPreSelModeMonth') )
      {
       params = params + "&strWhere=" + CAL_SELECTIONMODE_MONTH;
       calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "PreSelection", params);
       return false;
      }
      else if( !document.getElementById(calId).getAttribute('EvDateSelected') || document.getElementById(calId).getAttribute('DisplayModePopup') )
      {
       //local selection, clear previous selection
       calendarClearSelection(calId, firstSelDate, lastSelDate, false);
       //get first and last day of selected month
       firstSelDate = date + "01";
       lastSelDate = date + "31";
       if( document.getElementById(idPrefix+firstSelDate) == null )
        firstSelDate = calendarGetNextDay(calId, firstSelDate);
       if( document.getElementById(idPrefix+lastSelDate) == null )
        lastSelDate = calendarGetPreviousDay(calId, lastSelDate);
       if( calendarSetSelection(calId, firstSelDate, lastSelDate, false) )
       {
        calendarSaveSelection(calId, date, date);
        document.getElementById(calId).setAttribute("FirstMouseClick", 0);
        document.getElementById(calId).setAttribute("LocalFirstSelDate", firstSelDate);
        document.getElementById(calId).setAttribute("LocalLastSelDate", lastSelDate);
       }
      }
     }
     else if( date.length == 10 )
     {
      //week selected
      //check if week is out of max range
      var year = date.slice(0,4);
      if( year == 9999 )
      {
       var month = date.slice(4,6);
       var week = date.slice(8, 10);
       if( month == 12 && week >= 52 )
        return false;
      }

      //!!! do not change order !!!
      if( document.getElementById(calId).getAttribute('IsPreSelModeWeek') )
      {
       params = params + "&strWhere=" + CAL_SELECTIONMODE_WEEK;
       calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "PreSelection", params);
       return false;
      }
      else if( !document.getElementById(calId).getAttribute('EvDateSelected') || document.getElementById(calId).getAttribute('DisplayModePopup') )
      {
       //local selection, clear previous selection
       calendarClearSelection(calId, firstSelDate, lastSelDate, false);
       //get first and last day of selected week
       firstSelDate = date.slice(0, 8);
       lastSelDate = firstSelDate;
       for( var i = document.getElementById(calId).getAttribute('LastWeekSelDay')-1; i > 0; i-- )
       {
        lastSelDate = calendarGetNextDay(calId, lastSelDate);
       }
       for( i = document.getElementById(calId).getAttribute('FirstWeekSelDay')-1; i > 0; i-- )
       {
        firstSelDate = calendarGetNextDay(calId, firstSelDate);
       }
       if( lastSelDate == null )
        lastSelDate = document.getElementById(calId).getAttribute('LastVisibleDate');

       if( calendarSetSelection(calId, firstSelDate, lastSelDate, false) )
       {
        calendarSaveSelection(calId, date, date);
        document.getElementById(calId).setAttribute("FirstMouseClick", 0);
        document.getElementById(calId).setAttribute("LocalFirstSelDate", firstSelDate);
        document.getElementById(calId).setAttribute("LocalLastSelDate",lastSelDate);
       }
      }
     }
     else
     {
      //single day or interval selected
      if( event.shiftKey )
      {
       //global pointer to calId because eventlistener can't be added to a table in NS6 and calId can't be forwarded
       // as an attribute to function calendarKeyUp:
       if ( !its_ua.ie55up )
       {
        gLocalSelectionPointerCalId=calId;
        document.documentElement.onkeyup=calendarKeyUp_firefox;
       }

       //interval selected
       if( document.getElementById(calId).getAttribute('IsSelModeInterval') )
       {
        if( document.getElementById(calId).getAttribute('FirstMouseClick')==1 )
        {
         //deselect backend selection
         calendarClearSelection(calId, firstSelDate, lastSelDate, false);
         //highlight selection
         if( calendarSetSelection(calId, date, date, false) )
         {
          calendarSaveSelection(calId, date, date);
          document.getElementById(calId).setAttribute("FirstMouseClick", 0);
          document.getElementById(calId).setAttribute("LocalFirstSelDate", date);
          document.getElementById(calId).setAttribute("LocalLastSelDate", date);
          if (document.getElementById(calId).getAttribute('DisplayModeDtPicker'))
          {
           var year=parseInt(date.substring(0,4),10);
           var month=parseInt(date.substring(4,6),10);
           var day=parseInt(date.substring(6,8),10);
           calendarGetWebGuiWindow().calendarDtpSetDate(calId, year, month, day, false, true, false, false)
          }
          if (document.getElementById(calId).getAttribute('DisplayModePopup') )
           calendarGetWebGuiWindow().calendarClosePopupNavigator(calPopupId, calContId);
          else
           calendarSetFocusStyle(calId, idPrefix + date);
         }
        }
        else
        {
         //if not first mouseClick
         var bRet = false;
         if( firstSelDate != "" && lastSelDate != "" )
         {
          if( date > lastSelDate )
          {
           if( firstSelDate <= lastSelDate )
           {
            //enlarge selected range
            bRet = calendarSetSelection(calId, calendarGetNextDay(calId, lastSelDate), date, false);
           }
           else
           {
            if( date > firstSelDate )
            {
             calendarClearSelection(calId, lastSelDate, firstSelDate, false);
             //enlarge selected range
             bRet = calendarSetSelection(calId, firstSelDate, date, false);
            }
            else
            {
             calendarClearSelection(calId, lastSelDate, calendarGetPreviousDay(calId, date), false);
             bRet = true;
            }
           }
          }
          else if( date < lastSelDate )
          {
           if( firstSelDate > lastSelDate )
           {
            //enlarge selected range
            bRet = calendarSetSelection(calId, calendarGetPreviousDay(calId, lastSelDate), date, false);
           }
           else
           {
            if( date > firstSelDate )
            {
             calendarClearSelection(calId, calendarGetNextDay(calId, date), lastSelDate, false);
             bRet = true;
            }
            else
            {
             calendarClearSelection(calId, firstSelDate, lastSelDate, false);
             //enlarge selected range
             bRet = calendarSetSelection(calId, date, firstSelDate, false);
            }
           }
          }
          if( bRet )
          {
           document.getElementById(calId).setAttribute("LocalLastSelDate", date);
           //do not overwrite first selected date
           calendarSaveSelection(calId, null, date);
          }
         }
        }
       }
       return false;
      }
      else
      {
       //single day selected
       if( !document.getElementById(calId).getAttribute('EvDateSelected') || document.getElementById(calId).getAttribute('DisplayModePopup') )
       {
        //local selection, clear previous selection
        calendarClearSelection(calId, firstSelDate, lastSelDate, false);
        if( calendarSetSelection(calId, date, date, false) )
        {
         document.getElementById(calId).setAttribute("LocalFirstSelDate", date);
         document.getElementById(calId).setAttribute("LocalLastSelDate", date);
         calendarSaveSelection(calId, date, date);
         document.getElementById(calId).setAttribute("FirstMouseClick", 0);
         if (document.getElementById(calId).getAttribute('DisplayModeDtPicker'))
         {
          var year=parseInt(date.substring(0,4),10);
          var month=parseInt(date.substring(4,6),10);
          var day=parseInt(date.substring(6,8),10);
          calendarGetWebGuiWindow().calendarDtpSetDate(calId, year, month, day, false, true, false, false)
         }
         if (document.getElementById(calId).getAttribute('DisplayModePopup') )
          calendarGetWebGuiWindow().calendarClosePopupNavigator(calPopupId, calContId);
         else
          calendarSetFocusStyle(calId, idPrefix + date);
        }
       }
      }
     }
     if( document.getElementById(calId).getAttribute('EvDateSelected') )
     {
      calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "DateSelected", params);
     }
    }
   }
  }
 }
 return false; //stop default action
}

function calendarKeyUp(calId, event)
{
 if( event.keyCode == 16 && document.getElementById(calId).getAttribute('EvDateSelected') && !(document.getElementById(calId).getAttribute('FirstMouseClick')==1) )
 {
  var params = "strDateBegin=" + document.getElementById(calId).getAttribute('LocalFirstSelDate') + "&strDateEnd=" + document.getElementById(calId).getAttribute('LocalLastSelDate');
  calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "DateSelected", params);
 }
}

function calendarKeyUp_firefox(event)
{
 var calId=gLocalSelectionPointerCalId;
 if( event.keyCode == 16 && document.getElementById(calId).getAttribute('EvDateSelected') && !(document.getElementById(calId).getAttribute('FirstMouseClick')==1) )
 {
  var params = "strDateBegin=" + document.getElementById(calId).getAttribute('LocalFirstSelDate') + "&strDateEnd=" + document.getElementById(calId).getAttribute('LocalLastSelDate');
  calendarPostUrl(document.getElementById(calId).getAttribute('ControlId'), "DateSelected", params);
 }
}

//set scroll position
function calendarOnResizeSetScrollPosition(calId, calContId, focusDate, scrollTop, scrollLeft)
{
 if( focusDate.length > 0 )
 {
  var el = document.getElementById(focusDate);
  if( el != null )
  {
   if( el.tagName == "DIV" )
    el = el.offsetParent;
   document.getElementById(calContId).scrollTop = el.offsetTop - document.getElementById(calContId).offsetHeight / 2;
   document.getElementById(calContId).scrollLeft = el.offsetLeft - document.getElementById(calContId).offsetWidth / 2;
   calendarSetFocusStyle(calId, focusDate);
  }
 }
 else
 {
        var el = document.getElementById(calContId);
  if( el != null )
  {
         el.scrollTop = scrollTop;
         el.scrollLeft = scrollLeft;
              }
 }
}

//onclick handler for popup navigator
function calendarShowPopupNavigator(calPopupId, calContId, url, top, left, width, height)
{
 if( CAL_A11Y_ON )
  a11yCalendarLastActiveElement = document.activeElement;

 gCalendarCallback = "calendarClosePopupNavigator('" + calPopupId + "','" + calContId + "')";
 var navigator = calendarGetWebGuiWindow().document.getElementById(calPopupId);
 var container = calendarGetWebGuiWindow().document.getElementById(calContId);

        if ( its_ua.ie55up ) {
    /*
     * take changes to Groupbox container into account
     * we have to reallocate the calendar container in the DOM
     * /tj/2003-11-18
    */
  navigator.style.top = top;
  navigator.style.left = left;
  navigator.style.width = width;
  navigator.style.height = height;


          gcntTop = navigator.style.top;
          gcntLeft = navigator.style.left;
          var pos = wgu_getAbsolutePosition( navigator );
          navigator     = container.removeChild( navigator);
          document.getElementsByTagName("body")[0].appendChild( navigator);
          navigator.style.top = pos.y;
          navigator.style.left = pos.x;
 }
 else {
     /*
     * iframe could not be displayed over iframe in Gecko Browsers,
     * therefore move the calendar iframe to the body element.
     * during appendChild the src Attribut of the iframe is evaluated again,
     * therefore only the first appendchild with src=emptypage is made
     * rs:14.09.2005
     */
    var pos = wgu_getAbsolutePosition( container );
    if ( navigator.FirstClick != 1 )
    {
          navigator.FirstClick = 1;
     navigator = container.removeChild( navigator);
     document.getElementsByTagName("body")[0].appendChild( navigator);
    }
    navigator.style.top = pos.y + 18;  // 18 = size of Popup-Button
    navigator.style.left = pos.x;
  navigator.style.width = width;
  navigator.style.height = height;
 }

 //switch off optimization in accessibility mode to enshure that the focus is set
 //to today in the onload event handler of the iframe
 navigator.style.visibility = "visible";
 //set zIndex, because of windowless iframes in IE5.5
 navigator.style.zIndex = 999;
 container.style.zIndex = 999 ;

 if( navigator.src.indexOf("emptypage.html") != -1 )
  navigator.src = url;
 else if( CAL_A11Y_ON )
  dom_focus(navigator);
}

function calendarClosePopupNavigator(calPopupId, calContId)
{
 var navigator = document.getElementById(calPopupId);
 var container = document.getElementById(calContId);

  /*
   * take changes to Groupbox container into account
   * we have to reallocate the calendar container in the DOM
   * /tj/2003-11-18
  */

        if ( its_ua.ie55up ) {
   navigator = document.getElementsByTagName("body")[0].removeChild( navigator);
     container.appendChild( navigator);
     navigator.style.top = gcntTop;
     navigator.style.left = gcntLeft;
        }


 //reset zIndex, because a BUTTON of another calendar control would overlap the
 //calendar iframe if once activated(both get zIndex 999)
 if( navigator != null )
 {
  navigator.style.visibility = "hidden";
  navigator.style.zIndex = 0;
         if ( !its_ua.ie55up ) {
     navigator.style.top = -200;
     navigator.style.left = -200;
  }
 }
 if( container != null )
  container.style.zIndex = 0;

 gCalendarCallback = null;

 //set focus to popup button
 if( CAL_A11Y_ON && a11yCalendarLastActiveElement != null )
 {
  dom_focus(a11yCalendarLastActiveElement);
  a11yCalendarLastActiveElement = null;
 }
}

function calendarGetParent(el)
{
 if( el != null )
  return el.parentNode;

 return null;
}

function calendarGetContainerHeight(navScrl, nav)
{
 //subtract 4 px for the borders and 16 px for the scrollbar from container size
 var scrollbarHeight = 0;
 if ( navScrl.offsetWidth < nav.offsetWidth )
  scrollbarHeight = 16;
 return (navScrl.offsetHeight - 4 - scrollbarHeight);
}

function calendarGetContainerWidth(navScrl, nav)
{
 //set width, subtract 5 px for the borders and 16 px for the scrollbar from container size
 var scrollbarWidth = 0;
 if ( navScrl.offsetHeight < nav.offsetHeight )
  scrollbarWidth = 16;
 return (navScrl.offsetWidth - 5 - scrollbarWidth);
}

function calendarSetTabIndex(calId, tabIndex, displayWeekNo)
{
       var FirstNonTextChildNode = null;
 var table = document.getElementById(calId);

 if( table.getAttribute('DisplayModeHorizontal') )
 {
  var rowspan=0, headerCol=1;

  //special handling of first column
  for (i=displayWeekNo ? 2 : 1; i < table.rows.length; i++)
  {
   table.rows[i].cells[0].tabIndex = tabIndex++;
  }

              var tableCols = calendargetTableCols(table);
  for ( i=1; i < tableCols; i++)
  {
   for (j=0; j < table.rows.length; j++)
   {
    if( j == 0 )
    {
     //month header
     if( rowspan > 1 )
     {
      rowspan--;
     }
     else
     {
      rowspan = table.rows[0].cells[headerCol].colSpan;
      table.rows[0].cells[headerCol++].tabIndex = tabIndex++;
     }
    }
    cell = table.rows[j].cells[i];
    if( cell != null )
    {
     FirstNonTextChildNode = calendargetFirstNonTextChildNode(cell);
     if( FirstNonTextChildNode != null ) {
      //cell contains a nested DIV which has to get the focus
      FirstNonTextChildNode.tabIndex = tabIndex++;
     }
     else
      cell.tabIndex = tabIndex++;
    }
   }
  }
 }
 else
 {
  //special handling of header
  var row = table.rows[0];
  for (i=displayWeekNo ? 2 : 1; i < row.cells.length; i++)
  {
   row.cells[i].tabIndex = tabIndex++;
  }

  for (i=1; i < table.rows.length; i++)
  {
   row = table.rows[i];
   for (j=0; j < row.cells.length; j++)
   {
    cell = row.cells[j];
    if( cell != null )
    {
     FirstNonTextChildNode = calendargetFirstNonTextChildNode(cell);
     if( j != 0 && FirstNonTextChildNode != null ) {
      //cell contains a nested DIV which has to get the focus
      FirstNonTextChildNode.tabIndex = tabIndex++;
     }
     else
      cell.tabIndex = tabIndex++;
    }
   }
  }
 }
 return tabIndex;
}

function calendarKeyPressed(calId, calPopupId, calContId, event)
{
 var keyCode = calendarGetKeyCode(event);
 var FirstNonTextChildNode = null;
 var cell = null;

 if( keyCode == 115 )
 {
  // 's' pressed -> go to end or skip calendar
  if( calPopupId != null && calContId != null )
   calendarGetWebGuiWindow().calendarClosePopupNavigator(calPopupId, calContId);
  else {
   cell = document.getElementById(calendarGetPrefix(calId) + document.getElementById(calId).getAttribute('LastVisibleDate'));
   FirstNonTextChildNode = calendargetFirstNonTextChildNode(cell);
   if( FirstNonTextChildNode)
    dom_focus(FirstNonTextChildNode);
  }
  return false;
 }
 else if( keyCode == 98 )
 {
  // 'b' pressed -> go to begin of calendar
  cell = document.getElementById(calendarGetPrefix(calId) + document.getElementById(calId).getAttribute('FirstVisibleDate'));
  FirstNonTextChildNode = calendargetFirstNonTextChildNode(cell);
  if( FirstNonTextChildNode)
   dom_focus(FirstNonTextChildNode);
  return false;
 }
 else if( keyCode == 101 )
 {
  // 'e' pressed -> go to begin of calendar
  cell = document.getElementById(calendarGetPrefix(calId) + document.getElementById(calId).getAttribute('LastVisibleDate'));
  FirstNonTextChildNode = calendargetFirstNonTextChildNode(cell);
  if( FirstNonTextChildNode)
   dom_focus(FirstNonTextChildNode);
  return false;
 }
 else if( keyCode == 116 )
 {
  // 't' pressed -> go to today
  var todayEl = document.getElementById(calendarGetPrefix(calId) + document.getElementById(calId).getAttribute('Today'));
  if( todayEl )
  {
   dom_focus(todayEl);
  }
  else
  {
   calendarClickReload(calId, 0, document.getElementById(calId).getAttribute('Today'));
  }
  return false;
 }
 else if(keyCode==13)
 {
  return calendarClick(calId, calPopupId, calContId, event);
 }
}

function calendargetFirstNonTextChildNode(myParentNode){
    var FirstNonTextChildNode = null; //false
    if (myParentNode) {
        if ( its_ua.ie55up ) {
            FirstNonTextChildNode = myParentNode.children(0);
        } else {
            if (myParentNode.hasChildNodes() ){
                for (z = 0; z < myParentNode.childNodes.length; z++){
                    if (myParentNode.childNodes[z].nodeName != "#text"){
                        FirstNonTextChildNode = myParentNode.childNodes[z];
                        break;
                    }
                }
            }
        }
    }

    return FirstNonTextChildNode;
}

function calendargetTableCols(table){
    var TableCols = 0;
    if ( its_ua.ie55up ) {
        TableCols = table.cols;
    } else {
        TableCols = table.getAttribute('NsCols');
    }

    return TableCols;
}
