/* Javascript-Java-server communication
 *
 */

var updownxmlHttpObj = null;
var applet_id = "";

function UpDownIsAjaxAvailable()
{
  return (updownxmlHttpObj != null);
}

function   UpDownSendRequest( in_url, in_params, in_multipart, boundary, in_Async, appletid )
{
  var rv      = null,
    contenttype = null,
    len, buf, i;
    applet_id = appletid;

  if (null != in_url)
  {

    if (!!updownxmlHttpObj)
    {
      try {
         // create request body for POST request
        buf = "";
        if ("string" === typeof in_params)
        {
          buf = in_params;
        }
        len = buf.length;

        updownxmlHttpObj.open('POST', in_url, in_Async);

        if ("X" != in_multipart)
        {
          contenttype = "application/x-www-form-urlencoded";
        }
        else
        {
          contenttype = "multipart/form-data; boundary=" + boundary;
        }
        updownxmlHttpObj.setRequestHeader("Content-type", contenttype);
        updownxmlHttpObj.setRequestHeader("Content-length", len);
        updownxmlHttpObj.setRequestHeader("Connection", "close");
        if (in_Async)
        {
            updownxmlHttpObj.onreadystatechange = UpdownHandleResponse;
            updownxmlHttpObj.send(buf);
            rv = null;

        }
        else
        {
            updownxmlHttpObj.send(buf);
            rv = updownxmlHttpObj;
        }

      }
      catch(ex3) {
        alert("UpDownSendRequest Exception: " + ex3);
      }
    } //
  }
  return rv;
}
function UpDownCallBackFromAjaxWithDelay( el )
{

  try {
    i = el.callBackFromAjax();
  }
  catch (e3) {
    window.setTimeout("UpDownCallBackFromAjaxWithDelay( el )", 200);
  }

}

function UpdownHandleResponse()
{
  xmlHttpObj = updownxmlHttpObj;

  if (!!xmlHttpObj)
  {
    if (4 == xmlHttpObj.readyState)
    {
      el = window.document.getElementById(applet_id);
      if (el == null)
      {
        alert("updown async ajax could not find applet with id: " + applet_id);
        return false;
      }
      // in firefox for the filedialogs we need a delay, because applet runs in init phase
      UpDownCallBackFromAjaxWithDelay( el );
    }
  }
  return true;
}

function UpdownGetXmlHttpObj()
{
  return updownxmlHttpObj;
}

function UpdownCreateAjaxObj()
{
  if ("undefined" !== typeof XMLHttpRequest)
  {
    updownxmlHttpObj = new XMLHttpRequest();
  }

  if (!updownxmlHttpObj)   // IE5, IE6 :(
  {
    try { updownxmlHttpObj = new ActiveXObject("Msxml2.XMLHTTP"); }
    catch(ex)
    {
      try { updownxmlHttpObj = new ActiveXObject("Microsoft.XMLHTTP"); }
      catch(ex2) { updownxmlHttpObj = null;}
    }
  }
}

UpdownCreateAjaxObj();

function updownSendOkCode(OkCode, FieldName, XSRFCheckOn, WebguiDontFocus)
{
  var rc = webguiIsActive();
  var params = "";
  if (WebguiDontFocus)
    params = "~updownnofocus=1";

  if (rc)
  {
    window.setTimeout("setOkCode('" + OkCode + "', '" + FieldName + "','" + params + "')", 100);
  }
  else
  {
    window.wgu_global_eventhandler.RegisterTimedHandler("load", wgu_global_eventhandler.CONST.TIME.LAST, "updown", 0,
                                                        function() { setOkCode(OkCode, FieldName, params); }  )

  }
  return true;
}

function updownShowDocument(docUrl, windowName, OkCode, FieldName)
{
  var myWindow = window.open(docUrl, windowName, "location=no,locationbar=no,menubar=no,resizable=no,status=no,toolbar=no,directories=no");
  myWindow.focus();
  window.setTimeout("setOkCode('" + OkCode + "', '" + FieldName + "')", 1000);
  return true;
}

////////////////////////////////////////////////////////////////////////////////
//
// getscreenshot utility functions
//
////////////////////////////////////////////////////////////////////////////////

function UpDownGetTopModalScreenRectAll(x_applet, y_applet, width, height, isFirefoxOnMac)
{
  var rect  = { x1: 0, y1: 0, x2: 0, y2: 0, width: 0, height: 0};
  var actdynproframe = null;
  var toppopupwindow = null;
  var topmodalwindow = null;
  if ( true == ITS_Frameset("IS_ACTIVE") )
    actdynproframe = ITS_Frameset("FRAME");
  if ( actdynproframe == null)
    actdynproframe = window;

  //      does a webgui popup exists?
  if (actdynproframe.webguiHasPopup)
  {
    var f = actdynproframe.document.getElementsByName("webguiPopupWindow" + actdynproframe.webguiHasPopup)[0];
    if (f)
      toppopupwindow = f.contentWindow;
  }

  if (toppopupwindow)
    topmodalwindow = toppopupwindow;
  else
    topmodalwindow = actdynproframe;

  if (its_ua.ie55up)
  {

    // get top modal window coordinates
    rect.x1 = topmodalwindow.screenLeft;
    rect.y1 = topmodalwindow.screenTop;
    rect.x2 = rect.x1 + topmodalwindow.document.body.clientWidth;
    rect.y2 = rect.y1 + topmodalwindow.document.body.clientHeight;


  } else {
    if (isFirefoxOnMac)
    {
      // in firefox 3.6 the properties window.mozInnerScreenX and window.mozInnerScreenY are identically to the IE properties
      // window.screenLeft and window.screenTop. In older firefox versions window.screenX and window.screenY are used
      // and the coordinates of the whole browser window will be returned.
      // maybe the window's viewport is in the hidden frame (left = left - 8000, top = top - 8000)
      // get top modal window coordinates
      if ( topmodalwindow.mozInnerScreenX )
      {
        rect.x1 = topmodalwindow.mozInnerScreenX;
        rect.y1 = topmodalwindow.mozInnerScreenY;
        if (rect.x1 < 0 )
          rect.x1 = rect.x1 + 8000;
        if (rect.y1 < 0 )
          rect.y1 = rect.y1 + 8000;
        rect.x2 = rect.x1 + window.innerWidth;
        rect.y2 = rect.y1 + window.innerHeight;

        // if webguipopups exist, add the offset to the left upper corner of the webgui window.
        if (toppopupwindow)
        {
          rect.x1 = rect.x + toppopupwindow.frameElement.offsetLeft;
          rect.y1 = rect.y + toppopupwindow.frameElement.offsetTop;
          rect.x2 = rect.x1 +  toppopupwindow.document.body.clientWidth;
          rect.y2 = rect.y1 +  toppopupwindow.document.body.clientHeight;
        }
      } else {
        rect.x1 = topmodalwindow.screenX;
        rect.y1 = topmodalwindow.screenY;
        if (rect.x1 < 0 )
          rect.x1 = rect.x1 + 8000;
        if (rect.y1 < 0 )
          rect.y1 = rect.y1 + 8000;
        rect.x2 = rect.x1 +  window.outerWidth;
        rect.y2 = rect.y1 +  window.outerHeight;
      }
    } else {
      // in firefox window.screenX and window.screenY always point to the left upper corner of the browser window.
      // to calculate the upper left corner of the webgui window the screen position of the applet, determined in java, is
      // used.
      // applet is on swapped frame (left = left - 8000, top = top - 8000)
      var xapp = parseInt(x_applet);
      var yapp = parseInt(y_applet);
      if (xapp < 0 )
        xapp = xapp + 8000;
      if (yapp < 0 )
        yapp = yapp + 8000;
      var app = document.applets[0];
      var pos = wgu_getAbsolutePosition( app );

      // set rectangle to the left upper corner of the webgui window.
      rect.x1 = xapp - pos.x;
      rect.y1 = yapp - pos.y;
      rect.x2 = rect.x1 + window.innerWidth;
      rect.y2 = rect.y1 + window.innerHeight;

      // if webguipopups exist, add the offset to the left upper corner of the webgui window.
      if (toppopupwindow)
      {
        rect.x1 = rect.x1 + toppopupwindow.frameElement.offsetLeft;
        rect.y1 = rect.y1 + toppopupwindow.frameElement.offsetTop;
        rect.x2 = rect.x1 + toppopupwindow.document.body.clientWidth;
        rect.y2 = rect.y1 + toppopupwindow.document.body.clientHeight;
      }
    }
  }

  if (rect.x1 < 0 )
    rect.x1 = 0;
  if (rect.y1 < 0 )
    rect.y1 = 0;
  if (rect.x2 >  screen.availWidth)
    rect.x2 = screen.availWidth;
  if (rect.y2 >  screen.availHeight)
    rect.y2 = screen.availHeight;
  rect.width = rect.x2 - rect.x1;
  rect.height = rect.y2 - rect.y1;

  rectstring = rect.x1 + ":" + rect.y1 + ":" + rect.width + ":" + rect.height;
  return rectstring;
}

function UpDownGetTopModalScreenRect(x_applet, y_applet, width, height)
{
  return UpDownGetTopModalScreenRectAll(x_applet, y_applet, width, height, false)
}