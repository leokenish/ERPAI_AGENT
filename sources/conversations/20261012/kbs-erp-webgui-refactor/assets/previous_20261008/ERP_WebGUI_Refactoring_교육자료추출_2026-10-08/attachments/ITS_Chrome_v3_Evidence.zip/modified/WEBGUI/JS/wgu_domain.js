// wgu_domain.js
//
// SAP GUI for HTML / ITS Domain Relaxing
// (c) 2002-2010, SAP AG
//
// Set document.domain for allowing inter-frame communication in SAP GUI for HTML
//
// /tj/2004-01-12
//

function wgu_setdomain ()
{
  // Origin-keyed Chrome uses the existing same-origin frame boundary.
  // Legacy domain relaxation remains available only where the browser allows it.
  if (window.originAgentCluster === true)
  {
    wgu_setdomain.domain = document.domain;
    return;
  }
  if (wgu_setdomain.domain == null)
  {
    var isNumAddr = wgu_setdomain.regexp_ipaddr.test( window.location.hostname),
        sDomain   = null;

    if (!isNumAddr)
    {
      sDomain = window.location.hostname.match(wgu_setdomain.regexp_server)[8];
      if (sDomain != null && sDomain != "")
        document.domain = wgu_setdomain.domain = sDomain;
    }  // if (!isNumAddr)
    else
    {
      wgu_setdomain.domain = document.domain;
    }
  }  // if (serverinfo already set) ... else
  else
  {
    document.domain = wgu_setdomain.domain;
  }
}
wgu_setdomain.domain = null;
wgu_setdomain.regexp_ipaddr = /^\d+\.\d+\.\d+\.\d+/;
wgu_setdomain.regexp_server = /^(([a-zA-Z0-9-_\.!~\*'\(\)%;&=\+\$,]*)@)?(([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)|(([^:\.]+)(\.([^:]+))*\.?))(:([0-9]*))?$/;
//                                12                                      34                                56        7  8             9 A
//                              +-------------User Info------------+    +----------IPv4Address---------+  +HostNam++--Domain-+        +-Port-+
//                                                                     +------------------------Host-------------------------------+

its_setdomain = wgu_setdomain;

// wgu_domain.js end
