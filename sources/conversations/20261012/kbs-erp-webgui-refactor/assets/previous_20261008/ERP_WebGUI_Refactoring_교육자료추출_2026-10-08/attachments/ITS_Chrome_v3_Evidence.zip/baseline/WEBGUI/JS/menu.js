var gMenuOpen,
    gCurrentMenu,
    gContextMenu,
    gDynamicTBCMenu,
    gCalendarCallback,
    gOfficeControlFreeze,
    gOfficeControlUnFreeze,
    gFunctionMenu            = "",
    menuIFRAMEcreated        = false,
    contextIFRAMEcreated     = false,

    setMenuFontHeight        = false,
    // cCharWidth = 7,  (This is dynamically set in menudhtml.html!)
    cLineHeight              = 18,
    cLeftOffset              = 15,

    gLastMenuButton = null,
    gLastMenuButtonLevel = -1,


    contextMenuException = false,
    contextMenuXPos, contextMenuYPos,
    gNumMenuIFRAME = 6,

    contextframe_controlid,
    contextframe_params,
    contextframe_event,
    controlctxmnu_active = false,

    menuArray = {}
    ;



function MenuInvalidateCache ( in_menuid )
{
  if (null != in_menuid && !!menuArray[in_menuid])
    menuArray[in_menuid] = null;
} // MenuInvalidateCache()


function MenuOut ()
{
  if (null == gMenuOpen)
  {
    LowLight(gCurrentMenu);
    gCurrentMenu = null;
  }
} // MenuOut()


function LowLight ( el )
{
  var s;
  if (null != el)
  {
    s = el.style;

    if ("NewMenuCaptionOn" == el.className)
    {
      el.className = "NewMenuCaption";
    }
    else if (null != s)
    {
      s.backgroundColor = el.oldBg;
      s.color           = el.oldColor;
    }
  }
} // LowLight()


function freezeOfficeControl()
{
  if (null != gOfficeControlFreeze)
    eval(gOfficeControlFreeze);
} // freezeOfficeControl()


function unFreezeOfficeControl()
{
  if (null != gOfficeControlUnFreeze)
    eval(gOfficeControlUnFreeze);
} // unFreezeOfficeControl()


function CloseCalendarPopups()
{
  //callback is only registered, if any calendar popup is displayed
  if( gCalendarCallback != null )
    eval(gCalendarCallback);
}

function CloseAllMenus ()
{
  LowLight(gCurrentMenu);
  CloseMenus(0);
  CloseCalendarPopups();
  unFreezeOfficeControl();
}

function RetrieveVfcode ( menuitem )
{
  var idx;

  if (!gFunctionMenu)
    gFunctionMenu = eval(arrMenu_FM);

  for (idx=gFunctionMenu.length-6; idx >= 0; idx-=6)
  {
    if (menuitem == gFunctionMenu[idx])
      return gFunctionMenu[idx+5].substr(1);
  }

  return null;
} // RetrieveVfcode()


/*
 * Set event handler
 */

document.documentElement.onmousedown = CloseAllMenus;



function checkformask ( str )
{
  return ( -1 != str.search(/&(amp|lt|gt|quot);/g));
} // checkformask()


function str2html ( str )
{
  if (!checkformask( str)) {
    str = str.replace(/\&/g,"&amp;");
    str = str.replace(/\</g,"&lt;");
    str = str.replace(/\>/g,"&gt;");
    str = str.replace(/\"/g,"&quot;");
  }
  return str;
} // str2html()


//---------------------------------------------------------------------

function openMenu_AddVerticalScrollbars(vscrollDIV){
  if (document.all) vscrollDIV.style.overflowY = "scroll"
  else vscrollDIV.style.overflow = "-moz-scrollbars-vertical";
}


//---------------------------------------------------------------------

function OpenMenu ( menuID, parentLoc, in_event )
{
  var level,
      menuFrame,
      menuDoc,
      menuAll,
      xPos, pos,
      arr, arr2, inc, incno = 0, ientry,
      s, i,
      maxWidth,
      toptop   = 0,
      leftleft = 0,
      menuitem, vfcode, fkey, fkeylength, chksymbol,
      menutext,
      sepcnt = 0,
      newEventSrcElement, srcElement,
      showsubmenu, hilight, depth,
      ev,
      controlctxmnu = false;

  var alignleft  = isBidiRTL() ? "right" : "left",      // for BIDI
      alignright = isBidiRTL() ? "left"  : "right";

  var onkeydown = "onkeydown='keyNavMenu(event);' ",    // for key events on menu
      onfocus   = "onfocus='Hilight(event);' ",
      onfocusd  = "onfocus='HilightDisabled(event);' ",
      onhelp    = "onhelp='return false;' ";

  getMenuFontHeight();
  freezeOfficeControl();

  if (webguiIsPopup)  // a hack for IE (&§%$@!)
  {
    self.document.getElementsByTagName("html")[0].style.height = "100%";
  }

  if (null != menuID && 0 < menuID.indexOf("txmnu"))
    controlctxmnu = true;

  if (null != webguiTSPulldownMenu)
  {
    TSMenuShow( webguiTSPulldownMenu.id.substring(0, webguiTSPulldownMenu.id.length-9) ); //substring not including '-PULLDOWN'
    return;
  }

  ev = (null != in_event) ? in_event : (null != window.event ? window.event : null);
  if (null != ev)
  {
    newEventSrcElement = (null != ev.srcElement) ? ev.srcElement : ev.target;
  }

  if ((!controlctxmnu && (ev && ev.type == "contextmenu" || contextMenuException ))
      || (ev && ev.type == "keydown" && ev.shiftKey && (521 == ev.keyCode || 121 == ev.keyCode))
     )
  {
    menuID = "arrMenu_FM";
  }

  // Count the number of 'x' in the menuID
  arr = menuID.split("_");
  level = arr.length - 2;

/*
  if (0 != menuID.indexOf( gstr_webgui_MenuArrayName + "_1_")
      && gstr_webgui_MenuArrayName + "_1" != menuID
     )
  {
    level++;
  }
*/

  if(!parentLoc)
  {
    document.getElementById("MenuFrame0").style.visibility = "hidden";
  }

  if (!controlctxmnu && (null != ev && ev.type == "contextmenu" || contextMenuException))
  {
    menuFrameObj = new wguObjFrame('MenuFrame0');
    menuFrame    = menuFrameObj.GetWindowObject();
    menuDoc      = menuFrameObj.GetDocument();
    menuAll      = menuFrameObj.GetHTMLObject();
    gCurrentMenu = menuAll;
    gMenuOpen    = menuAll;
    gContextMenu = gCurrentMenu;
  }
  else
  {
    menuFrameObj = new wguObjFrame("MenuFrame" + level);
    menuFrame    = menuFrameObj.GetWindowObject();
    menuDoc      = menuFrameObj.GetDocument();
    menuAll      = menuFrameObj.GetHTMLObject();
    if (controlctxmnu)
    {
      gMenuOpen    = menuAll;
      gCurrentMenu = menuAll;
    }
  }

  if (isBidiRTL())
  {
    menuDoc.body.setAttribute("dir", "rtl");
  }

  if (!controlctxmnu)
    arr = (eval(menuID));
  else
  {
     //cut of parent. if present (needed for submenus) he.pi
     if (menuID.substr(0,7) == "parent.")
     {
       menuID = menuID.substr(7, menuID.length - 1) ;
     }
     arr = this[menuID];
   }

 if (null == (s = menuArray[menuID]))
 {
  s = "";
  maxWidth = 0;

  depth = "DEPTH='"+level+"' ";
  s = "<div id=\"scrollDIV\" style=\"width:100%; height:100%; overflow-y:hidden; overflow-x:hidden\"" + onkeydown + onhelp + depth + ">";

  for (i = ientry = 0; i < arr.length-1; i += inc, ientry++)
  {
    inc = 6;
    fkey = "";
    menutext = str2html(arr[ i]);
    if ("STD" == arr[i+2])
    {
      vfcode = ((vfcode = arr[ i+5]).charAt( 0) == "F") ? vfcode.substr( 1) : vfcode = RetrieveVfcode(arr[i]);
      if (vfcode != null)
        fkey = webguivfcode2key(vfcode);
    }
    else if ("LCL" == arr[i+2])
    {
      inc++; incno++;
      if ( (vfcode = arr[i+6]).charAt( 0) == "F")
        fkey = webguivfcode2key(vfcode.substr( 1));
    }

    menuitem_label = "";
    s += "<div id=\"menuitem-" + ientry + "\" style=\"height:" + (("-" == arr[i]) ? "9" : cLineHeight)
         + "\" VPOS=\"" + ientry + "\" ";
    chkclass = (arr[i+4]=="CHK") ? "NewMenuCheck" : "NewMenuCheckNone";
    popclass = (arr[i+2]=="POP") ? "NewMenuArrow" : "NewMenuArrowNone";
    if (arr[i]=="-")
    {
      s += "class=\"NewMenuSep1\">" + menuitem_label + "<div class=\"NewMenuSep2\"></div>";
      sepcnt++;
    }
    else if ("OFF" == arr[i+1])
    {
      hilight = "onmouseover=\"HilightDisabled(event);\"";
      s += onfocusd + "class=\"NewMenuItemDisabled\"" + hilight + ">" + menuitem_label
         + "<table width=\"100%\" cols=\"3\" cellpadding=\"0\" cellspacing=\"0\"><tr height=\""+cLineHeight
         + "\"><td class=\"" + chkclass + "\" align=\"" + alignleft + "\">&nbsp;</td>"
         + "<td class=\"NewMenuItemFontDisabled\" align=\"" + alignleft + "\"" + ">" + menutext
         + "</td><td class=\"" + popclass  + "\" align=\"" + alignright + "\">&nbsp;</td></tr></table>";
    }
    else
    {
      s += onfocus + "class=\"NewMenuItem\" onmouseout=\"Lowlight();\"";
      hilight = "onmouseover=\"Hilight(event);\"";
      if ("STD" == arr[i+2] || "LCL" == arr[i+2])
      {
        whataction = (arr[i+5] != "") ? 5 : 3;
        arr[i+whataction] = arr[i+whataction].replace(/\\\"/g, "\\'");
        action = " action=\"" + arr[i+whataction] + "\"";
        s += action + hilight + " onmouseup=\"Action('" + arr[i+whataction] + "', event);\">" + menuitem_label
           + "<table width=\"100%\" cols=\"3\" cellpadding=\"0\" cellspacing=\"0\"><tr height=\""+cLineHeight
           + "\"><td class=\"" + chkclass + "\" align=\"" + alignleft + "\"" + ">&nbsp;</td>"
           + "<td class=\"NewMenuItemFont\" align=\"" + alignleft + "\">" + menutext + "</td>";
        if (fkey != "")
        {
          s += "<td class=\"NewMenuItemFont\" align=\"" + alignright + "\">" + fkey + "</td>";
        }
        s += "</tr></table>";
      }
      else
      {
        showsubmenu = " showsubmenu=\"" + arr[i+3] + "\" onmouseover=\"ShowSubMenu('" + arr[i+3] + "',event);\"";
        s += showsubmenu + ">" + menuitem_label
           + "<table width=\"100%\" cols=\"3\" cellpadding=\"0\" cellspacing=\"0\"><tr height=\""+cLineHeight
           + "\"><td class=\"" + chkclass + "\" align=\"" + alignleft + "\">&nbsp;</td>"
           + "<td class=\"NewMenuItemFont\" align=\"" + alignleft + "\"" + showsubmenu + ">" + menutext
           + "</td><td class=\"" + popclass  + "\" align=\"" + alignright + "\">&nbsp;</td></tr></table>";
      }
    }
    s += "</div>";

    fkeylength = fkey ? ((15 == cCharWidth) ? fkey.length/2 : fkey.length) : 0;

    if (maxWidth < (arr[i].length + fkeylength))
    {
      maxWidth = (arr[i].length + fkeylength);
      if (arr[i+2]=="POP")
      {
        maxWidth += 2;
      }
    }
  } // for (i)
  s = s + "</div>";

  menuArray[menuID] = {"s":s, "i":i-incno, "entries":ientry, "sepcnt":sepcnt, "maxWidth":maxWidth};
 }
 else
 {
   i        = s["i"];
   ientry   = s["entries"];
   sepcnt   = s["sepcnt"];
   maxWidth = s["maxWidth"];
   s        = s["s"];
 }

  menuDoc.body.innerHTML = s;
  menuAll.keyNavIndex = 0;
  menuAll.style.height = cLineHeight*ientry +4 - ((0 < sepcnt) ? sepcnt*9 : 0);
  menuAll.style.width = cCharWidth*maxWidth+27+7;  // +27 for scrollbar +7 for check symbol
  menuAll.style.top = "-1000px";
  menuAll.style.left = "-1000px";

  CloseMenus (level+1);

  if (0 <= level && parentLoc)
  {
    var parentMenuAll, parentMenuFrame, parentScrollDIV;

    parentMenuAll = document.getElementById("MenuFrame" + (level-1));
    parentMenuFrame = new wguObjFrame(parentMenuAll);
    parentScrollDIV = parentMenuFrame.doc.getElementById('scrollDIV');
    if (null != (i = parentScrollDIV.childNodes[parentLoc]))
      toptop = parentMenuAll.offsetTop + i.offsetTop;
    else
      toptop = parentMenuAll.offsetTop + cLineHeight*Number(parentLoc);
    if (parentScrollDIV)
      toptop = toptop - parentScrollDIV.scrollTop;
    leftleft = parentMenuAll.offsetLeft + parentMenuAll.offsetWidth;
    if (leftleft + cCharWidth*maxWidth+1 > document.body.clientWidth)
    {
      leftleft = parentMenuAll.offsetLeft - cCharWidth*maxWidth+1-7 - cLeftOffset;
    }
  }
  else
  {
    // sk/20041203 - implementation of the new toolbar control
    if (typeof its_toolbarctrl_button != "undefined" &&
        gCurrentMenu instanceof its_toolbarctrl_button)
    {
      pos = wgu_getAbsolutePosition( gCurrentMenu.outer );
      toptop = pos.y + gCurrentMenu.outer.offsetHeight + 1; //+1 cosmetic gap
      leftleft = pos.x;
      if (webguiIsPopup && !webguiNoPopupMargin && webguiFullScreenPopup)
      {
        var localwebguiPage = document.getElementById("webguiPage");
        var xdiff = (document.body.offsetWidth - localwebguiPage.offsetWidth)/2;
        var ydiff = (document.body.offsetHeight - localwebguiPage.offsetHeight)/2;
        toptop -= ydiff - 2; // -2 cosmetic
        leftleft -= xdiff;
      }
    }
    // ******** New CUA Menu ********
    else if (ev && newEventSrcElement && newEventSrcElement.className.substr(0,17) == "WebguiCUAMetaMenu")
    {
      srcElement = newEventSrcElement;    //.parentNode;
      pos = wgu_getAbsolutePosition( srcElement );
      leftleft = pos.x;
      if (isBidiRTL())
      {
        leftleft -= (menuAll.offsetWidth - srcElement.offsetWidth) - (srcElement.clientWidth - srcElement.clientLeft);
      }
      toptop = pos.y + srcElement.offsetHeight + 1;
    }
    else if ( ev && newEventSrcElement && (newEventSrcElement.className == "NewMenuCaption"
                       || newEventSrcElement.className == "NewMenuCaptionOn"
                       || newEventSrcElement.className == "webguiMetaMenu"
                       || newEventSrcElement.className.substr(0,17) == "WebguiCUAMetaMenu")
            )
    {
      var
        grandParentAll;

      srcElement = newEventSrcElement;

      if(srcElement.className=="webguiMetaMenu")
        srcElement = srcElement.parentNode;

      grandParentAll = srcElement.parentNode.parentNode.parentNode;

      leftleft = grandParentAll.offsetLeft + srcElement.offsetLeft ;

      if(srcElement.id == "webguiMetaStdButton") {
        toptop = grandParentAll.parentNode.offsetTop + srcElement.offsetTop + srcElement.offsetHeight + 1;
        if (typeof(webguiMenusl) != "undefined" && webguiMenusl) {  //tj/2002-11-06/ frog2002 && HCM menu2002
          if (document.getElementById("NewMenuslBar") && document.getElementById("NewMenuslBar").parentNode) {
            leftleft += document.getElementById("NewMenuslBar").parentNode.offsetWidth;
          }
          else
            leftleft += 88;
        }
      }
      else if (srcElement.id == "NewMenuslBar")
      {
        toptop = grandParentAll.parentNode.offsetTop + srcElement.offsetTop + srcElement.offsetHeight + 1;
      }
      else if (srcElement.id == "webguiMetaAppButton")
      {
        leftleft = srcElement.parentNode.parentNode.parentNode.parentNode.offsetLeft
             + srcElement.offsetLeft + 8
             - menuAll.offsetWidth
             + newEventSrcElement.offsetWidth;
        toptop = grandParentAll.parentNode.offsetTop + srcElement.offsetTop + srcElement.offsetHeight - 1;
      }
      else if (srcElement.id == "webguiMetaPageUpDown")
      {
        toptop = grandParentAll.parentNode.offsetTop + grandParentAll.offsetHeight;
        leftleft += srcElement.offsetWidth;

        if (leftleft + cCharWidth*maxWidth+1 > document.body.clientWidth)
          leftleft = leftleft - (cCharWidth*maxWidth+1);

        if (webguiIsPopup && !webguiNoPopupMargin && webguiFullScreenPopup)
        {
          var localwebguiPage = document.getElementById("webguiPage");
          var xdiff = (document.body.offsetWidth - localwebguiPage.offsetWidth)/2;
          var ydiff = (document.body.offsetHeight - localwebguiPage.offsetHeight)/2;

          toptop += ydiff - 2; // -2 cosmetic
          leftleft += xdiff;
        }
      }
      else
      {
        toptop = grandParentAll.offsetTop + srcElement.offsetTop + srcElement.offsetHeight + 2;
        if (webguiTheme == "sl" && ( srcElement.className == "NewMenuCaptionOn" || srcElement.className == "NewMenuCaptionOn"))
          toptop -= 2;
      }
    }
    else if (true == controlctxmnu && 0 == level)
    {
      toptop = contextmenu_y + 1; //Cosmetic Gap
      leftleft = contextmenu_x;
    }
    else if( gCurrentMenu.className == "TBCMenu" || gCurrentMenu.parentNode.className == "TBCMenu" )
    {
      if ( gCurrentMenu.TBC_Type == 'menu' || gCurrentMenu.TBC_Type == 'dropdown')
      {
        gDynamicTBCMenu = gCurrentMenu;
      }

      // formerly called function getYPos, getXPos are in basis.js which is not included in case of ~crm_webgui =1
      // new functions are in d_toolbarctrl.js of nsnavigator branch.
      toptop = TBC_getYPos(gCurrentMenu) + gCurrentMenu.offsetHeight + 2;
      leftleft = TBC_getXPos(gCurrentMenu) -2;
    }
    else
    {
      if (true == webguiIsPopup)
        {
        if (!webguiFullScreenPopup || webguiNoPopupMargin)
        {
          toptop = MenuGetClientYPos(ev);
          leftleft = MenuGetClientXPos(ev);
        }
        else if (!webguiNoPopupMargin)
        {
          var localwebguiPage = document.getElementById("webguiPage");
          var xdiff = (document.body.offsetWidth - localwebguiPage.offsetWidth)/2;
          var ydiff = (document.body.offsetHeight - localwebguiPage.offsetHeight)/2;

          toptop = MenuGetClientYPos(ev);
          leftleft = MenuGetClientXPos(ev);
        }
      }
      else
      {
        toptop = MenuGetClientYPos(ev);
        leftleft = MenuGetClientXPos(ev);
      }

      var containerHeight,containerWidth;

      if (xdiff > 0 && ydiff > 0 && localwebguiPage)
      {
        containerHeight = localwebguiPage.offsetHeight + ydiff;
        containerWidth = localwebguiPage.offsetWidth + xdiff;
      }
      else
      {
        containerHeight = document.body.offsetHeight;
        containerWidth = document.body.offsetWidth;
      }

      if (toptop + menuAll.offsetHeight > containerHeight && containerHeight > menuAll.offsetHeight)
        toptop = containerHeight - menuAll.offsetHeight - 5;  // -5 cosmetc gap
      if (leftleft + menuAll.offsetWidth > containerWidth && containerWidth > menuAll.offsetWidth)
        leftleft = containerWidth - menuAll.offsetWidth - 5;
    }
  }

  if (leftleft + menuAll.offsetWidth > document.body.offsetWidth)
  {
    leftleft -= (leftleft + menuAll.offsetWidth) - document.body.offsetWidth + 5;
  }
  if ( leftleft < 0 )
  {
    leftleft = 0;
  }

  if (toptop + menuAll.clientHeight > document.body.offsetHeight)
  {
    var overflowHeight, vscrollDIV;

    vscrollDIV = menuFrameObj.doc.getElementById("scrollDIV");

    overflowHeight = (toptop + menuAll.clientHeight) - document.body.offsetHeight;

    if ((level > 0 || webguiIsPopup) && (overflowHeight/menuAll.clientHeight > 0.6))
    {
      if (menuAll.clientHeight > document.body.offsetHeight && parentMenuAll)
      {
        toptop = parentMenuAll.offsetTop;
        menuAll.style.height = parentMenuAll.offsetHeight;
        if (vscrollDIV)
          openMenu_AddVerticalScrollbars(vscrollDIV);
      }
      else
      {
        toptop = document.body.offsetHeight - menuAll.clientHeight - 5;
        if (toptop < 0)
        {
          toptop = 5;
          menuAll.style.height = document.body.offsetHeight - 10;
          if (vscrollDIV)
            openMenu_AddVerticalScrollbars(vscrollDIV);
        }
      }
    }
    else
    {
      menuAll.style.height = menuAll.clientHeight - overflowHeight - 5;
      if (vscrollDIV)
        openMenu_AddVerticalScrollbars(vscrollDIV);
    }
  }

  if ((s = menuDoc.getElementById("scrollDIV")).addEventListener)
  {
    try
    {
      window.wgu_global_eventhandler.RegisterHandler("keydown",  "~menu", 990, menuFrame.keyNavMenu);
      window.wgu_global_eventhandler.RegisterHandler("focus",    "~menu", 990, menuFrame.Hilight);
      window.wgu_global_eventhandler.RegisterHandler("mouseout", "~menu", 990, menuFrame.Lowlight);
    }catch(ex){alert(ex);}

/*
      for (menuitem = 0, i = s.childNodes.length; menuitem < i; menuitem++)
      {
        s.childNodes[menuitem].onfocus = function(event) {Hilight(event);};
        s.childNodes[menuitem].onmouseout = Lowlight;
      }
*/
  }

  menuAll.style.top = toptop + "px";
  menuAll.style.left = leftleft + "px";
  menuAll.style.visibility = "visible";

  dom_focus(menuAll);

  if (menuID)
  {
    try {
      if (menuID.indexOf( document.gstr_webgui_MenuArrayName + "_1") != -1) // Menu
        currentSubMenu = "menu";
      else if (menuID.indexOf("stdButtonBar") != -1) // Tools
        currentSubMenu = "tools";
      else if (menuID.indexOf("appBarCur") != -1) // More
        currentSubMenu = "more";
      else
        currentSubMenu = "";
    } catch(exception) { status = " caught exception : " + exception.message; }
  }
} // OpenMenu()


function CloseMenus ( fromLevel )
{
  var i;
  var n;
  var menuAll;
  n = Number (fromLevel);

  if (contextIFRAMEcreated && n == 0)
  {
    // he.pi crossbrowser
    cmenuframe = document.getElementById("ContextFrame0");
    cmenuframe.outerHTML = "";
    cmenuframe = null;
    contextIFRAMEcreated = false;
    controlctxmnu_active = false;
  }

  if (gMenuOpen)
  {
    window.wgu_global_eventhandler.UnregisterHandler("keydown",  null, "~menu");
    window.wgu_global_eventhandler.UnregisterHandler("focus",    null, "~menu");
    window.wgu_global_eventhandler.UnregisterHandler("mouseout", null, "~menu");

    if (menuIFRAMEcreated)
    {
      for (i=n; i < gNumMenuIFRAME; i++)
      {
        menuAll = eval( "document.getElementById('MenuFrame" + i + "')" );
        if (menuAll)
        {
          menuAll.style.visibility = "hidden";
          menuAll.style.posTop = 0;
          menuAll.style.posLeft = 0;
        }
      }
    }
  }

  if (n==0)
  {
    gMenuOpen = null;
    if ( gDynamicTBCMenu != null )
    {
      TBC_Strip(gDynamicTBCMenu);
      gDynamicTBCMenu = null;
    }
    gCurrentMenu = null;
    webguiTSPulldownMenu = null;
    gContextMenu = null;
  }

  if (n <= gLastMenuButtonLevel)
  {
    if (null != gLastMenuButton)
    {
      dom_focus(gLastMenuButton);
    }
  }
} // CloseMenus()


function MenuDown ( onElement, aEvent )
{
  var el;
  var bo;
  var myEvent = null;

  contextMenuException = false;

  if (gContextMenu)
    CloseMenus(0);

  if (webguiTSPulldownMenu)
    CloseMenus(0);

  if (aEvent == null && window.event != null)
  {
    aEvent = window.event;
  }

  if (aEvent)
  {
    myEvent = new its_event(aEvent);
    if (myEvent)
    {
      myEvent.stopPropagation();
    }
  }

  if ( onElement == null )
  {
    if (myEvent)
    {
      el = myEvent.target;
    }
  }
  else
  {
    el = onElement;
  }

  if (null == el) return;

  if (null != el.className
     && (el.className.substr(0,17) == "WebguiCUAMetaMenu"
         || el.className == "webguiMetaMenu"
        )
     )
  {
    CloseMenus(0);
    if (!el.CMD && (null != el.parentNode && el.parentNode.getAttribute("CMD")))
      el = el.parentNode;
  }

  // we need an intermediate variable for Mozilla/Firefox :-(
  tbbutton = typeof its_toolbarctrl_button != "undefined" && el instanceof its_toolbarctrl_button;
  bo = false;
  if (!tbbutton)
  {
    bo = (el.className != "NewMenuCaption" && el.className != "NewMenuCaptionOn" && el.className != "NewMenuCaptionsl" && !el.getAttribute("CMD"));
  }

  if ( bo == true )
  {
    return;
  }

  if ( gMenuOpen != null )
  {
    CloseMenus(0);
    gMenuOpen = null;
  }
  else
    MenuDowncheck(el, aEvent);
} // MenuDown()

function MenuOver(onElement, hideNew, aEvent)
{
  var s,
      el,
      tempEvent;

  if (window.event)
  {
    window.event.cancelBubble = true;
    tempEvent = window.event;
  }
  else
  {
    tempEvent = aEvent; //mozilla
  }

  contextMenuException = false;

  if (gContextMenu || webguiTSPulldownMenu)
    return;

  if ( onElement == null )
    //el = event.srcElement;
    el = (tempEvent.srcElement == undefined) ? tempEvent.target : tempEvent.srcElement; //mozilla / ie?
  else
    el = onElement;

  if ( el.className == "WebguiIconTextButton" ) /* menu2002 */
  {
    CloseMenus( 0);
    el = el.parentNode;
  }

  if (  (   el.className != "NewMenuCaption"
         && el.className != "NewMenuCaptionOn"
         && el.className != "NewMenuCaptionsl"
         && !el.getAttribute("CMD")
         )
        || el.id == "WebguiCUAMetaMenu"
      )
  {
    return;
  }
  s = el.style;

  if ( el.oldBg == null )
  {
    el.oldBg = s.backgroundColor;
    el.oldColor = s.color;
  }

  if (el.className == "NewMenuCaption" || el.className == "NewMenuCaptionOn") {
    el.className = "NewMenuCaptionOn";
  }
  else if (el.className.substr(0,17) != "WebguiCUAMetaMenu")
    s.color = "#FFFFFF";

  if ( gCurrentMenu != el)
  {
    LowLight(gCurrentMenu);
  }
  gCurrentMenu = el;

  if ( gMenuOpen != null && !hideNew)
  {
    OpenMenu(el.getAttribute("CMD"), "");
    gCurrentMenu = el;
    gMenuOpen = el;
  }
}


function getMenuFontHeight()
{
  if (!setMenuFontHeight)
  {
    var tester = document.getElementById("fontheighttester");
    if (!tester)
      tester = parent.document.getElementById("fontheighttester");

    if (tester)
    {
      tester.style.display = "inline";

      if (tester.offsetHeight > 15)
      {
        if (tester.offsetHeight >= 18)
          cLineHeight = tester.offsetHeight + 1;
        else
        {
          cLineHeight = tester.offsetHeight + 2;
          if (cLineHeight > 18)
            cLineHeight = 18;
        }

        if (cCharWidth < 15)
          cCharWidth = 8;
      }
      tester.style.display = "none";
    }
    setMenuFontHeight = true;
  }
}


//BEGIN @@ JB 8.3.2002


function returnctxframe()
{
  return "<HTML><HEAD>" +
  "<SCRIPT language=\"JavaScript\" src=\"" + webguiMimeURL + "\/webgui\/"+webguiTheme+"\/scripts\/menubase.js\"><\/SCRIPT>" +
  "<LINK REL=\"stylesheet\" HREF=\"" + webguiMimeURL + "\/webgui\/"+webguiTheme+"\/style\/menu.css\" TYPE=\"text\/css\">" +
  "<script language=\"Javascript\" src=\"" + webguiMimeURL + "\/system\/"+webguiTheme+"\/script\/sapwebframework.js\"><\/script><script>" +
  "  SAP_bindPageToDomain();<\/script>" +
  "<\/HEAD><BODY CLASS=NewMenuBody onload='parent.ContextMenu_postUrl(parent.contextframe_controlid, parent.contextframe_event, parent.contextframe_params, parent.contextmenu_x, parent.contextmenu_y);'>" +
  "<\/BODY>" +
  "<\/HTML>";

}

function GetContextIFRAME(controlid, myevent, params, x, y)
{
  if (!contextIFRAMEcreated)
  {
    var
      iFrameSrc,
      iFrameHTML;

    iFrameSrc = webguiMimeURL+"/system/"+webguiTheme+"/page/contextmenubase.html";
//    iFrameHTML = '<IFRAME APPLICATION=YES SCROLLING=NO ID=ContextFrame0 name=ContextFrame0 SRC=\"' + iFrameSrc + '\" FRAMEBORDER=0 style=\"position:absolute; top=' + y + '; left=' + x + '; height=100; width=100;visibility:hidden;\"></IFRAME>';
    iFrameHTML = '<iframe application="yes" scrolling="no" id="ContextFrame0" name="ContextFrame0" src="' + iFrameSrc + '" frameborder="0" style="position:absolute; top=' + y + '; left=' + x + '; height=100; width=100;visibility:hidden;"></IFRAME>';


    contextframe_controlid = controlid;
    contextframe_params = params;
    contextframe_event = myevent;
    contextmenu_x = x;
    contextmenu_y = y;

    // crossbrowser insertadjacenthtml he.pi
        if (!document.all){
          //mozilla
          var r = document.createRange();
          r.setStartBefore(document.body);
          var parsedHTML = r.createContextualFragment(iFrameHTML);
          document.body.insertBefore(parsedHTML,document.body.firstChild);
        }
        else{
          //ie
          document.body.insertAdjacentHTML("AfterBegin", iFrameHTML);
        }
    contextIFRAMEcreated = true;
  }

}

function CTXM_Click(controlId, fCode,eve)
{
  var
    param = "key=" + fCode;
  var webguiform;

  webguiform = document.getElementById("webguiform");

  webguiform.elements[formControlIdx].value = controlId;
  webguiform.elements[formEventIdx].value = "OnCtxMnuSelected";

  webguiform.elements["~ctxmenuselected"].value = "X";

  if (param)
  {

    if (webguiform.saveAction)
      webguiform.action = webguiform.saveAction;
    else
      webguiform.saveAction = webguiform.action;


    webguiform.action += "?" + param;

  }
  // Do it, the menu selection has been done
  // and the flickerfree submit is permitted
  submitForm();

  if (webguiform.saveAction)
    webguiform.action = webguiform.saveAction;
  else
    webguiform.saveAction = webguiform.action;

  webguiform.elements[formControlIdx].value = "";
  webguiform.elements[formEventIdx].value = "";
  webguiform.elements["~ctxmenuselected"].value = "";

  if (eve)
  {
    eve.cancelBubble = true;
  }

  CloseMenus(0);
}

function OpenContextMenu ( in_event )
{
  var menuFrame;

  menuFrame = document.getElementById("MenuFrame0");

  MenuDowncheck(menuFrame, in_event);
}


function ContextMenu_postUrl(controlid, myevent, params, x, y)
{
  var
    theParams = "",
    webguiform,
    oldtarget;

//he.pi crossbrowser  if (document.all.ContextFrame0)
  if (document.getElementById("ContextFrame0"))
  {
    contextFrameObj = new wguObjFrame('ContextFrame0');
    contextFrame = contextFrameObj.htmlObj;

    if (contextFrame)
    {
      webguiform = document.getElementById("webguiform");
      oldtarget = webguiform.target;
      webguiform.target = "ContextFrame0";

      webguiform.elements[formControlIdx].value = controlid;
      webguiform.elements[formEventIdx].value = myevent;

      webguiform.elements["~ctxmenurequest"].value = "X";
      var hiddenfield;
      if ((hiddenfield = document.getElementById("ctxmenurequest_x")) == null)
      {
        hiddenfield = document.createElement("input");
        hiddenfield.setAttribute("type", "hidden");
        hiddenfield.setAttribute("name", "~ctxmenurequest_x");
        hiddenfield.setAttribute("id", "ctxmenurequest_x");
        webguiform.appendChild(hiddenfield);
      }
      else
        hiddenfield = document.getElementById("ctxmenurequest_x");

      hiddenfield.setAttribute("value", x);

      if ((hiddenfield = document.getElementById("ctxmenurequest_y")) == null)
      {
        hiddenfield = document.createElement("input");
        hiddenfield.setAttribute("type", "hidden");
        hiddenfield.setAttribute("name", "~ctxmenurequest_y");
        hiddenfield.setAttribute("id", "ctxmenurequest_y");
        webguiform.appendChild(hiddenfield);
      }
      else
        hiddenfield = document.getElementById("ctxmenurequest_y");

      hiddenfield.setAttribute("value", y);

      if (params)
      {

        if (webguiform.saveAction)
          webguiform.action = webguiform.saveAction;
        else
          webguiform.saveAction = webguiform.action;

        webguiform.action += "?" + params;

      }
      // Load the Context menu, do not call submitform()
      webguiform.submit();
      webguiform.target = oldtarget;

      if (webguiform.saveAction)
        webguiform.action = webguiform.saveAction;
      else
        webguiform.saveAction = webguiform.action;

      webguiform.elements[formControlIdx].value = "";
      webguiform.elements[formEventIdx].value = "";
      webguiform.elements["~ctxmenurequest"].value = "";
    }
  }
}

function OpenControlContextMenu(controlId, myevent_desc, params, clientX, clientY)
{
  var param;
  param = params;

  controlctxmnu_active = true;

  if (!contextIFRAMEcreated)
  {
    GetContextIFRAME(controlId, myevent_desc, param, clientX, clientY);
  }
  else
  {
    ContextMenu_postUrl(controlId, myevent_desc, param, clientX, clientY);
  }
}

function OpenControlContextMenu2(controlId, myevent_desc, params, clientX, clientY)
{
  var param;
  var webguiform;
  param = params;

  controlctxmnu_active = true;

  webguiform = document.getElementById("webguiform");

  webguiform.elements[formControlIdx].value = controlId;
  webguiform.elements[formEventIdx].value = myevent_desc;

  webguiform.elements["~ctxmenurequest"].value = "X";
  var hiddenfield = document.createElement("input");
  hiddenfield.setAttribute("type", "hidden");
  hiddenfield.setAttribute("style", "display:none")
  hiddenfield.setAttribute("name", "~ctxmenurequest_x");
  hiddenfield.setAttribute("value", clientX);
  webguiform.appendChild(hiddenfield);

  hiddenfield = document.createElement("input");
  hiddenfield.setAttribute("type", "hidden");
  hiddenfield.setAttribute("style", "display:none")
  hiddenfield.setAttribute("name", "~ctxmenurequest_y");
  hiddenfield.setAttribute("value", clientY);
  webguiform.appendChild(hiddenfield);

  if (params)
  {

    if (webguiform.saveAction)
      webguiform.action = webguiform.saveAction;
    else
      webguiform.saveAction = webguiform.action;


    webguiform.action += "?" + params;

  }

  submitForm();
}


function InitToolbarMenu ()
{
}

function OpenToolbarMenu (menuElement)
{
  var scrollDIV;
  MenuDown(menuElement);

  webgui_donot_set_focus = true;
  menuFrameObj = new wguObjFrame('MenuFrame1');
  menuFrame = menuFrameObj.htmlObj;
  if (menuFrame && menuFrame.style.visibility != "hidden")
  {
    scrollDIV = menuFrameObj.doc.getElementByID("scrollDIV");
    if (scrollDIV)
      dom_focus(scrollDIV.children[menuFrame.keyNavIndex]);
  }
}

function MenuException(forceException, in_event)
{
  var ev = in_event;

  CloseMenus(0);

  if (!ev)
  {
    ev = event;
  }

  if ((ev && ev.type == "contextmenu") || forceException)
  {
    contextMenuException = true;
    contextMenuXPos = ev.clientX;
    contextMenuYPos = ev.clientY;
    window.setTimeout(OpenContextMenu, webguiCtxtMenuTimeout);
  }
}

function MenuGetClientXPos( in_event )
{
  var ev = in_event ? in_event : (typeof event != "undefined" ? event : null);

  if (contextMenuException)
    return contextMenuXPos;
  else if (ev)
    return ev.clientX;
}

function MenuGetClientYPos( in_event )
{
  var ev = in_event ? in_event : (typeof event != "undefined" ? event : null);
  if (contextMenuException)
    return contextMenuYPos;
  else if (ev)
    return ev.clientY;
}

function MenuKeyDown(in_event, el)
{
  var ev = (null != in_event) ? new its_event(in_event) : null,
      v;

  if (!gMenuOpen)
  {
    var frameIndex;
    if (ev.keyCode == "13" || ev.keyCode == "40") // if enter or down arrow
    {
      ev.cancel();
      if (null != el)
        v = (null != el && "tsm_td" == el.className)
            ? 1
            : ((el.className.substr(0,17) == "PULLDOWN-TABSTRIP")
               ? 2
               : null
              )
            ;
      if (null != v)
      {
        webguiTSPulldownMenu = el;
        gMenuOpen = el;
        if (2 == v && el.parentNode.id == "tsm_td")
          gCurrentMenu = el.parentNode;
        v = el.id.substring(0, el.id.length - (1 == v ? 5 : 9));
        TSMenuShow(v);
        frameIndex = 0;
      }
      else
      {
        MenuDown(null, in_event);
        frameIndex = 0; // (null != el && el.id == "menuslmenubutton") ? 0 : 1;

      }
    }

    gLastMenuButton = el;
    gLastMenuButtonLevel = frameIndex;

    if (frameIndex != 0)
      frameIndex = 1;
    menuFrameObj = new wguObjFrame('MenuFrame' + parseInt(frameIndex));
    menuFrame = menuFrameObj.htmlObj;
    if (menuFrame && menuFrame.style.visibility != "hidden")
    {
      var scrollDIV = menuFrameObj.doc.getElementById("scrollDIV");
      if (scrollDIV)
        dom_focus(scrollDIV.childNodes[menuFrame.keyNavIndex]);
    }
  }
  else
  {
    if (ev.keyCode == "13")
    {
      ev.cancel();
      CloseMenus(0);
    }
    else if (ev.keyCode == "9")
      CloseMenus(0);
  }
}






/**************************************
 *
 * Frontend option menu
 *
 *************************************/

/* Object of frontend (SAP GUI for HTML) menu entries and actions
 *
 *              0          1        2         3     4     5     6     7      8      / optional         9             10
 * Entry : { Menu text, Active?, Checked?, vfcode, Key, Shift, Ctrl, Alt, function,               sub menu id, has sub menu }
 */

wguObjGuiMenu = function ( in_menuId )
{
  if (null != in_menuId)
  {
    this._iEntries     = 0;
    this._mnuEntries   = {};
    this._keybmpcache  = null;

    // menu and submenu making
    this.menuId = in_menuId;
  }
};  // wguObjGuiMenu

wguObjGuiMenu.prototype.addEntry = function ( in_id, in_name, in_boactive, in_bochecked, in_vfcode, in_key, in_boshift, in_boctrl, in_boalt, in_fn, in_submenu_id, in_bohasSubmenu )
{
  if (!!in_id && !!in_name && (!!in_fn || !!in_bohasSubmenu || "-" == in_name))
  {
    this._iEntries++;
    this._mnuEntries[in_id] = [in_name, in_boactive, in_bochecked, in_vfcode, in_key, in_boshift, in_boctrl, in_boalt, in_fn, in_submenu_id, in_bohasSubmenu];
  }
};  // wguObjGuiMenu.AddEntry()

wguObjGuiMenu.prototype.removeEntry = function ( in_id )
{
  if (!!in_id)
  {
    delete(this._mnuEntries[in_id]);
    --this._iEntries;
  }
};  // wguObjGuiMenu.AddEntry()

wguObjGuiMenu.prototype.getEntryArray = function ()
{
  var rv = null,
      arr = [],
      i, oMnuE = this._mnuEntries;

  for (i in oMnuE)
    arr.push(i);

  if (arr.length > 0) rv = arr;

  return rv;
};  // wguObjGuiMenu.getEntryArray()

wguObjGuiMenu.prototype.getEntryById = function ( in_id )
{
  var rv = null;
  if (!!in_id)
  {
    rv = this._mnuEntries[in_id];
  }
  return rv;
};  // wguObjGuiMenu.getEntryById()

wguObjGuiMenu.prototype.getEntryByVfcode = function ( in_vfcode )
{
  var rv = null,
      arr = this._mnuEntries, i;
  if (!!in_vfcode)
  {
    for (i in arr)
    {
      if (arr[i][3] == in_vfcode)
      {
        rv = i;
        break;
      }
    }
  }
  return rv;
};  // wguObjGuiMenu.getEntryByVfcode()

wguObjGuiMenu.prototype.getEntryByiVfcode = function ( in_ivfcode )
{
  var rv = null,
      arr = this._mnuEntries, i, vfc;
  if (!!in_ivfcode)
  {
    for (i in arr)
    {
      if (!!(vfc = arr[i][3]) && parseInt(vfc.substr(1)) == in_ivfcode)
      {
        rv = i;
        break;
      }
    }
  }
  return rv;
};  // wguObjGuiMenu.getEntryByiVfcode()

wguObjGuiMenu.prototype.isActiveEntry = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[1];
  }
  return rv;
};  // wguObjGuiMenu.isActiveEntry()

wguObjGuiMenu.prototype.isChecked = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[2];
  }
  return rv;
};  // wguObjGuiMenu.isChecked()

wguObjGuiMenu.prototype.setActive = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    e[1] = true;
  }
};  // wguObjGuiMenu.setActive()

wguObjGuiMenu.prototype.setInactive = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    e[1] = false;
  }
};  // wguObjGuiMenu.setInactive()

wguObjGuiMenu.prototype.setChecked = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    e[2] = true;
  }
};  // wguObjGuiMenu.setChecked()

wguObjGuiMenu.prototype.setUnchecked = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    e[2] = true;
  }
};  // wguObjGuiMenu.setUnchecked()

wguObjGuiMenu.prototype.invertChecked = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    e[2] = !e[2];
  }
};  // wguObjGuiMenu.invertChecked()

wguObjGuiMenu.prototype.getName = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[0];
  }
  return rv;
};  // wguObjGuiMenu.getName()

wguObjGuiMenu.prototype.getExecFn = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[8];
  }
  return rv;
};  // wguObjGuiMenu.getFunction()

wguObjGuiMenu.prototype.getVfcode = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[3];
  }
  return rv;
};  // wguObjGuiMenu.getVfcode()

wguObjGuiMenu.prototype.getEntryKey = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]) && !!e[4])
  {
    rv = [];
    if (e[6]) rv.push("Ctrl");
    if (e[5]) rv.push("Shift");
    if (e[7]) rv.push("Alt");
    rv.push(e[4]);
    rv = rv.join("+");
  }

  return rv;
};  // wguObjGuiMenu.getEntryKey()

wguObjGuiMenu.prototype.getEntryIdByKeybitmap = function ( in_ibmp )
{
  var rv = null,
      id, i, a, e, k, bmp;
  if (!!in_ibmp)
  {
    if (!this._keybmpcache || this._iEntries != (this._keybmpcache.length >> 1))
    {
      a = this._mnuEntries;
      i = 0;
      this._keybmpcache = [];
      // create cache
      for (id in a)
      {
        if (null != (k = a[id][4]))
        {
          e = { keyCode : a[id][4].charCodeAt(0), shiftKey : !!a[id][5], ctrlKey : !!a[id][6], altKey : !!a[id][7] };
          bmp = this.getKeybitmapByEvent(e);
          this._keybmpcache[i++] = bmp;
          this._keybmpcache[i++] = id;
        }
      }
      if (this._iEntries != (i >>= 1)) this._iEntries = i;
    }

    for (i = 0, a = this._keybmpcache, e = a.length; i < e; i += 2)
    {
      if (a[i] == in_ibmp)
      {
        rv = a[i+1];
        break;
      }
    }
  }

  return rv;
};  // wguObjGuiMenu.getEntryByKeybitmap()

wguObjGuiMenu.prototype.getKeybitmapByEvent = function ( in_event )
{
  var rv = null;

  if (!!in_event)
    rv = (in_event.keyCode << 10) | ((in_event.shiftKey ? 1 : 0) << 2) | ((in_event.ctrlKey ? 1 : 0) << 1) | (in_event.altKey ? 1 : 0);

  return rv;
};  // wguObjGuiMenu.getKeybitmapByEvent()

//  bmp = event.keyCode << 10 | (event.shiftKey ? 1 : 0) << 2 | (event.ctrlKey ? 1 : 0) << 1 | (event.altKey ? 1 : 0);

wguObjGuiMenu.prototype.execEntryFunction = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    try
    {
      eval(e[8].replace(/\\/g, ""));
    } catch(ex){ alert("SAP GUI for HTML error:\nExecute menu function\n\n" + ex.name + "\n" + ex.message);}
  }
  return rv;
};  // wguObjGuiMenu.execEntryFunction()

wguObjGuiMenu.prototype.hasSubmenu = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = !!e[10];
  }
  return rv;
};  // wguObjGuiMenu.hasSubmenu()

wguObjGuiMenu.prototype.getSubmenuId = function ( in_id )
{
  var rv = null,
      e;
  if (null != in_id && !!(e = this._mnuEntries[in_id]))
  {
    rv = e[9];
  }
  return rv;
};  // wguObjGuiMenu.hasSubmenu()


wguObjGuiMenu.prototype.buildMenu = function ( in_submenuId )
{
  var arMnu,
      mnuid,
      am, l, e, iter, fn, oThis = this,
      sm, boIsRootMenu, boHasSubmenu, boIsSubmenu,
      s;

  if (null == in_submenuId)
  {
    mnuid = this.menuId;
  }
  else
  {
    mnuid = this.currentSM;
  }

  arMnu = eval("window." + mnuid);
  if ("undefined" != typeof arMnu)
    arMnu = eval("window." + mnuid + " = null");


  // build local frontend options menu
  //
  am = eval("window." + mnuid + " = []");
  l = 1;

  fn  = function(){ return oThis.getEntryArray(); };
  iter = new wguObjIterator(fn);
  e = iter.First();
  while (!!e)
  {
    sm = this.getSubmenuId(e);
    boHasSubmenu = this.hasSubmenu(e);
    boIsSubmenu  = !!sm && !boHasSubmenu;
    boIsRootMenu = !in_submenuId  && (!sm || !boIsSubmenu);
    boIsSubmenu  = (in_submenuId == sm) && boIsSubmenu;

    if (boIsRootMenu ? !boIsSubmenu : boIsSubmenu)
    {
      if (!boHasSubmenu)
      {
        s = this.getName(e);
        if ("-" == s)
          am.push("-", "OFF", "STD", "1/"+l++, "-", "-");
        else
          am.push(this.getName(e), this.isActiveEntry(e) ? "ON" : "OFF", "LCL", "1/"+l++, this.isChecked(e) ? "CHK" : "-", "J"+this.getExecFn(e), this.getVfcode(e));
      }
      else
      {
        this.currentSM = [mnuid,l++].join("_");
        am.push(this.getName(e), this.isActiveEntry(e) ? "ON" : "OFF", "POP", this.currentSM, this.isChecked(e) ? "CHK" : "-", "");
        this.buildMenu(sm);
      }
    }
    e = iter.Next();
  }
  iter.Finish();

  delete fn; fn = null;

};  // wguObjGuiMenu.buildMenu()
