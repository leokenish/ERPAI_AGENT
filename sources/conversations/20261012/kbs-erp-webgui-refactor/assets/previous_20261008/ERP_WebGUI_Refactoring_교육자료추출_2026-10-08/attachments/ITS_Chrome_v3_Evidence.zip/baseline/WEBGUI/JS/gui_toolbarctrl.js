/*******************************************************************************
 *
 * toolbarctrl.js
 *
 * Description: toolbar control framework for sap gui for html / webgui
 *
 * Date       : 2004/11/22
 * Author     : Simon Kruska
 *
 * History    :
 *
 * YYYY/MM/DD ID DESCRIPTION
 * 2004/11/22 sk initial implementation
 *
 *
 *
 *
 *
 *
 *
 *
 *
 ******************************************************************************/

// Toolbar modes
TBC_HORIZONTAL  = 0;
TBC_VERTICAL    = 1;

// Tollbar button types
TBC_B_BUTTON    = 0;
TBC_B_DROPDOWN  = 1;
TBC_B_MENU      = 2;
TBC_B_SEPARATOR = 3;
TBC_B_GROUP     = 4;
TBC_B_CHECK     = 5;

// Menu type
TBC_M_NOMENU    = 0;
TBC_M_STATIC    = 1;
TBC_M_DYNAMIC   = 2;

TBC_B_DISABLED  = 0;
TBC_B_ENABLED   = 1;

TBC_B_UNCHECKED = 0;
TBC_B_CHECKED   = 1;

// when the scroll buttons will be shown
TBC_SCRCNT_OFFSET = 0;

/** <its_toolbarctrl>
  *
  *   cunstructor for the class its_toolbarctrl
  *
  *
  *   params:
  *   jsname          - String  - the jsname name of the toolbar control
  *   controlid       - String  - the control id of the toolbar control
  *   type            - Number  - type of the toolbar: 0 = horizontal,
  *                               1 = vertical
  */
function its_toolbarctrl(jsname, controlId, type)
{
  this.jsname             = jsname;
  this.controlId          = controlId;
  this.type               = type;
  this.parentIsALVGrid    = false;
  this.alvGridObject      = null;
  this.container          = null;
  this.scrollContainer    = null;
  this.scrollingEnabled   = false;
  this.buttons            = new Array();
  this.activeElement      = null;
  this.window             = window;
  this.scrollLeftPosition = 0;
  this.scrollTopPosition  = 0;

  var thisPtr = this;
  this.ehCancel           = function(evt)
                            {
                              e = new its_event(evt);
                              if (e)
                              {
                                e.cancel();
                                delete(e);
                              }
                            };

  this.ehMousedown        = function(evt)
                            {
                              thisPtr.mousedown(evt);
                            };
  this.ehMouseoutButton   = function(evt)
                            {
                              thisPtr.mouseout(evt);
                            };
  this.ehMousemoveButton  = function(evt)
                            {
                              thisPtr.mousemove(evt);
                            };
  this.ehMouseupButton    = function(evt)
                            {
                              thisPtr.mouseup(evt);
                            };
  this.ehScrollLeft       = function(evt)
                            {
                              thisPtr.scrollLeft(evt);
                            }
  this.ehScrollRight      = function(evt)
                            {
                              thisPtr.scrollRight(evt);
                            }
  this.ehScrollUp         = function(evt)
                            {
                              thisPtr.scrollUp(evt);
                            }
  this.ehScrollDown       = function(evt)
                            {
                              thisPtr.scrollDown(evt);
                            }
  this.ehMouseOut         = function(evt)
                            {
                              thisPtr.hideScrollButton(evt);
                            }
  this.ehResize           = function(evt)
                            {
                              thisPtr.resize();
                            }
  this.ehKeydown          = function(evt)
                            {
                              thisPtr.keydown();
                            }
  this.ehScroll           = function(evt)
                            {
                              thisPtr.scroll();
                            }
}
// </its_toolbarctrl>


/** <its_toolbarctrl::init>
  *
  *   initialize the control
  *
  */
its_toolbarctrl.prototype.init = function()
{
  this.container         = document.getElementById(this.jsname + "_container");
  this.scrollContainer   = dom_getChildNodeByNodeName(this.container, "DIV");
  this.scrollContainerInner   = dom_getChildNodeByNodeName(this.scrollContainer, "DIV");

  its_eMgr.registerEvent(this.container, "drag", this.ehCancel);
  its_eMgr.registerEvent(this.container, "selectstart", this.ehCancel);
  its_eMgr.registerEvent(this.container, "resize", this.ehResize);
  its_eMgr.registerEvent(this.container, "keydown", this.ehKeydown);
  its_eMgr.registerEvent(this.container, "scroll", this.ehScroll);

  its_eMgr.registerEvent(this.container, "mousedown", this.ehMousedown);

  // initialize the scrolling buttons
  if (this.type == TBC_HORIZONTAL)
  {
    this.scrollLeftButton  = document.getElementById(this.jsname + "_toolbarctrl_scroll_button_left");
    its_eMgr.registerEvent(this.scrollLeftButton, "click", this.ehScrollLeft);
    its_eMgr.registerEvent(this.scrollLeftButton, "dblclick", this.ehScrollLeft);
    this.scrollRightButton = document.getElementById(this.jsname + "_toolbarctrl_scroll_button_right");
    its_eMgr.registerEvent(this.scrollRightButton, "click", this.ehScrollRight);
    its_eMgr.registerEvent(this.scrollRightButton, "dblclick", this.ehScrollRight);
  }
  else if (this.type == TBC_VERTICAL)
  {
    this.scrollUpButton   = document.getElementById(this.jsname + "_toolbarctrl_scroll_button_up");
    its_eMgr.registerEvent(this.scrollUpButton, "click", this.ehScrollUp);
    its_eMgr.registerEvent(this.scrollUpButton, "dblclick", this.ehScrollUp);
    this.scrollDownButton = document.getElementById(this.jsname + "_toolbarctrl_scroll_button_down");
    its_eMgr.registerEvent(this.scrollDownButton, "click", this.ehScrollDown);
    its_eMgr.registerEvent(this.scrollDownButton, "dblclick", this.ehScrollDown);
  }
}
// </its_toolbarctrl::init>


/** <its_toolbarctrl::resize>
  *
  *   resize parts of the control on load or on resize events
  */
its_toolbarctrl.prototype.resize = function(evt)
{
  if (this.type == TBC_VERTICAL)
  {
    this.container.scrollLeft = this.scrollLeftPosition;
    if (this.scrollTopPosition > this.scrollContainerInner.offsetHeight || this.container.offsetHeight + TBC_SCRCNT_OFFSET >= this.scrollContainerInner.offsetHeight)
    {
      document.getElementById(this.jsname + "scrollTop").value = 0;
      this.container.scrollTop = 0;
    }
    else
      this.container.scrollTop = this.scrollTopPosition;

    this.scrollContainer.style.width = this.container.offsetWidth + "px";
    if (this.container.offsetHeight + TBC_SCRCNT_OFFSET < this.scrollContainerInner.offsetHeight)
    {
      this.scrollingEnabled = true;
      this.scrollUpButton.style.width = this.container.offsetWidth;
      this.scrollDownButton.style.width = this.container.offsetWidth;
    }
    this.updateVerticalScrollButtons(true);
    // check if there is a dynamic menu to be displayed on load and resize
    // buttons
    for (var i = 0; i < this.buttons.length; i++)
    {
      this.buttons[i].resize(this.container.offsetWidth);
    }
  }
  else if (this.type == TBC_HORIZONTAL)
  {
    this.container.scrollTop  = this.scrollTopPosition;
    if (this.scrollLeftPosition > this.scrollContainerInner.offsetWidth || this.container.offsetWidth + TBC_SCRCNT_OFFSET >= this.scrollContainerInner.offsetWidth)
    {
      document.getElementById(this.jsname + "scrollLeft").value = 0;
      this.container.scrollLeft = 0;
    }
    else
      this.container.scrollLeft = this.scrollLeftPosition;

    if (this.container.offsetWidth + TBC_SCRCNT_OFFSET < this.scrollContainerInner.offsetWidth)
    {
      this.scrollingEnabled = true;
    }
    this.updateHorizontalScrollButtons(true);
  }

  for (var i = 0; i < this.buttons.length; i++)
  {
    if (this.buttons[i].menuType == TBC_M_DYNAMIC &&
        this.buttons[i].CMD != "" &&
        !this.buttons[i].dynmenushown)
    {
        MenuDown(this.buttons[i]);
        this.buttons[i].dynmenushown = true;
    }
  }

}
// </its_toolbarctrl::resize>


/** <its_toolbarctrl::setScrollPosition>
  *
  *   sets the scroll position of the container after a request/response
  *
  *   params:
  *   left - Number - scroll left value
  *   top  - Number - scroll top value
  */
its_toolbarctrl.prototype.setScrollPosition = function(scrollLeft, scrollTop)
{
  this.scrollLeftPosition = scrollLeft;
  this.scrollTopPosition = scrollTop;
}
// </its_toolbarctrl::setScrollPosition>


/** <its_toolbarctrl::scroll>
  *
  *   event handler for scrolling
  *
  *   params:
  *   evt - Object - event (mozilla only)
  */
its_toolbarctrl.prototype.scroll = function(evt)
{
  if (this.type == TBC_HORIZONTAL)
    this.updateHorizontalScrollButtons(true);
  else if (this.type == TBC_VERTICAL)
    this.updateVerticalScrollButtons(true);
  this.scrollLeftPosition = this.container.scrollLeft;
  this.scrollTopPosition = this.container.scrollTop;
  document.getElementById(this.jsname + "scrollLeft").value = this.scrollLeftPosition;
  document.getElementById(this.jsname + "scrollTop").value = this.scrollTopPosition;

}
// </its_toolbarctrl::scroll>


/** <its_toolbarctrl::keydown>
  *
  *   handle the keydown event
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_toolbarctrl.prototype.keydown = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    target = this.getButtonTarget(e.target);
    if (target)
    {
      e.stopPropagation();
      button = target[0];
      switch(e.keyCode)
      {
        case EVT_KEY_RIGHT :
          this.keyRight(button);
          break;
        case EVT_KEY_LEFT :
          this.keyLeft(button);
          break;
        case EVT_KEY_RETURN :
          if (target[0].disabled != TBC_B_DISABLED)
            this.processClick(target, e);
          break;
        case EVT_KEY_UP :
          if (button.type == TBC_B_DROPDOWN ||
              button.type == TBC_B_MENU)
          {
            target[1] = true;
            this.processClick(target, e);
          }
          else
            this.keyLeft(button);
          break;
        case EVT_KEY_DOWN :
          if (button.type == TBC_B_DROPDOWN ||
              button.type == TBC_B_MENU)
          {
            target[1] = true;
            this.processClick(target, e);
          }
          else
            this.keyRight(button);
          break;
      }
    }
    delete(e);
  }
}
// </its_toolbarctrl::keydown>


/** <its_toolbarctrl::keyLeft>
  *
  *   handle the key left event. this function is swapped out from keydown
  *   because it is reused by the key up event.
  *
  *   params:
  *   button - Object - the events target button
  */
its_toolbarctrl.prototype.keyLeft = function(button)
{
  button = button.previous;
  while (button != null &&
         (button.type == TBC_B_SEPARATOR ||
          button.disabled == TBC_B_DISABLED))
  {
    button = button.previous;
  }
  if (button == null)
  {
    button = this.buttons[this.buttons.length-1];
    while (button != null &&
           (button.type == TBC_B_SEPARATOR ||
            button.disabled == TBC_B_DISABLED))
    {
      button = button.previous;
    }
  }
  if (button && button.outer)
    dom_focus(button.outer);
}
// </its_toolbarctrl::keyLeft>


/** <its_toolbarctrl::keyRight>
  *
  *   handle the key right event. this function is swapped out from keydown
  *   because it is reused by the key down event.
  *
  *   params:
  *   button - Object - the events target button
  */
its_toolbarctrl.prototype.keyRight = function(button)
{
  button = button.next;
  while (button != null &&
         (button.type == TBC_B_SEPARATOR ||
          button.disabled == TBC_B_DISABLED))
  {
    button = button.next;
  }
  if (button == null)
  {
    button = this.buttons[0];
    while (button != null &&
           (button.type == TBC_B_SEPARATOR ||
            button.disabled == TBC_B_DISABLED))
    {
      button = button.next;
    }
  }
  if (button && button.outer)
    dom_focus(button.outer);
}
// </its_toolbarctrl::keyRight>


/** <its_toolbarctrl::setParentIsALVGrid>
  *
  *
  *   params:
  *   alvGridObject - Object - the its_gridviewObject
  */
its_toolbarctrl.prototype.setParentIsALVGrid = function(alvGridObject)
{
  this.parentIsALVGrid = true;
  this.alvGridObject = alvGridObject;
}
// </its_toolbarctrl::setParentIsALVGrid>


/** <its_toolbarctrl::processClick>
  *
  *   process the toolbar click if a button or its menu was the target
  *
  *
  *   params:
  *   target - Array     - [0] = button; [1] = menu(true/false)
  *   e      - ITS_EVENT - event
  */
its_toolbarctrl.prototype.processClick = function(target, e)
{
  var data = "";
  if (!(e instanceof its_event))
  {
    e = new its_event();
  }
  if (target)
  {
      var scrollPosition = "scrollLeft=" +
                           this.container.scrollLeft +
                           "&" +
                           "scrollTop=" +
                           this.container.scrollTop;

    button = target[0];
    hasMenu = target[1];
    if (button.type == TBC_B_MENU ||
       (button.type == TBC_B_DROPDOWN && hasMenu == true))
    {
      // open menu
      if (button.menuType == TBC_M_STATIC)
      {
        MenuDown(target[0])
      }
      else if (button.menuType == TBC_M_DYNAMIC)
      {
        if (this.parentIsALVGrid)
        {
          data = "fCode=" + button.fcode +
                 "&" +
                 "left=0" +
                 "&" +
                 "top=0" +
                 "&" +
                 scrollPosition;
          this.postURL(data, "ToolBarMenuButtonClicked");
        }
        else
        {
          data = "strFCode=" + button.fcode +
                 "&" +
                 "nPosX=" + e.clientX +
                 "&" +
                 "nPosY=" + e.clientY +
                 "&" +
                 scrollPosition;
          this.postURL(data, "OnDropdownClicked");
        }
      }
    }
    else
    {
      if (this.parentIsALVGrid)
      {
      if (button.fcode.substr(5,5) == "LOCAL")
      {
          fCode = button.fcode.substring(15, button.fcode.length);

          if (fCode=="INSERT_ROW")
          {
            its_gvMgr.postToolbarEvent(this.alvGridObject, "InsertLine");
/*
            if (its_ua.gecko)
              GVInsertLineEvent(e, this.alvGridName);
            else if (its_ua.ie55up)
              GVInsertLineEvent(this.alvGridName);
*/
          }
          else if (fCode=="APPEND")
          {
            its_gvMgr.postToolbarEvent(this.alvGridObject, "AppendLine");
/*
            if (its_ua.gecko)
              GVAppendLineEvent(e, this.alvGridName);
            else if (its_ua.ie55up)
              GVAppendLineEvent(this.alvGridName);
*/
          }
          else if (fCode=="DELETE_ROW")
          {
            its_gvMgr.postToolbarEvent(this.alvGridObject, "DeleteLine");
/*
            if (its_ua.gecko)
              GVDeleteLineEvent(e, this.alvGridName);
            else if (its_ua.ie55up)
              GVDeleteLineEvent(this.alvGridName);
*/
          }
          else if (fCode=="COPY_ROW")
          {
            its_gvMgr.postToolbarEvent(this.alvGridObject, "CopyLine");
/*
            if (its_ua.gecko)
              GVCopyLineEvent(e, this.alvGridName);
            else if (its_ua.ie55up)
              GVCopyLineEvent(this.alvGridName);
*/
          }
        }
        this.postURL("fCode=" + button.fcode, "ToolBarButtonClicked");
      }
      else
      {
        data = "strFCode=" + button.fcode +
               "&" + scrollPosition;
        this.postURL(data, "OnFunctionClicked");
      }
    }
  }
}
// </its_toolbarctrl::processClick>


/** <its_toolbarctrl::processMenu>
  *
  *   send the FCode to the its, when a menuitem is clicked
  *
  *   params:
  *   fcode - String - fcode to be send
  */
its_toolbarctrl.prototype.processMenu = function(fcode)
{
  this.postURL("strFCode=" + fcode, "OnFunctionClicked");
}
// </its_toolbarctrl::processMenu>


/** <its_toolbarctrl::mousedown>
  *
  *   toolbar mousedown event
  *
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.mousedown = function(evt)
{
  e = new its_event(evt);
  if (e.button && e.button == EVT_MB_LEFT)
  {
    target = this.getButtonTarget(e.target);
    if (target)
    {
      if (target[0].disabled != TBC_B_DISABLED)
      {
        if ((target[1] || target[0].type == TBC_B_MENU) &&
            target[0].menuType == TBC_M_STATIC)
        {
          MenuDown(target[0]);
        }
        else
        {
          this.activeElement = target[0];
          this.activeElement.setChecked(true);
          its_eMgr.registerEvent(e.getGlobalEventReceiver(), "mousemove", this.ehMousemoveButton);
          its_eMgr.registerEvent(this.activeElement.outer, "mouseup", this.ehMouseupButton);
        }
      }
    }
  }
  e.stopPropagation();
  delete(e);
}
// </its_toolbarctrl::mousedown>


/** <its_toolbarctrl::mouseup>
  *
  *   toolbar mouseup event
  *
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.mouseup = function(evt)
{
  e = new its_event(evt);
  if (this.activeElement)
  {
    this.activeElement.setChecked(false);
    its_eMgr.unregisterEvent(e.getGlobalEventReceiver(), "mousemove", this.ehMousemoveButton);
    its_eMgr.unregisterEvent(this.activeElement.outer, "mouseup", this.ehMouseupButton);
  }
  target = this.getButtonTarget(e.target);
  if (target)
  {
    button = target[0];
    menu = target[1];

    if (button == this.activeElement)
    {
      this.processClick(target, e);
    }
    else
    {
      this.activeElement = null;
    }
  }
  delete(e);
}
// </its_toolbarctrl::mouseup>


/** <its_toolbarctrl::mousemove>
  *
  *   check where the mouse is moved after the mouse button is pressed
  *
  *
  *   params:
  *   evt  - Object - event
  */
var asdfasdf = 0;
its_toolbarctrl.prototype.mousemove = function(evt)
{
  e = new its_event(evt);
  if (e && this.activeElement)
  {
    if (!dom_contains(this.activeElement.outer, e.target))
    {
      this.activeElement.setChecked(false);
      its_eMgr.unregisterEvent(e.getGlobalEventReceiver(), "mousemove", this.ehMousemoveButton);
      its_eMgr.unregisterEvent(this.activeElement.outer, "mouseup", this.ehMouseupButton);
    }
    else
    {
      e.cancel();
    }
    delete(e);
  }
}
// </its_toolbarctrl::mousemove>


/** <its_toolbarctrl::getButtonTarget>
  *
  *   tries to find the button of a clicked element
  *
  *
  *   params:
  *   target  - Object - the clicked target
  */
its_toolbarctrl.prototype.getButtonTarget = function(target)
{
  var max = 3;
  var count = 0;
  var ret = new Array(null, false);
  while (target && count < max)
  {
    if (target.id.indexOf(this.jsname + "_button_") >= 0)
    {
      var splitId = target.id.split("_");
      var nr = splitId[2];
      if (splitId.length == 4)
      {
        // menu
        ret[0] = this.buttons[parseInt(nr, 10)-1];
        ret[1] = true;
        return ret;
      }
      else
      {
        // button
        ret[0] = this.buttons[parseInt(nr, 10)-1];
        return ret;
      }
    }
    else
    {
      target = target.parentNode;
    }
    count++;
  }
}
// </its_toolbarctrl::getButtonTarget>


/** <its_toolbarctrl::addButton>
  *
  *   add a button to the toolbar
  *
  *
  *   params:
  *   id            - String  - the buttons id
  *   type          - String  - the buttons type (button, dropdown, menu,
  *                               separator, group or check)
  *   fcode         - String  - the buttons fcode
  *   menuStatic    - Boolean - button has a static menu
  *   disabled      - Boolean - button is disabled or not
  *   checked       - Boolean - button is checked or not
  *   menuAvailable - Boolean - menu is avaliable
  */
its_toolbarctrl.prototype.addButton = function(id,
                                               type,
                                               fcode,
                                               menu,
                                               menuAvailable,
                                               disabled,
                                               checked,
                                               titleAvailable
                                              )
{
  button = new its_toolbarctrl_button(this,
                                  this.buttons.length + 1,
                                  id,
                                  type,
                                  fcode,
                                  menu,
                                  menuAvailable,
                                  disabled,
                                  checked,
                                  titleAvailable
                                 );
  this.buttons.push(button);
  if (this.buttons.length > 1)
  {
    var len = this.buttons.length;
    this.buttons[len-1].previous = this.buttons[len-2];
    this.buttons[len-2].next = this.buttons[len-1];
  }
  return button;
}
// </its_toolbarctrl::addButton>


/** <its_toolbarctrl::postURL>
  *
  *   send the event to the its
  *
  *
  *   params:
  *   data - String - data to be send to the its
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.postURL = function(data, event)
{
 var mainWindow;

 mainWindow = getMainWindow();
 if (mainWindow == self)
 {
  raiseEvent(this.controlId, event, data);
 }
 else
 {
  mainWindow.raiseEvent(controlid, event, data);
 }
}
// </its_toolbarctrl::postURL>


/** <its_toolbarctrl::scrollLeft>
  *
  *   scroll the toolbar container to the left
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.scrollLeft = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    e.stopPropagation();
    e.preventDefault();
    delete(e);
  }
  if (this.scrollingEnabled)
  {
    // temporarly remove the event handler to prevent fireing the scroll event
    // that would hide the scroll buttons anyway
    its_eMgr.unregisterEvent(this.container, "scroll", this.ehScroll);
    this.container.scrollLeft -= this.container.offsetWidth - 28;
    this.updateHorizontalScrollButtons(false);
    this.scrollLeftPosition = this.container.scrollLeft;
    document.getElementById(this.jsname + "scrollLeft").value = this.scrollLeftPosition;
    // reset the above removed event handler
    its_eMgr.registerEvent(this.container, "scroll", this.ehScroll);
  }
}
// </its_toolbarctrl::scrollLeft>


/** <its_toolbarctrl::scrollRight>
  *
  *   scroll the toolbar container to the right
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.scrollRight = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    e.stopPropagation();
    e.preventDefault();
    delete(e);
  }
  if (this.scrollingEnabled)
  {
    // temporarly remove the event handler to prevent fireing the scroll event
    // that would hide the scroll buttons anyway
    its_eMgr.unregisterEvent(this.container, "scroll", this.ehScroll);
    if (this.container.offsetWidth + this.container.scrollLeft + TBC_SCRCNT_OFFSET <
        this.scrollContainerInner.offsetWidth)
    {
      if (this.buttons.length == 1 && this.buttons[0].titleAvailable == false )
        scrollLeft = 0;
      else
        scrollLeft = this.container.scrollLeft + this.container.offsetWidth - 28;
      if (this.container.offsetWidth + scrollLeft > this.scrollContainerInner.offsetWidth)
        scrollLeft = this.scrollContainerInner.offsetWidth - this.container.offsetWidth;
      this.container.scrollLeft = scrollLeft;
      this.updateHorizontalScrollButtons(false);
    }
    this.scrollLeftPosition = this.container.scrollLeft;
    document.getElementById(this.jsname + "scrollLeft").value = this.scrollLeftPosition;
    // reset the above removed event handler
    its_eMgr.registerEvent(this.container, "scroll", this.ehScroll);
  }
}
// </its_toolbarctrl::scrollRight>


/** <its_toolbarctrl::scrollUp>
  *
  *   scroll the toolbar container up
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.scrollUp = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    e.stopPropagation();
    e.preventDefault();
  }
  if (this.scrollingEnabled)
  {
    // temporarly remove the event handler to prevent fireing the scroll event
    // that would hide the scroll buttons anyway
    its_eMgr.unregisterEvent(this.container, "scroll", this.ehScroll);
    this.container.scrollTop -= this.container.offsetHeight - 22;
    this.updateVerticalScrollButtons(false);
    this.scrollTopPosition = this.container.scrollTop;
    document.getElementById(this.jsname + "scrollTop").value = this.scrollTopPosition;
    // reset the above removed event handler
    its_eMgr.registerEvent(this.container, "scroll", this.ehScroll);
  }
}
// </its_toolbarctrl::scrollUp>


/** <its_toolbarctrl::scrollDown>
  *
  *   scroll the toolbar container to the down
  *
  *   params:
  *   evt  - Object - event
  */
its_toolbarctrl.prototype.scrollDown = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    e.stopPropagation();
    e.preventDefault();
  }
  if (this.scrollingEnabled)
  {
    // temporarly remove the event handler to prevent fireing the scroll event
    // that would hide the scroll buttons anyway
    its_eMgr.unregisterEvent(this.container, "scroll", this.ehScroll);

    if (this.container.offsetHeight + this.container.scrollTop + TBC_SCRCNT_OFFSET <
        this.scrollContainerInner.offsetHeight)
    {
      scrollTop = this.container.scrollTop + this.container.offsetHeight - 22;
      if (this.container.offsetHeight + scrollTop > this.scrollContainerInner.offsetHeight)
        scrollTop = this.scrollContainerInner.offsetHeight - this.container.offsetHeight;
      this.container.scrollTop = scrollTop;
      document.getElementById(this.jsname + "scrollTop").value = this.container.scrollTop;
      this.updateVerticalScrollButtons(false);
    }
    // reset the above removed event handler
    its_eMgr.registerEvent(this.container, "scroll", this.ehScroll);
  }
}
// </its_toolbarctrl::scrollDown>


/** <its_toolbarctrl::updateHorizontalScrollButtons>
  *
  *   update the position of the scroll buttons after the container has scrolled
  *
  *
  *   params:
  */
its_toolbarctrl.prototype.updateHorizontalScrollButtons = function(hideScrollButtons)
{
  this.scrollRightButton.style.left = this.container.scrollLeft +
                                      this.container.offsetWidth -
                                      this.scrollRightButton.offsetWidth;
  this.scrollLeftButton.style.left = this.container.scrollLeft;

  if (this.container.scrollLeft == 0)
  {
    if (hideScrollButtons)
    {
      this.scrollLeftButton.style.visibility = "hidden";
    }
    else
    {
      its_eMgr.registerEvent(this.scrollLeftButton, "mouseout", this.ehMouseOut);
    }
  }
  else
  {
    this.scrollLeftButton.style.visibility = "visible";
  }

  if ((this.container.offsetWidth + TBC_SCRCNT_OFFSET + this.container.scrollLeft <
      this.scrollContainerInner.offsetWidth) && (this.buttons.length > 1 || (this.buttons.length == 1 && this.buttons[0].titleAvailable == true )))
  {
    this.scrollRightButton.style.visibility = "visible";
  }
  else
  {
    if (hideScrollButtons)
    {
      this.scrollRightButton.style.visibility = "hidden";
    }
    else
    {
      its_eMgr.registerEvent(this.scrollRightButton, "mouseout", this.ehMouseOut);
    }
  }
}
// </its_toolbarctrl::updateHorizontalScrollButtons>


/** <its_toolbarctrl::updateVerticalScrollButtons>
  *
  *   update the position of the scroll buttons after the container has scrolled
  *
  *
  *   params:
  */
its_toolbarctrl.prototype.updateVerticalScrollButtons = function(hideScrollButtons)
{
  this.scrollUpButton.style.top   = this.container.scrollTop;
  this.scrollDownButton.style.top = this.container.scrollTop +
                                    this.container.offsetHeight -
                                    this.scrollDownButton.offsetHeight;


  if (this.container.scrollTop == 0)
  {
    if (hideScrollButtons)
    {
      this.scrollUpButton.style.visibility = "hidden";
    }
    else
    {
      its_eMgr.registerEvent(this.scrollUpButton, "mouseout", this.ehMouseOut);
    }
  }
  else
  {
    this.scrollUpButton.style.visibility = "visible";
  }

  if (this.container.offsetHeight + TBC_SCRCNT_OFFSET + this.container.scrollTop <
      this.scrollContainerInner.offsetHeight)
  {
    this.scrollDownButton.style.visibility = "visible";
  }
  else
  {
    if (hideScrollButtons)
    {
      this.scrollDownButton.style.visibility = "hidden";
    }
    else
    {
      its_eMgr.registerEvent(this.scrollDownButton, "mouseout", this.ehMouseOut);
    }
  }
}
// </its_toolbarctrl::updateVerticalScrollButtons>


/** <its_toolbarctrl::hideScrollButton>
  *
  *   hide a scroll button, when scrolling in its direction is no longer
  *   necessary/possible
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_toolbarctrl.prototype.hideScrollButton = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    e.target.style.visibility = "hidden";
    its_eMgr.unregisterEvent(e.target, "mouseout", this.ehMouseOut);
    e.stopPropagation();
    delete(e);
  }
}
// </its_toolbarctrl::hideScrollButton>


/** <its_toolbarctrl_button>
  *
  *   cunstructor for the class its_toolbarctrl_button
  *
  *
  *   params:
  *   parent   - Object  - the buttons parent, just the its_toolbarctrl
  *   id       - String  - the buttons id
  *   type     - String  - the buttons type (button, dropdown, menu,
  *                          separator, group or check)
  *   fcode      - String  - the buttons fcode
  *   menuStatic - Boolean - button has a static menu
  *   disabled   - Boolean - button is disabled or not
  *   checked    - Boolean - button is checked or not
  *   menu       - Boolean - button has a menu
  */
function its_toolbarctrl_button(parent,
                                index,
                                id,
                                type,
                                fcode,
                                menuType,
                                menuAvailable,
                                disabled,
                                checked,
                                titleAvailable)
{

  WIDTH_ICON = 18;
  WIDTH_MENU = 14;
  WIDTH_TEXT_MARGIN = 1;
  WIDTH_BUTTON_BORDER = 4;
  WIDTH_BUTTON_RIGHT_PADDING = 2;

  this.parent        = parent;
  this.index         = index;
  this.id            = id;
  this.type          = type;
  this.fcode         = fcode;
  this.menu          = null;
  this.menuType      = menuType;
  this.menuAvailable = menuAvailable;
  this.disabled      = disabled;
  this.checked       = checked;
  this.outer         = document.getElementById(id);
  this.inner         = dom_getChildNodeByNodeName(this.outer, "DIV");
  this.text          = dom_getChildNodeByNodeName(this.inner, "DIV");
  this.previous      = null;
  this.next          = null;
  this.dynmenushown  = false;
  this.titleAvailable = titleAvailable;

  // this is for the menu.js/d_menu.js :-(
  this.CMD = "";
  if (this.menuAvailable)
  {
    this.CMD      = "cmenu" + parent.jsname + "_" + this.index;
  }
}
// </its_toolbarctrl_button>


/** <its_toolbarctrl_button::setChecked>
  *
  *   change a buttons class attribute so that it looks like checked/unchecked
  *
  *
  *   params:
  */
its_toolbarctrl_button.prototype.setChecked = function(checked)
{
  if (checked)
  {
    this.inner.className = dom_addClass(this.inner.className,
                                        "toolbarctrl_button_checked");
  }
  else
  {
    this.inner.className = dom_removeClass(this.inner.className,
                                           "toolbarctrl_button_checked");
  }
}
// </its_toolbarctrl_button::setChecked>


/** <its_toolbarctrl_button::resize>
  *
  *   resize the text within the button so, that the other elements wont wrap.
  *   this is only used for a vertical toolbar.
  *
  *   params:
  *   containerWidth - Number - width of the toolbar container
  */
its_toolbarctrl_button.prototype.resize = function(containerWidth)
{
  if (this.type != TBC_B_SEPARATOR && this.text)
  {
    var width = containerWidth -
                WIDTH_BUTTON_BORDER -
                WIDTH_ICON -
                WIDTH_TEXT_MARGIN -
                WIDTH_BUTTON_RIGHT_PADDING;

    if (this.type == TBC_B_DROPDOWN ||
        this.type == TBC_B_MENU)
    {
      width -= WIDTH_MENU;
    }
    this.text.style.width = "auto";
    if (width < 0)
    {
      this.text.style.width = "0px";
      this.text.style.visibility = "hidden";
    }
    else
    {
      this.text.style.visibility = "visible";
      if (width < this.text.offsetWidth)
      {
        this.text.style.width = width + "px";
      }
      else
      {
        this.text.style.width = "";
      }
    }
  }
}
// </its_toolbarctrl_button::resize>












<!-- --> <HR><H1> This page requires JavaScript</H1>
<!-- --> Please consider upgrading to Internet Explorer 4.0 or higher
<!-- --> or to Netscape Navigator 4.0 or higher

function TBC_postUrl(controlid, event, params)
{
 var
  theParams = "",
  mainWindow;

 if (params)
  theParams += params;

 mainWindow = getMainWindow();
 if (mainWindow == self)
 {
  raiseEvent(controlid, event, theParams);
 }
 else
 {
  mainWindow.raiseEvent(controlid, event, theParams);
 }
}

function TBC_Click(controlId, fCode,eve)
{
 var
  param = "strFCode=" + fCode;

 TBC_postUrl(controlId, "OnFunctionClicked", param);
 if (eve)
 {
  eve.cancelBubble = true;
 }
}

function TBC_MenuItemClick(controlId, fCode, posX, posY, local)
{
 var
  param = "strFCode=" + fCode;
  param += "&nPosX=" + posX;
  param += "&nPosY=" + posY;

 if (local)
 {
  controlCreateDataIFRAME("toolbarData", "display:none;", "toolbar");
  webguiRaiseDataEvent(controlId, "OnDropdownClicked", param, "toolbarData");
 }
 else
 {
  TBC_postUrl(controlId, "OnDropdownClicked", param);
 }

 if (event)
 {
  event.cancelBubble = true;
 }
}

function TBC_Strip(el)
{
 el.onclick = null;
 el.onmousedown = null;
 el.onmouseout = null;

 var strOuterHTML = new String(),
  pos;

 pos = el.outerHTML.indexOf("TBC_Default");
 strOuterHTML = el.outerHTML.substr(0,pos) + "onclick" + el.outerHTML.substr(pos + 11);
 el.outerHTML = strOuterHTML;

}

// copy from similarly named functions from basis.js
// needed in menuopen of d_menu.js of nsnavigator, but
// in case of crm_webgui basis.js is not included
function TBC_getXPos( obj )
{
 var x = 0, parentElement;

 parentElement = obj.offsetParent;
 if( parentElement != null ) x = TBC_getXPos( parentElement );
 if ( obj.clientLeft )
  return x + obj.offsetLeft + obj.clientLeft ;
 else
  return x + obj.offsetLeft;
}
function TBC_getYPos( obj )
{
 var y = 0, parentElement;
 parentElement = obj.offsetParent;
 if( parentElement != null ) y = TBC_getYPos( parentElement );
 if ( obj.clientTop )
  return y + obj.offsetTop + obj.clientTop;
 else
  return y + obj.offsetTop;
}

