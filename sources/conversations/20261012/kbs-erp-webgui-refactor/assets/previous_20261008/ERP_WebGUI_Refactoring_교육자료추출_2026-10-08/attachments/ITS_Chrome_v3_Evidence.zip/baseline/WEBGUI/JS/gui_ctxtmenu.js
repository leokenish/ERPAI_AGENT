function webguiDoContextMenu ( in_event )
{
  var obj;
  var ev = new its_event(in_event);

  if (ev.target && ev.target.getAttribute("cm") != "X")
  {
    if (ev.target.parentNode && ev.target.parentNode.getAttribute("cm") == "X")
      ev.target = ev.target.parentNode;
  }

  if (ev.target && ev.target.getAttribute("cm") == "X")
  {
     if (ev.target.id=="")
        ev.target.id = ev.target.name;

     webguiDoFocus(in_event);

     webguiDoControlContextMenu(ev.target.id, 'OnDynproContextMenu', '', in_event.clientX, in_event.clientY);
     ev.cancel();
  }
  else
  {
    if (webguiContextMenu && arrMenu_FM!="")
    {
        if (webguiIsActive())
        {
          // check if legal object for context menu
          obj = webguiEventOnControl();
          if (!obj || obj.oncontextmenu != null) {
            OpenContextMenu(in_event);
          }
        }
     }
     ev.cancel();
  }
}

function webguiDoControlContextMenu (controlId, myevent_desc, local, clientX, clientY)
{
  if (webguiIsActive())
  {
    //contextMenuException = false;
    OpenControlContextMenu(controlId, myevent_desc, local, clientX, clientY);
  }
}