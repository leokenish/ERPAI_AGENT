/**********************************************************************

  Variables

**********************************************************************/



var
  WEBGUI_RESIZE_TIMEOUT  = 250,
  WEBGUI_DISABLE_TIMEOUT = 500,

  WEBGUI_DISABLE_CHECK = 10,
  WEBGUI_BUSY_PAGE     = false,
  WEBGUI_RESIZE_WIDTH  = 25,

  TOOLTIP_DELAY = 750,

  METRIC_DYNPRO = 4,
  METRIC_PIXEL = 1,
  WEBGUIDYNPROROWHEIGHT = 21,
  WEBGUIDYNPROCHARWIDTH = 7,

  webguiSetBusyPage   = WEBGUI_BUSY_PAGE,
  webguiIsBusy        = false,
  webguiRefreshPage   = true,
  webguiMessageLine   = null,
  webguiNewWindowUrl  = null,
  webguiNewWindowName = null,
  webguiUserArea      = null,
  webguiDynpro        = null,
  webguiFontWidth     = 0,
  webguiFontHeight    = 0,
  webguiLanguage      = "",
  webguiTimeoutId     = 0,
  webguiStartDate     = new Date(),
  webguiPerfOn        = false,
  webguiPerfObjects   = null,
  webguiTheme,
  webguiStyle,
  webguiIsPopup,
  webguiFullScreenPopup,
  webguiModalNo,
  webguiLeanAndMean,
  webguiIsInactive,
  webguiOldSearchHelp,
  webguiIsResizable,
  webguiMenusl,
  webguiSelectedElementOld  = null,
  webguiSearchhelpButton    = null,
  webguiComboBox            = null,
  webguiTSPulldownMenu      = null,
  webguiStartupBanner       = null,
  webguiStartupBannerText   = null,
  webguiFocusFieldCursorPos = 0,
  in_webguiSetFocus = false,

  a11yAltB = "";

// used in webguiEventOnControl() to check for control
var
  garr_controlClasses = new Array
  (
    "ColumnTree", "Docking", "gridview", "htmlviewer", "image", "splitter", "TCViewContainer", "TextEdit"
  );




/*****************************************************************/
/** see NOTE below before adding a new input form element here ***/
/*****************************************************************/
var
  formMenuItemIdx= 0,
  formFocusfieldIdx = 1,
  formOkCodeIdx = 2,
  formFKeyIdx = 3,
  formSearchHelpIdx = 4,
  formControlIdx = 5,
  formEventIdx = 6,
  formEventPrmIdx = 7,
  formWebguiUserAreaHeight = 8,
  formWebguiUserAreaWidth = 9,
  formWebguiRenderTime = 10,
  formWebguiRequestTime = 11,
  formWebguiStartRequestTime = 12,
  /* 13 is left out for printing */
  formWebguiModalLeft = 14,
  formWebguiModalTop = 15,
  formDynproTypeIdx = 16,
  formWebguiModalWindow = 17,
  formWebguiCursorObj = 18,
  formWebguiCursorCol = 19;


/***
 *** NOTE:
 *** for netscape6 the input fields are often out of order, so this
 *** static indexing will not work.  These indices are set dynamically
 *** in the onload (in d_generator.js) for netscape in the function:
 *** webguiSetBaseInputIndices().  Please if you are adding any indices
 *** here, add them also to this function.  Thanks.
 ***/












/**********************************************************************

  Functions

**********************************************************************/


function webguiDebugMode()
{
  return ("undefined" != typeof gboWguDebugMode && !!gboWguDebugMode);
}

function webguiTextResource( in_rsrcname )
{
  return webguiTextRsrc[in_rsrcname];
}

function webguiSetDocumentName()
{
  if (!window.name || window.name == "")
        window.name = "WebGuiDoc" ;
}

function webguiGetDocumentName()
{
  return window.name;
}

//used by HTML Viewer to retrieve webgui document name
function webguiGetRootDocumentName ()
{
  var rootdocname = null;
  var parentframe = self;

  /* traverse back to root and determine first SAPGUI for HTML frame
   */

  // first, find previous SAPGUI for HTML frame
  while( parentframe != parentframe.parent && parentframe.parent.webguiGetRootDocumentName == null )
    parentframe = parentframe.parent;
  // and traverse back again
  if( parentframe != parentframe.parent && parentframe.parent.webguiGetRootDocumentName )
    rootdocname = parentframe.parent.webguiGetRootDocumentName();

  if (rootdocname == null) {
    // if window is SAPGUI for HTML base window
    if( self.document.body.id.search(/^webguiBody\d?$/) != -1 && self.webguiGetDocumentName)
      rootdocname = webguiGetDocumentName();
  }
  return rootdocname;   // either null or name of root SAPGUI for HTML window
}

function webguiNoting()
{
}

function getMainWindow()
{
  return self;
}

function webguiToggleVisibility (b,c,onoff)
{
  if ( b != null && c != null )
  {
    if ( onoff )
    {
      b.style.visibility = "visible" ;
      c.style.zIndex = 1 ;
    }
    else
    {
      b.style.visibility = "hidden" ;
      c.style.zIndex = 0 ;
    }
  }
}


function webguiIsFocusElement(element)
{
    if (!element)
        return false;

    if (element.tagName &&
        (element.tagName == "INPUT" || element.tagName == "SELECT") &&
        element.type.toUpperCase() != "HIDDEN")
    {
        return true;
    }

    if (null != element.getAttribute("ct"))
    {
      return true;
    }

    if (element.className &&
        (element.className == "d_label" ||
         element.className == "d_labelHighlighted" ||
         element.className == "d_labelSelected" ||
         element.className == "d_labelHighlightedSelected" ||
         element.className == "d_toggle" ||
         element.className == "d_toggleSelected" ||
         element.className == "d_toggleText" ||
         element.className == "labelTable" ||
         element.className == "labelTableSelected" ||
         element.className == "labelTableHighlighted" ||
         element.className == "labelTableHighlightedSelected" ||
         element.className == "labelTableComboCtrl" ||
         element.className == "d_ofield" ||
         element.className == "d_ofieldSelected" ||
         element.className == "d_ofieldHighlighted" ||
         element.className == "d_ofieldHighlightedSelected"))
    {
        return true;
    }

    return false;
}

// abp 07.08.2003
var GAR_depth = 0;
function getAttributeRecursive(obj, attrib)
{
  if (obj.getAttribute(attrib))
  {
    GAR_depth = 0;
    return obj;
  }
  else if (obj.children.length > 0)
  {
    if (GAR_depth >= 40) // just arbitrary number... will have to test
    {
      GAR_depth = 0;
      return null;
    }
    var temp;
    for (i = 0; i < obj.children.length; i++)
    {
      GAR_depth++;
      temp = getAttributeRecursive(obj.children[i], attrib);
      if (temp)
      {
        GAR_depth = 0;
        return temp;
      }
    }
  }
  else
    return null;
}

function skipToolbar()
{
  var toolbar = document.getElementById("menuslToolbarEnd");
  if (toolbar)
    dom_delayedFocus(toolbar);
}

function WebGUISetControlFocus(controlid)
{
  var cfid = document.getElementsByName("~controlfocusid");
  var cf = document.getElementsByName("~controlfocus");
  if (!!cfid && cfid.length > 0)
  {
    if (!!controlid)
    {
      WebGUISetFocusField(); // unset focus field
      var cid = controlid.split(".");
      if (cid && cid.length > 1)
      {
        cfid[0].value = cid[1];
        if (cf && cf.length > 0)
          cf[0].value   = 1;
      }
    }
    else
    {
      cfid[0].value = "";
      if (cf && cf.length > 0)
        cf[0].value = "";
    }
  }
}
function WebGUISetFocusField(id)
{
  var wguFrm = getMainWindow().document.webguiform;
  var fcsFld = wguFrm.elements[formFocusfieldIdx];
  if (fcsFld)
  {
    if (id != null)
    {
      WebGUISetControlFocus(); // unset control focus
      fcsFld.value = id;
    }
    else
    {
      fcsFld.value = "";
    }
  }
}

function webguiGetContainer(selectedElement)
{
  while (selectedElement != null && selectedElement.className != "WebguiDynpro")
  {
    // search for an element with the id webguicontainer or the class webguitsdiv
    if ( (selectedElement.getAttribute("cn") && selectedElement.getAttribute("cn").toUpperCase() == "WEBGUICONTAINER")
        || (selectedElement.className && selectedElement.className == "webguiTSDiv")
       )
    {
      return selectedElement;
    }
    selectedElement = selectedElement.parentNode;
  }
  return null;
}

function webguiGetFocusElement(element)
{
  while (true)
  {
    if (webguiIsFocusElement(element))
      return element;

    if (element)
    {
      //he.pi crossbrowser element.all
      var elements = element.all ? element.all : element.getElementsByTagName('*');
      if (
        elements[0] &&
        (elements[0].tagName == "SCRIPT" || (elements[0].tagName == "LABEL" && elements[0].style.display=="none"))
      )
        element = elements[1];
      else
        element = elements[0];
    }
    else
      return null;
  }
}

function webguiSetCursorPosition(f)
{
  // The legacy UA flag can match Chromium. Use the field API without changing focus timing.
  if (!f.createTextRange && typeof f.setSelectionRange == "function")
  {
    f.setSelectionRange(webguiFocusFieldCursorPos, webguiFocusFieldCursorPos);
    return;
  }
  var t = f.createTextRange(webguiFocusFieldCursorPos, webguiFocusFieldCursorPos);
  t.move("character", webguiFocusFieldCursorPos);
  t.select();
}

function webguiSetFocus(sFocusElement)
{
  var oAnchor, oInputs = null;
  var i, j = 0;
  try
  {
    var oFocusElement = document.getElementById(sFocusElement);
    if (oFocusElement && typeof oFocusElement != "undefined")
    {
      if (oFocusElement.nodeName == "INPUT" && oFocusElement.type == "text" &&
          webguiFocusFieldCursorPos && typeof webguiFocusFieldCursorPos != "undefined")
      {
        if (its_ua.ie55up)
        {
          dom_delayedFocus(oFocusElement);
          window.setTimeout("webguiSetCursorPosition(webgui._focusElement)");
        }
        else
        {
          oFocusElement.setSelectionRange(webguiFocusFieldCursorPos, webguiFocusFieldCursorPos);
          dom_delayedFocus(oFocusElement);
        }
      }
      else
      {
        dom_delayedFocus(oFocusElement);
      }
    }
    else if (webguiDynproListExists == 1 && webguiFocusField == "")
    {
      var list = document.getElementById("list");

      if (null != list && list.focus)
      {
        webguiFocusField = "list";
        dom_delayedFocus(list);
      }
    }
    else
    {
      oInputs = document.getElementsByTagName("input");
      j = oInputs.length;
      for (i = 0; i < j; i++)
      {
        if (oInputs[i].type != "hidden" && oInputs[i].offsetWidth > 0)
        {
          dom_delayedFocus(oInputs[i]);
          j = -1;
          break;
        }
      }
      if (j >= 0)
      {
        oAnchor = document.getElementsByTagName("a")[0];
        if (null != oAnchor)
        {
          dom_delayedFocus(oAnchor);
        }
      }
    }
  }
  catch(err)
  {
  }
} // webguiSetFocus()

function webguiSetDynproScrollPos(x,y)
{
  if (webguiDynpro)
  {
    if (x) webguiDynpro.scrollLeft = x;
    if (y) webguiDynpro.scrollTop = y;
  }
}

function webguiGetDynproScrollPos()
{
  var scrollleft, scrolltop;

  scrollleft = document.getElementById("dynproscrollx");
  if (scrollleft)
    scrollleft.value = webguiDynpro.scrollLeft;

  scrolltop = document.getElementById("dynproscrolly");
  if (scrolltop)
    scrolltop.value = webguiDynpro.scrollTop;
}


function webguiSetUserArea()
{
  //convert back to SAP metric
  var targetObject, parentTargetObject;
  var webguibody;
  var h, w;

  if (webguiIsPopup)
  {
    webguibody = document.getElementsByTagName("body")[0];
    if (webguibody && webguibody.id.substr(0, 10) == "webguiBody")
    {
      for (var par = parent; par.webguiIsPopup && par != par.parent; par = par.parent)
      ;
      if (par && par.webguiIsPopup == false)
      {
        parentTargetObject = par.document.webguiform;
        targetObject = document.webguiform;
        targetObject.elements[ formWebguiUserAreaHeight].value = parentTargetObject.elements[ formWebguiUserAreaHeight].value;
        targetObject.elements[ formWebguiUserAreaWidth].value  = parentTargetObject.elements[ formWebguiUserAreaWidth].value;
      }
    }
  }

  //fontHeight = document.getElementById("FontWidthTester").offsetHeight;
  //fontWidth = document.getElementById("FontWidthTester").offsetWidth;
  //fontListHeight = document.getElementById("FontListTester").offsetHeight;
  //fontListWidth = document.getElementById("FontListTester").offsetWidth;

  //alert(fontHeight + " - " + fontWidth + "    " + fontListHeight + " - " + fontListWidth);

  targetObject = document.webguiform;
  webguibody = document.getElementById("webguiBody");

  var statusbarHeight = 0;

  if(webguiUserArea && targetObject && webguibody)
  {
    if(targetObject.elements[formWebguiUserAreaHeight] &&
      targetObject.elements[formWebguiUserAreaHeight].name.indexOf("~webgui")==0)
    {
      newAreaHeight = document.getElementById("webguiUserArea").offsetHeight - 12;
      if (newAreaHeight<0)
        newAreaHeight = 0;
      targetObject.elements[formWebguiUserAreaHeight].value = newAreaHeight;
    }

    if(targetObject.elements[formWebguiUserAreaWidth] &&
      targetObject.elements[formWebguiUserAreaWidth].name.indexOf("~webgui")==0)
    {
      newAreaWidth = document.getElementById("webguiUserArea").offsetWidth - 12;
      if (newAreaWidth<0)
        newAreaWidth = 0;
      targetObject.elements[formWebguiUserAreaWidth].value = newAreaWidth;
    }

    if (!document.getElementById("~webguiDynproMetric"))
    {
      targetObject.elements[formWebguiUserAreaHeight].value = newAreaHeight / WEBGUIDYNPROROWHEIGHT;
      targetObject.elements[formWebguiUserAreaWidth].value = newAreaWidth / WEBGUIDYNPROCHARWIDTH;
    }
    else
    {
      if (document.getElementById("~webguiDynproMetric").value == METRIC_DYNPRO)
      {
        targetObject.elements[formWebguiUserAreaHeight].value = newAreaHeight / WEBGUIDYNPROROWHEIGHT;
        targetObject.elements[formWebguiUserAreaWidth].value = newAreaWidth / WEBGUIDYNPROCHARWIDTH;
      }
        }
    }
}

function webguiGetAbsScreenPos(element)
{
  var vParent,parentToFind,scrolledTop,scrolledLeft,topPos,leftPos,insidewebguiDynpro;
  var webguiToolbar = document.getElementById("webguiCUA");

  if (webguiDynpro)
  {
    parentToFind = webguiDynpro;
    vParent = element;
  }
  else
    return;

  topPos = 0;
  leftPos = 0;
  scrolledLeft = 0;
  scrolledTop = 0;
  element.absTop = 0;
  element.absLeft = 0;
  insidewebguiDynpro = false;

  while (vParent)
  {
    topPos = topPos + vParent.offsetTop;
    leftPos = leftPos + vParent.offsetLeft;
    if (vParent.scrollTop)
      topPos = topPos - vParent.scrollTop;
    if (vParent.scrollLeft)
      leftPos = leftPos - vParent.scrollLeft;
    if (vParent==webguiDynpro)
    {
      insidewebguiDynpro = true;
      break;
    }

    vParent = vParent.offsetParent;
  }

  element.absTop = topPos;
  element.absLeft = leftPos;

        if (webguiToolbar && insidewebguiDynpro)
  {
    topPos = topPos + webguiToolbar.offsetHeight;
    element.absTop = topPos + 10; // +10 webguidynproborder
    element.absLeft = leftPos + 10;
  }
}


// checkNumber - returns true if the string is a valid number, false otherwise.
//               ignores leading and ending spaces.
//
function checkNumber(string)
{
//  var re = /^\s*\d+(\.\d+)?\s*$/;
//  return (string.match(re) == null ? 0 : 1);
  return (String(string.constructor).indexOf("Number") != -1);
}

function adjustRange(fromId, toId, range, max)
{
  if ((checkNumber(from.value)) && ((from.value - range) > 0) && (from.value < max))
    to.value = from.value + range;
}


function labelImageClick(event)
{
  var selectedElement;
  //he.pi crossbrowser 20050214
  var myEvent = new its_event(event);
  myEvent.stopPropagation();

  if (myEvent && (selectedElement = myEvent.target))
  {
    if (selectedElement.parentNode)
      dom_delayedFocus(selectedElement.parentNode);
  }
}







////////////////////////////////////////////////////////////////////////////////
//
//    Open new window / URL
//
//    Constructor wguObjExtWindow
//
////////////////////////////////////////////////////////////////////////////////


function wguObjExtWindow ( in_url, in_name, in_sAttributes, in_boOpenImmediate, in_focusTime, in_loadTime)
{
  var rc = null;

  this.CONST = {
    OPEN_TIME  : 330,        // time until window is opened (if !in_boOpenImmediate)
    FOCUS_TIME : 330,        // time until focus is executed
    LOAD_TIME  : 400         // time that is defined as "load" time
  };

  this.ATTR = {
    FOCUS_TIME : null,
    LOAD_TIME  : null
  }

  this._isValid  = false;

  if (in_url || in_name)
  {
    this._winName  = !!in_name ? in_name : "_blank";
    this._winUrl   = !in_url ? "" : in_url;
    this._winAttr  = (null == in_sAttributes) ? "" : in_sAttributes;

    this._id       = this.CreateUniqueId();
    this._gObjName = [this._id, "Obj"].join("");
    this._window   = null;

    this._onopenStatus = false;                               // for focusing the window onload

    this.ATTR.FOCUS_TIME = (null != in_focusTime) ? parseInt(in_focusTime) : this.CONST.FOCUS_TIME;
    this.ATTR.LOAD_TIME  = (null != in_loadTime)  ? parseInt(in_loadTime)  : this.CONST.LOAD_TIME;

    this._openTimer  = null;
    this._focusTimer = null;
    this._loadTimer  = null;

    eval(["window.", this._gObjName, " = this"].join(""));    // create unique variable

    this._isValid = true;
    rc = this;

    if (!!in_boOpenImmediate)
    {
      this.Open();
    }
    else
    {
      this._openTimer = setTimeout(["window.", this._gObjName, ".Open()"].join(""), this.CONST.OPEN_TIME);
    }
  } // if (in_url)

  return rc;
} // wguObjExtWindow()


wguObjExtWindow.prototype.IsValid = function ()
{
  return this._isValid;
} // wguObjExtWindow.IsValid()


wguObjExtWindow.prototype.CreateUniqueId = function ()
{
  var t = new Date(),
      s = ["wguObjExtWindow", parseInt(Math.random()*10000), t.getTime()].join("_");
  return s;
} // wguObjExtWindow.CreateUniqueId()


wguObjExtWindow.prototype.Open = function ()
{
  var rc = null;

  if (this.IsValid())
  {
    var timer = this._openTimer;
    if (timer != null) clearTimeout(timer);
    this._openTimer = null;

    this._window = window.open(this._winUrl, this._winName, this._winAttr);
    if (null != this._window)
    {
      this._focusTimer = setTimeout(["window.", this._gObjName, ".FocusDelayedOnOpen()"].join(""), this.ATTR.FOCUS_TIME);
      this._onopenStatus = true;
    }
    rc = this;
  }

  return rc;

} // wguObjExtWindow.Open()


wguObjExtWindow.prototype.Close = function ()
{
  var rc = null;

  if (this.IsValid())
  {
    var timer = this._openTimer;
    if (timer != null) clearTimeout(timer);
    this._openTimer = null;
    timer = this._focusTimer;
    if (timer != null) clearTimeout(timer);
    this._focusTimer = null;
    timer = this._loadTimer;
    if (timer != null) clearTimeout(timer);
    this._loadTimer = null;

    if (null == this._window && !this._window.closed)
    {
      this._window = window.open(this._winUrl, this._winName);
      this._window.close();
    }

    rc = this;
  }

  return rc;
} // wguObjExtWindow.Close()


/* Used to focus the external window directly */
wguObjExtWindow.prototype.Focus = function ()
{
  var rc = null;

  if (this.IsValid())
  {
    var timer = this._focusTimer;
    if (timer != null) clearTimeout(timer);
    this._focusTimer = null;

    if (null != this._window && !this._window.closed)
    {
      dom_delayedFocus(this._window);
    }

    rc = this;
  }

  return rc;
} // wguObjExtWindow.Focus()


/* Used (only) to focus the external window after opening */
wguObjExtWindow.prototype.FocusDelayedOnOpen = function ( in_boTimerStarted )
{
  var rc = null;

  if (this.IsValid())
  {
    var timer = this._focusTimer;
    if (timer != null) clearTimeout(timer);

    time = this._loadTimer;
    if (timer != null) clearTimeout(timer);

    if (in_boTimerStarted)
    {
      this._focusTimer = null;
      if (null != this._window && this._onopenStatus)
      {
        this.Focus();
        this._loadTimer = setTimeout(["window.", this._gObjName, "._onopenStatus = false"].join(""), this.ATTR.LOAD_TIME);
      }
    }
    else
    {
      this._focusTimer = setTimeout(["window.", this._gObjName, ".FocusDelayedOnOpen(true)"].join(""), this.ATTR.FOCUS_TIME);
    }

    rc = this;
  }

  return rc;
} // wguObjExtWindow.DelayedFocus()




////////////////////////////////////////////////////////////////////////////////
//
//    Raster layout for BIDI support
//
//    Constructor wguObjRaster ( in_htmlCnt, in_dir )
//                    with in_htmlCnt   parent container
//                         in_dir       direction ("ltr" or "rtl")
//
////////////////////////////////////////////////////////////////////////////////




/*******************************************************************@@
 * PosDim Object
 * Object that holds the position and dimension of an UI object
 *        { X position, Y position, Width, Height }
 *
 ********************************************************************/



function wguObjPosDim ( in_x, in_y, in_w, in_h )
{
  // public attributes

  this.isValid  = false;
  this.isPosDim = true;

  this.x = in_x;
  this.y = in_y;
  this.w = in_w;
  this.h = in_h;

  this.isValid = true;

} // wguObjPosDim() Constructor







/*******************************************************************@@
 * Raster Object
 * "Manages" child containers on parent container
 *           wguObjRasterChild   wguObjRasterParent
 *
 ********************************************************************/



function wguObjRaster ( in_htmlCnt, in_dir )
{
  // public attributes

  this.isValid  = false;
  this.isRaster = true;

  // private attributes

  this.CONST = {
    DIR : { LTR : 0, RTL : 1 }
  };

  if (null != in_htmlCnt)
  {
    this._dir               = ("rtl" == in_dir || this.CONST.DIR.RTL == in_dir) ? this.CONST.DIR.RTL : this.CONST.DIR.LTR;

    this._htmlContainer     = in_htmlCnt;
    this._oRasterContainer  = new wguObjRasterParent(in_htmlCnt);
    if (this._oRasterContainer.IsValid())
    {
      this._aRasterChilds   = null;   // new Array();

      this.isValid = true;
    }
  }
} // wguObjRaster() Constructor


/**************************************************************
 *
 * Get Routines
 *
 */


wguObjRaster.prototype.IsValid = function()
{
  return (true == this.isValid);
} // wguObjRaster.IsValid()


wguObjRaster.prototype.IsRaster = function()
{
  return true;
} // wguObjRaster.IsRaster()


wguObjRaster.prototype.GetDirection = function()
{
  var rv = null;
  if (this.isValid)
  {
    rv = this._dir;
  }

  return rv;
} // wguObjRaster.GetDirection()


wguObjRaster.prototype.GetParent = function()
{
  var rv = null;
  if (this.isValid && this._oRasterContainer.isValid)
  {
    rv = this._oRasterContainer;
  }

  return rv;
} // wguObjRaster.GetParent()


wguObjRaster.prototype.GetParentHTMLObject = function()
{
  var rv = null;
  if (this.isValid && this._oRasterContainer.isValid)
  {
    rv = this._oRasterContainer.GetHTMLObject();
  }

  return rv;
} // wguObjRaster.GetParent()


wguObjRaster.prototype.GetChildIndex = function ( in_child )
{
  var rv = null;
  var arr,
      idx, i, l,
      el;

  if (this.isValid && null != in_child && null != (arr = this._aRasterChilds))
  {
    // determine the type of in_child (wether it is an index, an HTML object or a Raster Child object
    if (isNaN(in_child))
    {
      if (in_child.isRasterChild)                     // in_child is a Raster Child object
      {
        if (null == (idx = in_child.GetChildIndex())) // this should not happen ... though ...
        {
          for (i = 0, l = arr.length, idx = null; i < l; i++)
          {
            if (in_child == arr[i][0])
            {
              idx = i;
              break;
            }
          } // for (i)
        }
      }
      else                                            // in_child is an HTML object
      {
        for (i = 0, l = arr.length, idx = null; i < l; i++)
        {
          if (in_child == arr[i][1])
          {
            idx = i;
            break;
          }
        } // for (i)
      }
    }
    else
    {
      idx = in_child;
    }

    rv = idx;
  }

  return rv;

} // wguObjRaster.GetChildIndex()


wguObjRaster.prototype.GetChild = function ( in_idx )
{
  var rv = null;
  var arr;

  if (this.isValid && null != in_idx && null != (arr = this._aRasterChilds))
  {
    rv = arr[idx];
  }
  return rv;
} // wguObjRaster.GetChild()


wguObjRaster.prototype.GetChildHTMLObject = function ( in_idx)
{
  var rv = null;
  var arr;

  if (this.isValid && null != in_idx && null != (arr = this._aRasterChilds) && null != arr[idx])
  {
    rv = arr[idx].GetHTMLObject();
  }

  return rv;
} // wguObjRaster.GetChildHTMLObject()


wguObjRaster.prototype.GetChildXPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetXPos();
  }

  return rv;
} // wguObjRaster.GetChildXPos()


wguObjRaster.prototype.GetChildLeftPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetLeftPos();
  }

  return rv;
} // wguObjRaster.GetChildLeftPos()


wguObjRaster.prototype.GetChildYPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetYPos();
  }

  return rv;
} // wguObjRaster.GetChildYPos()


wguObjRaster.prototype.GetChildTopPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetTopPos();
  }

  return rv;
} // wguObjRaster.GetChildTopPos()


wguObjRaster.prototype.GetChildWidth = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetWidth();
  }

  return rv;
} // wguObjRaster.GetChildWidth()


wguObjRaster.prototype.GetChildHeight = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetHeight();
  }

  return rv;
} // wguObjRaster.GetChildHeight()


wguObjRaster.prototype.GetChildPosDim = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.GetPosDim();
  }

  return rv;
} // wguObjRaster.GetChildWidth()



/**************************************************************
 *
 * Set Routines
 *
 */


wguObjRaster.prototype.AddChild = function ( in_htmlChild, in_objChild )
{
  var rv = null;
  var arr, idx, el;

  if (this.isValid && null != in_htmlChild)
  {
    if (null == (arr = this._aRasterChilds))
    {
      arr = this._aRasterChilds = new Array();
    }
    if (null != arr)
    {
      idx = arr.length;
      if (null != (el = new wguObjRasterChild(in_htmlChild, in_objChild, this, idx)))
      {
        if (null != (arr[idx] = new Array(el, in_htmlChild)))
          rv = el;
      }
    }
  }

  return rv;

} // wguObjRaster.AddChild()


wguObjRaster.prototype.RemoveChild = function ( in_child )
{
  var rc = false;
  var arr,
      idx, i, l,
      el;

  if (this.isValid && null != in_child && null != (arr = this._aRasterChilds))
  {
    // determine the type of in_child (wether it is an index, an HTML object or a Raster Child object
    if (isNaN(in_child))
    {
      if (in_child.isRasterChild)                     // in_child is a Raster Child object
      {
        if (null == (idx = in_child.GetChildIndex())) // this should not happen ... though ...
        {
        for (i = 0, l = arr.length, idx = null; i < l; i++)
        {
          if (in_child == arr[i][0])
          {
            idx = i;
            break;
          }
        } // for (i)
        }
      }
      else                                            // in_child is an HTML object
      {
        for (i = 0, l = arr.length, idx = null; i < l; i++)
        {
          if (in_child == arr[i][1])
          {
            idx = i;
            break;
          }
        } // for (i)
      }
    }
    else
    {
      idx = in_child;
    }

    if (null != idx)
    {
      arr[idx][0] = null;
      arr[idx]    = null;

      rc = true;    // child successfully removed
    }
  }

  return rc;

} // wguObjRaster.IsValid()


wguObjRaster.prototype.SetChildXPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetXPos();
  }

  return rv;
} // wguObjRaster.SetChildXPos()


wguObjRaster.prototype.SetChildLeftPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetChildLeftPos();
  }

  return rv;
} // wguObjRaster.SetChildLeftPos()


wguObjRaster.prototype.SetChildYPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetYPos();
  }

  return rv;
} // wguObjRaster.SetChildYPos()


wguObjRaster.prototype.SetChildLeftPos = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetLeftPos();
  }

  return rv;
} // wguObjRaster.SetChildLeftPos()


wguObjRaster.prototype.SetChildWidth = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetWidth();
  }

  return rv;
} // wguObjRaster.SetChildWidth()


wguObjRaster.prototype.SetChildHeight = function ( in_idx )
{
  var rv = null;
  var child;

  if (this.isValid && null != in_idx && null != (child = this.GetChild(in_idx)))
  {
    rv = child.SetHeight();
  }

  return rv;
} // wguObjRaster.SetChildHeight()




/*******************************************************************@@
 * Raster Parent Object
 * Parent container
 *
 ********************************************************************/



function wguObjRasterParent ( in_htmlCnt, in_rasterObj )
{
  // public attributes

  this.isValid = false;
  this.isRasterParent = true;

  // private attributes

  if (null != in_htmlCnt)
  {
    this._htmlContainer = in_htmlCnt;
    this._raster        = in_rasterObj;

    this.isValid = true;
  }
} // wguObjRasterParent() Constructor



wguObjRasterParent.prototype.IsValid = function()
{
  return (true == this.isValid);

} // wguObjRasterParent.IsValid()


wguObjRasterParent.prototype.IsRasterParent = function()
{
  return true;

} // wguObjRasterParent.IsRasterParent()


wguObjRasterParent.prototype.GetHTMLObject = function()
{
  var rv = null;

  if (this.isValid)
  {
    rv = this._htmlContainer;
  }

  return rv;

} // wguObjRasterParent.GetHTMLObject()


wguObjRasterParent.prototype.GetWidth = function()
{
  var rv = null,
      el;

  if (this.isValid && null != (el = this._htmlContainer))
  {
    rv = el.clientWidth;
  }

  return rv;

} // wguObjRasterParent.GetWidth()


wguObjRasterParent.prototype.GetHeight = function()
{
  var rv = null,
      el;

  if (this.isValid && null != (el = this._htmlContainer))
  {
    rv = el.clientHeight;
  }

  return rv;

} // wguObjRasterParent.GetHeight()







/*******************************************************************@@
 * Raster Child Object
 * Child container
 *
 ********************************************************************/


function wguObjRasterChild ( in_htmlObjChild, in_objChild, in_raster, in_idx )
{
  // public attributes

  this.isValid = false;
  this.isRasterChild = true;

  // private attributes

  if (null != in_htmlObjChild)
  {
    this._htmlObj   = in_htmlObjChild;
    this._custObj   = in_objChild;
    this._rasterObj = in_raster;
    this._childidx  = in_idx;

    if (null != in_raster)
    {
      this._parent        = in_raster.GetParent();
      this._parentHtmlObj = in_raster.GetParentHTMLObject();
    }

    this.isValid = true;
  }
} // wguObjRasterParent() Constructor



/**************************************************************
 *
 * Get Routines
 *
 */


wguObjRasterChild.prototype.IsValid = function()
{
  return (true == this.isValid);
} // wguObjRasterChild.IsValid()

wguObjRasterChild.prototype.IsRasterChild = function()
{
  return true;
} // wguObjRasterChild.IsRasterChild()


wguObjRasterChild.prototype.GetHTMLObject = function()
{
  return (this.isValid) ? this._htmlObj : null;
} // wguObjRasterChild.GetHTMLObject()


wguObjRasterChild.prototype.GetCustomObject = function()
{
  return (this.isValid) ? this._custObj : null;
} // wguObjRasterChild.GetCustomObject()


wguObjRasterChild.prototype.GetChildIndex = function()
{
  return (this.isValid) ? this._childidx : null;
} // wguObjRasterChild.GetChildIndex()


wguObjRasterChild.prototype.GetXPos = function()                                                   // x position dependend on dir
{
  var rv = null;
  var r, dir,
      wp, wc;

  if (this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    dir = r.GetDirection();
    if (dir == r.CONST.DIR.LTR)
    {
      rv = this._htmlObj.offsetLeft;
    }
    else
    {
      wp  = this._parent.GetWidth();
      wc  = this._htmlObj.offsetWidth;
      rv = wp - (this._htmlObj.offsetLeft + wc);
    }
  }

  return rv;
} // wguObjRasterChild.GetXPos()


wguObjRasterChild.prototype.GetLeftPos = function()                                                // x position independend on dir, left
{
  return (this.isValid && null != this._htmlObj) ? this._htmlObj.offsetLeft : null;
} // wguObjRasterChild.GetLeftPos()


wguObjRasterChild.prototype.GetYPos = function()                                                   // y position dependend on dir
{
  return (this.isValid && null != this._htmlObj) ? this._htmlObj.offsetTop : null;
} // wguObjRasterChild.GetYPos()


wguObjRasterChild.prototype.GetTopPos = function()
{
  return (this.isValid && null != this._htmlObj) ? this._htmlObj.offsetTop : null;
} // wguObjRasterChild.GetTopPos()


wguObjRasterChild.prototype.GetWidth = function()
{
  return (this.isValid && null != this._htmlObj) ? this._htmlObj.offsetWidth : null;
} // wguObjRasterChild.GetWidth()


wguObjRasterChild.prototype.GetHeight = function()
{
  return (this.isValid && null != this._htmlObj) ? this._htmlObj.offsetHeight : null;
} // wguObjRasterChild.GetHeight()


wguObjRasterChild.prototype.GetPosDim = function()
{
  var rv = null,
      x, y, w, h;

  if (this.isValid)
  {
    x = this.GetXPos();
    y = this.GetYPos();
    w = this.GetWidth();
    h = this.GetHeight();
    rv = new Array(x, y, w, h);
//    rv = {this.GetXPos(), this.GetYPos(), this.GetWidth(), this.GetHeight()};
  }

  return rv;
} // wguObjRasterChild.GetPosDim()





/**************************************************************
 *
 * Set Routines
 *
 */



wguObjRasterChild.prototype.SetXPos = function ( in_x )                                            // x position dependend on dir
{
  var rc;
  var r, dir, x;

  if (null != in_x && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    dir = r.GetDirection();
    if (dir == r.CONST.DIR.LTR)
    {
      x = in_x;
    }
    else
    {
      wp = this._parent.GetWidth();
      wc = this._htmlObj.offsetWidth;
      x  = wp - (in_x + wc);
    }
    this._htmlObj.style.left = x + "px";
    rc = true;
  }
  else
    rc = false;

  return rc;
} // wguObjRasterChild.SetXPos()


wguObjRasterChild.prototype.SetLeftPos = function ( in_x )                                         // x position independend on dir, left
{
  var rc;
  var r;

  if (null != in_x && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    this._htmlObj.style.left = in_x + "px";
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.SetLeftPos()


wguObjRasterChild.prototype.SetYPos = function ( in_y )                                            // y position dependend ...
{
  var rc;
  var r;

  if (null != in_y && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    this._htmlObj.style.top = in_y + "px";
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.GetXPos()


wguObjRasterChild.prototype.SetTopPos = function ( in_y )                                          // y position independend ..., top
{
  var rc;
  var r;

  if (null != in_y && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    this._htmlObj.style.top = in_y + "px";
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.SetTopPos()


wguObjRasterChild.prototype.SetWidth = function ( in_w, in_strdim )
{
  var rc;
  var r;

  if (null != in_w && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    this._htmlObj.style.width = in_w + in_strdim;
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.SetWidth()


wguObjRasterChild.prototype.SetHeight = function ( in_h, in_strdim )
{
  var rc;
  var r;

  if (null != in_h && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    this._htmlObj.style.height = in_h + in_strdim;
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.SetWidth()


wguObjRasterChild.prototype.SetPosDim = function ( in_oPosDim, in_strdim )
{
  var rc;
  var r;

  if (null != in_oPosDim && this.isValid && null != this._htmlObj && null != (r = this._rasterObj))
  {
    if (null != in_oPosDim[2]) this._htmlObj.style.width  = in_oPosDim[2] + in_strdim;
    if (null != in_oPosDim[3]) this._htmlObj.style.height = in_oPosDim[3] + in_strdim;
    if (null != in_oPosDim[0]) this.SetXPos(in_oPosDim[0]);
    if (null != in_oPosDim[1]) this._htmlObj.style.top    = in_oPosDim[1] + in_strdim;
    rc = true;
  }
  else rc = false;

  return rc;
} // wguObjRasterChild.SetPosDim()
