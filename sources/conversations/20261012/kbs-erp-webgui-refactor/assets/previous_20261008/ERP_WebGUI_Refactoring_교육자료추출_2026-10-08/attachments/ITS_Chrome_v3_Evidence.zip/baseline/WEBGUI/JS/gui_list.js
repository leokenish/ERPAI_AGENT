function webguiListDoDblClick(e)
{
  if (!webguiIsActive() || in_webguiSetFocus)
    return;

  if (document.selection)
    document.selection.empty();


  var eventOffsetX = 0;
  var elem;

  if (e.srcElement)
  {
    elem = e.srcElement;
    if (elem.tagName == "IMG" || elem.tagName == "A")
      elem = elem.parentElement;
  }
  else
  {
    elem = e.originalTarget;
    if (elem.tagName == "IMG")
      elem = elem.parentNode;
  }
  eventOffsetX = e.clientX - elem.offsetLeft;

  var listCharWidth = webguiFontWidth;
  if ( elem.tagName == "TD" )
  {
    if (!!webguiSelectedElementOld)
      webguiSelectedElementOld.className = webguiSelectedElementOld.webguiOldClassName;

    elem.webguiOldClassName = elem.className;
    var classname = elem.className.split(" ");
    if (classname[0].search(/Selected/i) < 0)
    {
      classname[0] += "Selected";
      elem.className = classname.join(" ");
    }
  }
  if (elem.getAttribute("colspan") && elem.innerHTML.indexOf("<") == -1)
  {
    elem.innerHTML = "<span class=\'"  + elem.className + "\'>" + elem.innerHTML + "</span>";
    listCharWidth = elem.firstChild.offsetWidth/elem.getAttribute("colspan");
  }

  id = webguiListElemId(elem);

  targetObject = getMainWindow().document.webguiform;
  targetObject.elements[formControlIdx].value = "~list" ;
  targetObject.elements[formEventIdx].value = "DblClick";
  targetObject.elements[formEventPrmIdx].name = "objid" ;
  targetObject.elements[formEventPrmIdx].value = id ;
  targetObject.elements[formWebguiCursorObj].value = id;
  targetObject.elements[formWebguiCursorCol].value = Math.floor(eventOffsetX / listCharWidth);
  submitForm();
}

function webguiDoListKeyDown(_event)
{
//  _event = replaceEvent(_event);

  switch (_event.keyCode)
  {
    case 33:
      if (typeof(document.getElementById("~listVscrollBarRange") != "undefined"))
        raiseEvent("~list", "PrevPage");
      break;
    case 34:
      if (typeof(document.getElementById("~listVscrollBarRange") != "undefined"))
        raiseEvent("~list", "NextPage");
      break;
    case 35:
      if (_event.ctrlKey && typeof(document.getElementById("~listVscrollBarRange") != "undefined"))
        raiseEvent("~list", "LastPage");
      break;
    case 36:
      if (_event.ctrlKey && typeof(document.getElementById("~listVscrollBarRange") != "undefined"))
        raiseEvent("~list", "topPage");
      break;
    default:
      break;
  }
}

function webguiListElemId(element)
{
  var
    id = "";

  if (element)
  {
    if(element.tagName == "IMG" || element.tagName == "A")
    {
      if(element.previousSibling)
        element = element.previousSibling;

      if(element.tagName == "INPUT")
        id = element.name;
      else
      {
        if (element.tagName == "IMG" && element.id == "")
          id = element.parentNode.id;
        else
          id = element.id;
      }
    }
    else
      id = element.id;
  }

  return(id);
}

function webguiGetListCursorPosition(selectedElement, thisEvent)
{
    var targetObject = getMainWindow().document.webguiform;
    // record clicked character position
    targetObject.elements[formWebguiCursorObj].value = webguiListElemId(selectedElement);

    if (null != thisEvent)
    {
      thisEvent.provideOffsetXY();
      targetObject.elements[formWebguiCursorCol].value = Math.floor(thisEvent.offsetX / webguiFontWidth);
    }
    else
    {
      targetObject.elements[formWebguiCursorCol].value = 1;
    }
}

function webguiSelectListElement(selectedElement, thisEvent)
{
    var targetObject = getMainWindow().document.webguiform;
    webguiGetListCursorPosition(selectedElement, thisEvent);
    webguiFocusField = targetObject.elements[formFocusfieldIdx].value = selectedElement.id ;

    webguiSaveFocus(new webguiFocusObj(1, selectedElement));

    if (selectedElement.getAttribute("ct") == "d_ListCheckBox")
    {
      if(selectedElement.getAttribute("checked") != null)
      {
        checked = selectedElement.getAttribute("checked");
        selectedElement = selectedElement.previousSibling;
        if(checked==1)
          selectedElement.value = "X";
        else
          selectedElement.value = " ";
      }
    }

    if (!!selectedElement.getAttribute("ct"))
    {
      webguiSetSelClassOnDynproElement(selectedElement);
    }
}

function webguiIsListElement(el)
{
  if (!!el && el.getAttribute("ct") != "")
  {
    if (el.getAttribute("ct").search(/d_List/) != -1 )
    {
      return true;
    }
  }
  return false;
}
