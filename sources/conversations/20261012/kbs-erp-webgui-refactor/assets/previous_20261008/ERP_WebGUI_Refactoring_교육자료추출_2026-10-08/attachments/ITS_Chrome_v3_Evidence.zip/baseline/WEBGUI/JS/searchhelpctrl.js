//
// The Javascript part used for the search help control
//

var elemHitlist;
var elemHitlistHeader;

var totalHeight = 0;
var totalWidth = 0;

var shCurrentHitlistCell = '';
var shVisibleRows = 0;
var isVSliderVisible = false;
var shHOffset = 0;
var shResultFieldRowIdx = 0;

function searchhelpDoNothing(fieldname, e)
{
}

function initSH()
{
    window.webguiEnableSearchhelpButton = searchhelpDoNothing;
    if ( shdisabled )
        parent.webguiCreateBusyDiv(1);
    shOnFindExpression ( '~sh_find' );
    elemHitlist = document.getElementById('SHHitlist');
    if (elemHitlist)
        elemHitlist.onscroll = scrollHitList;
    if (shMultipleSelections)
        shMakeSelections();
    shAdjustSeloptimgs();
    window.wgu_global_eventhandler.RegisterHandler( "keydown", "~sh", 950, shKeyDown );
    var control = document.getElementById(shDivId);
    if (control.parentNode.parentNode.offsetWidth < parseInt ( control.style.width))
        control.style.width = control.parentElement.parentElement.offsetWidth + 'px';
    totalHeight = control.offsetHeight;
    totalWidth  = control.offsetWidth -20 ;
    shSizeIt();
    arrMenu_FM = arrMenu_SH;
    if (shDialogs != null)
    {
        arrMenu_SH_1 = new Array( 6*shDialogs.length);
        var i;
        for ( i = 0; i < shDialogs.length; i++)
        {
            arrMenu_SH_1[6*i] = shDialogs[i][1];
            arrMenu_SH_1[6+i + 1] = "JshSwitchSH( " + shDialogs[i][0] +")";

            arrMenu_SH_1[6*i + 2] = 'STD';
            arrMenu_SH_1[6*i + 3] = '1/' + (i+1);
            if (shSearchhelpUsed == shDialogs[i][0])
                arrMenu_SH_1[6*i + 4] =  'CHK';
            else
                arrMenu_SH_1[6*i + 4] =  '-';
            arrMenu_SH_1[6*i + 5] = "JshSwitchSH( " + shDialogs[i][0] +")";
        }

        var shPopupWindow = parent.document.getElementById( this.name );
        var seloptsDialog = document.getElementById( 'SHSeloptDialogTable' );
        if (shPopupWindow && seloptsDialog)
        {
            if (parseInt(shPopupWindow.style.width) < seloptsDialog.clientWidth)
                shPopupWindow.style.width = String( seloptsDialog.clientWidth + 16 ) + 'px';
        }
    }
}

var shHitlistWidth = -1;
var shHitlistVisibleWidth;

function shResize( ResizePopup, execute )
{
    if (true != execute)
        ResizePopup.GetPopupFrame().contentWindow.shResize( ResizePopup, true );
    else
    {
        var size = ResizePopup.GetSize();
        try
        {
            document.getElementById( shDivId + 'width' ).value = size.width;
            document.getElementById( shDivId + 'height' ).value = size.height;
            totalHeight = size.height - 24 ;  // titlebar
            totalWidth  = size.width - 20;
            shSizeIt();
            if (shVisibleRows > 0)
            {
                makeHitList();
                hitlistVScrollPos( shSelectionOffset, true );
                if ( 0 < shHOffset)
                    hitlistHScrollPos( shHitListHOffset, true);
            }
        }
        catch (e){}
    }
}

function shSizeIt()
{
    var seloptsDialogHeight = 0;
    var criteriaVisibleHeight = 0;

    var seloptsDialog = document.getElementById( 'SHSeloptDialogTable' );
    if (seloptsDialog)
    {
        seloptsDialogHeight = seloptsDialog.offsetHeight;
        document.getElementById( 'searchHelpCriteria' ).style.height =
            seloptsDialogHeight.toString() + 'px';
    }

    var oShCriteriaToggler = document.getElementById( 'SHSearchCriteriaVisible');
    if (oShCriteriaToggler)
        criteriaVisibleHeight = oShCriteriaToggler.offsetHeight;

    if (shNewHitlist)
    {
        var hitList = document.getElementById( 'SHHitlist' );
        if (hitList)
        {
            var hasHorizontalScroller = false;
            var hasVerticalScroller   = false;
            var hitListResultHeader   = document.getElementById( 'searchHelpResultHeader' );
            var hitListHeader         = document.getElementById( 'SHHitlistHeader' );
            var shresultBodyTable     = document.getElementById( 'SearchHelpResultBodyTable' );
            var shresultBody          = document.getElementById( 'SearchHelpResultBody' );
            var shresultBodyX         = document.getElementById( 'SearchHelpResultBodyX' );
            var oSCS                  = document.getElementById( 'SearchHelpResultBody_scrollContainerStructure' );

            var hitlistToolbarHeight  = document.getElementById( 'SHHitlistToolbar' ).offsetHeight;
            var hitlistHeaderHeight   = hitListHeader.offsetHeight;
            var hitListHeight         =
                totalHeight - seloptsDialogHeight - criteriaVisibleHeight - hitlistToolbarHeight - hitlistHeaderHeight - 16;
            var maxHitlistRows        = parseInt (hitListHeight/20);

            if (hitListHeight <= 0)
                return;

            document.getElementById( 'SHHitlistToolbarTable' ).style.width = (totalWidth - 8) + 'px';

            shVisibleRows = (hitlistrowcount < maxHitlistRows) ? hitlistrowcount : maxHitlistRows - 1;
            shVisibleRows = (shVisibleRows < 0 ) ? 0 : shVisibleRows;
            hitListHeight = shVisibleRows * 20;

            hasVerticalScroller   = ((hitlistrowcount > shVisibleRows) && (shVisibleRows > 1)) ? true : false;
            shHitlistVisibleWidth = totalWidth - 6 - 16 * hasVerticalScroller;

            if (shHitlistWidth == -1)
                shHitlistWidth = parseInt (shresultBodyTable.style.width);

            if (shHitlistVisibleWidth < shHitlistWidth)
                hasHorizontalScroller = true;

            hitListHeader.style.width       = shHitlistVisibleWidth  + 'px';
            shresultBodyTable.style.width   = shHitlistVisibleWidth  + 'px';
            hitListResultHeader.style.width = shHitlistVisibleWidth  + 'px';
            shresultBody.style.width        = (shHitlistVisibleWidth +  16) + 'px';
            hitList.style.width             = (shHitlistVisibleWidth +  16) + 'px';

            if (sh_SearchHelpResultBody_vScrollHandler)
            {
                var scrollArea = document.getElementById( 'SearchHelpResultBody_scrollArea' );

                inflate_vertScrollbar( shVisibleRows );
                if (scrollArea)
                    scrollArea.style.width = shHitlistVisibleWidth + 'px';
                if (shresultBodyX.clientWidth < shresultBodyTable.clientWidth)
                    shresultBodyX.style.width = shresultBodyTable.style.width;
            }

            if (hasHorizontalScroller)
            {
                inflate_horScrollbar( shHitlistWidth, shHitlistVisibleWidth );
                shresultBodyX.style.width = shHitlistWidth;
                hitListHeight = (shVisibleRows + 1) * 20;
            }
            else if (shVisibleRows)
            {
                deflate_horScrollbar();
            }

            if (oSCS)
            {
                var scrollAreaTD = document.getElementById( 'SearchHelpResultBody_scrollAreaTD' );

                oSCS.style.height          = hitListHeight + 'px';
                shresultBody.style.height  = hitListHeight + 'px';
                hitList.style.height       = hitListHeight + 'px';
                scrollAreaTD.style.height  = hitListHeight + 'px';
                hitList.style.height       = hitListHeight + 'px';

                hitListHeight = (hasHorizontalScroller) ? hitListHeight - 16 : hitListHeight;
                shresultBodyX.style.height = hitListHeight + 'px';

                oSCS.style.width          = (shHitlistVisibleWidth + 16) + 'px';
                scrollAreaTD.style.width  = shHitlistVisibleWidth + 'px';
            }

        }
        _CFWExeconFinalSizeHandlers();
    }
    else                // old style hit list
    {
        if (document.getElementById( 'SHHitlist' ))
        {
            var hitlistToolbarHeight = document.getElementById( 'SHHitlistToolbar').offsetHeight;
            var hitlistHeaderHeight = document.getElementById( 'SHHitlistHeader').offsetHeight;
            var hitListHeight =
                totalHeight - criteriaVisibleHeight - hitlistToolbarHeight -hitlistHeaderHeight - 20;
            if (document.getElementById('searchHelpCriteria'))
                if (document.getElementById('searchHelpCriteria').style.display == 'block')
                    hitListHeight =  hitListHeight - seloptsDialogHeight + 10;
            document.getElementById( 'SHHitlist' ).style.height =
                hitListHeight.toString() + 'px';
            // Do we have a scroll bar?
            if ( document.getElementById( 'SHHitlist' ).offsetHeight <
                document.getElementById( 'SearchHelpResultBodyX' ).offsetHeight)
            {
                document.getElementById( 'SHHitlistHeader').style.width =
                    (document.getElementById( 'SHHitlist').offsetWidth - 16 ).toString() + 'px';
            }
        }
    }
}

function inflate_vertScrollbar( VisibleRows )
{
    var sbt = document.getElementById( 'SearchHelpResultBody_vertScrollbar' );

    if (sbt.childNodes[0].style.display == 'none')
    {// *** inflate previous deflated vertical scrollbar
        sbt.childNodes[0].style.width   = '16px';
        sbt.childNodes[0].style.display = '';
    }

    sh_SearchHelpResultBody_vScrollHandler.visRange = VisibleRows;
}

function inflate_horScrollbar( HitlistWidth, HitlistVisibleWidth )
{
    var sbt = document.getElementById( 'SearchHelpResultBody_horScrollbar' );

    if (sbt.style.display == 'none')
    {// *** inflate previous deflated horizontal scrollbar
        sbt.style.height  = '16px';
        sbt.style.display = '';
        sbt.style.visibility = 'visible';
    }

    sh_SearchHelpResultBody_hScrollHandler.scrollbarObj.show();
    // sh_SearchHelpResultBody_hScrollHandler.totalRange = HitlistWidth;
    // sh_SearchHelpResultBody_hScrollHandler.visRange   = HitlistVisibleWidth;
}

function deflate_horScrollbar( )
{
    var sbt = document.getElementById( 'SearchHelpResultBody_horScrollbar' );

    if (sbt)
    {// *** deflate horizontal scrollbar
        var parent = sbt.parentNode;

        for ( var i = 0; i < parent.childNodes.length; i++ )
        {
            if (typeof parent.childNodes[i].style != "undefined")
            {
                parent.childNodes[i].style.height  = '0px';
                parent.childNodes[i].style.display = 'none';
            }
        }
    }
    parent.style.height  = '0px';
    parent.style.display = 'none';
    hitlistHScrollPos(0, false);

    sh_SearchHelpResultBody_hScrollHandler.totalRange = 0;
    sh_SearchHelpResultBody_hScrollHandler.visRange   = 0;
    sh_SearchHelpResultBody_hScrollHandler.currPos    = 0;
}

function scrollHitList()
{
    if (!elemHitlistHeader)
        elemHitlistHeader = document.getElementById('SHHitlistHeader');
    if (elemHitlistHeader)
        elemHitlistHeader.scrollLeft = elemHitlist.scrollLeft;
}

function shToggleCriteria(fieldname)
{
    var
        shCriteria = document.getElementById("searchHelpCriteria"),
        shExp = document.getElementById("searchHelpExp"),
        form = eval('document.webguiform');

    if (shCriteria)
        if (shCriteria.style.display == "none")
        {
            shCriteria.style.display = "block";
            if (shExp)
                shExp.className = "SearchHelpExpOpen";
                if (form && fieldname && form.elements[fieldname])
                {
                    form.elements[fieldname].value = "1";
                }
        }
        else
        {
            shCriteria.style.display = "none";
            if (shExp)
                  shExp.className = "SearchHelpExpClose";
            if (form && fieldname && form.elements[fieldname])
            {
                form.elements[fieldname].value = "0";
            }
        }
    shSizeIt();
    if (shNewHitlist && (shVisibleRows > 0))
    {
        makeHitList();
        var frickelspan = document.getElementById( 'SearchHelpResultBody_scrollArea');
        if (frickelspan)
          frickelspan.style.height = "100%";
        hitlistVScrollPos( shSelectionOffset, true );
    }
    return false;
}

// Override of the function defined in generator.js

function shRaiseSearchhelp(fieldId, action)
{
    var container = null;
    if (action == 1)
    {
        var container = document.getElementById( 'SHSelopts');
        if (container && container.getAttribute( 'sh_control'))
        {
            if (parseInt(fieldId) == fieldId)
            {
                var new_id = 200 + parseInt(fieldId) ;
                webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                    "id=" + container.getAttribute('sh_mid') +
                    "&dialog=" + container.getAttribute('sh_dialog') +
                    "&button_id=" + new_id +
                    "&opt=X",
                    '_parent');
            }
            if (fieldId.indexOf("shcellr") != 0)
                fieldId = shCurrentHitlistCell;
            if (fieldId.indexOf("shcellr") == 0)     // F1 for a hit list column
            {
                var split = fieldId.split("c");
                var col = 2400 + parseInt(split[split.length - 1]);
                webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                    "id=" + container.getAttribute('sh_mid') +
                    "&dialog=1" +
                    "&button_id=" + col +
                    "&opt=X",
                    '_parent');
            }
        }
    }
    if (action == 3)
    {
        var container = document.getElementById( 'SHSelopts');
        if (container && container.getAttribute( 'sh_control'))
        {
            webguiRaiseEvent(container.getAttribute('sh_control'), 'CloseTab',
                "m_id=" + container.getAttribute('sh_mid') ,
                '_parent');
        }
    }
    if (action == 4)
    {
        if (parseInt(fieldId) == fieldId)
        {
            var container = document.getElementById( 'SHSelopts');
            if (container && container.getAttribute( 'sh_control'))
            {
                webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                    "id=" + container.getAttribute('sh_mid') +
                    "&dialog=" + container.getAttribute('sh_dialog') +
                    "&button_id=" + fieldId +
                    "&opt=X",
                    '_parent');
            }
        }
    }
    if (action == 12)   // technische Info
    {
        var container = document.getElementById( 'SHSelopts');
        if (container && container.getAttribute( 'sh_control'))
        {
            webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                "id=" + container.getAttribute('sh_mid') +
                "&dialog=1&button_id=2601" +
                "&opt=X",
                '_parent');
        }
    }
    if (action == 14)   // personalization
    {
        var container = document.getElementById( 'SHSelopts');
        if (container && container.getAttribute( 'sh_control'))
        {
            webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                "id=" + container.getAttribute('sh_mid') +
                "&dialog=-1&button_id=1105" +
                "&opt=X",
                '_parent');
        }
    }
    if (action == 22)   // download
    {
        var container = document.getElementById( 'SHSelopts');
        if (container && container.getAttribute( 'sh_control'))
        {
            webguiRaiseEvent(container.getAttribute('sh_control'), 'Search',
                "id=" + container.getAttribute('sh_mid') +
                "&dialog=1&button_id=1107" +
                "&opt=X",
                '_parent');
        }
    }
}

function RaiseSHJumpRowEvent(fieldname, controlid)
{
    var ifieldvalue, param;

    ifieldvalue = document.getElementById(fieldname).value;
    param = "jumprow=" + ifieldvalue;

    window.webguiRaiseDataEvent(controlid, 'JumpRow', param, '_parent');
}

function shHilightRow( evt )
{
    var e = new its_event(evt);
    var selectedRow, oldselectedrow, selectedRowIdx, resultTable,
        form = eval('document.webguiform');
    shCurrentHitlistCell = e.target.id;
    updateContextMenu();
    resultTable = document.getElementById('SearchHelpResultBodyTable');
    if (resultTable)
    {
        selectedRow = shTableCellGetTR(e.target);
        if (selectedRow)
        {
            var Row;
            if (shNewHitlist)    // new dynamic hitlist
                Row = selectedRow.getAttribute("shindex");
            else
                Row = selectedRow.getAttribute("row");
            if (Row)
            {
                selectedRowIdx = Row - 1;
                strSelectedRow = Row.toString();
            }
        }
        if (selectedRowIdx >= 0)
        {
            if (!shNewHitlist ||
                ((resultTable.oldselectedRow  >= shSelectionOffset)
                    && (resultTable.oldselectedRow < shSelectionOffset + shVisibleRows)))
            {
                if (resultTable.oldselectedRow >= 0)
                {
                    if (shNewHitlist)
                        oldselectedrow = resultTable.rows[resultTable.oldselectedRow-shSelectionOffset ];
                    else
                        oldselectedrow = resultTable.rows[resultTable.oldselectedRow];
                    if (oldselectedrow)
                    {
                        var oldclassname = oldselectedrow.className;
                        var newclassname = oldclassname.substring(0,(oldclassname.indexOf("Selected")));
                        oldselectedrow.className = newclassname;
                    }
                }
            }

            // global variable
            shResultFieldRowIdx = selectedRowIdx;
            if (form && form.elements["~searchhelpcurrhitlistrow"])
            {
                    form.elements["~searchhelpcurrhitlistrow"].value
                        = selectedRowIdx;
            }
            resultTable.oldselectedRow = selectedRowIdx;
            if (shNewHitlist)
            {
                if (resultTable.rows[selectedRowIdx-shSelectionOffset])
                    resultTable.rows[selectedRowIdx-shSelectionOffset].className += "Selected";
            }
            else
            {
                if (resultTable.rows[selectedRowIdx])
                    resultTable.rows[selectedRowIdx].className += "Selected";
            }
        }
    }
}

function shGetTR(element)
{
    if(!element)
        return(0);

    while(element.nodeName!="TR" && element.nodeName!="TABLE")
        element = element.parentNode;

    if(element.nodeName=="TR")
        return(element);

    return(0);
}

function shSelectAll(evt)
{
    var resultTableBody = document.getElementById("SearchHelpResultBodyTable");
    var ev = new its_event(evt);
    if (resultTableBody)
    {
        var noLines = resultTableBody.rows.length;
        if (noLines > 0)
        {
            shSelected = ":";
            for ( i = 1; i <= hitlistrowcount; i++)
            {
                shSelected = shSelected + i;
                shSelected = shSelected + ":";
            }
            for ( i = 1; i <= noLines; i++)
            {
                if (resultTableBody.rows[i-1].className.indexOf("Selected")==-1)
                    resultTableBody.rows[i-1].className += "Selected";
            }
         }
    }
    try
    {
        document.webguiform.elements[ "~searchhelpselections" ].value = shSelected;
    }
    catch(e){}
    if (ev.valid)
    {
        ev.cancel();
    }
}

function shDeselectAll(evt)
{
    shSelected = ":";
    var resultTableBody = document.getElementById("SearchHelpResultBodyTable");
    var ev = new its_event(evt);
    if (resultTableBody)
    {
        var noLines = resultTableBody.rows.length;
        for ( i = 1; i <= noLines; i++)
            if (resultTableBody.rows[i-1].className.indexOf("Selected") > -1)
                resultTableBody.rows[i-1].className =
                resultTableBody.rows[i-1].className.substring(0,
                    resultTableBody.rows[i-1].className.indexOf("Selected"));
    }
    try
    {
         document.webguiform.elements[ "~searchhelpselections" ].value = shSelected;
    }
    catch(e){}
    if (ev.valid)
    {
        ev.cancel();
    }
}

function shIsSelected( row )
{

    var index = shSelected.indexOf(':' + row + ':');
    if (index != -1)
        return true;
    return false;
}

function shSelectRow(event)
{
    var e = new its_event( event);
    shTR = shGetTR(e.target);
    if(shTR==0 || shTR.rowIndex<0)
        return;
    var entry = ( 1 + shTR.rowIndex + shSelectionOffset) + ':';
    if(shTR.className.indexOf("Selected")==-1)
    {
        shTR.className += "Selected";
        // if the row is not stored in the list
        // then add it to the list of selected rows
        if(shSelected.indexOf(':' + entry)==-1)
            shSelected += entry;
    }
    else
    {
        shTR.className = shTR.className.substring(0, shTR.className.indexOf("Selected"));
        var index = shSelected.indexOf(':' + entry);

        if(index!=-1) // if the row is stored in the list
        {
            index += 1;
            var newShSelected = shSelected.substring(0, index);
            newShSelected += shSelected.substring(index + entry.length);
            shSelected = newShSelected;
        }
    }
    try
    {
        document.webguiform.elements[ "~searchhelpselections" ].value = shSelected;
    }
    catch(e) {}
}

function shMakeSelections()
{
    var index=0;
    var remainingSelected;
    var row;
    var rowobj;

    if(!shSelected)
        return;

    remainingSelected = shSelected.substring(1); //bypass the first ':'
    var resultTable = document.getElementById("SearchHelpResultBodyTable");

    for(;;)
    {
        index = remainingSelected.indexOf(':');
        if (index == -1)
            return;
        row = remainingSelected.substring(0, index);
        remainingSelected = remainingSelected.substring(index + 1);

        if(row=="")
            break;

        row--;
        row -= shSelectionOffset;
        if(row<0)
            continue;

        rowobj = resultTable.rows[row];
        if(!rowobj)
            continue;

        rowobj.className += "Selected";
    }
    try
    {
        document.webguiform.elements[ "~searchhelpselections" ].value = shSelected;
    }
    catch(e) {}
}

function shinputkeyup(FieldID)
{
    var contents = document.getElementById( FieldID);
    if (!contents)
        return;
    var selopt = document.getElementById( "DDSHSELOPTOPT[" + FieldID + "]");
    if (contents.value.length == 0 && selopt)
    {
        selopt.className = "SearchSeloptempty";
        selopt.title = "";
        selopt.setAttribute("set", "");
    }
    var seloptElem = document.getElementById( "SELOPT" + (parseInt(FieldID) - 400) + "[1]");
    if (!seloptElem)
    {
        var form = document.getElementById( 'webguiform' );
        if (form)  // not for the complex dialog
        {
            seloptElem = document.createElement( "input" );
            seloptElem.setAttribute( "selopt", "x" );
            seloptElem.setAttribute( "type", "hidden" );
            seloptElem.setAttribute( "name", "SELOPT" + (parseInt(FieldID) - 400) + "[1]" );
            seloptElem.setAttribute( "id", "SELOPT" + (parseInt(FieldID) - 400) + "[1]" );
            form.appendChild( seloptElem );
        }
    }
    if (contents.value.length == 0 && seloptElem)
    {
        seloptElem.parentNode.removeChild( seloptElem );
    }

    if (contents.value.search(/\*/) == -1 && contents.value.search(/\+/) == -1 )
    {
        if (selopt && selopt.getAttribute("set") != "x")
        {
            if (contents.value.length != 0)
            {
                selopt.className = "SearchSeloptieq";
                selopt.title = shequtooltip;
            }
            if (seloptElem)
                seloptElem.value = "I!EQ!" + contents.value;
        }
        else
            if (seloptElem)
            {
                if (!selopt)
                    seloptElem.value = "I!EQ!" + contents.value;
                seloptElem.value = seloptElem.value.slice(0, 5) + contents.value;
            }
    }
    else
    {
        if (selopt && selopt.getAttribute("set") != "x")
        {
            if (contents.value.length != 0)
            {
                selopt.className = "SearchSelopticp";
                selopt.title = shpattooltip;
            }
            if (seloptElem)
                seloptElem.value = "I!CP!" + contents.value;
        }
        else
            if (seloptElem)
           {
                if (!selopt)
                    seloptElem.value = "I!CP!" + contents.value;
                seloptElem.value = seloptElem.value.slice(0, 5) + contents.value;
            }
     }
}

var activeF4Key = '';

function shOnFocus(FieldID)
{
    var f4key;
    if (activeF4Key.length)
    {
        f4key = document.getElementById( activeF4Key );
        if (f4key)
            f4key.style.display = "none";
    }
    activeF4Key = '';
    if (!FieldID.length)
        return;
    f4key = document.getElementById( "DDSHSELOPTF4[" + FieldID + "]");
    if (f4key)
    {
        f4key.style.display = "inline";
        activeF4Key = "DDSHSELOPTF4[" + FieldID + "]";
    }
}

function shOnBlur()
{
    var f4key;
    if (activeF4Key.length)
    {
        f4key = document.getElementById( activeF4Key );
        if (f4key)
            f4key.style.display = "none";
    }
}


function searchHelpSelect(id)
{
    var line = parseInt(strSelectedRow, 10);
    if (!shNewHitlist)
        line += parseInt( shSelectionOffset, 10) ;
    var opts = 'row=' + line.toString() + '&m_ID=0&Column=0&Description=0&hold=0&destination=1';
    webguiRaiseEvent(id, 'ResultTableSelect', opts, '_parent');
}

function searchHelpUserButtonClick( id, dialog, sh_id, fcode)
{
    var line = parseInt(strSelectedRow, 10) + parseInt( shSelectionOffset, 10) ;
    var opts = 'id=' + sh_id + '&dialog=' + dialog + '&button_id=1106&opt=' + fcode + line.toString();
    webguiRaiseEvent(id, 'Search', opts, '_parent');
}

// The functions for the dynamic hit list

var Scroll_MouseDown=0;

function makeHitList()
{
    if (shSelectionOffset > hitlistrowcount - shVisibleRows)
        shSelectionOffset = hitlistrowcount - shVisibleRows;
    if (shSelectionOffset < 0)
        shSelectionOffset = 0;
    var waiter = document.getElementById( "searchHelpLoadIndicator");
    waiter.style.visibility = "visible";
    var shHitlist = document.getElementById("SearchHelpResultBodyTable");
    if (shHitlist.addEventListener)
    {
        shHitlist.addEventListener('DOMMouseScroll', shHitlistWheel, false);
    }
    var num_rows=shHitlist.rows.length;
    for (var k=0; k < num_rows; k++)
        shHitlist.deleteRow(0);
    var rowsToBuild = shVisibleRows;
    if (rowsToBuild > hitlistrowcount)
        rowsToBuild = hitlistrowcount;

    if (searchHelpFocusField == "DDSHSELOPT-LOW[1]")
    {
      var shHitlistResultTable = document.getElementById("SearchHelpResultBodyTable");
      if (shHitlistResultTable)
      {
        shHitlistResultTable.tabIndex = -1;
        dom_delayedFocus(shHitlistResultTable);
      }
    }

    for (var i = 0; i < rowsToBuild; i++)
    {
        var zeile = shHitlist.insertRow(i);
        zeile.setAttribute( "id", "hlrow" + i );
        zeile.setAttribute( "controlid", sh_mid );
        zeile.setAttribute( "row", i + 1 );
        zeile.setAttribute( "shindex", hl[i][0]);

        if ( (parseInt(hl[i][0]/2)) * 2 == hl[i][0])
            zeile.className="TCCellTextLight";
        else
            zeile.className="TCCellText";

        if (hl[i + shSelectionOffset] == undefined)
        {
            shLoadHits( i + shSelectionOffset, 100, true);
            return;
        }

        zeile.setAttribute("param",
            "row="+hl[i + shSelectionOffset][0]+"&destination=1&hold=0&~responsetype='dynpro'&m_ID="+sh_mid+"&Description='HUGO'&Column='egal'");
        if (!shMultipleSelections)
            if ( String(hl[i + shSelectionOffset][0]) == strSelectedRow)
            {
                if (zeile.className.indexOf("Selected")==-1)
                    zeile.className += "Selected";
                shHitlist.oldselectedRow = hl[i + shSelectionOffset][0] - 1;
            }
        for (var j=1; j <= hitlistcolumns; j++)
        {
            var zelle = document.createElement( "td");
            if (hitListColumnType[ j-1 ] == 'H')
            {
                zelle.className = "ShCellHighlighted";
                zelle.style.fontweight = "bold";
            }
            else
                zelle.className = "ShCell";
            zelle.setAttribute( "style", "overflow:hidden;white-space:nowrap;");
            if (hitListColumnType[ j-1 ] == 'I' || hitListColumnType[ j-1 ] == 'i' )
            {
                var TDImage = document.createElement("img");
                TDImage.src = imageURL + hl[i + shSelectionOffset][j] + '.gif';
                TDImage.alt = '';
                zelle.setAttribute( "id", "shcellr"+i+"c"+j);
                zelle.appendChild( TDImage );
            }
            else
                if (hitListColumnType[ j-1 ] == 'c' || hitListColumnType[ j-1 ] == 'C')
            {
                var TDImage = document.createElement("img");
                if (hl[i + shSelectionOffset][j] == 'X')
                    TDImage.src = checkbboxSelURL;
                else
                    TDImage.src = checkbboxUnselURL;
                TDImage.alt = '';
                zelle.setAttribute( "id", "shcellr"+i+"c"+j);
                zelle.appendChild( TDImage );
            }
            else
            {
                var TDtext = document.createTextNode(hl[i + shSelectionOffset][j]);
                zelle.setAttribute( "id", "shcellr"+i+"c"+j);
                zelle.appendChild( TDtext );
            }
            zelle.style.height = '20px';
            zeile.appendChild( zelle );
        }
    }
    if (shMultipleSelections)
        shMakeSelections();
    waiter.style.visibility = "hidden";
  }

  function hitlistVScrollPos( newPos, updateSlider )
  {
    if (shVisibleRows >= hitlistrowcount)
        return;
    var iNewPos = parseInt(newPos);
    if (iNewPos + shVisibleRows > hitlistrowcount)
        iNewPos = hitlistrowcount - shVisibleRows;
    if (sh_SearchHelpResultBody_vScrollHandler)
      sh_SearchHelpResultBody_vScrollHandler.currPos = iNewPos + 1;

    for (var i = 0; i < shVisibleRows; i++)
    {
        var zeile = document.getElementById( "hlrow" + i );
        if (hl[i + newPos] == undefined)
        {
            shLoadHits( i + iNewPos -50 , 150, false);
            return;
        }
        zeile.setAttribute( "shindex", hl[i + iNewPos][0]);
        zeile.setAttribute("param",
            "row="+ hl[i + iNewPos][0] +"&destination=1&hold=0&~responsetype='dynpro'&m_ID="+sh_mid+"&Description='HUGO'&Column='egal'");
        if ( (parseInt(hl[i + iNewPos][0]/2)) * 2 == hl[i + iNewPos][0])
          zeile.className="TCCellTextLight";
        else
          zeile.className="TCCellText";

        if (shMultipleSelections)
        {
            if (shIsSelected( hl[i + iNewPos][0]))
                if (zeile.className.indexOf("Selected")==-1)
                    zeile.className += "Selected";
        }
        else
        {
             if ( String(hl[i + iNewPos][0]) == strSelectedRow)
                if (zeile.className.indexOf("Selected")==-1)
                {
                    var resultTable = document.getElementById('SearchHelpResultBodyTable');
                    if (resultTable)
                        resultTable.oldselectedRow = hl[i + iNewPos][0] - 1;
                    zeile.className += "Selected";
                }
        }
        for (var j=1; j <= hitlistcolumns; j++)
        {
            var zelle = document.getElementById( "shcellr"+i+"c"+j);
            if (zelle)
            {
                if (hitListColumnType[ j-1 ] == 'I' || hitListColumnType[ j-1 ] == 'i' )
                {
                    zelle.childNodes[0].src = imageURL + hl[i+iNewPos][j] + '.gif';
                    zelle.childNodes[0].style.height = '';
                    zelle.childNodes[0].style.width = '';
                }
                else
                    if (hitListColumnType[ j-1 ] == 'c' || hitListColumnType[ j-1 ] == 'C')
                {
                    if (hl[i+iNewPos][j] == 'X')
                        zelle.childNodes[0].src = checkbboxSelURL;
                    else
                        zelle.childNodes[0].src = checkbboxUnselURL;
                }
                else
                {
                    // Reuse unchanged text only; keep row state, image and load paths intact.
                    // Inspect the live text node, not cached row data (partial reload safe).
                    if (zelle.childNodes[0].nodeValue !== hl[i+iNewPos][j])
                        zelle.childNodes[0].nodeValue = hl[i+iNewPos][j];
                }
            }
        }
    }
    if (updateSlider) // && isVSliderVisible    )
    {
        var sbSlider = document.getElementById("~listVSBSlider");
        if (!!sbSlider)
        {
            var vSliderRange = sbSlider.parentNode; //document.getElementById( '~LISTVscrollBarRange' );
            var newTop =
                (parseInt(vSliderRange.offsetHeight) - parseInt(sbSlider.offsetHeight))/(hitlistrowcount - shVisibleRows)* iNewPos;
            sbSlider.style.top = String ( parseInt( newTop) ) + "px";
        }
    }
  }

  function hitlistHScrollPos( newPos, updateSlider )
  {
    var tableBody = document.getElementById( 'SearchHelpResultBody_scrollArea' );
    var tableHeader = document.getElementById( 'SHHitlistHeader' );
    var hitList = document.getElementById( 'SHHitlistTable' );
    tableBody.style.width = shHitlistVisibleWidth + newPos;
    tableBody.style.left = -1 * newPos;
    tableHeader.style.width = shHitlistVisibleWidth + newPos;
    tableHeader.style.left = -1 * newPos;
    if (updateSlider)
    {
      var sbSlider = document.getElementById("~listHSBSlider");
      var newLeft =
         ((100 - (100 * shHitlistVisibleWidth)/shHitlistWidth) * newPos) / (shHitlistWidth - shHitlistVisibleWidth);
      if (!!sbSlider)
        sbSlider.style.left = String ( parseInt( newLeft) ) + "%";
    }
  }

  function scrollEvent(cntrl, ev, evparam)
  {
    var update = true;
    var direction = ' ';
    if (ev == "NextPage")
    {
      shSelectionOffset += shVisibleRows;
      if (shSelectionOffset > hitlistrowcount - shVisibleRows)
        shSelectionOffset = hitlistrowcount - shVisibleRows;
      direction = 'V';
    }
    else if (ev == "PrevPage")
    {
      shSelectionOffset -= shVisibleRows;
      if (shSelectionOffset < 0)
        shSelectionOffset = 0;
      direction = 'V';
    }
    else if (ev == "ScrollUp")
    {
      shSelectionOffset--;
      if (shSelectionOffset < 0)
        shSelectionOffset = 0;
      direction = 'V';
    }
    else if (ev == "ScrollDown")
    {
      shSelectionOffset++;
      if (shSelectionOffset > hitlistrowcount - shVisibleRows)
        shSelectionOffset = hitlistrowcount - shVisibleRows;
      direction = 'V';
    }
    else if (ev=="jumprow")
    {
      shSelectionOffset  = parseInt( evparam );
      shSelectionOffset--;
      if (shSelectionOffset < 0)
        shSelectionOffset = 0;
      if (shSelectionOffset > hitlistrowcount - shVisibleRows)
        shSelectionOffset = hitlistrowcount - shVisibleRows;
      update = false;
      direction = 'V';
    }
    else if (ev=="NextCol")
    {
      var totalwidth = 0;
      var column = 0;
      while (totalwidth <= shHitListHOffset && column < hitListColumnWidth.length )
        totalwidth += hitListColumnWidth[column++];
      shHitListHOffset = totalwidth;
      if (shHitListHOffset > shHitlistWidth - shHitlistVisibleWidth)
        shHitListHOffset = shHitlistWidth - shHitlistVisibleWidth;
      direction = 'H';
    }
    else if (ev=="PrevCol")
    {
      var totalwidth = 0;
      var column = 0;
      while (totalwidth < shHitListHOffset && column < hitListColumnWidth.length )
        totalwidth += hitListColumnWidth[column++];
      if (column == 0)
        shHitListHOffset = 0;
      else
        shHitListHOffset = totalwidth - hitListColumnWidth[column-1];
      direction = 'H';
    }
    else if (ev=="ScrollRight")
    {
      shHitListHOffset += 10;
      if (shHitListHOffset > shHitlistWidth - shHitlistVisibleWidth)
        shHitListHOffset = shHitlistWidth - shHitlistVisibleWidth;
      direction = 'H';
    }
    else if (ev=="ScrollLeft")
    {
      if (shHitListHOffset > 0)
      {
          shHitListHOffset -= 10;
          if (shHitListHOffset < 0)
            shHitListHOffset = 0;
          direction = 'H';
      }
    }
    else if (ev=="jumpcol")
    {
      shHitListHOffset  = parseInt( evparam );
      shHitListHOffset --;
      if (shHitListHOffset < 0)
        shHitListHOffset  = 0;
      update = false;
      direction = 'H';
    }

    if (direction == 'V')
        hitlistVScrollPos( shSelectionOffset, update );
    else if (direction == 'H')
        hitlistHScrollPos( shHitListHOffset, update );
  }


function myvSBSliderMouseMoveHandler( event, cntrl)
{
    if (vSBSliderMouseMoveHandler( event, cntrl))
    {
        var sbSlider = document.getElementById("~LISTVSBSlider");
        shSelectionOffset = sbSlider.getAttribute("currPos") - 1;
        if (shSelectionOffset < 0)
            shSelectionOffset = 0;
        if (shSelectionOffset > hitlistrowcount - shVisibleRows)
            shSelectionOffset = hitlistrowcount - shVisibleRows;
        hitlistVScrollPos( shSelectionOffset, false );
    }
}


function myhSBSliderMouseMoveHandler( event, cntrl)
{
    if (hSBSliderMouseMoveHandler( event, cntrl))
    {
        var sbSlider = document.getElementById("~LISTHSBSlider");
        shHitListHOffset = sbSlider.getAttribute("currPos") - 1 ;
        if (shHitListHOffset < 0)
            shHitListHOffset = 0;
        if (shHitListHOffset  > shHitlistWidth - shHitlistVisibleWidth)
            shHitListHOffset  = shHitlistWidth - shHitlistVisibleWidth;
        hitlistHScrollPos( shHitListHOffset, false );
    }
}

var req = null;

function hasloaded()
{
    var commands =
    req.contentWindow.document.documentElement.innerText.split( "\n");
    if (checkResponse( commands ))
    {
        for ( var k=1; k < commands.length; k++)
            eval ( commands[k]);
        hitlistVScrollPos( shSelectionOffset, true );
        var waiter = document.getElementById( "searchHelpLoadIndicator");
        waiter.style.visibility = "hidden";
        req = null;
    }
}

function loadDoc(url, type, initial)
{
    if (req)
        return;
    if (window.XMLHttpRequest)
        req = new XMLHttpRequest();
    else if (window.ActiveXObject)
        try {    // needed for IE6 without ActiveX support
        req = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch(e){}
    if ("undefined" != typeof oSAPSecu)
      url = oSAPSecu.URLAppendToken(url);
    if (!req)
    {
        if (!document.getElementById('reloadframe'))
        {
            dlgMultiselect =
                document.createElement( "<iframe onload='hasloaded();' style='height:0px;width:0px' id='reloadframe' >");
            document.appendChild( dlgMultiselect);
        }
        req = document.getElementById('reloadframe');
        req.src=url;
        return;
    }
    req.open("GET", url, true);
    req.onreadystatechange = isLoaded;
    req.send(null);
}

function shHitlistWheel(event)
{
    var delta = 0;
    if (!event)
    {
        event = window.event;
    }

    if (event.wheelDelta)
    {
        delta = event.wheelDelta/120;
    }
    else if (event.detail)
    {
        delta = -event.detail/3;
    }

    if (delta)
    {
        if (delta < 0)
        {
            scrollEvent("", "ScrollDown");
        }
        else
        {
            scrollEvent("", "ScrollUp");
        }
    }
}

function shLoadHits( index, range, initial)
{
    var waiter = document.getElementById( "searchHelpLoadIndicator");
    waiter.style.visibility = "visible";
    if (index < 1)
        index = 1;
    var loadto = index + range;
    if (loadto > hitlistrowcount)
        loadto = hitlistrowcount;
    loadDoc(hlreloadURL+'from'+String(index+1)+'to'+String(loadto), "text", initial);
    return true;
}

function isLoaded()
{
    if (req.readyState == 4)
    {
        var commands = req.responseText.split( "\n");
        if (checkResponse( commands ))
        {
            for ( var k=1; k < commands.length; k++)
                eval ( commands[k]);
            hitlistVScrollPos( shSelectionOffset, true );
            var waiter = document.getElementById( "searchHelpLoadIndicator");
            waiter.style.visibility = "hidden";
            req = null;
        }
    }
}

var ErrorHTML;

function checkResponse ( commands )
{
    if (commands[0].indexOf( "response from hitlist request") == -1)     // this is an error - due to a timeout?
    {
        parent.ErrorHTML = req.responseText;
        var pd = parent.document;
        var ErrorFrame;
        if (document.all)
        {
            ErrorFrame  =
                pd.createElement( "<iframe style='z-index:999;height:100%; width:100%; position: absolute; top:0px; left:0px' id='HUGO' src='/sap/public/bc/its/mimes/system/sl/page/sherror.html' >");
        }
        else
        {
            ErrorFrame  =
                pd.createElement( "iframe");
            ErrorFrame.setAttribute( "style" , "z-index:999;height:100%; width:100%; position: absolute; top:0px; left:0px");
            ErrorFrame.setAttribute( "src" , "/sap/public/bc/its/mimes/system/sl/page/sherror.html");
            ErrorFrame.setAttribute( "id" , "HUGO");
        }
        pd.body.appendChild( ErrorFrame);
        return false;
    }
    return true;
}

function shResultTableSelect(evt)
{
  var TRRow, controlid;
  var e = new its_event(((evt != null)? evt : window.event));
  var idx = shResultFieldRowIdx - shSelectionOffset;

  TRRow = document.getElementById( "hlrow" + idx );
  if ((TRRow == null) || !TRRow.getAttribute("param"))
  {
    TRRow = shTableCellGetTR(e.target);
  }

  if (TRRow && TRRow.getAttribute("param"))
  {
    if ( typeof SHHitlistToolbar_okay_disabled != "undefined" )
    {
      shRaiseSearchhelp("", 3); // closeTab
      return;
    }
    controlid = TRRow.getAttribute("controlid");
    raiseEvent(controlid,"ResultTableSelect",TRRow.getAttribute("param"))
  }
}

function shKeyDown( evt )
{
  var e = new its_event(evt);
  var bScrollVert = false;
  var keyCode = e.keyCode;
  if (keyCode > 400)
    keyCode -= 400;
  if (keyCode == 38)
  {
    shSelectionOffset--;
    bScrollVert = true;
  }
  if (keyCode == 40)
  {
    shSelectionOffset++;
    bScrollVert = true;
  }
  if (keyCode == 33)
  {
    shSelectionOffset -= shVisibleRows;
    bScrollVert = true;
  }
  if (keyCode == 34)
  {
    shSelectionOffset += shVisibleRows;
    bScrollVert = true;
  }
  if (keyCode == 35)
  {
    shSelectionOffset = hitlistrowcount - shVisibleRows;
    bScrollVert = true;
  }
  if (keyCode == 36)
  {
    shSelectionOffset = 0;
    bScrollVert = true;
  }
  if (bScrollVert)
  {
    if (shSelectionOffset <0)
      shSelectionOffset = 0;
    if ( (shSelectionOffset + shVisibleRows) >hitlistrowcount )
      shSelectionOffset = hitlistrowcount - shVisibleRows;
    hitlistVScrollPos( shSelectionOffset, true );
    return false;
  }
  else
  {
      if (keyCode == 37)
      {
          if (shHitlistVisibleWidth == null || shHitlistWidth <= shHitlistVisibleWidth)
            return;
        scrollEvent(null, 'PrevCol', '');
        return false;
      }
      if (keyCode == 39)
      {
          if (shHitlistVisibleWidth == null || shHitlistWidth <= shHitlistVisibleWidth)
            return;
        scrollEvent(null, 'NextCol', '');
        return false;
    }
  }
  if (keyCode == 112)     // F1
  {
     e.cancel();
     if (e.ctrlKey)
       shRaiseSearchhelp(0, 12);
     else
       shRaiseSearchhelp(e.target.id, 1);
     return false;
  }
  if (keyCode == 113)     // F2
  {
     e.cancel();
     if (e.shiftKey)
       shRaiseSearchhelp(0, 22);
     return false;
  }
  if (keyCode == 114)     // F3
  {
     e.cancel();
     shRaiseSearchhelp( 0, 3);
     return false;
  }
  if (keyCode == 115)    // F4
  {
     e.cancel();
     if (e.shiftKey)  //   personalisierung
        shRaiseSearchhelp(e.target.id, 14);
     else
       if (typeof(e.target.getAttribute("sh")) != "undefined")
         shRaiseSearchhelp(e.target.id, 4);
     return false;
  }
}

function shTableCellGetTR(selectedElement)
{
  while (selectedElement && selectedElement.nodeName!= "TR")
    selectedElement = selectedElement.parentNode ;
  return (selectedElement) ;
}

var shFindexpression = "";

function shOnFindKeyDown( shid, event )
{
    var e = new its_event(event);
    if ((e.keyCode == 13) && (shid != ''))
    {
        e.cancel();
        findinhitlistagain ( shid, event );
    }
}

function shOnFindExpression ( FieldID )
{
    var contents = document.getElementById( FieldID);
    if (!contents)
        return;
    var findbutton = document.getElementById( FieldID + "_Find");
    if (!findbutton)
        return;
    var findagainbutton = document.getElementById( FieldID + "_FindAgain");
    if (!findagainbutton)
        return;
    if (contents.value.length == 0 || contents.getAttribute( "initial") == "X" )
    {
        updateFindContextMenu( "OFF" );
        shFindexpression = "";
        shSetClass ( findbutton.childNodes[0], "WebguiOpacity25");
        shSetClass ( findagainbutton.childNodes[0], "WebguiOpacity25");
        contents = document.getElementById("~sh_findfexpinitial");
        contents.value = "X";
        return;
    }
    else
    {
        updateFindContextMenu( "ON" );
        shFindexpression = contents.value;
        shSetClass ( findbutton.childNodes[0], "");
        shSetClass ( findagainbutton.childNodes[0], "");
        contents = document.getElementById("~sh_findfexpinitial");
        contents.value = " ";
        return;
     }
}

function shOnFindFocus(FieldID )
{
    var contents = document.getElementById( FieldID);
    if (!contents)
        return;
    if (contents.getAttribute( "initial") == "X")
    {
        contents.setAttribute( "initial", " ");
        contents.style.color = "black";
        contents.value = "";
        contents = document.getElementById("~sh_findfexpinitial");
        contents.value = "";
    }
}

function findinhitlist ( id, evt )
{
    if ( shFindexpression == '' )
    {
        if (evt != null)
        {
            var ev = new its_event(evt);
            if (ev.valid)
            {
                ev.cancel();
            }
        }
        return;
    }
    var opts = 'Column="Nix"' + '&ID=' + sh_mid + '&row=0';
    owguDOM.HTMLCreateElement("input", {"name":"Expression", "type":"hidden", "value":shFindexpression}, self.document, 3, document.webguiform);
    webguiRaiseEvent(id, 'FindRow', opts, '_parent');
}

function findinhitlistagain ( id, evt )
{
    if ( shFindexpression == '' )
    {
        if (evt != null)
        {
            var ev = new its_event(evt);
            if (ev.valid)
            {
                ev.cancel();
            }
        }
        return;
    }
    var opts = 'Column="Nix"' + '&ID=' + sh_mid + '&row=' + strSelectedRow ;
    owguDOM.HTMLCreateElement("input", {"name":"Expression", "type":"hidden", "value":shFindexpression}, self.document, 3, document.webguiform);
    webguiRaiseEvent(id, 'FindRow', opts, '_parent');

}

function shSetClass( domobject, newclass)
{
    if (document.all)
        domobject.className = newclass;
    else
        domobject.setAttribute( "class", newclass);
}

var dlgMultiselect = null;
var shMSDTitle = "";
var shCurrInputDim = 0;
var shCurrInputID = 0;

function shMultiSelectionDialog (dlgTitle, top, left, inputDim, id)
{
    if (dlgMultiselect)
        return;
    shCurrInputDim = inputDim;
    shMSDTitle = dlgTitle;
    shCurrInputID = id;
    var pd;
    var height = 320;
    if (document.all)
        pd = document;
    else
        pd = document.getElementById( "webguiDynpro");
    var dlgWidth = 2*(7*inputDim+6)+ 84;
    if (dlgWidth < 230)
        dlgWidth = 230;
    top = top + 10;
    if (top + height + 28 > document.body.offsetHeight)
    {
        top = document.body.offsetHeight - height - 28;
        if (top < 0) top = 0;
    }
    if (left + dlgWidth + 10 > document.body.offsetWidth)
    {
        left = document.body.offsetWidth - dlgWidth - 10;
        if (left < 0) left = 0;
    }
    if (document.all)
    {
        dlgMultiselect =
            document.createElement( "<iframe onclick='closeMultiselect();' style='background:#ffffff;border-color:#000000;border-width:2px;height:"+height+"px;width:"+dlgWidth+"px;position:absolute;top:" + top.toString() +
                "px;left:" + left.toString() + "px' src='/sap/public/bc/its/mimes/system/sl/page/shmult.html' id='HUGO' >");
    }
    else
    {
        dlgWidth = dlgWidth - 20;
        dlgMultiselect =
            document.createElement( "iframe");
        // Match searchhelpctrl.css neutral surface; preserve iframe dimensions and attributes.
        dlgMultiselect.setAttribute( "style" , "background:#F0F3F6;border-width:2px;height:"+height+"px;width:"+dlgWidth+"px;position:absolute;top:"+ top.toString() +
            "px;left:" + left.toString() + "px");
        dlgMultiselect.setAttribute( "id" , "HUGO");
        dlgMultiselect.setAttribute( "src", "/sap/public/bc/its/mimes/system/sl/page/shmult.html");
        dlgMultiselect.setAttribute( "zOrder", "50");
    }
    shSetClass( dlgMultiselect, "WebguiPopupWindow");
    pd.appendChild( dlgMultiselect);
}

function closeMultiselect()
{
    dlgMultiselect.parentNode.removeChild( dlgMultiselect );
    dlgMultiselect = null;
    shMSDTitle = "";
}

function giveMultiselect( )
{
    var hugo = new Array ();
    var found = false;
    var form = document.getElementById( 'webguiform' );
    var seloptElems = form.getElementsByTagName("input");

    var idPattern = "SELOPT"+( parseInt( shCurrInputID )-400 );
    for (i = 0; i < seloptElems.length; i++)
    {
        if (seloptElems[i].type == "hidden" && seloptElems[i].getAttribute("selopt") == "x"
            && seloptElems[i].name.lastIndexOf(idPattern) == 0 )
        {
            var values = seloptElems[i].value.split("!");
            if (seloptElems[i].name == idPattern + "[1]")
            {
                var entryField = document.getElementById( shCurrInputID );
                if (entryField)
                    values[2] = entryField.value;
            }
            var tableLine = new Array( values[0], values[1],
                values[2], values[3]);
            hugo.push( tableLine );
            found = true;
        }
    }
    if (!found)
    {
        var entryField = document.getElementById( shCurrInputID );
        if (entryField && entryField.value != "")
        {
            var tableLine = new Array( "I", "EQ", entryField.value, "");
            hugo.push( tableLine );
        }
    }
    return ( hugo );
}

function takeMultiselect( optionsArray )
{
    var form = document.getElementById( 'webguiform' );
    var seloptElems = form.getElementsByTagName("input");
    var i, seloptElemsCount = seloptElems.length ;
    var idPattern = "SELOPT"+( parseInt( shCurrInputID )-400 );
    for (i = seloptElemsCount-1; i >= 0 ; i--)
    {
        if (seloptElems[i].type == "hidden" && seloptElems[i].getAttribute("selopt") == "x"
            && seloptElems[i].name.lastIndexOf(idPattern) == 0 )
            seloptElems[i].parentNode.removeChild( seloptElems[i] );
    }
    var seloptElem;
    for (i = 0; i < optionsArray.length; i++)
    {
        seloptElem = document.createElement( "input" );
        seloptElem.setAttribute( "selopt", "x" );
        seloptElem.setAttribute( "type", "hidden" );
        seloptElem.setAttribute( "name", idPattern+"["+(i+1)+"]" );
        seloptElem.setAttribute( "value", optionsArray[i][0]+"!"+optionsArray[i][1]+"!"+
            optionsArray[i][2]+"!"+optionsArray[i][3]);
        form.appendChild( seloptElem );
        if (i == 0)
        {
            seloptElem = document.getElementById( shCurrInputID );
            if (document.all)
                seloptElem.innerText = optionsArray[i][2];
            else
                seloptElem.value = optionsArray[i][2];
            seloptElem = document.getElementById( "DDSHSELOPTOPT["+shCurrInputID+"]" );
            seloptElem.className = "SearchSelopt" + optionsArray[i][0].toLowerCase() +
                optionsArray[i][1].toLowerCase();
            seloptElem.setAttribute( "set", "x");
        }
    }
    if (optionsArray.length == 0)
    {
        seloptElem = document.getElementById( shCurrInputID );
        seloptElem.innerText = "";
        seloptElem.value = "";
        seloptElem = document.getElementById( "DDSHSELOPTOPT["+shCurrInputID+"]" );
        seloptElem.className = "SearchSeloptEmpty";
        seloptElem.setAttribute( "set", "");
    }

    dlgMultiselect.parentNode.removeChild( dlgMultiselect );
    dlgMultiselect = null;
    shMSDTitle = "";
    var msbutton = document.getElementById( 'msbutton' + shCurrInputID );
    if (optionsArray.length > 1)
        shSetClass( msbutton , "SearchHelpMoreActive" );
    else
        shSetClass( msbutton , "SearchHelpMorePassive" );
}

function createSelectionArray()
{
    var hugo = new Array ();
    var inputs = document.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++)
    {
        if ( inputs[i].value != "" )
        {
            var signAndOptElem;
            if (inputs[i].id.slice(0,4) == "shew")
            {
                signAndOptElem = document.getElementById( "DDSHSELOPTOPT["+inputs[i].id+"]");
                var signAndOpt = signAndOptElem.className.split("SearchSelopt");
                var tableLine = new Array(signAndOpt[1].slice(0,1).toUpperCase(),
                    signAndOpt[1].slice(1,3).toUpperCase(), inputs[i].value, "" );
                hugo.push( tableLine );
            }
            if (inputs[i].id.slice(0,4) == "shrf")
            {
                var lineNo = inputs[i].id.slice( 4,5);
                var upperElem = document.getElementById( "shrt" + lineNo);
                lineNo = parseInt( lineNo ) + 4;
                signAndOptElem = document.getElementById( "DDSHSELOPTOPT["+lineNo+"]");
                var signAndOpt = signAndOptElem.className.split("SearchSelopt");
                if (signAndOpt[1] == "empty")
                    signAndOpt[1] = "ibt";
                var tableLine = new Array(signAndOpt[1].slice(0,1).toUpperCase(),
                    signAndOpt[1].slice(1,3).toUpperCase(), inputs[i].value, upperElem.value );
                hugo.push( tableLine );
            }
        }
    }
    parent.takeMultiselect( hugo );
}

function shMSDOnLoad()
{
    try
    {
        var titles = parent.shMSDTitle.split(":");
        var tt = document.getElementById( "shMSDTitle");
        if (tt)
            if (document.all)
                tt.innerText = titles[0];
            else
                tt.textContent = titles[0];
        var TitleBar = document.getElementById( "ModalTitleBar" );
        if (TitleBar)
        {
            TitleBar.style.width = parseInt( document.body.offsetWidth) + "px";
            if (!document.all)
            {
                if (document.body.offsetWidth != document.body.scrollWidth)
                    TitleBar.style.width = (parseInt( document.body.offsetWidth) ) + "px";
            }
        }
        var seloptelem;
        for (var i = 0; i < parent.shSeloptStrings.length; i++)
        {
            seloptelem = document.getElementById( (parent.shSeloptStrings[i][0] + parent.shSeloptStrings[i][1]).toLowerCase());
            if (seloptelem)
            {
                var newTitle;
                if (seloptelem.id == "sva" || seloptelem.id == "ran")
                    newTitle = parent.shSeloptStrings[i][2] + titles[1];
                else
                    newTitle = parent.shSeloptStrings[i][2];
                seloptelem.setAttribute( "title", newTitle );
                if (seloptelem.tagName == "TD")
                    if (document.all)
                        seloptelem.innerText = newTitle;
                    else
                        seloptelem.textContent = newTitle;
            }
        }
        var inputDim = parent.shCurrInputDim;
        var widthInChar = inputDim;
        if (widthInChar > 28)
            widthInChar = 28;
        var inputs = document.getElementsByTagName("input");
        var first = true;
        for (i = 0; i < inputs.length; i++)
        {
            if (inputs[i].type == "text")
            {
                if (first)
                {
                    dom_focus(inputs[i]);
                    first = false;
                }
                inputs[i].style.width = (widthInChar*7 + 6) + 'px';
                inputs[i].maxLength = inputDim;
            }
        }
        shequtooltip = parent.shequtooltip;
        shpattooltip = parent.shpattooltip;
        var seloptsArray = parent.giveMultiselect( );
        var  single = 1; var range = 1;
        var field; var optimage;
        for (i = 0; i < seloptsArray.length; i++)
        {
            if (seloptsArray[i][1] == "BT" || seloptsArray[i][1] == "NB")
            {
                // range value
                optimage = document.getElementById( "DDSHSELOPTOPT["+ (4+range) +"]");
                optimage.className = "SearchSelopt" + seloptsArray[i][0].toLowerCase() +
                    seloptsArray[i][1].toLowerCase();
                field = document.getElementById( "shrf" + range);
                field.innerText = seloptsArray[i][2];
                field.value = seloptsArray[i][2];
                field = document.getElementById( "shrt" + range);
                field.innerText = seloptsArray[i][3];
                field.value = seloptsArray[i][3];
                range++;
            }
            else
            {
                optimage = document.getElementById( "DDSHSELOPTOPT[shew"+ single +"]");
                optimage.className = "SearchSelopt" + seloptsArray[i][0].toLowerCase() +
                    seloptsArray[i][1].toLowerCase();
                field = document.getElementById( "shew" + single);
                field.innerText = seloptsArray[i][2];
                field.value = seloptsArray[i][2];
                single++;
            }
        }
    }
    catch(err){}
}

function shMultSelectOption( id )
{
    var imgElem = document.getElementById (  "DDSHSELOPTOPT["+shMltdlgFocus+"]" );
    shSetClass( imgElem , "SearchSelopt" + id );
    imgElem.setAttribute( "set", "x");
}

function shMultSelectOptionRange( id )
{
    var lineNo = shMltdlgFocus.slice( 4,5);
    lineNo = parseInt( lineNo ) + 4;
    var imgElem = document.getElementById (  "DDSHSELOPTOPT["+lineNo+"]" );
    shSetClass( imgElem , "SearchSelopt" + id );
    imgElem.setAttribute( "set", "x");
}

function removeMultiselectEntry()
{
    var selElem;
    if ( shMltdlgFocus.slice( 0,4) == "shew")
    {
        selElem = document.getElementById (  "DDSHSELOPTOPT["+shMltdlgFocus+"]" );
        shSetClass( selElem , "SearchSeloptempty");
        selElem.setAttribute( "set", "");
        selElem = document.getElementById (  shMltdlgFocus );
        selElem.innerText = "";
        selElem.value= "";
    }
    else
    {
        var lineNo = shMltdlgFocus.slice( 4,5);
        var lineNoImg = parseInt( lineNo ) + 4;
        selElem  = document.getElementById (  "DDSHSELOPTOPT["+lineNoImg+"]" );
        shSetClass( selElem , "SearchSeloptempty");
        selElem.setAttribute( "set", "");
        selElem = document.getElementById ( "shrf" + lineNo );
        selElem.innerText = "";
        selElem.value= "";
        selElem = document.getElementById ( "shrt" + lineNo );
        selElem.innerText = "";
        selElem.value= "";
    }
}


function removeMultiselectEntries()
{
    var inputs = document.getElementsByTagName("input");
    var first = true;
    for (i = 0; i < inputs.length; i++)
    {
        if (inputs[i].type == "text")
        {
            if (first)
            {
                dom_focus(inputs[i]);
                first = false;
            }
            inputs[i].innerText = "";
            inputs[i].value = "";
        }
    }
    var imgs = document.getElementsByTagName("img");
    for (i = 0; i < imgs.length; i++)
    {
        if (imgs[i].id.slice(0, 4)== "DDSH")
        {
            shSetClass( imgs[i], "SearchSeloptempty");
        }
    }
}

function shMSOptSelected( id, value, tt)
{
    var selopt = document.getElementById(id);
    shSetClass ( selopt, "SearchSelopt" + value);
    selopt.setAttribute( "set", "x");
    selopt.setAttribute( "title", tt);
}

function shAdjustSeloptimgs()
{
    var form = document.getElementById( 'webguiform' );
    var seloptElems = form.getElementsByTagName("input");

    for (i = 0; i < seloptElems.length; i++)
    {
        if (seloptElems[i].type == "hidden" && seloptElems[i].getAttribute("selopt") == "x" )
        {
            var idSplit = seloptElems[i].id.split("[");
            if (idSplit[1] == "1]")
            {
                var number = parseInt( idSplit[0].slice(6,10)) + 400;
                var values = seloptElems[i].value.split("!");
                var newSelOptClass = "SearchSelopt" + values[0].toLowerCase() + values[1].toLowerCase();
                var selOptField = document.getElementById( "DDSHSELOPTOPT[" + number + "]");
                if (selOptField)
                    shSetClass ( selOptField, newSelOptClass);
            }
        }
    }
}

function shSwitchSH( dlg )
{
    var name = shDivId + "-CRITERIA_VISIBLE";
    var visibleField = document.getElementById( name );
    if (visibleField)
        visibleField.value = "1";
    var dialog = document.getElementById('SH_Dialog');
    dialog.setAttribute("value", dlg);
    webguiRaiseEvent( sh_mid, 'TabChangedEx', 'id=' + sh_mid, '_parent');
}

function shCtxtMenu(actionid)
{
    var container = document.getElementById( 'SHSelopts');
    if (container && container.getAttribute( 'sh_control'))
    {
        if (actionid == 0)
        {
            searchHelpSelect( container.getAttribute('sh_mid') );
        }
        else if (actionid == 1)
        {
            shRaiseSearchhelp(shCurrentHitlistCell, 1);   // help
        }
        else if (actionid == 2)
        {
            shRaiseSearchhelp("", 12);   // techn. info
        }
        else if (actionid == 3)
        {
            findinhitlist ( container.getAttribute('sh_mid'), null );
        }
        else if (actionid == 4)
        {
            findinhitlistagain ( container.getAttribute('sh_mid'), null );
        }
        else if (actionid == 5)      // personalize
        {
            shRaiseSearchhelp("", 14);
        }
        else if (actionid == 6)      // print
        {
            webguiRaiseDataEvent(container.getAttribute('sh_control'),
                'Search',
                'id=' + container.getAttribute('sh_control') + '&dialog=2&button_id=1107&opt=X',
                '_parent');
        }
        else if (actionid == 7)            // sort asc
        {
            if (shCurrentHitlistCell.indexOf("shcellr") == 0)     // F1 for a hit list column
            {
                var split = shCurrentHitlistCell.split("c");
                var col = parseInt(split[split.length - 1]) - 1;
                webguiRaiseDataEvent(container.getAttribute('sh_control'), 'SortResultTable',
                    "id=" + container.getAttribute('sh_mid') +
                    "&Column=" + hitListColumnNames[col] +
                    "&mode=A",
                    '_parent');
            }
        }
        else if (actionid == 8)            // sort desc
        {
            if (shCurrentHitlistCell.indexOf("shcellr") == 0)     // F1 for a hit list column
            {
                var split = shCurrentHitlistCell.split("c");
                var col = parseInt(split[split.length - 1]) - 1;
                webguiRaiseDataEvent(container.getAttribute('sh_control'), 'SortResultTable',
                    "id=" + container.getAttribute('sh_mid') +
                    "&Column=" + hitListColumnNames[col] +
                    "&mode=D",
                    '_parent');
            }
        }
        else if (actionid == 9)            // insert pers
        {
            if (strSelectedRow != "")
            {
                webguiRaiseDataEvent(container.getAttribute('sh_control'),
                    'Search',
                     'id='+ container.getAttribute('sh_mid') +
                     '&dialog='+strSelectedRow+
                     '&button_id=1102&opt=X', '_parent');
            }
        }
        else if (actionid == 10)            // pers values
        {
            webguiRaiseDataEvent(container.getAttribute('sh_control'),
                'Search',
                 'id='+ container.getAttribute('sh_mid') +
                 '&dialog=10&button_id=1103&opt=X',
                 '_parent');
        }
        else if (actionid == 11)            // all values
        {
            webguiRaiseDataEvent(container.getAttribute('sh_control'),
                'Search',
                 'id='+ container.getAttribute('sh_mid') +
                 '&dialog=10&button_id=1103&opt=X',
                 '_parent');
        }
        else if (actionid == 12)            // delete pers
        {
            if (strSelectedRow != "")
            {
                webguiRaiseDataEvent(container.getAttribute('sh_control'),
                    'Search',
                     'id=' + container.getAttribute('sh_mid') +
                     '&dialog='+strSelectedRow+
                     '&button_id=1101&opt=X', '_parent');
            }
        }
        else if (actionid == 13)            // delete pers values
        {
            webguiRaiseDataEvent(container.getAttribute('sh_control'),
                'Search',
                 'id=' + container.getAttribute('sh_mid') +
                 '&dialog=-1&button_id=1101&opt=X',
                 '_parent');
        }
        else if (actionid == 14)
        {
            shRaiseSearchhelp("", 3);   // close
        }
   }
}

function updateContextMenu()
{
    if (shCurrentHitlistCell.indexOf("shcellr") == 0)   // enable lots of
    {
        arrMenu_SH[13] = "ON";    // copy
        arrMenu_SH[25] = "ON";    // techn. info
        arrMenu_SH[43] = "ON";    // personalize
        arrMenu_SH[49] = "ON";    // print
        arrMenu_SH[55] = "ON";    // sort asc
        arrMenu_SH[61] = "ON";    // sort desc
    }
    else                                                // disable
    {
        arrMenu_SH[13] = "OFF";    // copy
        arrMenu_SH[25] = "OFF";    // techn. info
        arrMenu_SH[43] = "OFF";    // personalize
        arrMenu_SH[49] = "OFF";    // print
        arrMenu_SH[55] = "OFF";    // sort asc
        arrMenu_SH[61] = "OFF";    // sort desc
    }
}

function updateFindContextMenu( onoff )
{
        arrMenu_SH[31] = onoff;
        arrMenu_SH[37] = onoff;
}
