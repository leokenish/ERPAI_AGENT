PAGE_UP_DOWN_COUNT = 7;

/** <gui_dropDownManager>
  *
  *   constructor for the gui_dropdownManager class.
  *
  *   params:
  *   parentObject - object - the parentObject, e. g. a gridview or tablecontrol
  *   parentType   - string - the type of the parent, e. g. "ALV" or "TC"
  */
function gui_dropdownManager(parentObject, parentType)
{
  this.parentObject     = parentObject;
  this.parentType       = parentType;
  this.itemsContainer   = document.createElement("DIV");
  this.opened           = false;
  this.disabled         = false;
  this.mouseoverElement = null;
  this.selectedElement  = null;
  this.searchString     = String();
  this.searchTimeoutID  = 0;
  this.width            = 0;
  this.items            = new Array();
  this.container        = null
  this.textContainer    = null
  this.input            = null;
  this.inputKey         = null;
  this.length           = 0;
  this.changed          = false;
  this.name             = "";
  this.itemsName        = "";
  this.x                = 0;
  this.y                = 0;
  this.holdBlocking     = false;
  this.specialItem      = null;

  var thisPtr = this;
  this.fClick       = function(evt)
                      {
                        thisPtr.click(evt);
                      };
  this.fChange      = function(evt)
                      {
                        thisPtr.change(evt);
                      };
  this.fMousedown   = function(evt)
                      {
                        thisPtr.mousedown(evt);
                      };
  this.fMouseover   = function(evt)
                      {
                        thisPtr.mouseover(evt);
                      };
  this.fKeydown     = function(evt)
                      {
                        thisPtr.keydown(evt);
                      };
  this.fMouseScroll = function(evt)
                      {
                        thisPtr.mousescroll(evt);
                      };
}
// <//gui_dropdownManager>



/** <gui_dropDownManager::setBlocking>
  *
  *   calculate the absolute position of the dropdown within its container
  *
  */
gui_dropdownManager.prototype.setBlocking = function(blocking)
{
  this.holdBlocking = blocking;
}
// </gui_dropDownManager::setBlocking>


/** <gui_dropDownManager::calcPosition>
  *
  *   calculate the absolute position of the dropdown within its container
  *
  */
gui_dropdownManager.prototype.calcPosition = function()
{
  var obj = this.container;
  var scrollLeft = 0;
  var scrollTop = 0;
  while (obj)
  {
    if (obj.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      scrollLeft += obj.scrollLeft;
      scrollTop += obj.scrollTop;
    }
    obj = obj.parentNode;
  }
  var pos = wgu_getAbsolutePosition( this.container );
  this.x = pos.x;
  this.y = pos.y + 19;
  if (its_ua.ie55up)
  {
    this.y -= 1;
  }
  // adjust positions to prevent the items container from beeing displayed
  // on the outside of the visible area of the document
  if (this.y + this.itemsContainer.offsetHeight > document.body.offsetHeight + document.body.scrollTop)
  {
    this.y -= (this.itemsContainer.offsetHeight + 19 + 1);
    if (this.y < 0)
    {
      this.y = 0;
    }
  }
  if (this.x + this.itemsContainer.offsetWidth > document.body.offsetWidth)
  {
    this.x -= (this.itemsContainer.offsetWidth - this.container.offsetWidth);
    if (this.x < 0)
    {
      this.x = 0;
    }
  }
  if (this.itemsContainer.offsetHeight > document.body.offsetHeight)
  {
    this.itemsContainer.style.height = document.body.offsetHeight - 4;
  }
}
// </gui_dropDownManager::calcPosition>


/** <gui_dropdownManager::renderInputField>
  *
  *   render the input field representating the dropdown
  *
  */
gui_dropdownManager.prototype.renderInputField = function()
{
  var content;

  if (this.textContainer)
  {
    // remove required sign
    if (this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP"
        || this.parentType == "SEARCHHELPMS")
    {
      this.textContainer.className = dom_removeClass(this.textContainer.className, "ddRequired");
    }
    if (its_ua.gecko)
    {
      content = this.textContainer.textContent;
    }
    else if (its_ua.ie55up)
    {
      content = this.textContainer.innerText;
    }
  }
  if (content == "&nbsp;" || content == "\xA0" || content == " ")
  {
    content = "";
  }

  input       = document.createElement("INPUT");
  input.type  = "hidden";
  input.value = content;
  this.input  = input;

  // insert the input field before the button
  this.container.insertBefore(input, null);

  // for tc an extra hidden input field is needed to send the key instead of
  // the value
  if (this.parentType == "TC" || this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP")
  {
    input = document.createElement("INPUT");
    input.type    = "hidden";
    input.id      = this.name;
    input.name    = this.name;
    input.value   = this.key;
    this.inputKey = input;
    // insert the input field before the button
    this.container.insertBefore(input, null);
  }
}
// </gui_dropdownManager::renderInputField>


/** <gui_dropdownManager::getContainer>
  *
  *   return the items tr element; the tr element is used to be the container
  *   of an item
  *
  *   params:
  *   node - Oject - the node to search for the tr
  */
gui_dropdownManager.prototype.getContainer = function(node)
{
  var tr = null;
  if (node.nodeName != "TR")
  {
    tr = dom_getParentNodeByNodeName(node, "TR");
    if (tr && tr.className.indexOf("ddItemsTr") != 0)
    {
      tr = null;
    }
  }
  else
  {
    tr = node;
  }
  return tr;
}
// </gui_dropdownManager::getContainer>


/** <gui_dropdownManager::checkSelected>
  *
  *   find the selected element and set selected attribute
  *
  */
gui_dropdownManager.prototype.checkSelected = function(optKey, optValue, value)
{
  if (true != this.displayKeys || this.parentType == "ALV")
  {
    return (optValue == value);
  }
  else
  {
    return (optKey + " " + optValue == value);
  }
}
// </gui_dropdownManager::checkSelected>


/** <gui_dropdownManager::prepareItems>
  *
  *   bring the items in the right form and append them to the dropdown
  *
  */
gui_dropdownManager.prototype.prepareItems = function()
{
  // get the dropdown items from the name applied to its container
  var itemsArray;
  var found = false;
  var item = "";
  var emptyKey, emptyValue = "";
  var appendEmpty = false;

  if (typeof this.itemsName != "undefined" && this.itemsName != "")
  {
    try
    {
      itemsArray = eval(this.itemsName);
    }
    catch (error)
    {

    }
  }
  if (itemsArray)
  {
    if (this.parentType == "ALV")
    {
      for (i = 0; i < itemsArray.length; i++)
      {
        opt = new gui_dropdownItem(itemsArray[i], itemsArray[i]);
        if (!found && this.checkSelected("", itemsArray[i], this.input.value))
        {
          opt.selected = true;
          found = true;
        }
        this.items.push(opt);
        if (i > 0)
        {
          this.items[i-1].next = opt;
          this.items[i].previous = this.items[i-1];
        }
      }
    }
    else if (this.parentType == "TC" || this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP"
        || this.parentType == "SEARCHHELPMS")
    {
      if (this.sortbykeys)
      {
        if (itemsArray[itemsArray.length-1][0] == "")
        {
          emptyKey   = itemsArray[itemsArray.length-1][0]
          emptyValue = itemsArray[itemsArray.length-1][1]
          appendEmpty = true;
          itemsArray.length -= 1;
        }
        itemsArray.sort();
        if (appendEmpty)
        {
          itemsArray[itemsArray.length] = Array(emptyKey, emptyValue);
        }
      }
      for (i = 0; i < itemsArray.length; i++)
      {
        opt = new gui_dropdownItem(itemsArray[i][0], itemsArray[i][1], itemsArray[i][2]);
        if (this.input.value != "" && !found && this.checkSelected(itemsArray[i][0], itemsArray[i][1], this.input.value))
        {
          opt.selected = true;
          found = true;
        }
        this.items.push(opt);
        if (i > 0)
        {
          this.items[i-1].next = opt;
          this.items[i].previous = this.items[i-1];
        }
      }
      if (this.specialItem != null)
      {
        opt = new gui_dropdownItem(this.specialItem, this.specialItem);
        i = this.items.length;
        if ( i > 0 && this.items[i-1].key == "")
        {
          emptyItem = this.items.pop();
          this.items.push(opt);
          i += 1;
          this.items.push(emptyItem);
          this.items[i-2].previous = this.items[i-3];
          this.items[i-2].next = emptyItem;
          this.items[i-1].previous = opt;
        }

      }
    }
    this.length = this.items.length;
  }
}
// </gui_dropdownManager::prepareItems>


/** <gui_dropdownManager::initDropdown>
  *
  *   initializes the dropdown; renders the inputfield (if needed), sets its
  *   event handlers and gathers the information needed to render the dropdown
  *   from its container
  *
  *   params:
  *   node - Object - the td-element containing the dropdown
  *
  */
gui_dropdownManager.prototype.initDropdown = function(node)
{
  if (this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP"
    || this.parentType == "SEARCHHELPMS")
  {
    this.container   = node;
  }
  else
  {
    this.container   = dom_getChildNodeByNodeName(node, "DIV");
  }
  this.name             = node.getAttribute("iname");
  this.key              = node.getAttribute("ivalue");
  this.itemsName        = node.getAttribute("iitems");
  this.specialItem      = node.getAttribute("ispecialItem");
  this.displayKeys      = node.getAttribute("idisplaykeys")? true : false;
  this.sortbykeys       = node.getAttribute("isortbykeys")? true : false;
  this.displayIcon      = node.getAttribute("idisplayicon")? true : false;
  this.dontDisplayValue = node.getAttribute("idontDisplayValue")? true : false;
  this.disabled         = node.getAttribute("idisabled")? true : false;
  this.textContainer    = dom_getChildNodeByNodeName(this.container, "DIV");
  if (this.container)
  {
    this.input = dom_getChildNodeByNodeName(this.container, "INPUT");
    if (!this.input)
    {
      this.renderInputField();
    }
    if (this.parentType == "TC" || this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP" || this.parentType == "SEARCHHELPMS")
    {
      this.inputKey = dom_getChildNodeByAttrAndValue(this.container, "id", this.name);
      dbg2("dropdown", "set inputKey to element.id = " + (this.inputKey == null) ? "null" : this.inputKey.id);
    }
  }
  this.initialized = true;
  return this.container;
}
// </gui_dropdownManager::initDropdown>


/** <gui_dropdownManager::dynproFocus>
  *
  *   handle the focus event on the dropdown input field; it should only be
  *   used on a dynpro dropdown
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *
  */
gui_dropdownManager.prototype.dynproFocus = function(evt)
{
  webguiResetOldFocus();

  var e = new its_event(evt);
  if (e)
  {
    if (e.target && e.target.className && e.target.className.indexOf("ddContainerDynpro") == 0)
    {
      if (!e.target.idisabled)
        e.target.className = dom_addClass(e.target.className, "ddCurrent");

      var div = dom_getChildNodeByNodeName(e.target, "DIV");
      if (div)
        div.className = dom_removeClass(div.className, "ddRequired");
    }
    e.cancel();
  }
}
// </gui_dropdownManager::dynproFocus>


/** <gui_dropdownManager::dynproBlur>
  *
  *   handle the blur event on the dropdown input field; it should only be
  *   used on a dynpro dropdown
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *
  */
gui_dropdownManager.prototype.dynproBlur = function(evt)
{
  var e = new its_event(evt);
  if (e)
  {
    if (e.target && e.target.className && e.target.className.indexOf("ddContainerDynpro") == 0)
    {
      if (!e.target.idisabled)
      {
        e.target.className = dom_removeClass(e.target.className, "ddCurrent");
      }
      var required = e.target.getAttribute("irequired");
      if (required)
      {
        var div = dom_getChildNodeByNodeName(e.target, "DIV");
        var text = "";
        if (its_ua.gecko)
          text = div.textContent;
        else if (its_ua.ie6up)
          text = div.innerText;
        if (div && text == "")
          div.className = dom_addClass(div.className, "ddRequired");
      }
    }
    e.cancel();
  }
}
// </gui_dropdownManager::dynproBlur>


/** <gui_dropdownManager::render>
  *
  *   render the dropdown list
  *
  */
gui_dropdownManager.prototype.render = function()
{
  if (this.parentType == "ALV" || this.parentType == "TC" ||
    this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP" ||
    this.parentType == "SEARCHHELPMS")
  {
    this.prepareItems();
  }

  this.itemsContainer.className = "ddItemsContainer";
  if (this.disabled)
  {
    this.itemsContainer.className = dom_addClass(this.itemsContainer.className, "ddDisabled");
  }

  var itemsTable = this.renderItems();

  this.itemsContainer.insertBefore(itemsTable, null);
  this.width = this.container.offsetWidth;
  if (typeof this.itemsContainerInserted == "undefined" || !this.itemsContainerInserted)
  {
    document.body.insertBefore(this.itemsContainer, null);
    this.itemsContainerInserted = true;
  }

  /////////////////////////////////////////////////////////////////////////////
  // calc height
  //
  if (this.length > 8)
  {
    visibleItems = 8
  }
  else
  {
    visibleItems = this.length;
  }

  if (its_ua.gecko)
  {
    this.itemsContainer.style.height = visibleItems * 18 + "px";
  }
  else
  {
    this.itemsContainer.style.height = visibleItems * 18 + 2 + "px";
  }

  /////////////////////////////////////////////////////////////////////////////
  // calc width
  //
  var scrollbarOffset = 0;
  var boxSizingOffset = 0;
  var borderOffset = 0;

  if (its_ua.ie55up)
    boxSizingOffset = 3;
  if (its_ua.gecko)
    borderOffset = 2;

  if (this.itemsContainer.offsetHeight < itemsTable.offsetHeight)
  {
    if (its_ua.gecko)
    {
      scrollbarOffset = 17;
    }
    else if (its_ua.ie55up)
    {
      scrollbarOffset = 16;
    }
  }
  this.itemsContainer.style.width = itemsTable.offsetWidth + scrollbarOffset + boxSizingOffset + "px";
  if (this.itemsContainer.offsetWidth < this.width)
  {
    this.itemsContainer.style.width = this.width + "px";
  }
  itemsTable.style.width =
    itemsTable.childNodes[0].childNodes[0].style.width =
      this.itemsContainer.offsetWidth - scrollbarOffset - boxSizingOffset - borderOffset + "px";

  /////////////////////////////////////////////////////////////////////////////
  // calc position
  //
  this.calcPosition();
  this.itemsContainer.style.visibility = "hidden";
}
// </gui_dropdownManager::render>


/** <gui_dropdownManager::renderItems>
  *
  *   render the items within a table and return this table
  *
  *   returns:
  *   table - Oject(HTMLTable) - the rendered table containing the items
  */
gui_dropdownManager.prototype.renderItems = function()
{
  var tr = null;
  var td = null;
  var div = null;
  var i;

  var table = document.createElement("TABLE");
  table.className = "ddItemsTable";

  var colgroup = document.createElement("colgroup");
  table.insertBefore(colgroup, null);

  var col = document.createElement("col");
  colgroup.insertBefore(col, null);

  var tbody = document.createElement("tbody");

  table.appendChild(tbody);

  for (i = 0; i < this.items.length; i++)
  {
    tr = document.createElement("tr");
    tbody.appendChild(tr);
    tr.className = "ddItemsTr";
    if (this.displayKeys)
    {
      td = document.createElement("td");
      td.className = "ddItemsTd";
      if (its_ua.gecko)
      {
        td.textContent = this.items[i].key;
      }
      else if (its_ua.ie55up)
      {
        td.innerText = this.items[i].key;
      }
      tr.appendChild(td);
    }
    if (!this.dontDisplayValue)
    {
        td = document.createElement("td");
        td.className = "ddItemsTd";
        if (its_ua.gecko)
        {
          td.textContent = this.items[i].value;
        }
        else if (its_ua.ie55up)
        {
          td.innerText = this.items[i].value;
        }
        its_eMgr.registerEvent(tr, "mouseover", this.fMouseover);

        if (this.items[i].selected)
        {
          tr.className = dom_addClass(tr.className, "ddItemsTrSelected");
        }
        tr.appendChild(td);
    }
    if (this.displayIcon)
    {
      if (!this.dontDisplayValue)
      {
          var col = document.createElement("col");
          colgroup.insertBefore(col, null);
      }
      td = document.createElement("td");
      td.className = "ddItemsTd";
      if (this.items[i].icon != "")
      {
        var img = document.createElement("img");
        img.src = this.items[i].icon;
        img.className = "ddItemsTd";
        its_eMgr.registerEvent(img, "mouseover", this.fMouseover);
        td.appendChild(img);
      }
      if (this.dontDisplayValue)
      {
        tr.title = this.items[i].value;
        its_eMgr.registerEvent(tr, "mouseover", this.fMouseover);
        if (this.items[i].selected)
        {
          tr.className = dom_addClass(tr.className, "ddItemsTrSelected");
        }
      }
      tr.appendChild(td);
    }
    tr.item = this.items[i];
    this.items[i].container = tr;
  }
  return table;
}
// </gui_dropdownManager::renderItems>


/** <gui_dropdownManager::switchDisplay>
  *
  *   switch the list with the items to open/close and render the container
  *   if necessary
  *
  */
gui_dropdownManager.prototype.switchDisplay = function()
{
  if (this.itemsContainer.childNodes.length == 0)
  {
    this.render();
  }
  if (this.opened)
  {
    this.close();
    this.reset();
  }
  else
  {
    this.open();
  }
}
// </gui_dropdownManager::switchDisplay>


/** <gui_dropdownManager::open>
  *
  *   open the list with the items
  *
  */
gui_dropdownManager.prototype.open = function()
{
  if (this.parentType == "TC")
  {
    its_eMgr.registerEvent(this.container, "keydown", this.fKeydown);
    dom_delayedFocus(this.container);
  }
  its_eMgr.registerEvent(this.itemsContainer, "click", this.fClick);
  window.wgu_global_eventhandler.RegisterHandler( "mousedown", "~body", 999, this.fMousedown, true);
  if (!its_ua.gecko)
    window.wgu_global_eventhandler.RegisterHandler( "mousewheel", "~body", 999, this.fMouseScroll, true);
  else
    window.wgu_global_eventhandler.RegisterHandler( "dommousescroll", "~body", 999, this.fMouseScroll, true);



  this.itemsContainer.style.display = "block";
  this.itemsContainer.style.visibility = "visible";
  this.itemsContainer.style.position = "absolute";
  this.itemsContainer.style.top = this.y;
  this.itemsContainer.style.left = this.x;

  this.selectedElement = null;

  for (var i = 0; i < this.items.length; i++)
  {
    if (this.items[i].selected)
    {
      this.items[i].container.className =
        dom_addClass(this.items[i].container.className, "ddItemsTrSelected");
      this.selectedElement = this.items[i];
      break;
    }
  }
  this.opened = true;
  this.scrollIntoView();
}
// </gui_dropdownManager::open>


/** <gui_dropdownManager::close>
  *
  *   close the list with the items
  *
  */
gui_dropdownManager.prototype.close = function()
{
  this.setBlocking(true);
  its_eMgr.unregisterEvent(this.itemsContainer, "click", this.fClick);
  if (this.parentType == "TC")
    its_eMgr.unregisterEvent(this.container, "keydown", this.fKeydown);
  window.wgu_global_eventhandler.UnregisterHandler( "mousedown", this.fMousedown, "~body");
  if (!its_ua.gecko)
    window.wgu_global_eventhandler.UnregisterHandler( "mousewheel", this.fMouseScroll, null);
  else
    window.wgu_global_eventhandler.UnregisterHandler( "dommousescroll", this.fMouseScroll, null);


  this.itemsContainer.style.visibility = "hidden";
  if (this.changed)
  {
    this.fireChangeEvent();
  }
  this.opened = false;
}
// </gui_dropdownManager::close>


/** <gui_dropdownManager::reset>
  *
  *   reset the the dropdown to its initial values
  *
  */
gui_dropdownManager.prototype.reset = function()
{
  var table = dom_getChildNodeByNodeName(this.itemsContainer, "TABLE");
  if (table)
  {
    this.itemsContainer.removeChild(table);
  }
  this.container = null;
  this.selectedElement = null;
  this.mouseoverElement = null;
  while (this.items.length)
  {
    this.items.pop();
  }
  this.opened = false;
  this.initialized = false;
}
// </gui_dropdownManager::reset>


/** <gui_dropdownManager::setValue>
  *
  *   Sets the value of the dropdown; for tc and dynpro dropdowns, the values
  *   key is saved as the value in an hidden input field.
  *
  *   params:
  *   key    - string - the key of the item to be set
  *   valule - string - the value of the item to be set
  */
gui_dropdownManager.prototype.setValue = function(key, value)
{
  if (!this.disabled)
  {
    if (this.displayKeys)
    {
      this.input.value = key + " " + value;
    }
    else
    {
      this.input.value = value;
    }
    if (its_ua.gecko)
      this.textContainer.textContent = this.input.value;
    else
      this.textContainer.innerText = this.input.value;
    if (this.parentType == "TC" || this.parentType == "DYNPRO" || this.parentType == "SEARCHHELP")
    {
      this.inputKey.value = key;
    }
    else if (this.parentType == "SEARCHHELPMS")
    {
      this.inputKey = key;
      this.specialItem = value;
    }
  }
}
// </gui_dropdownManager::setValue>


/** <gui_dropdownManager::setSelection>
  *
  *   set the selection to a specified element (newElement) and remove an
  *   element (oldElement) from the selection
  *
  *   params:
  *     newElement - Oject(wgu_dropDownitem) - current selected element
  *     oldElement - Oject(wgu_dropDownitem) - previous selected element
  */
gui_dropdownManager.prototype.setSelection = function(newElement, oldElement)
{
  if (this.selectedElement)
  {
    this.selectedElement.container.className =
      dom_removeClass(this.selectedElement.container.className, "ddItemsTrSelected");
    this.selectedElement.selected = false;
  }
  if (oldElement)
  {
    oldElement.container.className =
      dom_removeClass(oldElement.container.className, "ddItemsTrSelected");
    oldElement.selected = false;
  }
  if (newElement)
  {
    this.selectedElement = newElement;
    this.selectedElement.selected = true;
    this.selectedElement.container.className =
      dom_addClass(this.selectedElement.container.className, "ddItemsTrSelected");
    var table = dom_getParentNodeByNodeName(newElement.container, "TABLE");
    table.style.display = "";
    table.style.display = "block";
  }
  this.changed = true;
}
// </gui_dropdownManager::setSelection>


/** <gui_dropdownManager::scrollIntoView>
  *
  *   scrolls the selected element into view, only if necessary (if it is not
  *   already in the view)
  *
  */
gui_dropdownManager.prototype.scrollIntoView = function()
{
  if (this.selectedElement)
  {
    if (this.selectedElement.container.offsetTop +
      this.selectedElement.container.offsetHeight >
      this.itemsContainer.offsetHeight +
      this.itemsContainer.scrollTop
       )
    {
      this.itemsContainer.scrollTop =
        this.selectedElement.container.offsetTop +
        this.selectedElement.container.offsetHeight -
        this.itemsContainer.offsetHeight +
        2;
    }
    else if (this.itemsContainer.scrollTop >
             this.selectedElement.container.offsetTop)
    {
      this.itemsContainer.scrollTop =
        this.selectedElement.container.offsetTop;
    }
  }
}
// </gui_dropdownManager::scrollIntoView>


/** <gui_dropdownManager::click>
  *
  *   handle click event
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.click = function(evt)
{
  var tr;
  var e;
  if (this.holdBlocking == false)
  {
    if (evt instanceof its_event)
    {
      e = evt;
    }
    else
    {
      e = new its_event(evt);
    }
    if (!this.disabled)
    {
      tr = this.getContainer(e.target);
      if (tr && tr.className.indexOf("ddItemsTrSelected") > -1)
      {
        this.changed = true;
        this.selectedElement = tr.item;
        tr.item.selected = true;
        this.setValue(tr.item.key, tr.item.value);
      }
    }
    if (e.target.className.indexOf("dd") == 0)
    {
      if (this.parentType == "DYNPRO")
      {
        dom_delayedFocus(this.container);
      }
    }
    this.switchDisplay(null);
    this.setBlocking(false);
    e.cancel();
    delete e;
  }
}
// </gui_dropdownManager::click>


/** <gui_dropdownManager::fireChangeEvent>
  *
  *   close the list with the items
  *
  */
gui_dropdownManager.prototype.fireChangeEvent = function()
{
  its_eMgr.registerEvent(this.input, "change", this.fChange);
  if (its_ua.gecko)
  {
    var changeEvent = document.createEvent("HTMLEvents");
    changeEvent.initEvent("change", true, false);
    this.input.dispatchEvent(changeEvent);
  }
  else if (its_ua.ie55up)
  {
    this.input.fireEvent("onchange");
  }
  its_eMgr.unregisterEvent(this.input, "change", this.fChange);
  this.changed = false;
}
// </gui_dropdownManager::fireChangeEvent>


/** <gui_dropdownManager::change>
  *
  *   handle change event
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.change = function(evt)
{
  if (this.parentType == "TC" && evt)
  {
    var e = new its_event(evt);
    var node = dom_getParentNodeByNodeName(e.target, "TD");
    if (node)
    {
      var okcode = node.getAttribute("iokcode");
      if (okcode && okcode != "")
      {
        setOkCode(okcode);
      }
    }
  }
  else if (this.parentType == "ALV")
  {
    its_gvMgr.change(evt, this.parentObject)
  }
  else if (this.parentType == "DYNPRO" && evt)
  {
    var e = new its_event(evt);
    var node = dom_getParentNodeByNodeName(e.target, "DIV");
    if (node)
    {
      var okcode = node.getAttribute("iokcode");
      if (okcode && okcode != "")
      {
        setOkCode(okcode);
      }
    }
  }
  else if (this.parentType == "SEARCHHELP" && evt)
  {
    var e = new its_event(evt);
    var node = dom_getParentNodeByNodeName(e.target, "DIV");
    if (node)
    {
      var okcode = node.getAttribute("iokcode");
      if (okcode && okcode != "")
      {
        var dialog = document.getElementById('SH_Dialog');
        dialog.setAttribute("value", this.inputKey.value);
        webguiRaiseEvent(okcode, 'TabChangedEx', 'id=' + okcode, '_parent');
      }
    }
  }
  else if (this.parentType == "SEARCHHELPMS" && evt)
  {
    var e = new its_event(evt);
    var node = dom_getParentNodeByNodeName(e.target, "DIV");
    if (node)
    {
      var okcode = node.getAttribute("iokcode");
      if (okcode && okcode != "")
      {
        shMSOptSelected( okcode, this.inputKey, this.specialItem );
      }
    }
  }
}
// </gui_dropdownManager::change>


/** <gui_dropdownManager::mousedown>
  *
  *   handle mousedown event
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.mousedown = function(evt)
{
  var e = new its_event(evt)
  {
    if (e.target.className.indexOf("ddItemsTd") > -1 ||
        e.target.className.indexOf("ddItemsContainer") == 0 ||
        e.target.nodeName == "scrollbar"
       )
    {
    }
    else
    {
      this.switchDisplay(null);
    }
    if (e.target.className.indexOf("dd") != 0)
    {
      this.setBlocking(false);
    }
    e.stopPropagation();
    delete e;
  }
}
// </gui_dropdownManager::mousedown>


/** <gui_dropdownManager::mouseover>
  *
  *   handle the mouseover event for every single item
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.mouseover = function(evt)
{
  var tr = null;
  e = new its_event(evt);
  if (e)
  {
    tr = this.getContainer(e.target);
    if (tr)
    {
      if (this.mouseoverElement)
      {
        this.mouseoverElement.container.className = dom_removeClass
        (
          this.mouseoverElement.container.className,
          "ddItemsTrSelected"
        );
      }
      if (this.selectedElement)
      {
        this.selectedElement.container.className = dom_removeClass
        (
          this.selectedElement.container.className,
          "ddItemsTrSelected"
        );
      }
      this.mouseoverElement = tr.item;
      this.mouseoverElement.container.className = dom_addClass
      (
        this.mouseoverElement.container.className,
        "ddItemsTrSelected"
      );
      var table = dom_getParentNodeByNodeName(tr, "TABLE");
      table.style.display = "";
      table.style.display = "block";
    }
    delete e;
  }
}
// </gui_dropdownManager::mouseover>

/** <gui_dropdownManager::mousescroll>
  *
  *   handle the mouse wheel event captured on the body
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.mousescroll = function(evt)
{
  var delta;
  if (document.createEventObject)
  {
    delta = evt.wheelDelta / 40 * 19; // -/+120
  }
  else
  {
    delta = -evt.detail * 19; // -/+3 * 19
  }
  if (this.itemsContainer)
  {
    this.itemsContainer.scrollTop -= delta;
  }
  e = new its_event(evt);
  e.cancel();
  delete e;
}
// </gui_dropdownManager::mousescroll>

/** <gui_dropDownManager::keydown>
  *
  *   handles the keydown event on the inputfield. as the inputfield has the
  *   focus as long as the dropdown has the focus, it handles every keydown
  *   event.
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  */
gui_dropdownManager.prototype.keydown = function(evt)
{
  // Enter used to finish IME composition must not select or submit business data.
  var composingEvent = evt || window.event;
  if (composingEvent && (composingEvent.isComposing || composingEvent.keyCode == 229)) return;
  var clearSearchString = true;
  var cancelEvent = false;
  var e = new its_event(evt);
  if (e)
  {
    switch (e.keyCode)
    {
      // key down
      case EVT_KEY_DOWN :
        cancelEvent = this.kbDown(e.altKey);
        break;
      case EVT_KEY_UP :
        cancelEvent = this.kbUp(e.altKey);
        break;
      case EVT_KEY_RETURN :
        cancelEvent = this.kbReturn();
        break;
      case EVT_KEY_ESCAPE :
        cancelEvent = this.kbEscape();
        break;
      case EVT_KEY_TAB :
        cancelEvent = this.kbTab();
        break;
      case EVT_KEY_END :
        cancelEvent = this.kbEnd();
        break;
      case EVT_KEY_POS1 :
        cancelEvent = this.kbPos1();
        break;
      case EVT_KEY_PGDOWN :
        cancelEvent = this.kbPgdown();
        break;
      case EVT_KEY_PGUP :
        cancelEvent = this.kbPgup();
        break;
      case EVT_KEY_DEL :
        cancelEvent = this.kbDel();
        break;
      case EVT_KEY_F1 :
        cancelEvent = false;
        break;
      default :
        cancelEvent = this.kbOther(e);
        clearSearchString = false;
        break;
    }
    if (cancelEvent)
    {
      e.cancel();
    }
    if (clearSearchString)
    {
      this.searchString = "";
    }
    delete e;
  }
}
// </gui_dropDownManager::keydown>


/** <gui_dropDownManager::findItem>
  *
  *   find a certain item in the dd;
  *     find abc -> find first item beginning with "abc"
  *
  *
  *   params:
  *   e - Oject(Event) - the its_event object
  */
gui_dropdownManager.prototype.findItem = function(e)
{
  var n = 0;
  var element = this.selectedElement;
  if (element)
  {
    element = element.next;
  }
  else
  {
    element = this.items[0];
  }
  do
  {
    while (element)
    {
      if (this.displayKeys)
      {
        if (element.key.toUpperCase().indexOf(this.searchString) == 0)
        {
          return element;
        }
      }
      else
      {
        if (element.value.toUpperCase().indexOf(this.searchString) == 0)
        {
          return element;
        }
      }
      element = element.next;
    }
    n++;
    element = this.items[0];
  }
  while (n < 2) // prevent infinite loop
}
// </gui_dropDownManager::findItem>


/** <gui_dropDownManager::findNextItem>
  *
  *   find a certain item in the dd;
  *     find aaa -> find third item beginning with character "a"
  *
  *
  *   params:
  *   e - Oject(Event) - the its_event object
  */
gui_dropdownManager.prototype.findNextItem = function(firstChar)
{
  var n = 0;
  var element = this.selectedElement;
  if (element)
  {
    element = element.next;
  }
  else
  {
    element = this.items[0];
  }
  do
  {
    while (element)
    {
      if (this.displayKeys)
      {
        if (element.key.toUpperCase().charAt(0) == firstChar)
        {
          return element;
        }
      }
      else
      {
        if (element.value.toUpperCase().charAt(0) == firstChar)
        {
          return element;
        }
      }
      element = element.next;
    }
    n++;
    element = this.items[0];
  }
  while (n < 2) // prevent infinite loop
}
// </gui_dropDownManager::findNextItem>


/** <gui_dropDownManager::kbOther>
  *
  *   processes keys other than e. g. KEYUP or KEYDOWN and tries to find a
  *   string in the items which begin is equal to a possible character input
  *
  *   params:
  *   e - Oject(Event) - the its_event object
  */
gui_dropdownManager.prototype.kbOther = function(e)
{
  if (this.searchTimeoutID)
  {
    window.clearTimeout(this.searchTimeoutID);
    this.searchTimeoutID = 0;
  }

  var key = e.keyCode;
  var oldElement = this.mouseoverElement;
  var searchResult = null;
  var found = false;

  if (this.opened)
  {
    if (!oldElement)
    {
      oldElement = this.selectedElement;
    }
    // NUM-Pad
    if (key >= 96 && key <= 105)
    {
      key -= 48;
    }
    this.searchString += String.fromCharCode(key).toUpperCase();
    if (this.searchString.length == 2 && this.searchString.charAt(0) == this.searchString.charAt(1))
    {
      searchResult = this.findNextItem(this.searchString.charAt(0));
      this.searchString = this.searchString.substr(0, 1);
    }
    else
    {
      searchResult = this.findItem(this.searchString);
      if (searchResult == null)
      {
        this.searchString = this.searchString.substr(0, this.searchString.length-1);
      }
    }
    if (searchResult != null)
    {
      this.setSelection(searchResult, oldElement);
    }
    thisPtr = this;
    this.searchTimeoutID = window.setTimeout
    (
      "thisPtr.searchString = '';", 1000
    );
    this.scrollIntoView();
  }
  return true;
}
// </kbOther>


/** <gui_dropDownManager::kbDown>
  *
  *   handles the kbDown event
  *
  *   params:
  *   altKey - Boolean - has the ALT key been pressed while hitting kbDown?
  */
gui_dropdownManager.prototype.kbDown = function(altKey)
{
  if (altKey)
  {
    this.switchDisplay(null);
    return true;
  }
  else if (this.opened)
  {
    if (this.mouseoverElement)
    {
      if (this.mouseoverElement.next)
      {
        this.setSelection(this.mouseoverElement.next,
                  this.mouseoverElement);
        this.mouseoverElement = null;
      }
    }
    else if (this.selectedElement)
    {
      if (this.selectedElement.next)
      {
        this.setSelection(this.selectedElement.next,
                  this.selectedElement);
      }
    }
    else
    {
      this.setSelection(this.items[0], null);
    }
    this.scrollIntoView(false);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbDown>


/** <gui_dropDownManager::kbUp>
  *
  *   handles the kbUp event
  *
  *   params:
  *   altKey - Boolean - has the ALT key been pressed while hitting kbUp?
  */
gui_dropdownManager.prototype.kbUp = function(altKey)
{
  if (altKey)
  {
    this.switchDisplay(null);
    return true;
  }
  else if (this.opened)
  {
    if (this.mouseoverElement)
    {
      if (this.mouseoverElement.previous)
      {
        this.setSelection(this.mouseoverElement.previous,
                  this.mouseoverElement);
        this.mouseoverElement = null;
      }
    }
    else if (this.selectedElement)
    {
      if (this.selectedElement.previous)
      {
        this.setSelection(this.selectedElement.previous,
                  this.selectedElement);
      }
    }
    else
    {
      this.setSelection(this.items[this.length-1], null);
    }
    this.scrollIntoView(true);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbUp>


/** <gui_dropDownManager::kbDel>
  *
  *   handles the kbDel event; sets the selection to the empty item if
  *   available
  *
  *   params:
  *   forceDelete - Boolean - force delete even if dd is not opened?
  */
gui_dropdownManager.prototype.kbDel = function(forceDelete)
{
  var i = 0;
  var found = false;
  if (this.opened)
  {
    while (i < this.items.length && !found)
    {
      if (this.items[i].value == "" && this.items[i].key == "")
      {
        found = true;
      }
      else
      {
        i++;
      }
    }
    if (found)
    {
      this.setSelection(this.items[i], null);
      this.setValue(this.items[i].key, this.items[i].value);
      this.scrollIntoView(true);
    }
  }
  else if (typeof forceDelete != "undefined" && forceDelete == true)
  {
    this.setValue("", "");
    this.fireChangeEvent();
  }
  return true;
}
// </gui_dropDownManager::kbDel>


/** <gui_dropDownManager::kbReturn>
  *
  *   handles the kbReturn event; the current element gets selected and the
  *   dropdown list is closed if necessary
  *
  */
gui_dropdownManager.prototype.kbReturn = function()
{
  if (this.opened)
  {
    if (this.mouseoverElement)
    {
      this.setSelection(this.mouseoverElement, this.selectedElement);
      this.setValue(this.mouseoverElement.key, this.mouseoverElement.value);
    }
    else if (this.selectedElement)
    {
      this.setValue(this.selectedElement.key, this.selectedElement.value);
    }
    if (this.opened)
    {
      this.switchDisplay(null);
    }
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbReturn>


/** <gui_dropDownManager::kbEscape>
  *
  *   handles the kbEscape event and closes the dropdown list if necessary
  *
  *
  */
gui_dropdownManager.prototype.kbEscape = function()
{
  if (this.opened)
  {
    this.switchDisplay(null);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbEscape>


/** <gui_dropDownManager::kbTab>
  *
  *   handles the kbTab event and closes the dropdown list if necessary
  *   if necessary
  *
  */
gui_dropdownManager.prototype.kbTab = function()
{
  dbg3("dropdown", "<kbTab>");
  if (this.mouseoverElement)
  {
    this.setValue(this.mouseoverElement.key, this.mouseoverElement.value);
  }
  else if (this.selectedElement)
  {
    this.setValue(this.selectedElement.key, this.selectedElement.value);
  }
  if (this.opened)
  {
    this.close();
  }
  this.reset();
  return false;
}
// </gui_dropDownManager::kbTab>


/** <gui_dropDownManager::kbPos1>
  *
  *   handles the kbPos1 event; sets the selected element to the first element
  *   of the dropdown list
  *
  */
gui_dropdownManager.prototype.kbPos1 = function()
{
  var newElement = null;
  if (this.opened)
  {
    if (this.mouseoverElement)
    {
      newElement = this.mouseoverElement;
      while (newElement.previous && (newElement = newElement.previous));
      this.setSelection(newElement, this.mouseoverElement);
      this.mouseoverElement = null;
    }
    else if (this.selectedElement)
    {
      newElement = this.selectedElement;
      while (newElement.previous && (newElement = newElement.previous));
      this.setSelection(newElement, this.selectedElement);
    }
    else
    {
      this.setSelection(this.items[0], null);
    }
    this.scrollIntoView(true);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbPos1>


/** <gui_dropDownManager::kbEnd>
  *
  *   handles the kbEnd event; sets the selection to the last element in the
  *   dropdown list
  *
  */
gui_dropdownManager.prototype.kbEnd = function()
{
  var newElement = null;
  if (this.opened)
  {
    if (this.mouseoverElement)
    {
      newElement = this.mouseoverElement;
      while (newElement.next && (newElement = newElement.next));
      this.setSelection(newElement, this.mouseoverElement);
      this.mouseoverElement = null;
    }
    else if (this.selectedElement)
    {
      newElement = this.selectedElement;
      while (newElement.next && (newElement = newElement.next));
      this.setSelection(newElement, this.selectedElement);
    }
    else
    {
      this.setSelection(this.items[this.length-1], null);
    }
    this.scrollIntoView(true);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbEnd>


/** <gui_dropDownManager::kbPgdown>
  *
  *   handles the KEYPGDN event; sets the selected element PAGE_UP_DOWN_COUNT
  *   elements forward from the current selected element
  *
  */
gui_dropdownManager.prototype.kbPgdown = function()
{
  var newElement = null;
  var count = 0;
  if (this.opened)
  {
    if (this.mouseoverElement)
    {
      newElement = this.mouseoverElement;
      while (newElement.next && count < PAGE_UP_DOWN_COUNT)
      {
        newElement = newElement.next;
        count++;
      }
      this.setSelection(newElement, this.mouseoverElement);
      this.mouseoverElement = null;
    }
    else if (this.selectedElement)
    {
      newElement = this.selectedElement;
      while (newElement.next && count < PAGE_UP_DOWN_COUNT)
      {
        newElement = newElement.next;
        count++;
      }
      this.setSelection(newElement, this.selectedElement);
    }
    else
    {
      count = PAGE_UP_DOWN_COUNT;
      if (this.length < count)
      {
        count = this.length - 1;
      }
      this.setSelection(this.items[count], null);
    }
    this.scrollIntoView(true);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbPgdown>


/** <gui_dropdownManager::kbPgup>
  *
  *   handles the kbPgup event; sets the selected element PAGE_UP_DOWN_COUNT
  *   elements backward from the current selected element
  *
  */
gui_dropdownManager.prototype.kbPgup = function()
{
  var newElement = null;
  var count = 0;
  if (this.opened)
  {
    if (this.mouseoverElement)
    {
      newElement = this.mouseoverElement;
      while (newElement.previous && count < PAGE_UP_DOWN_COUNT)
      {
        newElement = newElement.previous;
        count++;
      }
      this.setSelection(newElement, this.mouseoverElement);
      this.mouseoverElement = null;
    }
    else if (this.selectedElement)
    {
      newElement = this.selectedElement;
      while (newElement.previous && count < PAGE_UP_DOWN_COUNT)
      {
        newElement = newElement.previous;
        count++;
      }
      this.setSelection(newElement, this.selectedElement);
    }
    else
    {
      this.setSelection(this.items[0], null);
    }
    this.scrollIntoView(true);
    return true;
  }
  return false;
}
// </gui_dropDownManager::kbPgup>


/** <gui_dropDownManager::dynproClick>
  *
  *   handle click event on dynpro dropdown
  *
  *   params:
  *     evt  - Object - the browser event
  *     name - String - the name of the dropdown object
  */
gui_dropdownManager.prototype.dynproClick = function(evt, name)
{
  var e = new its_event(evt);
  if (this.opened)
  {
    this.close();
    this.reset();
  }
  else if (e.target)
  {
    var node = dom_getParentNodeByNodeName(e.target, "DIV");
    if (node && node.className.indexOf("ddContainerDynpro") == 0)
    {
      if (this.holdBlocking == false)
      {
        this.initDropdown(node);
        this.switchDisplay();
      }
      dom_delayedFocus(node);
    }
  }
/*
  e.cancel();
  delete e;
*/
  this.setBlocking(false);
  return false;
}
// </gui_dropDownManager::dynproClick>


/** <gui_dropdownManager::dynproKeydown>
  *
  *   handle the blur event on the dropdown input field; it should only be
  *   used on a dynpro dropdown
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *
  */
gui_dropdownManager.prototype.dynproKeydown = function(evt)
{
  // Do not select a row or submit while Chrome is committing IME text.
  var composingEvent = evt || window.event;
  if (composingEvent && (composingEvent.isComposing || composingEvent.keyCode == 229)) return;
  var e = new its_event(evt);
  if (e)
  {
    if (!this.initialized && e.keyCode != EVT_KEY_TAB)
    {
      if (e.target && e.target.className.indexOf("ddContainerDynpro") == 0)
      {
        this.initDropdown(e.target);
      }
    }
    this.keydown(evt);
  }
  this.setBlocking(false);
}
// </gui_dropdownManager::dynproKeydown>


/** <gui_dropdownItem>
  *
  *   constructor for a single dropdown item
  *
  *   params:
  *   key   - String  - the key for the item
  *   value - String  - the displayed text for the item
  */
function gui_dropdownItem(key, value, icon)
{
  this.key             = key;
  this.value           = value;
  if (undefined != icon)
      this.icon        = icon;
  else
      this.icon        = "";
  this.previous        = null;
  this.next            = null;
  this.container       = null;
}
// </gui_dropdownItem>

