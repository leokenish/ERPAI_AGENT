<!--BHTMLPP:Disable -->
<!-- --> <HR><H1> This page requires JavaScript</H1>
<!-- --> Please consider upgrading to Internet Explorer 4.0 or higher
<!-- --> or to Netscape Navigator 4.0 or higher
<!--BHTMLPP:Enable -->

var TEC_SearchString = "";
var TEC_Set_Selection = "";

// dynamical increase textarea height, so that the content
// can be shown without scrollbars (decrease not possible)
// needed only for Gecko Browsers
function TEC_DynamicalIncreaseTextarea(el)
{
  if ( !its_ua.ie55up ) {
    if (el.offsetHeight > 0)
    {
      while (el.scrollHeight > el.offsetHeight)
      {
        var newrows = (el.scrollHeight * el.rows)/el.offsetHeight;
        if ( newrows <= (el.rows + 1))
          newrows = el.rows + 1;
        el.rows = newrows;
      }
    }
    if (el.offsetWidth > 0)
    {
      while (el.scrollWidth > el.offsetWidth)
      {
        var newcols = (el.scrollWidth * el.cols)/el.offsetWidth;
        if ( newcols <= (el.cols + 1))
          newcols = el.cols + 1;
        el.cols = newcols;
      }
    }
  }
}

function TEC_IsRangeContained(oOuter, oInner)
{
  if ( its_ua.ie55up )
  {
    // Workaround due to the fact that inRange in combination with selection.createRange() doesn't work with IE5!
    //  Optimistic ansatz: this is valid for all IE5 and in future version the bug is fixed.
    //  This assumption allthough questionable offers a chance - at least.

    var colElRects = oOuter.getClientRects();
    var colTempRects = oInner.getClientRects();


    if (  colElRects && colTempRects && colElRects.length > 0 && colTempRects.length > 0
      && (( colElRects[0].top < colTempRects[0].top )
        || (( colElRects[0].top == colTempRects[0].top ) && ( colElRects[0].left <= colTempRects[0].left )))
      && (( colElRects[colElRects.length-1].bottom > colTempRects[colTempRects.length-1].bottom )
            || (( colElRects[colElRects.length-1].bottom == colTempRects[colTempRects.length-1].bottom)
        && ( colElRects[colElRects.length-1].right >= colTempRects[colTempRects.length-1].right )))
      )
      return true;
  }
  else
  {
    return oOuter.inRange(oInner);
  }

  return false;
}

function TEC_setEndPoint_EndToStart(oRangeToAdopt, oMasterRange)
{
  if ( its_ua.ie55up )
  {
    // Another workaround for a problem with IE5 and textranges retrieved via the selection object.
    // See comment above.

    var pos = wgu_getAbsolutePosition( window.document.body );
    var colRects = window.document.body.getClientRects();
    var xdiff =  colRects[0].left - pos.x - 2;
    var ydiff =  colRects[0].top - pos.y - 2;

    var colMasterRects = oMasterRange.getClientRects();
    var oLocalRange = oRangeToAdopt.duplicate();
    oLocalRange.moveToPoint(colMasterRects[0].left  - xdiff, colMasterRects[0].top - ydiff);
    oRangeToAdopt.setEndPoint("EndToStart",oLocalRange);
  }
  else
  {
    oRangeToAdopt.setEndPoint("EndToStart",oMasterRange);
  }
}

function TEC_setEndPoint_StartToStart(oRangeToAdopt, oMasterRange)
{
  if ( its_ua.ie55up )
  {
    // Another workaround for a problem with IE5 and textranges retrieved via the selection object.
    // See comment above.

    var pos = wgu_getAbsolutePosition( window.document.body );
    var colRects = window.document.body.getClientRects();
    var xdiff =  colRects[0].left - pos.x - 2;
    var ydiff =  colRects[0].top - pos.y - 2;

    var colMasterRects = oMasterRange.getClientRects();
    var oLocalRange = oRangeToAdopt.duplicate();
    oLocalRange.moveToPoint(colMasterRects[0].left - xdiff, colMasterRects[0].top - ydiff);
    oRangeToAdopt.setEndPoint("StartToStart",oLocalRange);
  }
  else
  {
    oRangeToAdopt.setEndPoint("StartToStart",oMasterRange);
  }
}

function TEC_compareEndPoints_EndToEnd(oRangeFirst, oRangeSecond)
{
  if ( its_ua.ie55up )
  {
    // Another workaround for a problem with IE5 and textranges retrieved via the selection object.
    // See comment above.

    var colRangeFirstRects = oRangeFirst.getClientRects();
    var colRangeSecondRects = oRangeSecond.getClientRects();

    if (  colRangeFirstRects && colRangeSecondRects
      && ( colRangeFirstRects[colRangeFirstRects.length-1].right == colRangeSecondRects[colRangeSecondRects.length-1].right )
      && ( colRangeFirstRects[colRangeFirstRects.length-1].bottom == colRangeSecondRects[colRangeSecondRects.length-1].bottom )
      )
      return true;
  }
  else
  {
    return (oRangeFirst.compareEndPoints("EndToEnd",oRangeSecond) == 0);
  }

  return false;
}

function TEC_GetWords_AroundSelection(el, id)
{
  var words = null;
  var rtrimwords = null;

  if ( el )
  {
    if ( el._oSelRange == null )
    {
      var ptStart = document.getElementById("TEC_SelectionStart" + id).value;
      var ptEnd = document.getElementById("TEC_SelectionEnd" + id).value;
      if ( ptStart && ptEnd )
      TEC_SetSelection(el,ptStart,ptEnd,"","","0","");
    }
    if ( el._oSelRange != null )
    {
      var oTempRange = el._oSelRange.duplicate();
      if (!TEC_compareEndPoints_EndToEnd(oTempRange, el._oTextRange))
        oTempRange.expand("word");
      // Another workaround for a problem with expand("word"), if cursor is at home position
      if (( oTempRange.text.length >= el._oTextRange.text.length) && (el._oSelRange.text.length == 0))
      {
        oTempRange = el._oSelRange.duplicate();
        oTempRange.move("character");
        oTempRange.expand("word");
      }
      words = oTempRange.text;
      rtrimwords = words.replace(/\s*$/, "");
    }
  }
  return rtrimwords;
}

function TEC_InternalFind(el, id, string, event)
{
  var bFound = false;

  if( el && el._oTextRange != null )
  {
    var oSearchRange = el._oTextRange.duplicate();

    if ( el._oSelRange == null )
    {
      var ptStart = document.getElementById("TEC_SelectionStart" + id).value;
      var ptEnd = document.getElementById("TEC_SelectionEnd" + id).value;
      if ( ptStart && ptEnd )
      {
        TEC_SetSelection(el,ptStart,ptEnd,"","","0","");
      }
    }
    if ( el._oSelRange != null )
    {
      TEC_setEndPoint_StartToStart(oSearchRange, el._oSelRange);
      if ( el._oSelRange.text.length > 0 )
        oSearchRange.moveStart("character", 1);
    }
    bFound = oSearchRange.findText(string, oSearchRange.text.length);
    if ( bFound )
    {
      TEC_Set_Selection = "X";
      oSearchRange.scrollIntoView();
      dom_select(oSearchRange);
      TEC_CacheSelection(el,id, event)
    }
    else
    {
      TEC_Set_Selection = "X";
      window.alert("String '" + string + "' not found!");
    }
  }

  return bFound;
}

function TEC_DoFind(id, event)
{
  var el = document.getElementById(id);
    var buffer = TEC_GetWords_AroundSelection(el, id);

  if ( buffer == null)
    buffer = "";
  buffer = window.prompt("Please enter the search string: ", buffer);
  if ( buffer )
  {
    if ( buffer != "" )
      if ( TEC_InternalFind(el, id, buffer, event) )
        TEC_SearchString = buffer;
  }
  TEC_CheckButtonsState (el, id);
}

function TEC_DoFindAgain(id, event)
{
  var el = document.getElementById(id);
  var text = el._oSelRange.text;
  if ( TEC_SearchString && TEC_SearchString != "" )
    TEC_InternalFind(el, id, TEC_SearchString, event);
}

function TEC_DoCut(id, event)
{
  TEC_DoCommand (id, "Cut", event);
}

function TEC_DoCopy(id, event)
{
  TEC_DoCommand (id, "Copy", event);
}

function TEC_DoPaste(id, event)
{
  TEC_DoCommand (id, "Paste", event);
}

function TEC_DoCommand (id, cmd, event)
{
  var el = document.getElementById(id);
  if( el && el._oSelRange!=null)
  {
    el._oSelRange.execCommand(cmd);
    dom_select(el._oSelRange);
    TEC_CheckButtonsState (el, id);
  }
  TEC_Event_StopPropagation(event);
}

function TEC_CheckButtonsState (el, id)
{

  if ( its_ua.ie55up ) {
    if (el)
    {
      var elTD;
      var elButton, elButtonImg;

        var buttonclass = "d_button";
        var currentsel;
        try {
          currentsel = document.selection.createRange();
        }
        catch(err){return;}

        elTD = document.getElementById("TEC_Cut"+id);
        if (elTD)
        {
          elButton = elTD.children[0];
          if ( currentsel && currentsel.text.length > 0 && currentsel.queryCommandEnabled("Cut"))
            webguiSetButtonDisabledState(elButton, false);
          else
            webguiSetButtonDisabledState(elButton, true);
        }

        elTD = document.getElementById("TEC_Copy"+id);
        if (elTD)
        {
          elButton = elTD.children[0];
          if (currentsel && currentsel.text.length > 0 && currentsel.queryCommandEnabled("Copy"))
            webguiSetButtonDisabledState(elButton, false);
          else
            webguiSetButtonDisabledState(elButton, true);
        }

        elTD = document.getElementById("TEC_Paste"+id);
        if (elTD)
        {
          elButton = elTD.children[0];
          if (el._oTextRange.queryCommandEnabled("Paste"))
            webguiSetButtonDisabledState(elButton, false);
          else
            webguiSetButtonDisabledState(elButton, true);
        }

      elTD = document.getElementById("TEC_FindAgain"+id);
      if (elTD)
      {
        elButton = elTD.children[0];
        if (TEC_SearchString != "")
          webguiSetButtonDisabledState(elButton, false);
        else
          webguiSetButtonDisabledState(elButton, true);
      }
    }
  }
}

// Import a file. Changes the textarea value.
function TEC_DoImport (el, expimpwithjava, event)
{

  if (1 == expimpwithjava)
  {
    wgu_global_updown_text_edit.webguiDoImpExp(el.id, "X")
  }
  else
  {
    var fs, a, ForReading;
    ForReading = 1;

    try
    {
      fs = new ActiveXObject("Scripting.FileSystemObject");
    }
    catch (exception)
    {
      return;
    }
    if ( fs != null )
      {
      // Get the filename!
      var def = "";
      var fname = window.prompt("Please enter the filename to import: ", def);
      if (fname)
      {
        try
        {
          a = fs.OpenTextFile(fname, ForReading, false);
          el.value = a.ReadAll ();
          a.Close();
          TEC_NewText(el, el.id, event);
        }
        catch(e){alert("file not found")}
      }
    }
  }
}

// Export a file.
function TEC_DoExport (el, expimpwithjava, event)
{

  if (1 == expimpwithjava)
  {
    wgu_global_updown_text_edit.webguiDoImpExp(el.id, "")
  }
  else
  {
    var fs, a;

    try
    {
      fs = new ActiveXObject("Scripting.FileSystemObject");
    }
    catch (exception)
    {
      return;
    }
    if ( fs != null )
      {
      // Get the filename!
      var def = "";
      var fname = window.prompt("Please enter the filename to export to: ", def);
      if (fname)
      {
        try
        {
          a = fs.CreateTextFile (fname, true);
          a.Write (el.value);
          a.Close();
        }
        catch(e){}
      }
    }
  }
}

<!---     Events   ---->

function TEC_Event_PreventDefault(event)
{
  if ( its_ua.ie55up )
    event.returnValue = false;
  else
    event.preventDefault();
}

function TEC_Event_StopPropagation(event)
{
  if ( its_ua.ie55up )
    event.cancelBubble = true;
  else
    event.stopPropagation();
}

function TEC_RaiseEvent_DblClick(el, id, controlid, event)
{
  if ( its_ua.ie55up ) {
    if ( el._oTextRange != null )
      TEC_SaveSelection (el,id);
  }
  else
    TEC_SaveSelection (el,id);

  raiseEvent (controlid, "DblClick");
}

function TEC_UpdateChanged (el, controlid, event)
{
  if ( el._modified != "x" && el._readonly != "X") {
    el._modified = "x";
    var elModified = document.getElementById("TEC_TextChanged" + controlid);
    if (elModified)
      elModified.value = "x";
  }
  TEC_DynamicalIncreaseTextarea(el);
  TEC_CheckButtonsState (el, controlid);
}

function TEC_RaiseEvent_F1(controlid, event)
{
  raiseEvent (controlid, "F1");
  TEC_Event_StopPropagation(event);
  TEC_Event_PreventDefault(event);
}

function TEC_RaiseEvent_F4(controlid, event)
{
  raiseEvent (controlid, "F4");
  TEC_Event_StopPropagation(event);
  TEC_Event_PreventDefault(event);
}

<!--- Check if F4 pressed --->
function TEC_CheckKeydown(el, id, controlid, event)
{
  if (event.keyCode > 111 && event.keyCode < 124) {
    // function keys
    if ( its_ua.ie55up ) {
      if ( el._oTextRange != null )
        TEC_SaveSelection (el,id);
    } else
      TEC_SaveSelection (el,id);
    if ( event.keyCode == 112 && event.shiftKey == false && event.ctrlKey == false) {
      if ( its_ua.ie55up )
        event.keyCode = event.keyCode + 400;
      TEC_RaiseEvent_F1(controlid, event);
    }
    if ( event.keyCode == 115 && event.shiftKey == false && event.ctrlKey == false) {
      if ( its_ua.ie55up )
        event.keyCode = event.keyCode + 400;
      TEC_RaiseEvent_F4(controlid, event);
    }
  } else {
    // pageup and pagedown keys
    if (event.keyCode == 33 || event.keyCode == 34) {
      if (event.keyCode == 33) {
        el.parentNode.scrollTop = el.parentNode.scrollTop - el.parentNode.offsetHeight;
      } else {
        el.parentNode.scrollTop = el.parentNode.scrollTop + el.parentNode.offsetHeight;
      }
      TEC_Event_StopPropagation(event);
      TEC_Event_PreventDefault(event);
    } else {
      // Avoid that the form gets posted
      TEC_Event_StopPropagation(event);
      //if readonly, no delete operation is allowed
      if ( el._readonly == "X" && (event.keyCode == 46 || event.keyCode == 8))
        TEC_Event_PreventDefault(event);
    }
  }
}

function TEC_CheckMousedown(el, id, controlid, event)
{
  el._isMouseDown = true;
}

function TEC_CheckUpdatable(el, controlid, event)
{
  if ( el._readonly == "X" && (event.keyCode < 33 || event.keyCode > 40))
    TEC_Event_PreventDefault(event);
}

function TEC_StoreScrollPos ( el, id, event)
{
  document.getElementById("TEC_ScrollPos" + id).value = el.scrollTop;
}

function TEC_ClickBesides ( el, id, event)
{
  if ( its_ua.ie55up )
  {
    var textarea = document.getElementById(id);
    var oTextRange = textarea._oTextRange.duplicate();
    var cltX = event.clientX;
    var cltY = event.clientY;
    var oTextRangeRects = oTextRange.getClientRects();
    if (oTextRangeRects.length > 0)
    {
      var txtrgmaxY = oTextRangeRects[oTextRangeRects.length-1].bottom;
      if (cltY > txtrgmaxY)
        cltY =  txtrgmaxY;
      var i = 0;
      for (i = 0; i < oTextRangeRects.length; i++)
      {
        if (oTextRangeRects[i].bottom >= cltY)
          break;
      }
      if (i > oTextRangeRects.length - 1)
        i = oTextRangeRects.length - 1;
      if (cltX > oTextRangeRects[i].right - 10)
      {
        if (i == oTextRangeRects.length-1)
          cltX = oTextRangeRects[i].right;
       else
         cltX = oTextRangeRects[i].right - 10;
      }
      if (cltX < oTextRangeRects[i].left)
        cltX = oTextRangeRects[i].left;
      oTextRange.moveToPoint(cltX, cltY)
      oTextRange.collapse();
      dom_select(oTextRange);
      TEC_CheckButtonsState (textarea, id);
    }
  }
  else
    dom_focus(document.getElementById(id));
}

<!---     Selection  ---->
function TEC_StoreSelection(el, id, ptStart, ptEnd)
{
  document.getElementById("TEC_SelectionStart" + id).value = ptStart;
  document.getElementById("TEC_SelectionEnd" + id).value = ptEnd;
}

function TEC_SaveSelection(el,id)
{
  if ( its_ua.ie55up ) {
    if ( document.selection.type == "Text" || document.selection.type == "None") {
      el._oTextRange = el.createTextRange();
      var oTextRange = el._oTextRange.duplicate();
      var oSelRange;
      try {
        oSelRange = document.selection.createRange();
      }
      catch(err){return;}

      if ( oSelRange && TEC_IsRangeContained(oTextRange, oSelRange) ) {
        try {
          TEC_SaveSelection_Detail( el, id, oTextRange, oSelRange);
        }
        catch(err){}
      }
    }
  }
  else {
    var ptStart = -1;
    var ptEnd = -1;
    ptStart = el.selectionStart;
    ptEnd = el.selectionEnd;

    if (ptStart != -1 && ptEnd != -1)
      TEC_StoreSelection(el, id, ptStart, ptEnd);

  }
}

function TEC_IsEmptyRec(oTextRange, oTextRangeClientRec)
{
  var IsEmptyRec = false;
  var oTempRange = oTextRange.duplicate();
  var oTempRangeStart = oTextRange.duplicate();
  oTempRangeStart.moveToPoint(oTextRangeClientRec.left, oTextRangeClientRec.top);
  oTempRange.setEndPoint("StartToStart",oTempRangeStart);
  var oTempRangeEnd = oTextRange.duplicate();
  oTempRangeEnd.moveToPoint(oTextRangeClientRec.right, oTextRangeClientRec.top);
  oTempRange.setEndPoint("EndToStart",oTempRangeEnd);

  if (oTempRange.text.length == 0)
    IsEmptyRec = true;

  return IsEmptyRec;
}

function TEC_SaveSelection_Detail(el, id, oTextRange, oSelRange)
{
  if ( oSelRange )
  {
    var ptStart = -1;
    var ptEnd = -1;

    el._oSelRange = oSelRange.duplicate();

    var lenSelText= oSelRange.text.length;

    TEC_setEndPoint_EndToStart(oTextRange, oSelRange);

    ptStart = oTextRange.text.length;
    ptEnd = ptStart + lenSelText;


    if ( its_ua.ie55up )
    {
      // With IE4 no linebreak information was contained within the text of textrange objects.
      // However as of IE5 linebreak information is included.
      // Thus with IE5 wrong positions of the selection are retrieved via the implementation above.
      // Here follows the correction algorithm: a linebreak consists of "0x0D0x0A" thus two characters
      var colBeforeSelStart = 0;
      var coloTextRange = oTextRange.getClientRects();
      var coloSelRange = oSelRange.getClientRects();
      if ( coloSelRange[0].top != coloTextRange[coloTextRange.length -1].top)
      {
        for(var i = coloTextRange.length -1; i >=0 ; i--)
        {
          colBeforeSelStart = colBeforeSelStart + 2;
            if (TEC_IsEmptyRec(oTextRange, coloTextRange[i]) == false)
            break;
        }
      }
      var colSelection = 0;
        if (coloSelRange[0].left != coloSelRange[0].right)
        {
          for(var i = coloSelRange.length -1; i >=0 ; i--)
          {
              if (TEC_IsEmptyRec(oSelRange, coloSelRange[i]) == false)
              break;
            colSelection = colSelection + 2;
          }
        }
      ptStart = ptStart + colBeforeSelStart;
      ptEnd = ptEnd + colBeforeSelStart + colSelection;
    }

    TEC_StoreSelection(el, id, ptStart, ptEnd);
  }
}

// Finally calculate the selection when the focus leaves the TA.
function TEC_CacheSelection(el,id, event)
{
  // Make sure function is called only once by introducing a new flag.
  if (el._inselection == 1)
    return;

  TEC_Event_StopPropagation(event);

  el._inselection = 1;
  TEC_SaveSelection (el,id);
  el._inselection = 0;
}

function TEC_CheckSelChange( el, id, event)
{
  // is event thrown due to sel change within textarea?
  if ( event
    && ( event.offsetX > 0 )
    && ( event.offsetY > 0 )
    && ( event.offsetX <= event.srcElement.clientWidth )
    && ( event.offsetY <= event.srcElement.clientHeight )
    )
  {
    if ( its_ua.ie55up ){
      try {
         el._oSelRange = document.selection.createRange();
      }
      catch(err){return;}
    }
    TEC_CacheSelection(el,id, event);
    TEC_CheckButtonsState (el, id);
  }
}

function TEC_OnFocus( el, id, event)
{
  if ( id != "")
  {
    webguiSaveFocus(new webguiFocusObj(WEBGUI_FOCUS_TYPE_TEXTEDIT, el));

    if (TEC_Set_Selection == "X" || !el._isMouseDown)
    {
      TEC_Set_Selection = "";
      if (el._oSelRange)
      {
        dom_select(el._oSelRange);
        TEC_CheckButtonsState (el, id);
      }
    }
    el._isMouseDown = false;
  }
}
function TEC_OnBlur( el, id, event)
{
  el._isMouseDown = false;

}

// selection must be saved for every keyup, because in event onblur selection is incorrect.
function TEC_OnKeyUp( el, id, event)
{
  if ( its_ua.ie55up ) {
    if ( el._oTextRange != null )
      TEC_SaveSelection (el,id);
  }
  else
    TEC_SaveSelection (el,id);
}

// Try to get the selection back we had last time.
// It is assumed that the start and end positions include the number of previous linebreaks as offsets.
function TEC_SetSelection(el,start,end, setSelection, scrollIntoView, scrollTop, hasFocus)
{
  var l_start = new Number(start);
  var l_end = new Number(end);
  var l_scrollTop = new Number(scrollTop);

  if ( its_ua.ie55up )
  {
    if (l_start>=0 && l_end>=0 && l_end>=l_start)
    {
      el._oSelRange = el._oTextRange.duplicate();
      el._oSelRange.moveStart("character", l_start);
      el._oSelRange.collapse();
      el._oSelRange.moveEnd("character", l_end-l_start);
      if (setSelection == "true")
      {
        if (hasFocus == "1")
        {
          webguiSaveFocus(new webguiFocusObj(WEBGUI_FOCUS_TYPE_TEXTEDIT, el));
          dom_select(el._oSelRange);
        }
        if ( el._oTextRange != null )
          TEC_SaveSelection (el,el.id);
      }
      if (scrollIntoView == "true")
        el._oSelRange.scrollIntoView();
      else
      {
        if (l_scrollTop > 0 )
          el.parentNode.scrollTop = l_scrollTop;
      }
    }
  }
  else {
    if (l_start>=0 && l_end>=0 && l_end>=l_start)
    {
      if (setSelection == "true") {
        el.selectionStart = l_start;
        el.selectionEnd = l_end;
        if (hasFocus == "1")
        {
          webguiSaveFocus(new webguiFocusObj(WEBGUI_FOCUS_TYPE_TEXTEDIT, el));
          dom_focus(el);
        }
        if ( el._oTextRange != null )
          TEC_SaveSelection (el,el.id);
      }
      if (scrollIntoView == "true") {
//      selected text in textarea is no selection range
//      window.getSelection().scrollIntoView();
      }
      else
      {
        if (l_scrollTop > 0 )
          el.parentNode.scrollTop = l_scrollTop;
      }
    }
  }
  TEC_CheckButtonsState (el, el.id);
}

// ----------------------------------------------------------

// Add a textarea to the list of textareas that need the selection
// set upon startup. This is called right after the TEC is created.
function TEC_AddToList(id, controlid, ptStart, ptEnd, modified)
{
  var el = document.getElementById(id);

  if (el)
  {
    if (!window.TEC_ElementsList)
      window.TEC_ElementsList = new Array();

    window.TEC_ElementsList[window.TEC_ElementsList.length] = el;
    el._modified = modified;
    if ( its_ua.ie55up ) {
      el._oTextRange = el.createTextRange();
    }
    else {
      el._oTextRange = el.value;
    }
    el._oSelRange = null;
    el._ControlId = controlid;
    el._isMouseDown = false;
    TEC_StoreSelection(el, id, ptStart, ptEnd);
    TEC_CheckButtonsState (el, id);
    TEC_DynamicalIncreaseTextarea(el);
  }
}

function TEC_OnResize(id)
{
  var txtCont = document.getElementById(id + "CONT");
  var txtSCRL = document.getElementById(id + "SCRL");
  var txtarea = document.getElementById(id);
  var contBorderWidth = 6;

  if ( txtCont == null || txtSCRL == null || txtarea == null )
    return false;

  if ( its_ua.ie55up )
    contBorderWidth = 2;
  var contWidth = txtCont.offsetWidth;
  var contHeight = txtCont.offsetHeight;
  var scrlWidth = contWidth - contBorderWidth;
  var scrlHeight = contHeight - contBorderWidth;
  var txtTB = document.getElementById(id + "TB");
  var txtSTB = document.getElementById(id + "STB");
  if (txtTB)
    scrlHeight = scrlHeight - 26;
  if (txtSTB)
    scrlHeight = scrlHeight - 20;
  if ( scrlWidth > 0)
    txtSCRL.style.width = scrlWidth;
  if ( scrlHeight > 0)
    txtSCRL.style.height = scrlHeight;
  if ( its_ua.ie55up && scrlHeight > 28)
    txtarea.style.height = scrlHeight - 28;
  if ( !txtarea._wordwrappos)
  {
    var webguifontwidth = txtarea._webguifontwidth;
    if (webguifontwidth > 0)
      txtarea.cols = Math.max(1, contWidth/webguifontwidth - 6);
  }
  var webguifontheight = txtarea._webguifontheight;
  if (webguifontheight > 0)
    txtarea.rows = Math.max(1, contHeight/(2*(webguifontheight + 2)));
  if (!its_ua.ie55up)
    TEC_DynamicalIncreaseTextarea(txtarea);
}

function TEC_NewText(el, id, event)
{
  if (el)
  {
    if ( its_ua.ie55up ) {
      el._oTextRange = el.createTextRange();
    }
    else {
      el._oTextRange = el.value;
    }
    el._oSelRange = null;
    TEC_StoreSelection(el, id, 0, 0);
    el.scrollTop = 0;
    TEC_StoreScrollPos ( el, id, event);
    TEC_UpdateChanged (el, id, event);
  }
}
// ----------------------------------------------------------
// TextEdit Control save and load buttons java implementation
//-----------------------------------------------------------

function wguObjUpdownTextedit (webgui_updown_appletUrl, webgui_updown_debug, resp_content_charset)
{
  this.webgui_updown_appletUrl = webgui_updown_appletUrl;
  this.webgui_updown_debug =  (webgui_updown_debug == "") ? false : true;
  this.resp_content_charset = resp_content_charset;

  return this;
} // wguObjUpdown()

wguObjUpdownTextedit.prototype.webguiDoImpExp = function (controlid, upload)
{
  var ImpExpid  = "CONTIMPEXPTEXTEDIT",
      ImpExpdiv,
      myel;
  ImpExpdiv = document.getElementById(ImpExpid);
  if (null == ImpExpdiv)
  {
    // create div
    if (null != document.all)
    {
      myel = document.createElement('<div id="' + ImpExpid + '" name="' + ImpExpid + '">');
    }
    else
    {
      myel = document.createElement("div");
      myel.setAttribute("id",   ImpExpid);
      myel.setAttribute("name", ImpExpid);
    }
    myel = document.body.appendChild(myel);
  }

appletsource='<applet name="UpDown.class" MAYSCRIPT archive="ws.jar" CODEBASE="' + wgu_global_updown_text_edit.webgui_updown_appletUrl + '"';
appletsource+='code="UpDown.class" '+' height=0 width=0>\n';
appletsource+='<param name=cabbase value="">';
appletsource+='<param name=useslibrarycodebase value="' + wgu_global_updown_text_edit.webgui_updown_appletUrl + '">';
appletsource+='<param name="java_code" value="UpDown.class">';
appletsource+='<param name="java_codebase" value="' + wgu_global_updown_text_edit.webgui_updown_appletUrl + '">';
appletsource+='<param name="java_type" value="application/x-java-applet;version=1.3">';
appletsource+='<param name="java_archive" value="ws.jar">';
if (wgu_global_updown_text_edit.webgui_updown_debug)
  appletsource+='<param name=updowndebug value="X">';
appletsource+='<param name="controlid" value="' + controlid + '">';
appletsource+='<param name="upload" value="' + upload + '">';
appletsource+='<param name="charset" value="' + wgu_global_updown_text_edit.resp_content_charset + '">';

appletsource+='</applet>\n';

//setting applet to load withing div tags
document.getElementById(ImpExpid).innerHTML=appletsource;
}

function UpDownFileToControl (sControlId, sFileString)
{
  el = document.getElementById(sControlId);
  el.value = sFileString;
  TEC_NewText(el, el.id, null);
}

function UpDownFileFromControl (sControlId)
{
  el = document.getElementById(sControlId);
  return el.value;
}
