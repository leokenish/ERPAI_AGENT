/* htmlviewer.js
 *
 * Integration of HTML documents and dynamic documents
 * into the SAP GUI for HTML via the HTMLviewer control
 *
 * v2.0 object oITSHtmlViewer
 * v2.1 /tj/101022/ multi instance support
 */


if ("undefined" == typeof oITSHtmlViewer)
{

var oITSHtmlViewer = {

  // CONSTANTS ////////////////////////

  CONST : {
      ClientStandardMimeTypes : [ "text/html",       "text/xml",  "image/gif", "image/jpeg",
                                  "image/ico",       "image/bmp", "image/png", "text/xhtml",
                                  "text/xul",        "image/xbm", "image/mng", "text/plain",
                                  "text/javascript", "text/css"
                                ],

                     // 0:tag   1:link  2:target
      TagsToModify : [ ["area", "href", "target"],
                       ["a", "href", "target"],
                       ["img", "src", null],
                       ["form", "action", "target"],
                       ["frame", "src", null],
                       ["iframe", "src", null] ]

  },


  // ATTRIBUTES ///////////////////////

  _wRootWindow : null,

  _aInstances  : [],


  // PRIVATE METHODS //////////////////

  _initialize : function ()
      {
        this._wRootWindow = this._getRootWindow();
      },  // ._initialize()


  _getRootWindow : function ()
      {
        var rv,
            p;

        if (null == (rv = this._wRootWindow))
        {
          try
          {
            for (p = parent;
                 p  && p != p.parent
                    && (null == p.webguiGetRootDocumentName
                       || ("undefined" != typeof(p.webguiIsPopup) && p.webguiIsPopup
                           && "undefined" != typeof(p.webguiFullScreenPopup) && false == p.webguiFullScreenPopup
                          )
                       );
                 p = p.parent
                )
              ;

            if (null != p && "undefined" != typeof p.webguiGetRootDocumentName)
            {
              rv = p;
            }
          }
          catch (e) {}
        }

        return rv;
      },  // ._getRootWindow


  _getDocumentName : function ()
      {
        var rv = null,
            w = this._getRootWindow(),
            s;

        if (null != w)
        {
          while (!(s = w.webguiGetRootDocumentName()))
          {
            if ("" == s)
            {
              if ("undefined" != typeof w.webguiSetDocumentName)
                w.webguiSetDocumentName();    // sets name to "WebguiDoc" (must do it! :)
              else
                break;
            }
          }
          rv = s;
        }

        return rv;
      },  // ._getDocumentName()


  _modifyTarget : function ()
      {
        var dname = this._getDocumentName(),
            at, a, i, j, el, tg,
            bo, o, addr;

        /* NOTE: We have a problem with the load order of the documents!
           If someone jumps directly in a transaction with an HTMLviewer
           (passing corresponding URL parameters), the page in the iframe
           is loaded before webguiSetDocument() (called via onload) has
           been called. This would cause an invalid target name for all
           SAPEvent anchor and frame tags.
        */

        if (dname && dname != "WebGuiDoc")
        {
          at = this.CONST.TagsToModify;
          // is SAP Session Token active? Find the function to modify the URL
          if (!!(bo = (null != (o = this._getRootWindow())) && "undefined" != typeof((this._getRootWindow()).oSAPSecu)))
            o = o.oSAPSecu;

          for (i = at.length-1; i >= 0; --i)
          {
            a = document.getElementsByTagName(at[i][0]);
            if (null != a && 0 < a.length)
            {
              for (j = a.length-1; j >= 0; j--) // get all nodes with this tag name -> array a
              {
                if (null != (el = a[j]))
                {
                  // set target
                  if (null != (tg = at[i][2]) && "WebGuiDoc" == el.getAttribute(tg))  // "WebGuiDoc" is the predefined target name for applications
                  {
                    el.setAttribute(tg, dname);
                  }
                  // modify URL
                  tg = at[i][1];
                  if (!!(addr = el.getAttribute(tg)))
                  {
                    addr.replace(/sapevent\:/i, "sapevent%3A");
                    if (bo)
                      addr = o.URLAppendToken(addr);
                    el.setAttribute(tg, addr);
                  }
                } // if (a[j])
              } // for (j)
            } // if (a)
          } // for (i)
        } // if (dn)
      },  // ._modifyTarget()


  _mimeTypeSupported : function ( in_htmlviewerId, in_mimetype, in_srcAttr )
      {
        var thehtmlviewer = document.getElementById(in_htmlviewerId),
            mimetypeL = in_mimetype.toLowerCase(),
            i, atypes;

        // if type or subtype is missing, try to show the document inplace
        if ((mimetypeL.charAt(0) == '/') || (mimetypeL.charAt(mimetypeL.length -1) == '/'))
        {
          thehtmlviewer.src = in_srcAttr;
          return;
        }

        // default fileextensions, gecko browser can display inplace
        for (i = 0, atypes = this.CONST.ClientStandardMimeTypes; i < atypes.length; i++)
        {
          if (mimetypeL == atypes[i])
          {
            thehtmlviewer.src = in_srcAttr;
            return;
          }
        }

        // fileextensions, installed plugins can display inplace
        for(i = 0; i < navigator.mimeTypes.length; i++)
        {
          if ((navigator.mimeTypes[i].enabledPlugin) && (navigator.mimeTypes[i].type == mimetypeL))
          {
            thehtmlviewer.src = in_srcAttr;
            return;
          }
        }
      },  // ._mimeTypeSupported()


  _resizeOnload : function ( in_id )
      {
        var el, par, boAbsSize;

        if (null != in_id && null != (el = document.getElementById(in_id)))
        {
          boAbsSize = ("%" === el.style.height.slice(-1)) ? false : true;
          if (null != (par = el.parentNode))
          {
            el.style.width  = par.clientWidth  + "px";
            el.style.height = par.clientHeight + "px";
          }
          else
          {
            el.style.width = el.style.height = "";
          }
          if (!webguiIsPopup && boAbsSize)
          {
            setTimeout('(function(){var el = document.getElementById("'+in_id+'"); if (null != el) {el.style.width = el.style.height = "99.9%";}})();', 500);
            setTimeout("oITSHtmlViewer._resizeOnload('"+in_id+"')", 2000);
          }
          // else does not work - on popups setting the height to 100% does not work properly :(
        }
      },  // ._resizeOnload()


  _loadSource : function ( in_id, in_url )
  {
    var el;

    if (null != in_id && null != in_url && null != (el = document.getElementById(in_id)))
    {
      el.src = in_url;
    }
  },  // ._loadSource()


  // Methods for HTMLviewer instances /

  _instanceCreate : function ( in_id, in_url )
  {
    var a = this._aInstances,
        i, l, o,
        boStartTimer = true;

    o = this._getInstance(in_id);
    if (null == o)  // new entry
    {
      o = a[a.length] = {id : in_id, url : in_url, oTimer : { load : null, resize : null} };

      eval(["window.htmlviewerResize_", in_id, " = function(){htmlviewerResizeOnload('", in_id, "');}"].join(""));
    }
    else
    {
      if (o.oTimer.load)        // timer not yet ran out
      {
        clearTimeout(o.oTimer.load);
        o.oTimer.load = null;

        o.url = in_url;      // replace former url
      }
      else
        boStartTimer = false;
    }

    if (boStartTimer)
    {
      if (null != window.CFWAddonFinalSizeHandler)
      {
        window.CFWAddonFinalSizeHandler("htmlviewerResize_" + in_id);
      }
      if (null != window.wgu_global_eventhandler.RegisterHandler)
      {
        window.wgu_global_eventhandler.RegisterHandler("load", "~htmlviewer", -3,
             function(){setTimeout("htmlviewerLoadSrc('"+in_id+"')", 450);});
        window.wgu_global_eventhandler.RegisterHandler("load", "~htmlviewer", -3,
             function(){setTimeout("htmlviewerResizeOnload('"+in_id+"')", 550);});
      }
      else
      {
        o.oTimer.load   = setTimeout(["htmlviewerLoadSrc(", in_id, ");"].join(""), 500);
        o.oTimer.resize = setTimeout(["htmlviewerResizeOnload(", in_id, ");"].join(""), 550);
      }
    }

    return this;

  },  // ._instanceCreate()

  _getInstance : function ( in_id )
  {
    var rv = null,
        i, l, a = this._aInstances;

    for (i = 0, l = a.length; i < l; i++)
    {
      if (in_id == a[i].id)
      {
        rv = a[i];
        break;
      }
    }

    return rv;
  },  // ._getInstance()

  _instanceMimeTypeSupported : function ( in_id, in_mimetype )
  {
    var rv = null,
        o = this._getInstance(in_id);
    if (null != o)
    {
      rv = this._mimeTypeSupported(in_id, in_mimetype, o.url);
    }
  },  // ._instanceMimeTypeSupported()

  _instanceLoadSource : function ( in_id )
  {
    var rv = null,
        o = this._getInstance(in_id);
    if (null != o)
    {
      rv = this._loadSource(in_id, o.url);
    }
  },  // ._instanceLoadSource()

  end : null
};


  // PUBLIC METHODS /////////////////////

  // Initialize this object
  htmlviewerInitialize        = function () { oITSHtmlViewer._initialize(); }

  // global (static) functions
  htmlviewerGetDocumentName   = function () { oITSHtmlViewer._getDocumentName(); }
  htmlviewerReplaceTarget     = function () { oITSHtmlViewer._modifyTarget(); }

  // create new HTMLviewer instance
  htmlviewerCreate            = function ( in_id, in_url)         { oITSHtmlViewer._instanceCreate(in_id, in_url); }

  // instance specific functions
  htmlviewerMimetypeSupported = function ( in_id, in_mimetype )   { oITSHtmlViewer._instanceMimeTypeSupported(in_id, in_mimetype); }
  htmlviewerLoadSrc           = function ( in_id )                { oITSHtmlViewer._instanceLoadSource(in_id); }
  htmlviewerResizeOnload      = function ( in_id )                { oITSHtmlViewer._resizeOnload(in_id); }


  oITSHtmlViewer._initialize();

}

// FIN htmlviewer.js //////////////////
