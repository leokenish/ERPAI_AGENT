function sapWD_Active_Comp_opendoc(Ctrl)
{
    Ctrl.object.invoke( loadXMLDoc( sapWD_Active_Comp_getCommandURL(Ctrl.id)));
}

function sapWD_Active_Comp_freeze(controlId)
{
    var Ctrl = document.getElementById(controlId);
    Ctrl.object.freeze();
}

function sapWD_Active_Comp_unfreeze(controlId)
{
    if (webguiIsActive())
    {
        var Ctrl = document.getElementById(controlId);
        Ctrl.object.unfreeze();
    }
}

function sapWD_Active_Comp_trace(controlId, className, methodName, severity, description)
{
    //alert(controlId + "," + className + "," + methodName + "," + severity + "," +  description);
    switch(severity)
    {
        case "0":
            return;
        case "1":
            traceLevel = "\nERROR ";
            break;
        case "2":
            traceLevel = "\nWARNING ";
            break;
        case "3":
            traceLevel = "\nINFO ";
            break;
    }
}
 
function sapWD_Active_Comp_createEvent(controlId, name)
{
    //alert("Calling createEvent(" + controlId + "," + name + ")" );	
}

function sapWD_Active_Comp_getCommandURL(controlId)
{
     var varname = controlId + 'commandurl';
     var url = eval(varname);
     return url;
}

function sapWD_Active_Comp_getDocumentURL(controlId)
{
     var varname = controlId + 'docurl';
     var url = eval(varname);
     return url;
}

function sapWD_Active_Comp_getsaveURL(controlId)
{
     var varname = controlId + 'saveurl';
     var url = eval(varname);
     return url;
}


function sapWD_Active_Comp_saveData(controlId, data, size)
{
     var varname = '~acf' + controlId + 'content';
     var dataelem = document.getElementById( varname);
     dataelem.value = data;
     varname = '~acf' + controlId + 'mod';
     dataelem = document.getElementById( varname);
     dataelem.value = 'Yes';
     varname = '~acf' + controlId + 'size';
     dataelem = document.getElementById( varname);
     dataelem.value = size.toString();
     document.webguiform.action = sapWD_Active_Comp_getsaveURL( controlId);
     document.webguiform.encoding = "text/plain";
     document.webguiform.submit();
}

function sapWD_Active_Comp_fireEvent(controlId)
{
 //   alert( "fireEvent " + controlId);
}

function sapWD_Active_Comp_notifyHooked(controlId)
{
//    alert( "notifyHooked " + controlId);
}

function sapWD_Active_Comp_createEvent(controlId, Event)
{
//    alert( "createEvent " + controlId + " event: " + Event);
}

function sapWD_Active_Comp_notifyLoad(controlId)
{
    var Ctrl = document.getElementById(controlId);
    sapWD_Active_Comp_opendoc( Ctrl);
}

function sapWD_Active_Comp_setAttribute(controlId, name, value)
{
    var cid = eval(controlId); 
    if ( name == 'dataSource')
    {
        try
        {
            raiseEvent( cid, 'ACFEvent', 'EventName=OnSave&Eventparam=X');
        }
        catch(err)
        {
            alert ("raising ACFEvent failed");
        }
    }
}

function loadXMLDoc(url) {
    // branch for native XMLHttpRequest object
    if (window.XMLHttpRequest) {
        req = new XMLHttpRequest();
        req.open("GET", url, false);
        req.send(null);
    // branch for IE/Windows ActiveX version
    } else if (window.ActiveXObject) {
        req = new ActiveXObject("Microsoft.XMLHTTP");
        if (req) {
            req.open("GET", url, false);
            req.send(null);
        }
    }
    return req.responseText;
}

function outerControlID( controlId)
{
    var split = controlId.indexOf( "inner");
    if (split > 1)
        return controlId.substr(0, split);
    return "";
}