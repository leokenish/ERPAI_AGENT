
// ============================================================================
// Perfomance Counters
// ============================================================================

function webguiPerfStart(objectName, objectClass)
{
	if (webguiPerfOn)
	{
		var
			o,
			now = new Date();

		if (webguiPerfObjects == null)
			webguiPerfObjects = new Array();

		o = new Object();
		o.objectName = objectName;
		o.objectClass = objectClass;
		o.startTime = now.valueOf();
		webguiPerfObjects[webguiPerfObjects.length] = o;
	}
}

function webguiPerfStop(objectName)
{
	if (webguiPerfOn)
	{
		var
			i,
			o = null,
			now = new Date();

		if (webguiPerfObjects != null)
		{
			for (i = 0; i < webguiPerfObjects.length; i++)
			{
				o = webguiPerfObjects[i];
				if (o.objectName == objectName)
				{
					o.endTime = now.valueOf();
					break;
				}
			}
		}
	}
}

function webguiPerfGetObjectHTML(idx)
{
	if (webguiPerfOn)
	{
		var o = null;
              var oclasstext;
              var onametext;
              var line;

		if (webguiPerfObjects != null && idx < webguiPerfObjects.length)
		{
			o = webguiPerfObjects[idx];
                     line = "<tr> <td align=left>" + o.objectClass + "</td>" +
                                 "<td align=left>" + o.objectName + "</td>" +
                                 "<td align=right>" + (o.endTime - o.startTime) + "</td> </tr>"
			return line;
		}
	}
	return "";
}

function webguiPerfGetHTML()
{
	var result = "<h1>Start-Stop() Performance</h1>";
       result += "<table border=2>";
	if (webguiPerfOn && webguiPerfObjects != null)
	{
              // table headers
              result += "<tr> <th align=left>Class</th> <th align=left>Instance</th> <th align=left>Responstime(ms)</th> </tr>"
		for (i = 0; i < webguiPerfObjects.length; i++)
		{
		    result += webguiPerfGetObjectHTML(i);
		}
	}
       result += "</table>";
	return result;
}

function webguiPerfDisplay()
{
    var PerfWindow;
    var PerfPage;
    if (webguiPerfOn && webguiPerfObjects != null)
    {
        PerfPage = webguiMimeURL + "/system/" + webguiTheme + "/page/perfdisplay.html";
        PerfWindow = open(PerfPage, "PerfWindow");
    }
    else
    {
        alert("Webgui Start/Stop-Performance disabled.\n\r Activate with url parameter ~WEBGUI_PERF_ON=1");
    }
}

function webguiPerfGetData()
{
	// Collect performance data
	if (document.webguiform)
	{
		var
			now = new Date();

		if (document.webguiform.elements[formWebguiRenderTime] &&
			document.webguiform.elements[formWebguiRenderTime].name.indexOf("~webgui")==0)
		{
			document.webguiform.elements[formWebguiRenderTime].value =
				now.valueOf() - webguiStartDate.valueOf();

			// window.status = "t(render) = " + document.webguiform.elements[formWebguiRenderTime].value;
		}

		if (document.webguiform.elements[formWebguiRequestTime] &&
			document.webguiform.elements[formWebguiRequestTime].name.indexOf("~webgui")==0)
		{
			if (document.webguiform.elements[formWebguiStartRequestTime] &&
				document.webguiform.elements[formWebguiStartRequestTime].name.indexOf("~webgui")==0)
			{
				if (document.webguiform.elements[formWebguiStartRequestTime].value > 0)
				{
					document.webguiform.elements[formWebguiRequestTime].value =
						now.valueOf() - document.webguiform.elements[formWebguiStartRequestTime].value;

					// window.status += " t(request) = " + document.webguiform.elements[formWebguiRequestTime].value;
				}
			}
		}
	}
}


