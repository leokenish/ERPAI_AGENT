var its_SBArrayLength = 0;
var its_SCArrayLength = 0;
var its_scrollContainerMgr = null;


function sbEvent(x, y, target, button, keycode)
{
  // Support existing calls without new; keep each held-arrow event isolated.
  if (!(this instanceof sbEvent)) return new sbEvent(x, y, target, button, keycode);
  this.clientX = x;
  this.clientY = y;
  this.srcElement = target;
  this.target = target;
  this.type = "mousedown";
  this.button = its_ua.gecko ? (button == 1 ? 0 : (button == 2 ? 2 : (button == 4 ? 1 : button))) : button;
  this.which =button;
  this.keyCode = keycode;

  this.stopPropagation = function() {};
  this.preventDefault = function() {};
  return this;
}

/** <its_scrollContainerManager::its_scrollContainerManager>
  *
  *   constructor for the class its_scrollContainerManager
  *     its_scrollContainerManager encapsulates all interactive functions and
  *     actions on a scrollbar. the data of the particular scrollbar is thereby hold
  *     in the extern class its_scrollBarObject.
  *
  *   params: scrollbar object
  */
function its_scrollContainerManager(obj)
{
  // object that keeps data during an resize event
  this.sbTimeoutPtr = null;
  this.sbTimeout = null;
  this.eventFired = false;
  this.mousePressed = false;
  window.its_SBArray = new Array();
  window.its_SCArray = new Array();

  if (window.wgu_global_eventhandler)
    window.wgu_global_eventhandler.RegisterHandler( "load", "~body", 1000, SBMgrRegisterResize, true);

}
// </its_scrollContainerManager::its_scrollContainerManager>


/** <fNone>
  *
  *   cancels any event
  *
  *   params: scrollbar object
  */
function fNone(evt)
{
  var e = new its_event(evt);
  if (e)
  {
    e.cancel();
  }
  return false;
}


its_scrollContainerManager.prototype.keyDown = function(e, obj)
{
  var evt = new its_event(e);

  if ( e.keyCode == 33 || e.keyCode == 34 || (e.keyCode == 35 && e.ctrlKey==1 ) || (e.keyCode == 36 && e.ctrlKey==1))
  {

      var new_evt = sbEvent(evt.clientX, evt.clientY, e.target, e.button, e.keyCode);
      obj.scrollHandler.buttonHold = "true";
      switch (evt.keyCode)
      {
          case 33:
            this.clickPrevPage(evt, obj);
            break;
          case 34:
            this.clickNextPage(evt, obj);
            break;
          case 35:
            this.clickLastPage(evt, obj);
            break
          case 36:
            this.clickFirstPage(evt, obj);
            break
          default:
            return true;
            break;
      }

      if (evt)
      {
        evt.cancel();
      }
      return false;
  }
  else
    return true;
}


its_scrollContainerManager.prototype.keyUp = function(e, obj)
{
  var evt = new its_event(e);

  obj.scrollHandler.buttonHold = "false";

  this.toolTipTimeout = setTimeout("window.its_SBArray[" + obj.index + "].hideToolTip()", 700);


  if (evt)
  {
    evt.cancel();
  }
  return false;
}

/** </its_scrollContainerManager::init>
   *
   */
its_scrollContainerManager.prototype.init = function(obj)
{
    obj.index = its_SBArrayLength;
    window.its_SBArray[its_SBArrayLength++] = obj;

    // assign click event handler
    fClickPrev = function(evt) { its_scrollContainerMgr.clickPrev(evt, obj); };
    //its_eMgr.registerEvent(obj.buttonPrev, "click", fClickPrev);
    fClickNext = function(evt) { its_scrollContainerMgr.clickNext(evt, obj); };
    //its_eMgr.registerEvent(obj.buttonNext, "click", fClickNext);

    its_eMgr.registerEvent(obj.buttonPrev, "dblclick", fNone);
    its_eMgr.registerEvent(obj.buttonNext, "dblclick", fNone);
    its_eMgr.registerEvent(obj.sliderArea, "dblclick", fNone);
    its_eMgr.registerEvent(obj.slider, "dblclick", fNone);


    // assign click event handler
    fClick = function(evt) { its_scrollContainerMgr.click(evt, obj); };
    //its_eMgr.registerEvent(obj.sliderArea, "click", fClick);

    // assign mousedown event handler
    fMousedown = function(evt) { its_scrollContainerMgr.mousedown(evt, obj); };
    its_eMgr.registerEvent(obj.scrollbarTable, "mousedown", fMousedown);
    // assign mousedown event handler
    fMouseup = function(evt) { its_scrollContainerMgr.mouseup(evt, obj); };
    its_eMgr.registerEvent(obj.scrollbarTable, "mouseup", fMouseup);
//    fMouseout = function(evt) { its_scrollContainerMgr.mouseout(evt, obj); };
//    its_eMgr.registerEvent(obj.scrollbarTable, "mouseout", fMouseout);
    obj.mouseup = fMouseup;
    obj.mousedown = fMousedown;

    if (obj.direction == "v")
    {
        // assign mousewheel event handler
        fMousewheel = function(evt) { its_scrollContainerMgr.mousewheel(evt, obj); };
        fkeyDown = function(evt) { its_scrollContainerMgr.keyDown(evt, obj); };
        fkeyUp = function(evt) { its_scrollContainerMgr.keyUp(evt, obj); };
        obj.mousewheel = fMousewheel;
        obj.keyDown = fkeyDown;
        obj.keyUp = fkeyUp;
        if ("onmousewheel" in document.documentElement || !its_ua.gecko)
        {
            its_eMgr.registerEvent(document.getElementById(obj.scrollHandler.id), "mousewheel", fMousewheel);
        }
        else
        {
            its_eMgr.registerEvent(document.getElementById(obj.scrollHandler.id), "DOMMouseScroll", fMousewheel);
        }
        its_eMgr.registerEvent(document.getElementById(obj.scrollHandler.id), "keydown", fkeyDown);
        its_eMgr.registerEvent(document.getElementById(obj.scrollHandler.id), "keyup", fkeyUp);
    }
};
// </its_scrollContainerManager::init>


/** <its_scrollContainerManager::registerMovement>
  *
  *   registers mouse movement event handler to move the slider when the user holds down the mouse on the slider
  *
  *   params: scrollbar object
  */
its_scrollContainerManager.prototype.registerMovement = function(obj)
{
  // assign mouseup event handler
  fMouseup = function(evt) { its_scrollContainerMgr.mouseup(evt, obj); };

  // assign mousemove event handler
  fMousemove = function(evt) { its_scrollContainerMgr.mousemove(evt, obj); };


  obj.mousemove = fMousemove;
  obj.mouseup = fMouseup;

  its_eMgr.registerEvent(document.documentElement, "mousemove", fMousemove);
  its_eMgr.registerEvent(document.documentElement, "mouseup", fMouseup);

  if ( document.getElementById(obj.scrollHandler.id) && typeof document.getElementById(obj.scrollHandler.id).style.MozUserSelect!="undefined") //Firefox route
    document.getElementById(obj.scrollHandler.id).style.MozUserSelect="none";

  its_eMgr.registerEvent(document.body, "selectstart", this.nope);
  its_eMgr.registerEvent(document.body, "dragstart", this.nope);


};

/** <its_scrollContainerManager::unregisterMovement>
  *
  *   unregisters mouse movement when the user releases the mouse on the slider
  *
  *   params: scrollbar object
  */
its_scrollContainerManager.prototype.unregisterMovement = function(obj)
{
  its_eMgr.unregisterEvent(document.documentElement, "mousemove", obj.mousemove);
  its_eMgr.unregisterEvent(document.documentElement, "mouseup", obj.mouseup);
  its_eMgr.unregisterEvent(document.body, "selectstart", this.nope);
  its_eMgr.unregisterEvent(document.body, "dragstart", this.nope);

  if ( document.getElementById(obj.scrollHandler.id) && typeof document.getElementById(obj.scrollHandler.id).style.MozUserSelect!="undefined") //Firefox route
    document.getElementById(obj.scrollHandler.id).style.MozUserSelect="";

  obj.mousemove = null;

};

/** <its_SBToolTip::its_SBToolTip>
  *
  *   constructor for scrollbar tooltip object
  *   tooltips are hidden per default
  *
  *   params: scrollbar object
  */
function its_SBToolTip(cntrl)
{
  containerPosX = 0;
  containerPosY = 0;
  containerWidth = 0;
  containerHeight = 0;

  this.slider = cntrl.slider;

  this.body1 = document.createElement("DIV");
  this.body2 = document.createElement("DIV");
  this.body1.className = "SBToolTip";
  this.body2.className = "SBToolTip";
  cntrl.slider.appendChild(this.body1);
  cntrl.slider.appendChild(this.body2);

  if (cntrl.direction == "v")
  {
    if (!isBidiRTL())
    {
      this.body1.style.right = 20;
      this.body1.style.top = -16;
      this.body2.style.right = 20;
      this.body2.style.bottom = -16;
    }
    else
    {
      this.body1.style.left = 20;
      this.body1.style.top = -16;
      this.body2.style.left = 20;
      this.body2.style.bottom = -16;
    }
  }
  else
  {
    if (!isBidiRTL())
    {
      this.body1.style.left  = -16;
      this.body1.style.bottom = 20;
      this.body2.style.right = -16;
      this.body2.style.bottom = 20;
    }
    else
    {
      this.body1.style.right  = -16;
      this.body1.style.bottom = 20;
      this.body2.style.left   = -16;
      this.body2.style.bottom = 20;
    }
  }

  this.body1.style.visibility = "hidden";
  this.body2.style.visibility = "hidden";

  var modalNo = "";
  if (webguiIsPopup)
  {
    if (document.getElementById("webguiPopup"))
    {
      containerPosY = dom_getYPos(document.getElementById("webguiPopup"));
      containerPosX = dom_getXPos(document.getElementById("webguiPopup"));
    }
    else
    {
      modalNo = webguiModalNo;
    }
  }

  var container = document.getElementById("webguiBody" + modalNo);
  if (container)
  {
    containerWidth = container.clientWidth;
    containerHeight = container.clientHeight;
  }

  this.contX = containerPosX;
  this.contY = containerPosY;
  this.contWidth = containerWidth;
  this.contHeight = containerHeight;
}

/** <its_SBToolTip::show>
  *
  *   make tooltip visible.
  *
  *   params: text1   text to show on first tooltip
  *           text2   text to show on second tooltip
  */
its_SBToolTip.prototype.show = function(text1, text2)
{
  if (isBidiRTL()) return;
  if (text1 !== "" && text2 !== "")
  {
    this.body1.innerHTML = text1;
    this.body2.innerHTML = text2;
    this.body1.style.visibility = "visible";
    this.body2.style.visibility = "visible";
    this.body1.style.display = "block";
    this.body2.style.display = "block";
  }

};

/** <its_SBToolTip::show>
  *
  *   hide tooltip.
  *
  */
its_SBToolTip.prototype.hide = function()
{
  if (isBidiRTL()) return;
    this.body1.style.visibility = "hidden";
    this.body2.style.visibility = "hidden";
    this.body1.style.display = "none";
    this.body2.style.display = "none";
};

/** <its_scrollContainerObject::its_scrollContainerObject>
  *
  *   constructor for the class its_scrollContainerObject
  *     its_scrollContainerObject represens the scrollcontainer with scrollArea and scrollbars
  *     the data of the particular scrollbar is thereby hold
  *     in the extern class its_scrollBarObject.
  *
  *   params: id                  container id
  *           vScrollbar          vertical scrollbar object
  *           hScrollbar          horizontal scrollbar object
  *           overflowX           indicator for horizontal overflow, can be {"none/hidden/visible"}
  *           overflowX           indicator for horizontal overflow, can be {"none/hidden/visible"}
  *           resizable           boolean, specifies if the container has to adjust itself to the parent
  */
function its_scrollContainerObject(id,  vScrollbar, hScrollbar, overflowX, overflowY, resizable)
{
  this.outerDiv = document.getElementById(id );
  this.tableCell = document.getElementById(id + "_scrollAreaTD");
  this.table = document.getElementById(id + "_scrollContainerStructure");
  this.scrollDiv = document.getElementById(id + "_scrollArea");
  this.hScrollBarRow = hScrollbar.parentContainer.parentNode;
  this.vScrollBarCol = vScrollbar.parentContainer.parentNode;
  this.vScrollBar = vScrollbar;
  this.hScrollBar = hScrollbar;
  this.overflowX = overflowX;
  this.overflowY = overflowY;
  this.resizable = resizable;

  this.scrollAreaAbsPos = 0;


  window.its_SCArray[its_SCArrayLength++] = this;

  return this;
}

/** <its_scrollContainerObject::resize>
  *
  *   resizing the container to fit the parent if specified,
  *   consider the need of scrollbars and adjust the size of
  *   scrollArea pane for scrollbar display
  *   trigger calculation and display of the scrollbars
  *
  */
its_scrollContainerObject.prototype.resize = function()
{
  var outerWidth = 0;
  var outerHeight= 0;

  /* move the outer div back, if the browser scrolled the position*/
  if (this.outerDiv.scrollLeft != 0)
    this.outerDiv.scrollLeft = 0;
  if (this.outerDiv.scrollTop != 0)
    this.outerDiv.scrollTop = 0;

  /* find out, if scrollbars present or have to be rendered*/
  var vscroll_required = false;
  var hscroll_required = false;
  /* this is a hack to find out the true size of the scroll pane
     absolut positioned divs with no overflow don't reveal the size of inside elements
     so we have to set the overflow to scroll, retrieve the size and set it back to hidden.
  */
  var prevHeight = this.scrollDiv.style.height;

  this.scrollDiv.style.width="16px";
  this.scrollDiv.style.height="16px";

  this.scrollDiv.style.overflow = "scroll";
  var scrollHeight = this.scrollDiv.scrollHeight;
  var scrollWidth = this.scrollDiv.scrollWidth;
  this.scrollDiv.style.overflow = "hidden";
  this.scrollDiv.style.height = scrollHeight;
  this.scrollDiv.style.width = scrollWidth;

  this.scrollDiv.style.height = prevHeight;


  //alert(scrollWidth + "   " + scrollHeight + "   ");
  if (this.resizable == "true")
  {
    if (this.outerDiv.parentNode.clientWidth == 0)
      outerWidth = this.outerDiv.parentNode.parentNode.clientWidth;
    else
      outerWidth = this.outerDiv.parentNode.clientWidth;

    if (this.outerDiv.parentNode.clientHeight == 0)
      outerHeight = this.outerDiv.parentNode.parentNode.clientHeight;
    else
      outerHeight = this.outerDiv.parentNode.clientHeight;
  }
  else
  {
      outerWidth = this.outerDiv.clientWidth;
      outerHeight = this.outerDiv.offsetHeight;
  }

  /* if resize indicated adjust container size */
  if (this.resizable == "true")
  {
      this.outerDiv.style.width = outerWidth;
      this.outerDiv.style.height = outerHeight;
      this.table.style.width = outerWidth;
      this.table.style.height = outerHeight;
  }

  var vSHdl = this.vScrollBar.scrollHandler;
  var hSHdl = this.hScrollBar.scrollHandler;

  document.getElementById(vSHdl.id + "_contcol").width = outerWidth;

  /* see if:
      scrollbar is local and container height is greater than scroll content height
      scrollbar is "backend-style" and scrollbar total range is greater than visual range
      scrollbar is not needed but noHide is set to active
  */
  if ((this.vScrollBar.local && (this.table.offsetHeight < this.scrollDiv.clientHeight))
      || (!this.vScrollBar.local && (vSHdl.totalRange > vSHdl.visRange))
      || ((vSHdl.totalRange <= vSHdl.visRange)  && vSHdl.noHide))
  {
    vscroll_required = true;
  }

  if (this.overflowY == "hidden")
  {
    vSHdl.mode = "hidden";
    vShdl.disabled = "true";
    vscroll_required = false;
  }

    /* see if:
        scrollbar is local and container width is greater than scroll content width
        scrollbar is "backend-style" and scrollbar total range is greater than visual range
        scrollbar is not needed but noHide is set to active
    */
  if (this.hScrollBar.local && (this.table.offsetWidth < this.scrollDiv.offsetWidth)
      || (!this.hScrollBar.local && (hSHdl.totalRange > hSHdl.visRange))
      || ((hSHdl.totalRange <= hSHdl.visRange)  && hSHdl.noHide))
  {
    hscroll_required = true;
  }

  if (this.overflowX == "hidden")
  {
    hSHdl.mode = "hidden";
    hscroll_required = false;
    hShdl.disabled = "true";
  }

    /* doublecheck if scrollbars do affect each other
    */
  if ((!hscroll_required && vscroll_required) && this.hScrollBar.local && this.overflowX == "hidden")
    if ((this.table.offsetWidth - 16) < this.scrollDiv.offsetWidth )
  {
      hscroll_required = true;
  }

  if ((!vscroll_required && hscroll_required) && this.vScrollBar.local && !this.overflowY == "hidden")
    if ((this.table.offsetHeight - 16) < this.scrollDiv.offsetHeight )
  {
    vscroll_required = true;
  }

    /* checks are done, resize the panes for scrollbar display
     */
  if (vscroll_required)
  {
      if (outerWidth > 16)
      {
        document.getElementById(vSHdl.id + "_contcol").width = outerWidth - 16;
        document.getElementById(vSHdl.id + "_vsbcol").width = 16;
      }
      if (hSHdl.mode == "local")
        hSHdl.visRange -= 16;
  }
  else
  {
    this.tableCell.style.width = outerWidth;
    this.scrollDiv.parentNode.style.width = outerWidth;
    this.scrollDiv.style.top = "0px";
    vSHdl.mode = "hidden";
    vSHdl.disabled = "true";
  }

  if (hscroll_required)
  {
      if (outerHeight > 16)
      {
        this.tableCell.style.height = outerHeight - 16;
        this.scrollDiv.parentNode.style.height = outerHeight - 16;
        this.hScrollBarRow.style.display = "";
      }
      if (vSHdl.mode == "local")
        vSHdl.visRange -= 16;

      if (this.hScrollBar.local)
        hSHdl.mode = "local";
      hSHdl.disabled = "false";

  }
  else
  {
    this.scrollDiv.parentNode.style.height = outerHeight;
    this.tableCell.style.height = outerHeight;
    this.scrollDiv.style.left = "0px";
    hSHdl.mode = "hidden";
    hSHdl.disabled = "true";
  }

  /* trigger scrollbar resize*/
  its_hScrollBarSizeHandler(this.hScrollBar);
  its_vScrollBarSizeHandler(this.vScrollBar);

  if (this.tableCell.parentNode.scrollLeft != 0)
    this.tableCell.parentNode.scrollLeft = 0;
}

/** <its_scrollContainerObject::resizeWithValues>
  *
  *   resizing the container to fit the parent if specified,
  *   consider the need of scrollbars and adjust the size of
  *   scrollArea pane for scrollbar display
  *   trigger calculation and display of the scrollbars
  *
  */
its_scrollContainerObject.prototype.resizeWithValues = function(currPosH,
                                                                firstPosH,
                                                                visRangeH,
                                                                totalRangeH,
                                                                currPosV,
                                                                firstPosV,
                                                                visRangeV,
                                                                totalRangeV)
{
    if (currPosH != -1)
        this.hScrollBar.currPos = currPosH;
    if (firstPosH != -1)
        this.hScrollBar.firstPos = firstPosH;
    if (visRangeH != -1)
        this.hScrollBar.visRange = visRangeH;
    if (totalRangeH != -1)
        this.hScrollBar.totalRange = totalRangeH;
    if (currPosV != -1)
        this.vScrollBar.currPos = currPosV;
    if (firstPosV != -1)
        this.vScrollBar.firstPos = firstPosV;
    if (visRangeV != -1)
        this.vScrollBar.visRange = visRangeV;
    if (totalRangeV != -1)
        this.vScrollBar.totalRange = totalRangeV;

    this.resize();
}


/** <its_scrollBarObject::its_scrollBarObject>
    *
  * constructor for object its_scrollBarObject
  * holds all the relevant data for the scrollbar
    * params:
    *    scrollHandler            scrollHandler for the scrollbar,
    *    parentContainer          parent container object pointer, normally <td> on scroll container
    *    sliderObj                slider pointer
    *    buttonPrevObj            button "previous"
    *    buttonNextObj            button "next"
    *    sliderAreaObj            slider area pointer
    *    scrollbarTableObj        table pointer
*/
function its_scrollBarObject(scrollHandler,
                             parentContainer,
                             sliderObj,
                             buttonPrevObj,
                             buttonNextObj,
                             sliderAreaObj,
                             scrollbarTableObj)
{
  this.parentContainer = parentContainer;
  this.direction = scrollHandler.direction;
  // TG
  this.wheelDelay = scrollHandler.wheelDelay;
  this.firstPos = scrollHandler.firstPos;

  this.disabled = scrollHandler.disabled;
  this.noHide = (scrollHandler.noHide =="true" ? true : false);
  this.enableToolTip = scrollHandler.enableToolTip;
  if (scrollHandler.mode == "local")
  {
    this.local = true;
    this.enableToolTip = false;
  }
  else if (scrollHandler.mode == "hidden")
  {
    this.local = true;
    this.disabled = true;
    this.enableToolTip = false;
  }
  else
  {
    this.local = false;
    this.enableToolTip = true;
  }

  this.index = -1;

  this.scrollHandler = scrollHandler;
  this.slider = sliderObj;
  this.buttonPrev = buttonPrevObj;
  this.buttonNext = buttonNextObj;
  this.sliderArea = sliderAreaObj;
  this.scrollbarTable = scrollbarTableObj;

  if (scrollHandler.direction == "v")
  {
    this.moveHandler  = function(evt) {its_vScrollBarMoveHandler(evt, this);}
    this.resizeHandler = function() { its_vScrollBarSizeHandler(this); };
  }
  else
  {
    this.moveHandler  = function(evt) {its_hScrollBarMoveHandler(evt, this)};
    this.resizeHandler = function() { its_hScrollBarSizeHandler(this); };
  }

  this.tooltip = new its_SBToolTip(this);

  this.mousewheel = null;
  this.mouseup = null;
  this.mousemove = null;
  this.mynone = null;

  this.sliderAbsPos = 0;
  this.sliderAreaAbsPos = 0;


  return this;

}


/** <its_vScrollBarSizeHandler>
    *
  * size handler for a vertical scrollbar object
  * resizes and shows the scrollbar
    * params:
    *    cntrl    pointer to a scrollbar object
*/
function its_vScrollBarSizeHandler(cntrl)
{
    var SHdl = cntrl.scrollHandler;
    if (cntrl.local)
    {
        SHdl.totalRange = SHdl.targetArea.offsetHeight;
        if (SHdl.visRange == 0)
          SHdl.visRange = ( cntrl.parentContainer.offsetHeight == 0) ? SHdl.targetArea.offsetHeight : cntrl.parentContainer.offsetHeight;
    }
    if ( cntrl.sliderArea.offsetHeight == 0 )
    {
        if ( ( SHdl.targetArea.offsetHeight - 32 ) > 0 )
        {
            cntrl.sliderArea.style.height = SHdl.targetArea.offsetHeight - 32;
        }
    }

    if (SHdl.totalRange <= SHdl.visRange || SHdl.totalRange === 0 || SHdl.mode == "hidden")
    {
       cntrl.hide();
    }
    else
    {
        cntrl.buttonPrev.style.filter = "";
        cntrl.buttonNext.style.filter = "";
        if (document.getElementById(SHdl.id + "_vsbcol"))
            document.getElementById(SHdl.id + "_vsbcol").style.width = "16px";
        cntrl.parentContainer.style.width = "16px";
        cntrl.calcFactor = (cntrl.sliderArea.offsetHeight)/(SHdl.totalRange);

        if (cntrl.calcFactor < 0)
          cntrl.calcFactor = 0;

        if (Math.round((SHdl.visRange)*cntrl.calcFactor) < 5)
        {
            cntrl.calcFactor = (cntrl.sliderArea.offsetHeight - 5)/(SHdl.totalRange);
            cntrl.slider.style.height = 5;
        }
        else
            cntrl.slider.style.height = Math.round((SHdl.visRange)*cntrl.calcFactor);

        cntrl.physSize = cntrl.parentContainer.offsetHeight;
        cntrl.physScrollPos = Math.round((SHdl.currPos - SHdl.offset)*cntrl.calcFactor);

        cntrl.slider.style.top = cntrl.physScrollPos;
        if (cntrl.local)
            SHdl.targetArea.style.top = (-SHdl.currPos) + "px";

      cntrl.sliderAreaAbsPos = dom_getYPos(cntrl.sliderArea);
      cntrl.scrollbarTable.style.visibility ="visible";
      cntrl.slider.style.display = "";

    }
}

/** <its_hScrollBarSizeHandler>
    *
  * size handler for a horizontal scrollbar object
  * resizes and shows the scrollbar
    * params:
    *    cntrl    pointer to a scrollbar object
*/
function its_hScrollBarSizeHandler(cntrl)
{
    var SHdl = cntrl.scrollHandler;
    if (cntrl.local)
    {
        SHdl.totalRange = SHdl.targetArea.offsetWidth;
        SHdl.visRange = parseInt(document.getElementById(SHdl.id + "_contcol").width);
    }

    if (SHdl.totalRange <= SHdl.visRange || SHdl.totalRange === 0  || SHdl.visRange ===0 || SHdl.mode == "hidden")
    {
      cntrl.hide();
    }
    else
    {
        cntrl.buttonPrev.style.filter = "";
        cntrl.buttonNext.style.filter = "";
        cntrl.parentContainer.parentNode.style.display = "";
        cntrl.slider.style.display = "";

        //cntrl.calcFactor = (cntrl.sliderArea.clientWidth)/(SHdl.totalRange + SHdl.offset);
        cntrl.calcFactor = (document.getElementById(SHdl.id + "_contcol").width - 32)/(SHdl.totalRange);
        if (cntrl.calcFactor < 0)
          cntrl.calcFactor = 0;

        cntrl.physSize = cntrl.parentContainer.offsetWidth;
        cntrl.physScrollPos = Math.round((SHdl.currPos - SHdl.offset)*cntrl.calcFactor);

        if (isBidiRTL())
        {
          cntrl.slider.style.right = cntrl.physScrollPos;
          if (cntrl.local)
              SHdl.targetArea.style.right = (-SHdl.currPos) + "px";
        } else {
          cntrl.slider.style.left = cntrl.physScrollPos;
          if (cntrl.local)
              SHdl.targetArea.style.left = (-SHdl.currPos) + "px";
        }

        cntrl.sliderAreaAbsPos = dom_getXPos(cntrl.sliderArea);
        cntrl.slider.style.width = Math.round((SHdl.visRange)*cntrl.calcFactor);
        cntrl.slider.style.display = "";

   }
}

/** <its_vScrollBarMoveHandler>
    *
  * move handler for a vertical scrollbar object
  * moves the slider
    * params:
    *    cntrl    pointer to a scrollbar object
*/
function its_vScrollBarMoveHandler(evt, cntrl)
{
  var pos = evt.clientY - cntrl.sliderAreaAbsPos - cntrl.slider.currentClickOffset;

  cntrl.scrollToPixels(pos);
  cntrl.showToolTip("", "");
}

/** <its_hScrollBarMoveHandler>
    *
  * move handler for a horizontal scrollbar object
  * moves the slider
    * params:
    *    cntrl    pointer to a scrollbar object
*/
function its_hScrollBarMoveHandler(evt, cntrl)
{
  var pos = 0;
  if (!isBidiRTL())
    pos = evt.clientX - cntrl.sliderAreaAbsPos - cntrl.slider.currentClickOffset;
  else
    pos = cntrl.sliderArea.offsetWidth - (evt.clientX - cntrl.sliderAreaAbsPos + cntrl.slider.currentClickOffset);

  cntrl.scrollToPixels(pos);
  cntrl.showToolTip("", "");
}


/** <its_scrollBarObject::scrollToPixels>
    *
  * positioning the scroll pane to a specified position in pixels if the scrollbar is local
  * the slider postition will be set automatically
  *
    * params:
    *    posPixel    position in pixels
*/
its_scrollBarObject.prototype.scrollToPixels = function (posPixel)
{
  var pos = Math.round(posPixel/this.calcFactor);
  this.scrollTo(pos);
};


/** <its_scrollBarObject::moveSliderTo>
    *
  * positioning the scroll pane to a specified position in pixels if the scrollbar is local
  * the slider postition will be set automatically
  *
    * params:
    *    posPixel    position in pixels
*/
its_scrollBarObject.prototype.moveSliderTo = function (posPixel)
{
  // The pending callback must retain this control even if another control moves.
  var SHdl = this.scrollHandler;
  if (this.direction == "v")
  {
    if (posPixel < 0)
      posPixel = 0;
    else
    {
      // Read dimensions once per call, before writing; never cache across resize.
      var sliderHeight = this.slider.offsetHeight;
      var sliderAreaHeight = this.sliderArea.offsetHeight;
      if (posPixel + sliderHeight > sliderAreaHeight)
        posPixel = sliderAreaHeight - sliderHeight;
    }

    // Skip an identical pixel style only. Keep every callback below synchronous.
    if (this.slider.style.top !== posPixel + "px")
      this.slider.style.top = posPixel + "px";
  }
  else
  {
    if (posPixel < 0)
      posPixel = 0;
    else
    {
      var sliderWidth = this.slider.offsetWidth;
      var sliderAreaWidth = this.sliderArea.offsetWidth;
      if (posPixel + sliderWidth > sliderAreaWidth)
        posPixel = sliderAreaWidth - sliderWidth;
    }
    if (isBidiRTL())
    {
      if (this.slider.style.right !== posPixel + "px")
        this.slider.style.right = posPixel + "px";
    }
    else
    {
      if (this.slider.style.left !== posPixel + "px")
        this.slider.style.left = posPixel + "px";
    }
  }

  if (this.local)
  {
    if (this.direction == "h")
      if (isBidiRTL())
      {
        if (SHdl.targetArea.style.right !== (-SHdl.currPos) + "px")
          SHdl.targetArea.style.right = (-SHdl.currPos) + "px";
        var tableCell = document.getElementById(SHdl.id + "_scrollAreaTD");
        if (tableCell)
          tableCell.parentNode.scrollLeft = 0;
      }
      else
      {
        if (SHdl.targetArea.style.left !== (-SHdl.currPos) + "px")
          SHdl.targetArea.style.left = (-SHdl.currPos) + "px";
      }
    else
    {
      if (SHdl.targetArea.style.top !== (-SHdl.currPos) + "px")
        SHdl.targetArea.style.top = (-SHdl.currPos) + "px";
    }

  }

  if (this.local)
    SHdl.onSliderMove(SHdl.currPos);
  else
  {
    if (its_scrollContainerMgr.sbTimeout != null)
      window.clearTimeout(its_scrollContainerMgr.sbTimeout);
    its_scrollContainerMgr.sbTimeout = null;
    scrollSubmitTemp = function() { SHdl.onSliderMoveTo(SHdl.currPos); }
    its_scrollContainerMgr.sbTimeout = window.setTimeout("scrollSubmitTemp()", 350);
  }
};


/** <its_scrollBarObject::scrollTo>
    *
  * positioning the slider to a specified position in user coordinates
  * the scroll pane postition will be set automatically if the scrollbar is local
  *
    * params:
    *    cntrl    pointer to a scrollbar object
*/
its_scrollBarObject.prototype.scrollTo = function (pos)
{
  var SHdl = this.scrollHandler;
  if (pos + SHdl.visRange > SHdl.totalRange && (SHdl.visRange < SHdl.totalRange))
      SHdl.currPos = SHdl.totalRange - SHdl.visRange + SHdl.offset;
  else if (pos < SHdl.offset)
      SHdl.currPos = SHdl.offset;
  else
      SHdl.currPos = pos;

  var posPixel = Math.round((SHdl.currPos - SHdl.offset)*this.calcFactor);
  if (isNaN(posPixel))
    posPixel = 0;

  this.moveSliderTo(posPixel);

};
/* end of <its_scrollBarObject::scrollTo> */

/** <its_scrollBarObject::showToolTip>
    *
  * shows tooltip for the scrollbar
  *
    * params:
    *    text1    text to show
    *    text2    text to show
*/
its_scrollBarObject.prototype.showToolTip = function(text1, text2)
{
  var SHdl = this.scrollHandler;
  if (this.enableToolTip)
  {
    if (text1 === "")
    {
      text1 = SHdl.currPos;
    }
    if (text2 === "")
    {
        text2 = SHdl.visRange + SHdl.currPos - SHdl.offset;
    }

    this.tooltip.show(text1, text2);
  }
};
/* end of <its_scrollBarObject::showToolTip> */

/** <its_scrollBarObject::hideToolTip>
    *
  * hides tooltip for a scrollbar
  *
    * params:
*/
its_scrollBarObject.prototype.hideToolTip = function()
{
  if (this.enableToolTip)
  {
    this.tooltip.hide();
  }
};
/* end of <its_scrollBarObject::hideToolTip> */



/** <its_scrollBarObject::hide>
    *
  * hides the scrollbar
  *
    * params: none
*/
its_scrollBarObject.prototype.hide = function()
{
    if (!this.scrollHandler.noHide)
    {
      if (this.direction == "h")
      {
        this.scrollbarTable.style.visibility = "hidden";
        this.scrollbarTable.style.display = "none";
        this.parentContainer.parentNode.style.display = "none";
      }
      else
      {
        if (document.getElementById(this.scrollHandler.id + "_vsbcol"))
            document.getElementById(this.scrollHandler.id + "_vsbcol").style.width = "0px";
        this.parentContainer.style.width = "0px";
        this.scrollbarTable.style.visibility ="hidden";
        this.scrollbarTable.style.display ="none";
      }
    }
    else
    {
        if (this.direction == "v")
        {
            if (document.getElementById(this.scrollHandler.id + "_vsbcol"))
                document.getElementById(this.scrollHandler.id + "_vsbcol").style.width = "16px";
        }
        if (this.direction == "h")
        {
            this.parentContainer.parentNode.style.display = "inline-table";
        }

        this.buttonPrev.style.filter = "alpha(opacity=60)";
        this.buttonNext.style.filter = "alpha(opacity=60)";
        this.buttonPrev.style.MozOpacity = 0.6;
        this.buttonPrev.style.opacity = 0.6;
        this.buttonNext.style.MozOpacity = 0.6;
        this.buttonNext.style.opacity = 0.6;

        this.slider.style.visibility ="hidden";
        this.buttonPrev.setAttribute("disabled", "disabled");
        this.buttonNext.setAttribute("disabled", "disabled");
        this.sliderArea.setAttribute("disabled", "disabled");
        its_eMgr.unregisterEvent(this.scrollbarTable, "mouseup", this.mouseup);
        its_eMgr.unregisterEvent(this.scrollbarTable, "mousedown", this.mousedown);
        its_eMgr.registerEvent(this.scrollbarTable, "dblclick", fNone);
    }

    if (this.direction == "v")
    {
        if ("onmousewheel" in document.documentElement || !its_ua.gecko)
        {
          its_eMgr.unregisterEvent(document.getElementById(this.scrollHandler.id), "mousewheel", this.mousewheel);
        }
        else
        {
          if (document.getElementById(this.scrollHandler.id))
              its_eMgr.unregisterEvent(document.getElementById(this.scrollHandler.id), "DOMMouseScroll", this.mousewheel);
        }
        its_eMgr.unregisterEvent(document.getElementById(this.scrollHandler.id), "keydown", this.keyDown);
     }

     return false;
};
/* end of <its_scrollBarObject::hide> */

/** <its_scrollBarObject::show>
  *
  * shows the scrollbar again
  *
  * params: none
*/
its_scrollBarObject.prototype.show = function()
{
    if (!this.scrollHandler.noHide)
    {
      if (this.direction == "h")
      {
        this.scrollbarTable.style.visibility = "visible";
        this.scrollbarTable.style.display = "";
        this.parentContainer.parentNode.style.display = "";
      }
      else
      {
        if (document.getElementById(this.scrollHandler.id + "_vsbcol"))
            document.getElementById(this.scrollHandler.id + "_vsbcol").style.width = "16px";
        this.parentContainer.style.width = "16px";
        this.scrollbarTable.style.visibility ="visible";
        this.scrollbarTable.style.display ="";
      }
    }
};
/* end of <its_scrollBarObject::show> */





function createScrollbar(container,
                         scrollHandler)
{
  if (container)
  {

    scrollbarTable = document.createElement("TABLE");
    if (isBidiRTL())
      scrollbarTable.dir = "rtl";
    tBody = document.createElement("tbody");
    scrollbarTable.appendChild(tBody);
    scrollbarTable.setAttribute("cellPadding", "0");
    scrollbarTable.setAttribute("cellSpacing", "0");

    scrollPrevButton = document.createElement("TD");
    fillImage = document.createElement("img");
    fillImage.src = webguiMimeURL + "/webgui/" + webguiTheme + "/images/tabs/1x1.gif";
    scrollPrevButton.appendChild(fillImage);

    scrollNextButton = document.createElement("TD");
    fillImage = document.createElement("img");
    fillImage.src = webguiMimeURL + "/webgui/" + webguiTheme + "/images/tabs/1x1.gif";
    scrollNextButton.appendChild(fillImage);

    scrollArea = document.createElement("TD");
    scrollSlider = document.createElement("DIV");
    scrollArea.appendChild(scrollSlider);

    if (scrollHandler.direction !== "v")
    {
        scrollBarCols = document.createElement("COLGROUP");
        col1 = document.createElement("col");
        col2 = document.createElement("col");
        col3 = document.createElement("col");
        col1.width = "16px";
        col2.width = "100%";
        col3.width = "16px";
        scrollBarCols.appendChild(col1);
        scrollBarCols.appendChild(col2);
        scrollBarCols.appendChild(col3);
        scrollbarTable.appendChild(scrollBarCols);
        scrollbarTable.className = "HScrollbar";
        scrollSlider.className = "HSlider";
        scrollSlider.id = "~listHSBSlider";
        scrollArea.className = "HScrollArea";

        scrollbarRow = document.createElement("TR");
        if (!isBidiRTL())
        {
          scrollPrevButton.className = "ScrollLeft";
          scrollNextButton.className = "ScrollRight";
        }
        else
        {
          scrollPrevButton.className = "ScrollRight";
          scrollNextButton.className = "ScrollLeft";
        }
        scrollbarRow.appendChild(scrollPrevButton);
        scrollbarRow.appendChild(scrollArea);
        scrollbarRow.appendChild(scrollNextButton);

        tBody.appendChild(scrollbarRow);
        scrollbarTable.style.width = "100%";
    }
    else
    {
        scrollbarTable.className = "VScrollbar";
        scrollArea.className = "VScrollArea";
        scrollArea.style.position = "relative";
        scrollbarRow = document.createElement("TR");
        scrollPrevButton.className = "ScrollUp";
        scrollbarRow.appendChild(scrollPrevButton);
        tBody.appendChild(scrollbarRow);

        scrollSlider.className = "VSlider";
        scrollSlider.id = "~listVSBSlider";
        scrollbarRow = document.createElement("TR");
        scrollbarRow.style.height ="100%";

        tBody.appendChild(scrollbarRow);
        scrollbarRow.appendChild(scrollArea);

        scrollbarRow = document.createElement("TR");
        tBody.appendChild(scrollbarRow);
        scrollNextButton.className = "ScrollDown";
        scrollbarRow.appendChild(scrollNextButton);


        scrollbarTable.style.height = "100%";
        scrollArea.style.height="100%";
    }

    scrollSlider.style.display = "none";
    container.appendChild(scrollbarTable);

    var scrollbar = new its_scrollBarObject(scrollHandler,
                                                container,
                                                scrollSlider,
                                                scrollPrevButton,
                                                scrollNextButton,
                                                scrollArea,
                                                scrollbarTable);
        scrollHandler.scrollbarObj = scrollbar;
    if (its_scrollContainerMgr == null)
    {
      its_scrollContainerMgr = new its_scrollContainerManager(null);
    }

    its_scrollContainerMgr.init(scrollbar);

    return (scrollbar);
  }
}
/* end of <createScrollbar> */

its_scrollContainerManager.prototype.nope = function(evt)
{
  return false;
}

/** <its_scrollContainerManager::mousedown>
    *
  * mousedown handler for a scrollbar
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.mousedown = function(evt, cntrl)
{
  var e = new its_event(evt);
  var new_evt = sbEvent(evt.clientX, evt.clientY, e.target, e.button, e.keyCode);

  cntrl.mouseOut = function(evt) {its_scrollContainerMgr.mouseout(evt, cntrl);};
  its_eMgr.registerEvent(window, "mouseout", cntrl.mouseOut);

  if (e.button == 1 && e.target == cntrl.slider)
  {
    this.registerMovement(cntrl);
    this.mousePressed = true;

    var slider = cntrl.slider;
    Scroll_MouseDown = 1;

    if (cntrl.direction == "v")
      slider.currentClickOffset = Math.round(e.clientY - dom_getYPos(slider));
    else
    {
      if (isBidiRTL())
        slider.currentClickOffset = slider.offsetWidth - Math.round(e.clientX - dom_getXPos(slider)) - 16;
      else
        slider.currentClickOffset = Math.round(e.clientX - dom_getXPos(slider));
    }
  }
  else if (e.button == 1 && (e.target == cntrl.buttonNext || e.target == cntrl.buttonPrev || e.target == cntrl.sliderArea) )
  {
    //dbg("mousedown clear", this.sbTimeout, new_evt.clientX);

    if (this.sbTimeout != null)
      window.clearTimeout(this.sbTimeout);
    this.sbTimeout = null;
    scrollHoldTemp = function() { its_scrollContainerMgr.scrollHold(new_evt, cntrl); }
    this.sbTimeout = window.setTimeout("scrollHoldTemp()", 350);

    //dbg("mousedown set", this.sbTimeout);
  }

  if (e)
  {
    e.cancel();
  }
  return false;
};
/* end of <its_scrollContainerManager::mousedown> */

/** <its_scrollContainerManager::mouseup>
    *
  * mouseup handler for a scrollbar
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.mouseup = function(evt, obj)
{

  var e = new its_event(evt);
  this.mousePressed = false;

  if (isBidiRTL())
  {
    var tableCell = document.getElementById(obj.scrollHandler.id + "_scrollAreaTD");
    if (tableCell)
      tableCell.parentNode.scrollLeft = 0;
  }

  if (e.button == 1 && obj.mousemove == null && ( e.target == obj.buttonNext || e.target == obj.buttonPrev || e.target == obj.sliderArea))
  {
    this.unregisterMovement(obj);
    if (this.sbTimeout != null)
    {
      //dbg("mouseup clear", this.sbTimeout);
      this.click(evt, obj);
      window.clearTimeout(this.sbTimeout);
      this.sbTimeout = null;
      scrollSubmitTemp = function() { obj.scrollHandler.onSliderMoveTo(obj.scrollHandler.currPos); }
      this.sbTimeout = window.setTimeout("scrollSubmitTemp()", 350);
      //dbg("mouseup set", this.sbTimeout);
    }
  }
  else
  {
    this.unregisterMovement(obj);
    obj.scrollHandler.onSliderMoveTo(obj.scrollHandler.currPos);
  }

  obj.hideToolTip();
  its_eMgr.unregisterEvent(window, "mouseout", obj.mouseOut);

  if (e)
  {
    e.cancel();
    delete(e);
  }
};
/* end of <its_scrollContainerManager::mouseup> */

/** <its_scrollContainerManager::mousemove>
    *
  * mousemove handler for a scrollbar slider
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.mousemove = function(evt, obj)
{
  var e = new its_event(evt);

  obj.moveHandler(evt);

  if ((!its_ua.gecko && evt.button == 0) || (obj.mousePressed && obj.mouseOut))
  {
    this.unregisterMovement(obj);
    obj.scrollHandler.onSliderMoveTo(obj.scrollHandler.currPos);
    obj.mouseOut = false;
  }

  if (e)
  {
    e.preventDefault();
  }
};
/* end of <its_scrollContainerManager::mousemove> */

/** <its_scrollContainerManager::mouseout>
    *
  * mousemove handler for a scrollbar slider
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.mouseout = function(evt, obj)
{
  var e = new its_event(evt);

  if (this.sbTimeout)
  {
    //dbg("mouseout", this.sbTimeout);
    window.clearTimeout(this.sbTimeout);
    this.sbTimeout = null;
    obj.hideToolTip();
    obj.mouseOut = true;
  }
};
/* end of <its_scrollContainerManager::mousemove> */


/** <its_scrollContainerManager::click>
    *
  * click handler for a slider area, initiates scrolling in pages
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.click = function(evt, obj)
{
  var e = new its_event(evt);

  if (obj.scrollHandler.disabled == "true")
  {
      if (e)
      {
        e.cancel();
        delete(e);
      }
  }

  if (e.target == obj.sliderArea)
  {
    //dbg("click", dom_getYPos(obj.slider), this.sbTimeout);
    if (obj.direction == "v")
    {
      if (e.clientY < (dom_getYPos(obj.slider)))
      {
          this.clickPrevPage(evt, obj);
      }
      else if (e.clientY > (dom_getYPos(obj.slider) + obj.slider.clientHeight))
      {
          this.clickNextPage(evt, obj);
      }
    }
    else
    {
      if (e.clientX < dom_getXPos(obj.slider))
      {
        if (!isBidiRTL())
          this.clickPrevPage(evt, obj);
        else
          this.clickNextPage(evt, obj);
      }
      else if (e.clientX > dom_getXPos(obj.slider) + obj.slider.clientWidth)
      {
        if (!isBidiRTL())
          this.clickNextPage(evt, obj);
        else
          this.clickPrevPage(evt, obj);
      }
    }
  }
  else if (e.target == obj.buttonPrev)
  {
    //dbg("click", "prevbutton", this.sbTimeout);

    this.clickPrev(evt, obj);
  }
  else if (e.target == obj.buttonNext)
  {
    //dbg("click", "nextbutton", this.sbTimeout);
    this.clickNext(evt, obj);
  }

  if (obj.mousePressed == "true" && obj.mouseOut == "true")
  {
    this.unregisterMovement(obj);
    obj.scrollHandler.onSliderMoveTo(obj.scrollHandler.currPos);
  }

  if (e)
  {
    e.cancel();
    delete(e);
  }
};
/* end of <its_scrollContainerManager::click> */

/** <its_scrollContainerManager::clickPrev>
    *
  * click handler for "prev" button
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickPrev = function(evt, obj)
{
  var SHdl = obj.scrollHandler;
  var e = new its_event(evt);
  var old_pos = SHdl.currPos;
  if (obj.local)
  {
      if (obj.direction == "h")
          obj.scrollToPixels(SHdl.currPos*obj.calcFactor - 7);
      else
          obj.scrollToPixels(SHdl.currPos*obj.calcFactor - 21);

      SHdl.onSliderMoveTo(SHdl.currPos);
  }
  else
  {
      if (SHdl.currPos > SHdl.offset)
          SHdl.currPos -= 1;
      obj.scrollToPixels(SHdl.currPos*obj.calcFactor);
      if (!this.sbTimeout)
        SHdl.onSliderMoveTo(SHdl.currPos);
  }
  if ((SHdl.currPos != old_pos) && !this.sbTimeout)
      SHdl.onPrev();
  if (e)
  {
    e.cancel();
  }
};
/* end of <its_scrollContainerManager::clickPrev> */

/** <its_scrollContainerManager::clickFirstPage>
    *
  * handler for "topOfPage"
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickFirstPage = function(evt, obj)
{
  var SHdl = obj.scrollHandler;
  obj.scrollTo(SHdl.offset);
  SHdl.onSliderMoveTo(SHdl.currPos);
  e = new its_event(evt);
  if (e)
  {
    e.cancel();
  }

};
/* end of <its_scrollContainerManager::clickFirstPage> */

/** <its_scrollContainerManager::clickLastPage>
    *
  * handler for "endOfPage"
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickLastPage = function(evt, obj)
{
  var SHdl = obj.scrollHandler;
  obj.scrollTo(SHdl.totalRange - SHdl.visRange + SHdl.offset);
  SHdl.onSliderMoveTo(SHdl.currPos);
  e = new its_event(evt);
  e.cancel();
};
/* end of <its_scrollContainerManager::clickLastPage> */

/** <its_scrollContainerManager::clickPrevPage>
    *
  * handler for "prevPage"
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickPrevPage = function(evt, obj)
{
  var SHdl = obj.scrollHandler;
  obj.scrollTo(SHdl.currPos - SHdl.visRange);
  //dbg("prevpage", SHdl.currPos, "timeout", this.sbTimeout);
  if (SHdl.currPos >= SHdl.offset && !this.sbTimeout)
    SHdl.onPrevPage();
  if (obj.local)
    SHdl.onSliderMoveTo(SHdl.currPos);
  //obj.scrollTo(SHdl.currPos);
};
/* end of <its_scrollContainerManager::clickPrevPage> */

/** <its_scrollContainerManager::clickNextPage>
    *
  * handler for "prevNext"
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickNextPage = function(evt, obj)
{
  var SHdl = obj.scrollHandler;
  obj.scrollTo(SHdl.currPos + SHdl.visRange);
  //dbg("clicknextpage", "timeout", this.sbTimeout);
  if (SHdl.currPos - SHdl.offset + SHdl.visRange <= SHdl.totalRange && !this.sbTimeout)
    SHdl.onNextPage();
  if (obj.local)
    SHdl.onSliderMoveTo(SHdl.currPos);
  //obj.scrollTo(SHdl.currPos);
};

/* end of <its_scrollContainerManager::clickPrevPage> */
/** <its_scrollContainerManager::clickNext>
    *
  * click handler for "next" button
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.clickNext = function(evt, obj)
{
  var e = new its_event(evt);
  var SHdl = obj.scrollHandler;
  var old_pos = SHdl.currPos;

  if (obj.local)
  {
      if (obj.direction == "h")
          obj.scrollToPixels(SHdl.currPos*obj.calcFactor + 7);
      else
          obj.scrollToPixels(SHdl.currPos*obj.calcFactor + 21);

        SHdl.onSliderMoveTo(SHdl.currPos);
  }
  else
  {
      if (SHdl.currPos + SHdl.visRange - SHdl.offset < SHdl.totalRange)
      {
          SHdl.currPos += 1;
          obj.scrollToPixels(SHdl.currPos*obj.calcFactor);
          if (!this.sbTimeout)
            SHdl.onSliderMoveTo(SHdl.currPos);
      }
  }
  if ((SHdl.currPos != old_pos) && !this.sbTimeout)
      SHdl.onNext();

  if (e)
  {
    e.cancel();
  }
};
/* end of <its_scrollContainerManager::clickNext> */

/** <its_scrollContainerManager::scrollHold>
  *
  *
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.scrollHold = function(evt, cntrl)
{
  its_eMgr.unregisterEvent(window, "mouseout", cntrl.mouseOut);

  var e = new its_event(evt);

  //dbg("scrollHold", "createNewEvent", evt.clientX, e.target);

  var new_evt = sbEvent(evt.clientX, evt.clientY, e.target, e.button, e.keyCode);

  cntrl.showToolTip("", "");

  if (evt.target == cntrl.buttonPrev)
  {
    this.clickPrev(evt, cntrl);
  }
  else if (evt.target == cntrl.buttonNext)
  {
    this.clickNext(evt, cntrl);
  }
  else if (evt.target == cntrl.sliderArea)
  {
    //dbg("scrollHold", evt.clientX, evt.clientY);
    this.click(new_evt, cntrl);
  }
  else if (!!evt.keyCode && evt.keyCode != "" && (evt.keyCode > 32 && evt.keyCode < 37))
  {
      switch (evt.keyCode)
      {
          case 33:
            this.clickPrevPage(evt, cntrl);
            break;
          case 34:
            this.clickNextPage(evt, cntrl);
            break;
          case 35:
            this.clickLastPage(evt, cntrl);
            break
          case 36:
            this.clickFirstPage(evt, cntrl);
            break
          default:
            return;
          break;
      }
  }

  if (this.sbTimeout != null)
  {
    //dbg("scrollhold clear", this.sbTimeout);

    window.clearTimeout(this.sbTimeout);
    this.sbTimeout = null;
    scrollHoldTemp = function() { its_scrollContainerMgr.scrollHold(new_evt, cntrl); }
    this.sbTimeout = window.setTimeout("scrollHoldTemp()", 350);
    //dbg("scrollhold set", this.sbTimeout);
  }
  else
  {
    cntrl.scrollTo(cntrl.SHdl.currPos);
  }

 if (e)
 {
  e.cancel();
 }
}


/** <its_scrollContainerManager::mousewheel>
    *
  * handler for mouse wheel action, currently on verticak scrollbar only
  *
    * params:
    *   evt             browser event
    *   cntrl           scrollbar control which received the event
*/
its_scrollContainerManager.prototype.mousewheel = function(evt, cntrl)
{

   var delta = 0;
   var slider = cntrl.slider;
   var parentCont = slider.parentNode;
   var pixelsPerRow = cntrl.calcFactor;

   if (this.sbTimeout)
    window.clearTimeout(this.sbTimeout);
   this.sbTimeout = null;
   if (this.toolTipTimeout)
    window.clearTimeout(this.toolTipTimeout);

    if (evt.wheelDelta)
    {
        delta = evt.wheelDelta/40;
    }
    else if (evt.detail)
    {
        delta = -evt.detail;
    }

    if (delta)
    {
      //delta = Math.round(delta / cntrl.calcFactor);

        var initialPos = slider.offsetTop - 16;
        if (initialPos >= 0 || initialPos < (parentCont.clientHeight - slider.offsetHeight) )
        {
            var SHdl = cntrl.scrollHandler;
          //window.status = SHdl.currPos + "   " + delta + "    " + SHdl.totalRange + "   " + SHdl.visRange + "   " + SHdl.offset;

            if ((SHdl.currPos - delta) >= SHdl.totalRange - SHdl.visRange + SHdl.offset)
                SHdl.currPos = SHdl.totalRange - SHdl.visRange + SHdl.offset;
            else if(SHdl.currPos - delta  <= SHdl.offset)
                SHdl.currPos = SHdl.offset;
            else
                SHdl.currPos -= delta;
            if (SHdl.currPos >= 0)
            {
                cntrl.scrollTo(SHdl.currPos);

                // scrollTo may have queued the slider 350ms callback. The wheel owns
                // this submission: cancel it before applying the existing wheel delay.
                if (this.sbTimeout != null) window.clearTimeout(this.sbTimeout);
                this.sbTimeout = null;

                cntrl.showToolTip("", "");

                if (cntrl.firstPos != SHdl.currPos && !cntrl.local && cntrl.wheelDelay > 0)
                    this.sbTimeout = setTimeout("window.its_SBArray[" + cntrl.index + "].scrollHandler.onSliderMoveTo(" + SHdl.currPos +")", cntrl.wheelDelay);
                else
                  window.its_SBArray[cntrl.index].scrollHandler.onSliderMoveTo(SHdl.currPos );

                this.toolTipTimeout = setTimeout("window.its_SBArray[" + cntrl.index + "].hideToolTip()", 700);
            }
      }
    }
    var e = new its_event(evt);
    if (e)
    {
        e.cancel();
        //e.stopPropagation();
        //delete(e);
    }

    return false;
};
/* end of <its_scrollContainerManager::mousewheel> */

/** <its_ScrollBarHandlerObject::its_ScrollBarHandlerObject>
    *
  * constructor for its_ScrollBarHandlerObject
  * this object can hold user specified functions which are bound to scroll events
  * also it specifies scroll parameters for backend scrolling.
  *
    * params:
    *          id               scroll handler id
               direction        direction of the scrollbar, {"h"/"v"}
               onPrev           user exit if button "prev" is pressed
               onNext           user exit if button "next" is pressed
               onPrevPage       user exit if slider area is clicked on left side or higher than the slider
               onNextPage       user exit if slider area is clicked on right side or lower than the slider
               onSliderMoveTo   user exit if slider was moved to a special position
               onSliderMove     user exit called on slider movement, normally used on local scrollbar
               targetArea       scroll content
               total_range      total operating range, in abstract units, default is "-1" which indicates local scrollbar
               vis_range        rows / cols visible, in abstract units, default is "-1" which indicates local scrollbar
               curr_pos         current position of the slider, in abstract units, default is "0"
               offset           starting value of the scrollbar, in abstract units, default is "0"
               mode             scroll mode, {"local"/"backend"}, default is "local"
               noHide           defines, if the scrollbar is always visible, even if there is nothing to scroll, {"false"/"true"}, default is "false"
               disabled         scrolling not possible, interferes with noHide {"false"/"true"}, default is "false"
               showToolTip      defines if tooltip should be shown. default is "false" for local and "true" for "backend" mode
*/
function its_ScrollBarHandlerObject(id,
                                    direction,
                                    onPrev,
                                    onNext,
                                    onPrevPage,
                                    onNextPage,
                                    onSliderMoveTo,
                                    onSliderMove,
                                    targetArea,
                                    total_range,
                                    vis_range,
                                    curr_pos,
                                    offset,
                                    mode,
                                    noHide,
                                    disabled,
                                    showToolTip,
                          wheelDelay)
{
  this.direction = direction;
  this.id = id;

  this.mousePressed = "false";
  this.mouseOut = "false";
  this.buttohHold = "false";

  if (typeof (disabled) !== "undefined" && disabled)
    this.disabled = "true";
  else
    this.disabled = "false";

  if (onPrev)
    this.onPrev = onPrev;
  else
    this.onPrev = function(evt){};
  if (onNext)
    this.onNext = onNext;
  else
    this.onNext = function(evt){};
  if (onPrevPage)
    this.onPrevPage = onPrevPage;
  else
    this.onPrevPage = function(evt){};
  if (onNextPage)
    this.onNextPage = onNextPage;
  else
    this.onNextPage = function(evt){};
  if (onSliderMoveTo)
    this.onSliderMoveTo = onSliderMoveTo;
  else
    this.onSliderMoveTo = function(evt){};
  if (onSliderMove)
    this.onSliderMove = onSliderMove;
  else
    this.onSliderMove = function(evt){};
  if (targetArea)
    this.targetArea = targetArea;
  else
    this.targetArea = document.getElementById(id);

  if (vis_range)
    this.visRange = vis_range;
  else
    this.visRange = -1;

  if (offset)
    this.offset = offset;
  else
    this.offset = 0;

  if (total_range)
    this.totalRange = total_range;
  else
    this.totalRange = -1;

  if (curr_pos)
    this.currPos = curr_pos;
  else
    this.currPos = 0;

  if (typeof (mode) !== "undefined")
    this.mode = mode;
  else
    this.mode = "local";

  if (showToolTip)
    this.showToolTip = showToolTip;
  else
    this.showToolTip = "false";

  if (noHide)
    this.noHide = (noHide == "false")?false:true;
  else
    this.noHide = false;
  if (wheelDelay)
    this.wheelDelay = wheelDelay;
  else
        if (this.mode == "local")
        this.wheelDelay = 50;
      else
        this.wheelDelay = 700;

    this.scrollbarObj = null;

  return this;
}
/* end of  <its_ScrollBarHandlerObject::its_ScrollBarHandlerObject> */

/** <SBMgrRegisterResize>
    *
  * registers resize handlers for all scroll container
*/
function SBMgrRegisterResize()
{
  if (its_scrollContainerMgr)
  {
    for (i=0; i < its_SCArrayLength; i++)
    {
      CFWAddonFinalSizeHandler("window.its_SCArray[" + i + "].resize");
    }
  }
}
/* end of  SBMgrRegisterResize */

/** <initScrollContainer>
    *
  * init function for a scroll container.
  * container parent and structure is analyzed and a scroll container JS object created
  * if no scrollhandler objects are defined by user, default will be created
*/
function initScrollContainer(id)
{
    scrollContainer = document.getElementById(id);
    if (null == scrollContainer)
      return;

    scrollContentArea = document.getElementById(id + "_scrollArea");

    var vscrollHandler;
    var hscrollHandler;

    try
    {
      vscrollHandler = eval("sh_" + id + "_vScrollHandler");
    }
    catch( e )
    {
      if (typeof(vscrollHandler) == "undefined")
      {
        vscrollHandler = new its_ScrollBarHandlerObject(id, "v");
      }
    }
    try
    {
      hscrollHandler = eval("sh_" + id + "_hScrollHandler");
    }
    catch( e )
    {
      if (typeof(hscrollHandler) == "undefined")
      {
        hscrollHandler = new its_ScrollBarHandlerObject(id, "h");
      }
    }

    if (vscrollHandler.mode == "local" && null != scrollContentArea)
    {
      vscrollHandler.totalRange = scrollContentArea.offsetHeight;
      vscrollHandler.visRange = scrollContentArea.parentNode.offsetHeight;
    }

    vscrollHandler.targetArea = scrollContentArea;
    vScrollbarCont = document.getElementById(id + "_vertScrollbar");
    vScrollBar = createScrollbar(vScrollbarCont, vscrollHandler);

    if (hscrollHandler.mode == "local" && null != scrollContentArea)
    {
      hscrollHandler.totalRange = scrollContentArea.offsetWidth;
      hscrollHandler.visRange = scrollContentArea.parentNode.offsetWidth;
    }

    hscrollHandler.targetArea = scrollContentArea;
    hScrollbarCont = document.getElementById(id + "_horScrollbar");
    hScrollBar = createScrollbar(hScrollbarCont, hscrollHandler);

    jsScrollContainer = new its_scrollContainerObject(id, vScrollBar, hScrollBar, hscrollHandler.mode, vscrollHandler.mode, scrollContainer.getAttribute("resizable"));

    return jsScrollContainer;
}



function createScrollContainer(id, className, x,y, width, height, position, overflow_y, overflow_x, allow_resize, attributes)
{
    if (typeof its_scrollContainerMgr == "undefined")
    {
      var its_scrollContainerMgr = new its_scrollContainerManager(null);
    }

      var outerdiv = document.createElement("DIV");
      outerdiv.id = id;
      outerdiv.className = className;
      if (position == "absolute")
          styletext = "position:absolute; left:" & x & "; top:" & y & "; ";
      else
          styletext = "position:relative; ";

      outerdiv.setAttribute("overflowX", overflow_x);
      outerdiv.setAttribute("overflowY", overflow_y);
      //attributes??
      outerdiv.style = styletext & "overflow:hidden; width:" & width & "; height;" & height & ";"
      var table = document.createElement("TABLE");
      var colgroup = document.createElement("COLGROUP");
      var col1 = document.createElement("COL");
      col1.style.width = "100%";

      var col2 = document.createElement("COL");
      col2.style.width = "0px";
      col2.id = id & "_vsbcol";
      var row1 = document.createElement("TR");
      row1.style = "height:100%; position:relative; overflow:hidden;"
      var row2 = document.createElement("TR");
      var cell1 = document.createElement("TD");
      var scrollCont = document.createElement("SPAN");
      var cell2 = document.createElement("TD");
      cell2.id = id & "_vertScrollbar";
      cell2.style = "height:100%; width:16px; position:relative";

      row2.style = "height:16px; width:100%; display:none;";
      var cell3 = document.createElement("TD");
      cell3.id = id& "_horScrollbar";
      cell3.style = "width:100%; height: 16px; vertical-align:bottom;";
      var cell4 = document.createElement("TD");
      cell4.className = "HScrollBar";


      table.id = id & "scrollContainerStructure";
      table.className = className;
      table.cellspacing = 0;
      table.cellpadding = 0;
      table.border = 0;
      table.style = "table-layout:fixed; top:0px; left:0px; width:" & width & "; height:" & height & "; overflow:hidden; border:0px; padding:0px; margin:0px; ";
      cell1.id = id & "scrollAreaTD";
      cell1.className = "classname";
      cell1.style = "position:relative; overflow:hidden; top:0px; left:0px; width:" & width & "; height:" & height & "; display:inline-table; border:0px; padding:0px; margin:0px; ";
      scrollCont.id = id & "scrollArea";
      scrollCont.style = "position:absolute; left:0px; top:0px; height:100%; width:100%; overflow: visible;";
      cell1.appendChild(scrollCont);
      row1.appendChild(cell1);
      colgroup.appendChild(col1);
      colgroup.appendChild(col2);
      table.appendChild(colgroup);

      row2.appendChild(cell3);
      row2.appendChild(cell4);
      table.appendChild(row2);
      outerdiv.appendChild(table);

      return outerdiv;
}


its_scrollContainerManager.prototype.scrollIntoView = function(scrollCont, in_element, dim)
{
  var tableCell = document.getElementById(scrollCont.id + "_scrollAreaTD");
  if (tableCell)
    tableCell.parentNode.scrollLeft = 0;
  var posElem = wgu_getAbsolutePosition( in_element );
  var posCont = wgu_getAbsolutePosition( scrollCont.scrollDiv );

  var vHdl = scrollCont.vScrollBar.scrollHandler;
  var hHdl = scrollCont.hScrollBar.scrollHandler;
  dim = { w:in_element.offsetWidth, h:in_element.offsetHeight };
  if (in_element.getAttribute("f4") == "1" || in_element.getAttribute("sh") == "1")
    dim.w += 16;
  var pos = { x:0, y:0 };
  if (!scrollCont.vScrollBar.local)
    pos.y = vHdl.currPos;
  else
  {
    pos.y = posElem.y - posCont.y;
    if (pos.y - vHdl.currPos + dim.h > vHdl.visRange)
      pos.y = pos.y - vHdl.visRange + dim.h;
    else
    {
      if (pos.y > vHdl.currPos)
        pos.y = vHdl.currPos;
    }
  }

  if (!scrollCont.hScrollBar.local)
    pos.x = scrollCont.hScrollBar.scrollHandler.currPos;
  else
  {
    pos.x = posElem.x - posCont.x;

    if (isBidiRTL())
    {
      pos.x = hHdl.totalRange - pos.x - dim.w;
    }

    if (pos.x - hHdl.currPos + dim.w > hHdl.visRange)
    {
      if (dim.w < hHdl.visRange)
        pos.x = pos.x - hHdl.visRange + dim.w;
    }
    else
    {
      if (pos.x > hHdl.currPos)
        pos.x = hHdl.currPos;
    }
  }
  if (tableCell)
    tableCell.parentNode.scrollLeft = 0;

  if (scrollCont.hScrollBar.scrollHandler.currPos != pos.x ||
      scrollCont.vScrollBar.scrollHandler.currPos != pos.y)
    this.scrollTo(scrollCont, pos);
}

its_scrollContainerManager.prototype.scrollTo = function(scrollCont, pos)
{
  if ( scrollCont.vScrollBar.scrollHandler.mode != "hidden" && scrollCont.vScrollBar.scrollHandler.disabled == "false")
    scrollCont.vScrollBar.scrollTo(pos.y);
  if ( scrollCont.hScrollBar.scrollHandler.mode != "hidden" && scrollCont.hScrollBar.scrollHandler.disabled == "false")
    scrollCont.hScrollBar.scrollTo(pos.x);
}

