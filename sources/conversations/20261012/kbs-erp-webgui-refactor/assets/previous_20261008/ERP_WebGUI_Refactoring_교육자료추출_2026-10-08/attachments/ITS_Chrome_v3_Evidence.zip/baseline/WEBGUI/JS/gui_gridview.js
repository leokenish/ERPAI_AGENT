/*******************************************************************************
 *
 * gui_gridview.js
 *
 * Description: alv gridview control framework for sap gui for html / webgui
 *
 * Date       : 2005/02/16
 * Author     : Simon Kruska
 *
 * History    :
 *
 * YYYY/MM/DD ID DESCRIPTION
 * 2005/02/16 sk initial re-implementation (beginning)
 * 2005/11/24 sk initial re-implementation completed
 *
 ******************************************************************************/

its_gvMgr = null;
its_gvCurrentInputField = null;
its_gvTimeout = 0;
its_gvFocusTimeout = 50;

// Selection modes
GV_SEL_MODE_NONE     = 0;
GV_SEL_MODE_SINGLE   = 1;
GV_SEL_MODE_MULTIPLE = 2;

// scroll to on load
GV_SCROLL_TO_POSITION = 0;
GV_SCROLL_TO_CELL     = 1;
GV_SCROLL_TO_ROW      = 2;
GV_SCROLL_TO_COLUMN   = 4;

// Events
GV_EVT_CLICKROWCOL                = 1;
GV_EVT_CLICKCOLHEADER             = 2;
GV_EVT_DOUBLECLICKROWCOL          = 4;
GV_EVT_TOTALCLICKROWCOL           = 8;
GV_EVT_MODIFIED                   = 16;
GV_EVT_BUTTONCLICKROWCOL          = 32;
GV_EVT_DELAYEDMOVEDCURRENTCELL    = 64;
GV_EVT_DELAYEDCHANGEDSELECTION    = 128;

// focus modes
GV_FOCUS_NONE   = 1;
GV_FOCUS_FOCUS  = 2;
GV_FOCUS_SELECT = 4;

/** <its_gridviewManager::its_gridviewManager>
  *
  *   constructor for the class its_gridviewManager
  *     its_gridviewManager encapsulates all interactive functions and
  *     actions on a gridview. the data of the gridview is thereby hold
  *     in a json object.
  *
  *   params:
  */
function its_gridviewManager()
{
  // object that keeps data during an resize event
  this.cr = null;
  this.eventFired = false;
}
// </its_gridviewManager::its_gridviewManager>


/** <its_gridviewManager::remove>
  *
  *   remove the gridview and its descendant(s)
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.remove = function(obj)
{
  if (obj)
  {
    if (obj.selection)
    {
      delete obj.selection;
    }
    delete obj;
  }
}
// </its_gridviewManager::remove>


/** <its_gridviewManager::init>
  *
  *   initialize the gridview javascript object
  *
  *   params:
  */
its_gridviewManager.prototype.init = function(obj)
{
  obj.initialized         = false;

  if (obj.controlFocus)
  {
    ITS_Frameset("DONT_FOCUS");
  }

  obj.container           = document.getElementById(obj.name + "_gvContainer");
  obj.layout              = document.getElementById(obj.name + "_gvLayoutTable");
  if (obj.toolbarName != null)
    obj.toolbarContainer = document.getElementById(obj.toolbarName + "_container");
  obj.titleContainer      = document.getElementById(obj.name + "_gvTitleContainer");
  obj.fixHeaderLayout     = document.getElementById(obj.name + "_gvFixHeaderLayout");
  obj.fixHeaderContainer  = document.getElementById(obj.name + "_gvFixHeaderContainer");
  obj.freeHeaderLayout    = document.getElementById(obj.name + "_gvFreeHeaderLayout");
  obj.freeHeaderContainer = document.getElementById(obj.name + "_gvFreeHeaderContainer");
  obj.fixBodyLayout       = document.getElementById(obj.name + "_gvFixBodyLayout");
  obj.fixBodyContainer    = document.getElementById(obj.name + "_gvFixBodyContainer");
  obj.freeBodyLayout      = document.getElementById(obj.name + "_gvFreeBodyLayout");
  obj.freeBodyContainer   = document.getElementById(obj.name + "_gvFreeBodyContainer");
  obj.fixHeaderTable      = document.getElementById(obj.name + "_gvFixHeaderTable");
  obj.freeHeaderTable     = document.getElementById(obj.name + "_gvFreeHeaderTable");
  obj.fixBodyTable        = document.getElementById(obj.name + "_gvFixBodyTable");
  obj.freeBodyTable       = document.getElementById(obj.name + "_gvFreeBodyTable");
  obj.footerContainer     = document.getElementById(obj.name + "_gvFooterContainer");

  obj.tpScrollContext     = document.getElementById(obj.name + "-ScrollContext");
  obj.tpScrollTop         = document.getElementById(obj.name + "-ScrollTop");
  obj.tpScrollLeft        = document.getElementById(obj.name + "-ScrollLeft");
  obj.tpCurrentPage       = document.getElementById(obj.name + "PageCurrent");
  obj.tpRowsPerPage       = document.getElementById(obj.name + "RowsPerPage");
  obj.tpPages             = document.getElementById(obj.name + "Pages");
  obj.currentPage         = parseInt(obj.tpCurrentPage.value, 10);
  obj.rowsPerPage         = parseInt(obj.tpRowsPerPage.value, 10);
  obj.pages               = parseInt(obj.tpPages.value, 10);

  obj.selection           = new its_gridviewSelectionObject(obj);
  obj.dropdown            = new gui_dropdownManager(obj, "ALV");

  obj.hasFocus            = false;

  // assign mousedown event handler
  fMousedown = function(evt) { its_gvMgr.mousedown(evt, obj); };
  its_eMgr.registerEvent(obj.container, "mousedown", fMousedown);

  // assign mouseup event handler
  fMouseup = function(evt) { its_gvMgr.mouseup(evt, obj); };

  // assign focus event handler
  fFocus = function(evt) { its_gvMgr.focus(evt); };
  its_eMgr.registerEvent(obj.container, "focus", fFocus);

  // assign click event handler
  this.fClick = function(evt) { its_gvMgr.click(evt, obj); };
  its_eMgr.registerEvent(obj.container, "click", this.fClick);

  this.fMouseover = function(evt) { its_gvMgr.mouseover(evt, obj); };
  its_eMgr.registerEvent(obj.container, "mouseover", this.fMouseover);

  // assign doubleclick event handler
  fDoubleclick = function(evt) { its_gvMgr.doubleclick(evt, obj); };
  its_eMgr.registerEvent(obj.container, "dblclick", fDoubleclick);

  // assign contextmenu event handler
  fContextmenu = function(evt) { its_gvMgr.contextmenu(evt, obj); };
  its_eMgr.registerEvent(obj.container, "contextmenu", fContextmenu);

  // assign key down event handler
  fKeydown = function(evt) { its_gvMgr.keydown(evt, obj); };
  its_eMgr.registerEvent(obj.container, "keydown", fKeydown);

  obj.fChange = function(evt) { its_gvMgr.change(evt, obj); };

  // assign scroll event handler
  fScroll = function (evt) { its_gvMgr.scroll(evt, obj); };
  if (obj.fixBodyContainer)
  {
    its_eMgr.registerEvent(obj.fixBodyContainer, "scroll", fScroll);
  }
  if (obj.freeBodyContainer)
  {
    its_eMgr.registerEvent(obj.freeBodyContainer, "scroll", fScroll);
  }

  if (obj.events & GV_EVT_DELAYEDMOVEDCURRENTCELL)
  {
    obj.fDelayedMovedCurrentCell = function()
    {
      its_gvMgr.triggerDelayedEvent("DelayedMovedCurrentCell", obj);
    };
    if (obj.delayedMovedCurrentCellTimeout == undefined)
      obj.delayedMovedCurrentCellTimeout = 1500;
  }
  if (obj.events & GV_EVT_DELAYEDCHANGEDSELECTION)
  {
    obj.fDelayedChangedSelection = function()
    {
      its_gvMgr.triggerDelayedEvent("DelayedChangedSelection", obj);
    };
    if (obj.delayedChangedSelectionTimeout == undefined)
      obj.delayedChangedSelectionTimeout = 1500;
  }

  its_gvMgr.switchSelectionOnLoad(obj);
}
// </its_gridviewManager::init>


/** <its_gridviewManager::finish>
  *
  *   finish initialization of the gridview javascript object
  *
  *   params:
  */
its_gridviewManager.prototype.finish = function(obj)
{
  obj.initialized = true;
}
// </its_gridviewManager::finish>


/** <its_gridviewManager::resize>
  *
  *   resize the gridview containers
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.resize = function(obj)
{
  if (arguments.length == 2)
    obj = arguments[1];

  var headerHeight = 0;
  var bodyHeight = obj.container.offsetHeight;
  var bodyWidth = obj.container.offsetWidth - 2;
  var tableHeight = 0;
  var verticalScrollbar = 0;
  var horizontalScrollbar = 0;

  if (obj.toolbarContainer)
    bodyHeight -= obj.toolbarContainer.offsetHeight;
  if (obj.titleContainer)
    bodyHeight -= obj.titleContainer.offsetHeight;
  if (obj.fixHeaderContainer)
  {
    headerHeight = obj.fixHeaderContainer.offsetHeight;
    bodyHeight -= headerHeight;
  }
  else if (obj.freeHeaderContainer)
  {
    headerHeight = obj.freeHeaderContainer.offsetHeight;
    bodyHeight -= headerHeight;
  }
  if (obj.footerContainer)
    bodyHeight -= obj.footerContainer.offsetHeight;

  bodyHeight -= 2;
  tableHeight = bodyHeight + headerHeight;

  if (bodyHeight >= 0 && bodyWidth >= 2)
  {
    if (obj.layout)
    {
      obj.layout.style.height = bodyHeight.toString() + "px";
      obj.layout.style.width = bodyWidth.toString() + "px";
    }
    if (obj.fixBodyLayout)
    {
      obj.fixBodyLayout.style.height = bodyHeight.toString() + "px";
    }
    if (obj.freeBodyLayout)
    {
      obj.freeBodyLayout.style.height = bodyHeight.toString() + "px";
    }
    if (obj.freeBodyContainer)
    {
      obj.freeBodyContainer.style.height = bodyHeight.toString() + "px";
      obj.freeBodyContainer.style.width = (bodyWidth).toString() + "px";
      if (obj.fixBodyContainer)
      {
        _width = bodyWidth - obj.fixBodyContainer.offsetWidth;
        obj.freeBodyContainer.style.width = (_width < 0)? 0 : _width;
      }
      obj.freeBodyLayout.style.width = obj.freeBodyContainer.style.width;
      // check the table sizes against the container sizes; remember that checking must be done mutually
      // for horizontal and vertical scrollbar; therefor the check for verticalScrollbar is done twice
      if (obj.freeBodyTable.offsetHeight > (obj.freeBodyContainer.offsetHeight - horizontalScrollbar))
      {
        verticalScrollbar = 16;
      }
      if (obj.freeBodyTable.offsetWidth > obj.freeBodyContainer.offsetWidth - verticalScrollbar)
      {
        horizontalScrollbar = 16;
      }
      // second check for verticalScrollbar; read above
      if (obj.freeBodyTable.offsetHeight > (obj.freeBodyContainer.offsetHeight - horizontalScrollbar))
      {
        verticalScrollbar = 16;
      }
      if (obj.freeHeaderContainer)
      {
        _width = obj.freeBodyContainer.offsetWidth - verticalScrollbar;
        obj.freeHeaderContainer.style.width = (_width < 0)? 0 : _width;
        obj.freeHeaderLayout.style.width = obj.freeBodyContainer.style.width;
      }
      if (obj.fixBodyContainer)
      {
        _height = obj.freeBodyContainer.offsetHeight - horizontalScrollbar;
        obj.fixBodyContainer.style.height = (_height < 0)? 0 : _height;
      }
    }
  }
}
// </its_gridviewManager::resize>


/** <its_gridviewManager::mousedown>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.mousedown = function(evt, obj)
{
  if (typeof CloseAllMenus != "undefined")
  {
    CloseAllMenus ();
  }
  if (obj.dropdown)
  {
    obj.dropdown.holdBlocking = false;
    if (obj.dropdown.opened)
    {
      return;
    }
  }
  var e = new its_event(evt);
  if (e.valid)
  {
    webguiSaveFocus(new webguiFocusObj(3, obj));
    if (e.target.className.indexOf("gvSearchHelp") >= 0 && e.button == EVT_MB_LEFT)
    {
      row = parseInt(obj.selection.tpCurrentCellRow.value, 10);
      column = parseInt(obj.selection.tpCurrentCellColumn.value, 10);
      if (row > 0 && column > 0)
      {
        this.fireEvent(obj, "F4", "strRowID=" + row.toString() + "&" +
                                  "strColID=" + column.toString() + "&" +
                                  "nRowID=0&" +
                                  "nColID=0&" +
                                  "nRowIDSub=0");
      }
    }
    else
    {
      var node = this.getParentCell(e.target);
      var input = null;
      if (node)
      {
        // mousedown on a header cell?
        if (node.nodeName == "TH")
        {
          this.headerMousedown(obj, e, node);
        }
        // mousedown on a body cell
        else if (node.nodeName == "TD")
        {
          if (node.className.indexOf("gvBodyMarkCell") == 0)
          {
            this.markCellMousedown(obj, e, node);
          }
          else if (node.className.indexOf("alv") == 0)
          {
            this.bodyMousedown(obj, e, node);
          }
        }
      }
      else if (e.target.nodeName == "IMG")
      {
        var span = dom_getParentNodeByNodeName(e.target, "SPAN");
        var id = "";
        if (span && (id = span.getAttribute("id")))
        {
          var button = id.split("_");
          if (button.length == 2)
          {
            switch (button[1])
            {
              case "gvPageTop" :
                this.fireEvent(obj, "PageTop", "");
                break;
              case "gvPageUp" :
                this.fireEvent(obj, "PageUp", "");
                break;
              case "gvPageDown" :
                this.fireEvent(obj, "PageDown", "");
                break;
              case "gvPageBottom" :
                this.fireEvent(obj, "PageBottom", "");
                break;
            }
          }
        }
      }
    }
    // start timout for delayed selection if necessarry
    if (e.button == EVT_MB_LEFT)
      this.startDelayedChangedSelectionTimeout(obj);

    if (e.shiftKey)
    {
      setTimeout("its_gvMgr.resetBrowserSelection()", 0);
    }
    e.stopPropagation();
    if (its_ua.gecko && e.ctrlKey) // prevent firefox from drawing big borders
    {
      e.preventDefault();
    }
    delete(e);
  }
  obj.selection.changed = false;
}
// </its_gridviewManager::mousedown>


/** <its_gridviewManager::mouseup>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.mouseup = function(evt, obj)
{
  var e = new its_event(evt);
  var row, column;
  if (e)
  {
    delete(e);
  }
}
// </its_gridviewManager::mouseup>


/** <its_gridviewManager::click>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.click = function(evt, obj)
{
  var e = new its_event(evt);
  var rowColumn = null;
  var row       = 0;
  var column    = 0;
  var hotspot   = false;
  var itype     = "";
  if (e)
  {
    var node = this.getParentCell(e.target);
    if (e.target.nodeName == "A")
    {
      return;
    }
    if (node)
    {
      // get row/column attributes
      rowColumn = this.getRowColumn(node);
      if (rowColumn)
      {
        row = rowColumn.row;
        column = rowColumn.column;
        hotspot = rowColumn.hotspot;
        rowid = rowColumn.rowId;
      }
      // click on a header cell?
      if (node.nodeName == "TH")
      {
        if (obj.events && obj.events & GV_EVT_CLICKCOLHEADER)
        {
          var rowColumn = this.getRowColumn(node);
          var column = rowColumn.column;
          if (column > 0)
          {
            this.fireEvent(obj, "ClickColHeader", "strColID=" + column + "&nColID=0");
          }
        }
      }
      else if (node.nodeName == "TD")
      {
        // get node attributes
        var itype = node.getAttribute("itype");
        var disabled = (node.getAttribute("idisabled") == "disabled")? true : false;
        if (e.target.className.indexOf("ddButton") == 0)
        {
          if (itype && itype == "dropdown")
          {
            obj.dropdown.initDropdown(node);
            obj.dropdown.click(e.event);
          }
        }
        else if (e.target.className.indexOf("gvButton") == 0)
        {
          if (obj.events && obj.events & GV_EVT_BUTTONCLICKROWCOL)
          {
            if (row > 0 && column > 0)
            {
              this.fireEvent(obj, "ButtonClickRowCol",
                             "strRowID=" + row.toString() + "&" +
                             "strColID=" + column.toString() + "&" +
                             "nRowID=0&" +
                             "nColID=0&" +
                             "nRowIDSub=0");
            }
          }
        }
        else if (hotspot && obj.events && obj.events & GV_EVT_BUTTONCLICKROWCOL)
        {
          this.fireEvent(obj, "ClickRowCol", "strRowID=" +
                                             row.toString() +
                                             "&strColID=" +
                                             column.toString() +
                                             "&nRowID=0&nColID=0&nRowIDSub=0");
        }
        else if (e.target.className.indexOf("gvTotalExpander") == 0)
        {
          if (obj.events && obj.events & GV_EVT_TOTALCLICKROWCOL)
          {
            if (row > 0 && column > 0)
            {
              var td = dom_getParentNodeByNodeName(e.target, "TD");
              var tr = dom_getParentNodeByNodeName(e.target, "TR");
              if (tr && td)
              {
                var totalLevel = td.getAttribute("totallevel");
                var rowType = tr.getAttribute("rowtype");
                var overallTotal = rowType? rowType.indexOf("OverallTotal") != -1 : false;
                if (!overallTotal || totalLevel > 1)
                {
                  this.fireEvent(obj, "TotalClickRowCol",
                                 "strRowID=" + row.toString() + "&" +
                                 "strColID=" + column.toString() + "&" +
                                 "nRowID=0&" +
                                 "nColID=0&" +
                                 "nRowIDSub=0");
                }
              }
            }
          }
        }
        else if ((e.target.className.indexOf("gvCheckbox") != -1 ||
                  e.target.className.indexOf("gvRadiobutton") != -1))
        {
          if (!disabled && obj.editable == true)
          {
            if (rowid > 0 && column > 0)
            {
              var state = this.switchImage(e.target);
              this.change({type:'itsevent',rowId:rowid,column:column,value:state}, obj);
            }
          }
        }
        else
        {
          href = node.getAttribute("href");
          if (href)
          {
            var input = dom_getChildNodeByNodeName(node, "INPUT");
            if (input)
            {
              window.open(href);
            }
          }
        }
      }
    }
    e.stopPropagation();
    e.preventDefault();
    delete(e);
  }
}
// </its_gridviewManager::click>


/** <its_gridviewManager::doubleclick>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.doubleclick = function(evt, obj)
{
  var e = new its_event(evt);
  var row, column;
  if (e)
  {
    if (obj.events && obj.events & GV_EVT_DOUBLECLICKROWCOL)
    {
      var node = this.getParentCell(e.target);
      if (node)
      {
        var cellNo = this.getRowColumn(node);
        if (cellNo)
        {
          row = cellNo.row;
          column = cellNo.column;
          this.fireEvent(obj, "DoubleClickRowCol",
                         "strRowID=" + row.toString() + "&" +
                         "strColID=" + column.toString() + "&" +
                         "nRowID=0&" +
                         "nColID=0&" +
                         "nRowIDSub=0");
        }
      }
    }
    if (e)
    {
      e.stopPropagation();
      delete(e);
    }
  }
}
// </its_gridviewManager::doubleclick>


/** <its_gridviewManager::mouseover>
  *
  *   Apply tooltip on mouseover if the content exceeds the cells width
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.mouseover = function(evt, obj)
{
  var e = new its_event(evt);
  var td = null;
  var div = null;
  if (e.valid == true)
  {
    if (e.target.className.indexOf("alv") == 0)
    {
      td = e.target;
      div = dom_getChildNodeByNodeName(e.target, "DIV");
    }
    else if (e.target.parentNode.className.indexOf("alv") == 0)
    {
      div = e.target;
      td = dom_getParentNodeByNodeName(e.target, "TD");
    }
    if (div && td)
    {
      if ((td.offsetWidth < div.offsetWidth || td.offsetWidth < div.scrollWidth) &&
          (td.getAttribute("title") == null || td.getAttribute("title").length == 0))
      {
        td.setAttribute("title", div.innerHTML.replace(/&nbsp;/g, " "));
      }
    }
  }
}
// </its_gridviewManager::mouseover>


/** <its_gridviewManager::contextmenu>
  *
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.contextmenu = function(evt, obj)
{
  var e = new its_event(evt);
  if (e)
  {
    var element = dom_getParentNodeByNodeName(e.target, "TABLE");
    if (element && element.className == "gv")
    {
      this.clearDelayedChangedSelectionTimeout(obj);
      this.clearDelayedMovedCurrentCellTimeout(obj);
      webguiDoControlContextMenu(obj.controlId, "ContextMenu", "", e.clientX, e.clientY);
    }
    e.cancel();
    delete(e);
  }
}
// </its_gridviewManager::contextmenu>


/** <its_gridviewManager::keyDown>
  *
  *   process the key down event on a gridview
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj  - Object      - the gridview json object
  */
its_gridviewManager.prototype.keydown = function(evt, obj)
{
  if (obj.dropdown)
  {
    obj.dropdown.holdBlocking = false;
  }
  // if a dropdown is opened it has to handle the keydown event
  if (obj.dropdown.opened)
  {
    obj.dropdown.keydown(evt);
  }
  else
  {
    var e = new its_event(evt);
    if (e)
    {
      var keydownProcessed = false;
      switch (e.keyCode)
      {
        case EVT_KEY_TAB :
          keydownProcessed = this.kbTab(e, obj);
          break;
        case EVT_KEY_RETURN :
          keydownProcessed = this.kbReturn(e, obj);
          break;
        case EVT_KEY_LEFT :
          keydownProcessed = this.kbLeft(e, obj);
          break;
        case EVT_KEY_UP :
          keydownProcessed = this.kbUp(e, obj);
          break;
        case EVT_KEY_RIGHT :
          keydownProcessed = this.kbRight(e, obj);
          break;
        case EVT_KEY_DOWN :
          keydownProcessed = this.kbDown(e, obj);
          break;
        case EVT_KEY_POS1 :
          keydownProcessed = this.kbPos1(e, obj);
          break;
        case EVT_KEY_END :
          keydownProcessed = this.kbEnd(e, obj);
          break;
        case EVT_KEY_PGUP :
          keydownProcessed = this.kbPgup(e, obj);
          break;
        case EVT_KEY_PGDOWN :
          keydownProcessed = this.kbPgdn(e, obj);
          break;
        case EVT_KEY_DEL :
        case EVT_KEY_BCKSPC :
          keydownProcessed = this.kbDelOrBackspace(e, obj);
          break;
        case EVT_KEY_F1 :
          // ie prevent default behaviour (help window)
          if (its_ua.ie55up)
          {
            e.event.keyCode += 400;
          }
          keydownProcessed = this.kbF1(e, obj);
          break;
        case EVT_KEY_F4 :
          // ie prevent default behaviour (jump to adress bar)
          if (its_ua.ie55up)
          {
            e.event.keyCode += 400;
          }
          keydownProcessed = this.kbF4(e, obj);
          break;
        case EVT_KEY_SPACE :
          var itype = e.target.getAttribute("itype");
          // prevent keyboard entries on closed dropdown
          if (e.target.className.indexOf("dd") == 0)
          {
            keydownProcessed = true;
          }
          else if (itype && itype == "checkbox" || itype == "radiobutton")
          {
            keydownProcessed = true;
            var disabled = node.getAttribute("idisabled");
            if (!disabled)
            {
              var rc = this.getRowColumn(e.target);
              var div = dom_getChildNodeByNodeName(e.target, "DIV");
              if (rc && div && rc.rowId > 0 && rc.column > 0)
              {
                var state = this.switchImage(div);
                this.change({type:'itsevent',rowId:rc.rowid,column:rc.column,value:state}, obj);
              }
            }
          }
          break;
        default :
          // prevent keyboard entries on closed dropdown
          if (e.target.className.indexOf("dd") == 0)
          {
            keydownProcessed = true;
          }
          break;
      }
      if (keydownProcessed)
      {
        e.cancel();
      }
      delete(e);
    }
  }
}
// </its_gridviewManager::keyDown>


/** <its_gridviewManager::kbTab>
  *
  *   process the tabulator key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbTab = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr             = dom_getParentNodeByNodeName(node, "TR");
    var input          = null;
    var bodyTable      = dom_getParentNodeByNodeName(tr, "TABLE");
    var firstCellIndex = bodyTable == obj.freeBodyTable? 0 : obj.markCell;
    var cellIndex      = node.cellIndex;
    var rowIndex       = tr.rowIndex;
    var switchResult   = null;
    var leaveRow       = false;
    var i              = 0;

    if (node.className.indexOf("alv") != 0)
    {
      return false;
    }
    else
    {
      if (e.shiftKey)
      {
        cellIndex--;
        if (cellIndex < firstCellIndex)
        {
          leaveRow = false;
          switchResult = this.switchBodyTable(obj, bodyTable, false);
          bodyTable = switchResult.table;
          leaveRow  = switchResult.leaveRow;
          firstCellIndex = switchResult.firstCellIndex;
          if (leaveRow)
          {
            rowIndex--;
          }
          if (rowIndex >= 0)
          {
            cellIndex = bodyTable.rows[rowIndex].cells.length - 1;
          }
        }
        _rv = false;
        if (rowIndex >= 0 && cellIndex >= 0)
        {
          node = bodyTable.rows[rowIndex].cells[cellIndex];
          _rv = true;
        }
      }
      else
      {
        cellIndex++;
        if (cellIndex > bodyTable.rows[rowIndex].cells.length - 1)
        {
          leaveRow = false;
          switchResult = this.switchBodyTable(obj, bodyTable, true);
          bodyTable = switchResult.table;
          leaveRow  = switchResult.leaveRow;
          firstCellIndex = switchResult.firstCellIndex;
          if (leaveRow)
          {
            rowIndex++;
          }
          if (rowIndex < bodyTable.rows.length)
          {
            cellIndex = firstCellIndex;
          }
        }
        _rv = false;
        if (rowIndex < bodyTable.rows.length && cellIndex < bodyTable.rows[rowIndex].cells.length)
        {
          node = bodyTable.rows[rowIndex].cells[cellIndex];
          _rv = true;
        }
      }
      if (_rv && node)
      {
        this.setCurrentCell(obj, node, GV_FOCUS_SELECT);
      }
    }
  }
  return _rv;
}
// </its_gridviewManager::kbTab>


/** <its_gridviewManager::kbReturn>
  *
  *   process the return key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbReturn = function(e, obj)
{
  var _rv = true;
  // return pressed in the repage input field?
  if (e.target.nodeName == "INPUT" && e.target.className == "gvFooter")
  {
    this.fireEvent(obj, "repage", "repage=" + e.target.value);
  }
  else if (obj.editable)
  {
    e.stopPropagation();
    this.change(e.event, obj);
    this.fireEvent(obj, "enter", "");
  }
  return _rv;
}
// </its_gridviewManager::kbReturn>


/** <its_gridviewManager::kbLeft>
  *
  *   process the left key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbLeft = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr           = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable    = null;
    var cellIndex    = node.cellIndex;
    var rowIndex     = tr.rowIndex;
    var cell         = null;
    var cellCount    = 0;
    if (e.target.nodeName == "INPUT")
    {
      _rv = false;
    }
    else if (e.target.nodeName != "INPUT" || e.target.className == "dd" || e.ctrlKey)
    {
      if (e.ctrlKey)
      {
        bodyTable = this.getContainingBodyTable(obj, 1);
        cell = bodyTable.rows[rowIndex].cells[obj.markCell];
      }
      else
      {
        bodyTable = dom_getParentNodeByNodeName(tr, "TABLE");
        cellIndex--;
        if (cellIndex >= 0 && (bodyTable != obj.fixBodyTable || cellIndex >= obj.markCell))
        {
          cell = bodyTable.rows[rowIndex].cells[cellIndex];
        }
        else
        {
          if (bodyTable == obj.freeBodyTable && obj.fixBodyTable)
          {
            cellCount = obj.fixBodyTable.rows[rowIndex].cells.length;
            if (cellCount >= obj.markCell)
            {
              cell = obj.fixBodyTable.rows[rowIndex].cells[cellCount-1];
            }
          }
        }
      }
      if (cell)
      {
        this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
      }
      _rv = true;
    }
  }
  return _rv;
}
// </its_gridviewManager::kbLeft>


/** <its_gridviewManager::kbRight>
  *
  *   process the right key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbRight = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr = dom_getParentNodeByNodeName(node, "TR");
    var rowIndex = tr.rowIndex;
    var bodyTable, cellIndex, cellCount;
    var cell = null;
    if (e.target.nodeName == "INPUT")
    {
      _rv = false;
    }
    else if (e.target.nodeName != "INPUT" || e.target.className == "dd" || e.ctrlKey)
    {
      if (e.ctrlKey)
      {
        bodyTable = this.getContainingBodyTable(obj, obj.columns)
        cellCount = bodyTable.rows[rowIndex].cells.length;
        cell = bodyTable.rows[rowIndex].cells[cellCount-1];
      }
      else
      {
        bodyTable = dom_getParentNodeByNodeName(tr, "TABLE");
        cellIndex = node.cellIndex;
        cellCount = bodyTable.rows[rowIndex].cells.length;
        cellIndex++;
        if (cellIndex < cellCount)
        {
          cell = bodyTable.rows[rowIndex].cells[cellIndex];
        }
        else
        {
          if (bodyTable == obj.fixBodyTable && obj.freeBodyTable)
          {
            cellCount = obj.freeBodyTable.rows[rowIndex].cells.length;
            cellIndex = 0;
            if (cellCount >= cellIndex+1)
            {
              cell = obj.freeBodyTable.rows[rowIndex].cells[cellIndex];
            }
          }
        }
      }
      if (cell)
      {
        this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
      }
      _rv = true;
    }
  }
  return _rv;
}
// </its_gridviewManager::kbRight>


/** <its_gridviewManager::kbUp>
  *
  *   process the up key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbUp = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr           = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable    = dom_getParentNodeByNodeName(tr, "TABLE");
    var cellIndex    = node.cellIndex;
    var rowIndex     = tr.rowIndex;
    var cell         = null;
    if (e.ctrlKey)
    {
      rowIndex = 0;
    }
    else if (rowIndex > 0)
    {
      rowIndex--;
    }
    // be aware of colspans! and find the cell to the left if it is spanned
    do
    {
      cell = bodyTable.rows[rowIndex].cells[cellIndex];
      cellIndex--;
    }
    while (!cell && cellIndex >= 0);
    // update row selection
    if (obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
    {
      this.updateRowSelection(obj, cell);
      this.startDelayedChangedSelectionTimeout(obj);
    }
    this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
    _rv = true;
  }
  return _rv;
}
// </its_gridviewManager::kbUp>


/** <its_gridviewManager::kbDown>
  *
  *   process the up key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbDown = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var isDropdown   = (node.getAttribute("itype") == "dropdown");
    var tr           = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable    = dom_getParentNodeByNodeName(tr, "TABLE");
    var cellIndex    = node.cellIndex;
    var rowIndex     = tr.rowIndex;
    var rowCount     = bodyTable.rows.length;
    var cell         = null;
    if (e.altKey && isDropdown)
    {
      var div = dom_getChildNodeByNodeName(node, "DIV");
      if (div)
      {
        div = dom_getChildNodeByNodeName(div, "DIV");
        if (div)
        {
          e.target = div;
          obj.dropdown.initDropdown(node);
          obj.dropdown.click(e);
        }
      }
    }
    else
    {
      if (e.ctrlKey)
      {
        rowIndex = bodyTable.rows.length - 1;
      }
      else if (rowIndex < rowCount-1)
      {
        rowIndex++;
      }
      // be aware of colspans! and find the cell to the left if it is spanned
      do
      {
        cell = bodyTable.rows[rowIndex].cells[cellIndex];
        cellIndex--;
      }
      while (!cell && cellIndex >= 0);

      // update row selection
      if (obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
      {
        this.updateRowSelection(obj, cell);
        this.startDelayedChangedSelectionTimeout(obj);
      }
      this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
    }
    _rv = true;
  }
  return _rv;
}
// </its_gridviewManager::kbDown>


/** <its_gridviewManager::kbDelOrBackspace>
  *
  *   process the del opr backspace keydown event on a gridview; only for
  *   dropdowns
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbDelOrBackspace = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var isDropdown = (node.getAttribute("itype") == "dropdown");
    var isDisabled = (node.getAttribute("idisabled") != null);
    if (isDropdown)
    {
      if (!isDisabled)
      {
        obj.dropdown.kbDel(true);
      }
      _rv = true;
    }
  }
  return _rv;
}
// </its_gridviewManager::kbDelOrBackspace>


/** <its_gridviewManager::kbPos1>
  *
  *   process the up key pos1 event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbPos1 = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr           = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable    = dom_getParentNodeByNodeName(tr, "TABLE");
    var cellIndex    = node.cellIndex;
    var rowIndex     = tr.rowIndex;
    var cell         = null;
    if (e.target.nodeName == "INPUT")
    {
      _rv = false;
    }
    else if (e.target.nodeName != "INPUT" || e.ctrlKey)
    {
      if (obj.fixBodyTable && obj.fixBodyTable.rows[0].cells.length > obj.markCell)
      {
        bodyTable = obj.fixBodyTable;
        cellIndex = obj.markCell;
      }
      else if (obj.freeBodyTable)
      {
        bodyTable = obj.freeBodyTable;
        cellIndex = 0;
      }
      if (e.ctrlKey)
      {
        rowIndex = 0;
      }
      cell = bodyTable.rows[rowIndex].cells[cellIndex];
      // update row selection
      if (e.ctrlKey && obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
      {
        this.updateRowSelection(obj, cell);
        this.startDelayedChangedSelectionTimeout(obj);
      }
      this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
      _rv = true;
    }
  }
  return _rv;
}
// </its_gridviewManager::kbPos1>


/** <its_gridviewManager::kbEnd>
  *
  *   process the up key end event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbEnd = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr           = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable    = dom_getParentNodeByNodeName(tr, "TABLE");
    var cellIndex    = node.cellIndex;
    var rowIndex     = tr.rowIndex;
    var cell         = null;
    if (e.target.nodeName == "INPUT")
    {
      _rv = false;
    }
    else if (e.target.nodeName != "INPUT" || e.ctrlKey)
    {
      if (obj.freeBodyTable)
      {
        bodyTable = obj.freeBodyTable;
        cellIndex = obj.freeBodyTable.rows[rowIndex].cells.length - 1;
      }
      else if (obj.fixBodyTable)
      {
        bodyTable = obj.fixBodyTable;
        cellIndex = obj.fixBodyTable.rows[rowIndex].cells.length - 1;
      }
      if (e.ctrlKey)
      {
        rowIndex = bodyTable.rows.length - 1;
        e.cancel();
      }
      cell = bodyTable.rows[rowIndex].cells[cellIndex];
      // update row selection
      if (e.ctrlKey && obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
      {
        this.updateRowSelection(obj, cell);
        this.startDelayedChangedSelectionTimeout(obj);
      }
      this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
      _rv = true;
    }
  }
  return _rv;
}
// </its_gridviewManager::kbEnd>


/** <its_gridviewManager::kbPgup>
  *
  *   process the up key pgup event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbPgup = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr            = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable     = dom_getParentNodeByNodeName(tr, "TABLE");
    var bodyContainer = dom_getParentNodeByNodeName(bodyTable, "DIV");
    var cellIndex     = node.cellIndex;
    var rowIndex      = tr.rowIndex;
    var cell          = null;
    var scrollUp      = Math.round(bodyContainer.offsetHeight / 19 - 1);

    if (e.ctrlKey)
    {
      if (obj.fixBodyTable)
      {
        bodyTable = obj.fixBodyTable;
        cellIndex = obj.markCell;
      }
      else if (obj.freeBodyTable)
      {
        bodyTable = obj.freeBodyTable;
        cellIndex = 0;
      }
      rowIndex = 0;
    }
    else
    {
      rowIndex -= scrollUp;
      if (rowIndex < 0)
      {
        rowIndex = 0;
      }
    }
    cell = bodyTable.rows[rowIndex].cells[cellIndex];
    // update row selection
    if (obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
    {
      this.updateRowSelection(obj, cell);
      this.startDelayedChangedSelectionTimeout(obj);
    }
    this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
    _rv = true;
  }
  return _rv;
}
// </its_gridviewManager::kbPgup>


/** <its_gridviewManager::kbPgdn>
  *
  *   process the up key pgdn event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbPgdn = function(e, obj)
{
  var _rv = false;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var tr            = dom_getParentNodeByNodeName(node, "TR");
    var bodyTable     = dom_getParentNodeByNodeName(tr, "TABLE");
    var bodyContainer = dom_getParentNodeByNodeName(bodyTable, "DIV");
    var cellIndex     = node.cellIndex;
    var rowIndex      = tr.rowIndex;
    var cell          = null;
    var scrollDown    = Math.round(bodyContainer.offsetHeight / 19 - 1);

    if (e.ctrlKey)
    {
      if (obj.freeBodyTable)
      {
        bodyTable = obj.freeBodyTable;
        cellIndex = obj.freeBodyTable.rows[rowIndex].cells.length - 1;
      }
      else if (obj.fixBodyTable)
      {
        bodyTable = obj.fixBodyTable;
        cellIndex = obj.fixBodyTable.rows[rowIndex].cells.length - 1;
      }
      rowIndex = bodyTable.rows.length - 1;
    }
    else
    {
      rowIndex += scrollDown;
      if (rowIndex > bodyTable.rows.length-1)
      {
        rowIndex = bodyTable.rows.length-1;
      }
    }
    cell = bodyTable.rows[rowIndex].cells[cellIndex];
    // update row selection
    if (obj.selection.rows == GV_SEL_MODE_SINGLE || (obj.selection.rows == GV_SEL_MODE_MULTIPLE && !obj.markCell))
    {
      this.updateRowSelection(obj, cell);
      this.startDelayedChangedSelectionTimeout(obj);
    }
    this.setCurrentCell(obj, cell, GV_FOCUS_SELECT);
    _rv = true;
  }
  return _rv;
}
// </its_gridviewManager::kbPgdn>


/** <its_gridviewManager::kbF4>
  *
  *   process the f4 key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbF4 = function(e, obj)
{
  var _rv = true;
  node = this.getCurrentCell(obj);
  if (node)
  {
    var f4 = node.getAttribute("f4");
    if (f4 && f4 == "1")
    {
      var rowColumn = this.getRowColumn(node);
      if (rowColumn.row > 0 && rowColumn.column > 0)
      {
        var params = "strRowID=" + rowColumn.row + "&" +
                     "strColID=" + rowColumn.column + "&" +
                     "nRowID=0&nColID=0&nRowIDSub=0";
        this.fireEvent(obj, "F4", params);
      }
    }
  }
  return _rv;
}
// </its_gridviewManager::kbF4>


/** <its_gridviewManager::kbF1>
  *
  *   process the f1 key down event on a gridview
  *
  *   params:
  *     e    - Oject  - the its_event
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.kbF1 = function(e, obj)
{
  var _rv = false;
  this.fireEvent(obj, "F1", "");
  e.cancel();
  _rv = true;
  return _rv;
}
// </its_gridviewManager::kbF1>


/** <its_gridviewManager::startDelayedChangedSelectionTimeout>
  *
  *  start delayed change selection timeout
  *
  *   params:
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.startDelayedChangedSelectionTimeout = function(obj)
{
  if (obj.selection.changed && obj.events & GV_EVT_DELAYEDCHANGEDSELECTION)
  {
    this.clearDelayedChangedSelectionTimeout(obj);
    obj.tDelayedChangedSelectionTimeout = window.setTimeout
    (
      obj.fDelayedChangedSelection,
      obj.delayedChangedSelectionTimeout
    );
  }
}
// </its_gridviewManager::startDelayedChangedSelectionTimeout>


/** <its_gridviewManager::clearDelayedChangedSelectionTimeout>
  *
  *  clear delayed change selection timeout
  *
  *   params:
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.clearDelayedChangedSelectionTimeout = function(obj)
{
  if (obj.delayedChangedSelectionTimeout != undefined)
    window.clearTimeout(obj.tDelayedChangedSelectionTimeout);
}
// </its_gridviewManager::clearDelayedChangedSelectionTimeout>


/** <its_gridviewManager::startDelayedMovedCurrentCellTimeout>
  *
  *  start delayed moved current cell timeout
  *
  *   params:
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.startDelayedMovedCurrentCellTimeout = function(obj)
{
  if (obj.initialized == true && obj.events & GV_EVT_DELAYEDMOVEDCURRENTCELL)
  {
    this.clearDelayedMovedCurrentCellTimeout(obj);
    obj.tDelayedMovedCurrentCellTimeout = window.setTimeout
    (
      obj.fDelayedMovedCurrentCell,
      obj.delayedMovedCurrentCellTimeout
    );
  }
}
// </its_gridviewManager::startDelayedMovedCurrentCellTimeout>


/** <its_gridviewManager::clearDelayedMovedCurrentCellTimeout>
  *
  *  clear  delayed moved current cell timeout
  *
  *   params:
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.clearDelayedMovedCurrentCellTimeout = function(obj)
{
  if (obj.delayedMovedCurrentCellTimeout != undefined)
    window.clearTimeout(obj.tDelayedMovedCurrentCellTimeout);
}
// </its_gridviewManager::clearDelayedMovedCurrentCellTimeout>


/** <its_gridviewManager::triggerDelayedEvent>
  *
  *   timout for delayed event is over, fire event to backend
  *
  *   params:
  *     obj  - Object      - the gridview json object
  */
its_gridviewManager.prototype.triggerDelayedEvent = function(evt, obj)
{
  dbg3("gridview", "<triggerDelayedEvent>");
  this.fireEvent(obj, evt, "");
  dbg3("gridview", "</triggerDelayedEvent>");
}
// </its_gridviewManager::triggerDelayedEvent>


/** <its_gridviewManager::switchImage>
  *
  *   switches the source of an image; used for displaying checkboxes and
  *   radios
  *
  *   params:
  *     div - Oject - HTML div element representing the checkbox/radiobutton
  */
its_gridviewManager.prototype.switchImage = function(div)
{
  var checked = (div.className.indexOf("Unchecked") == -1);
  if (checked)
  {
    div.className = div.className.replace(/Checked/g, "Unchecked");
    return " ";
  }
  else
  {
    div.className = div.className.replace(/Unchecked/g, "Checked");
    return "X";
  }
}
// </its_gridviewManager::switchImage>


/** <its_gridviewManager::switchBodyTable>
  *
  *  return the opposite table, e. g. when fixBodyTable is given, freeBodyTable
  *  is returned; if fixBodyTable is null, freeBodyTable will be returned.
  *
  *   params:
  *   obj     - Object  - the its_tablecontrolObject
  *   table   - Object  - the table
  *   forward - Boolean - navigate for- or backward
  */
its_gridviewManager.prototype.switchBodyTable = function(obj,
                                                         table,
                                                         forward)
{
  var result = new Object();
  if (table == obj.fixBodyTable)
  {
    if (obj.freeBodyTable)
    {
      result.leaveRow = (forward? false : true);
      result.table = obj.freeBodyTable;
      result.firstCellIndex = 0;
    }
    else
    {
      result.leaveRow = true;
      result.table = obj.fixBodyTable;
      result.firstCellIndex = obj.markCell;
    }
  }
  else if (table == obj.freeBodyTable)
  {
    if (obj.fixBodyTable)
    {
      if (obj.fixBodyTable.rows[0].cells.length > obj.markCell)
      {
        result.leaveRow = (forward? true : false);
        result.table = obj.fixBodyTable;
        result.firstCellIndex = obj.markCell;
      }
      else
      {
        result.leaveRow = true;
        result.table = obj.freeBodyTable;
        result.firstCellIndex = 0;
      }
    }
    else
    {
      result.leaveRow = true;
      result.table = obj.freeBodyTable;
      result.firstCellIndex = 0;
    }
  }
  return result;
}
// </its_gridviewManager::switchBodyTable>


/** <its_gridviewManager::setCurrentCell>
  *
  *  set the current cell including className (for background-color), focus and
  *  text selection
  *
  *   params:
  *   obj  - Object - the gridview json object
  *   node - Object - the current cell object (td)
  */
its_gridviewManager.prototype.setCurrentCell = function(obj, node, focusType, scrollIntoView)
{
  if (focusType != GV_FOCUS_NONE)
    webguiSaveFocus(new webguiFocusObj(3, obj));

  if (node && typeof(node) != "undefined" && node != obj.currentCell)
  {
    var input = this.getInputField(node);
    var searchHelp = node.getAttribute("f4");
    var rowColumn = null;
    var table = null;

    // call the unsetCurrentCell method as it does not work otherwise be
    // timing problems
    if (obj.currentCell)
    {
      this.unsetCurrentCell(obj);
    }

    obj.currentCell = node;

    this.startDelayedMovedCurrentCellTimeout(obj);

    var itype = node.getAttribute("itype");
    if (input == null && itype)
    {
      if (itype == "text")
      {
        input = this.renderInputField(obj, node);
      }
      else if (itype == "dropdown")
      {
        input = obj.dropdown.initDropdown(node);
      }
    }
    //
    // SETTING THE NODES STYLE
    //
    node.className = dom_addClass(node.className, "gvBodyCurrent");
    //
    // REMEMBERING THE WEBGUIS FOCUS FIELD
    //
    rowColumn = this.getRowColumn(node);
    if (rowColumn)
    {
      obj.selection.tpCurrentCellRow.value = rowColumn.row;
      obj.selection.tpCurrentCellColumn.value = rowColumn.column;
    }
    //
    // SETTING THE BROWSERS FOCUS
    //
    var focusElement = null;
    if (input)
      focusElement = input;
    else if (itype != undefined && itype == "dropdown")
      focusElement = obj.dropdown.initDropdown(node);
    else
      focusElement = obj.container;
    if (focusElement != null)
    {
      switch (focusType)
      {
        case GV_FOCUS_SELECT :
          dom_delayedSelect(focusElement);
          break;
        case GV_FOCUS_FOCUS  :
          dom_delayedFocus(focusElement);
          break;
      }
    }
    //
    // DISPLAY THE SEARCHHELP BUTTON
    //
    if (typeof webguiShButtonManager != "undefined" &&
        typeof webguiShButtonManager.Update != "undefined")
    {
      webguiShButtonManager.Update("gridviewSearchHelpButton", obj, node);
    }
    if (searchHelp)
    {
      this.displaySearchHelpButton(obj, node);
    }
    //
    // SCROLL THE CELL INTO VIEW
    //
    if (scrollIntoView == undefined || scrollIntoView == true)
      this.scrollCellIntoView(obj, node);
  }
}
// </its_gridviewManager::setCurrentCell>


/** <its_gridviewManager::unsetCurrentCell>
  *
  *  unset the current cell including className (for background-color) and
  *  selection; only if focus is set outside the GV, this method is invoked by
  *  the blur event handler, otherwise it is called from method setCurrentCell.
  *
  *   params:
  *   node - Object - the gridview json object
  */
its_gridviewManager.prototype.unsetCurrentCell = function(obj)
{
  if (obj.currentCell)
  {
    this.clearDelayedMovedCurrentCellTimeout(obj);

    var searchHelp = obj.currentCell.getAttribute("f4");
    obj.currentCell.className = dom_removeClass(obj.currentCell.className,
                                                "gvBodyCurrent");
    var input = this.getInputField(obj.currentCell);
    if (searchHelp)
    {
      this.hideSearchHelpButton(obj, obj.currentCell);
    }
    obj.currentCell = null;
  }
}
// </its_gridviewManager::unsetCurrentCell>


/** <its_gridviewManager::scrollCellIntoView>
  *
  *  scrolls the current cell into view
  *
  *   params:
  *   obje  - Object - the gridview json object
  *   node  - Object - the current cell
  */
its_gridviewManager.prototype.scrollCellIntoView = function(obj, node)
{
  var scrollLeft = -1, scrollTop = -1;
  if (node)
  {
    var verticalScrollBarOffset = 0;
    var horizontalScrollBarOffset = 0;
    var table = dom_getParentNodeByNodeName(node, "TABLE");
    var container = dom_getParentNodeByNodeName(table, "DIV");
    if (table && container)
    {
      if (container == obj.freeBodyContainer)
      {
        if (table.offsetHeight > container.offsetHeight)
        {
          verticalScrollBarOffset = 16;
        }
        if (table.offsetWidth > container.offsetWidth)
        {
          horizontalScrollBarOffset = 16;
        }
        if (node.offsetLeft + node.offsetWidth > container.offsetWidth + container.scrollLeft - verticalScrollBarOffset)
        {
          scrollLeft = node.offsetLeft + node.offsetWidth + verticalScrollBarOffset - container.offsetWidth;
          if (scrollLeft > node.offsetLeft)
          {
            scrollLeft = node.offsetLeft
          }
        }
        else if (node.offsetLeft < container.scrollLeft)
        {
          scrollLeft = node.offsetLeft;
        }
        if (scrollLeft != -1)
        {
          container.scrollLeft = scrollLeft;
          if (obj.freeHeaderContainer)
          {
            obj.freeHeaderContainer.scrollLeft = scrollLeft;
          }
        }
        if (node.offsetTop + node.offsetHeight > container.offsetHeight + container.scrollTop - horizontalScrollBarOffset)
        {
          scrollTop = node.offsetTop + node.offsetHeight - container.offsetHeight + horizontalScrollBarOffset;
        }
        else if (node.offsetTop < container.scrollTop)
        {
          scrollTop = node.offsetTop;
        }
        if (scrollTop != -1)
        {
          container.scrollTop = scrollTop;
          if (obj.fixBodyContainer)
          {
            obj.fixBodyContainer.scrollTop = scrollTop;
          }
        }
      }
      else if (container == obj.fixBodyContainer)
      {
        if (node.offsetTop + node.offsetHeight > container.offsetHeight + container.scrollTop)
        {
           scrollTop = node.offsetTop + node.offsetHeight - container.offsetHeight;
        }
        else if (node.offsetTop < container.scrollTop)
        {
          scrollTop = node.offsetTop;
        }
        if (scrollTop != -1)
        {
          container.scrollTop = scrollTop;
          if (obj.freeBodyContainer)
          {
            obj.freeBodyContainer.scrollTop = scrollTop;
          }
        }
      }
    }
  }
}
// </its_gridviewManager::scrollCellIntoView>


/** <its_gridviewManager::focus>
  *
  *  Event handler for focus event on the gridview; does only stop propagation
  *  of focus to the dynpro (webguiDoFocus)
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *   obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.focus = function(evt)
{
  e = new its_event(evt);
  if (e.valid)
  {
    e.stopPropagation();
    delete(e);
  }
}
// </its_gridviewManager::focus>


/** <its_gridviewManager::setBrowserFocus>
  *
  *  set the focus to an input field and select the input field if it is of
  *  type text
  *
  *   params:
  *   obj    - Object  - the gridview json object
  *   field  - Object  - the input field to set the focus to
  *   select - Boolean - select/dont selct the content of the input field
  */
/*
its_gridviewManager.prototype.setBrowserFocus = function(obj, input, focusType)
{
  if (focusType != GV_FOCUS_NONE)
  {
    webguiSaveFocus(obj);
    if (input.nodeName == "INPUT")
    {
      if (focusType == GV_FOCUS_SELECT)
      {
        dom_delayedSelect(input);
      }
      else if (focusType == GV_FOCUS_FOCUS)
      {
        dom_delayedFocus(input);
      }
    }
    else
      dom_delayedFocus(obj.container);
  }
}
// </its_gridviewManager::setBrowserFocus>
*/

/** <its_gridviewManager::renderInputField>
  *
  *   render an input field in the appropriate cell
  *   params:
  *     node - Object - the td object to render the input field
  */
its_gridviewManager.prototype.renderInputField = function(obj, node)
{
  var input = this.getInputField(node);
  var itype, ivalue, idisabled, imaxlength, itabindex, ialign,
      ivalueset, iselectedindex;
  var cc = null;
  var a = null;
  var value = "";

  if (!input)
  {
    itype = node.getAttribute("itype");
    idisabled = node.getAttribute("idisabled");
    if (itype && !idisabled)
    {
      node.removeAttribute("itype");
    }
    cc = dom_getChildNodeByNodeName(node, "DIV");
    if (cc && cc.childNodes.length > 0)
    {
      a = dom_getChildNodeByNodeName(cc, "A");
      if (a)
      {
        cc = a;
      }
    }
    if (cc)
    {
      if (its_ua.gecko)
      {
        value = cc.textContent;
      }
      else if (its_ua.ie55up)
      {
        value = cc.innerText;
      }
    }
    if (value == "&nbsp;" || value == "\xA0" || value == " ")
    {
      value = "";
    }
    imaxlength  = node.getAttribute("imaxlength");
    ialign      = node.getAttribute("ialign");
    isize       = node.getAttribute("isize");
    itabindex   = node.getAttribute("tabindex");
    className   = node.className;

    if (itype == "text")
    {
      input = document.createElement("INPUT");
      if (cc.nodeName == "A")
      {
        input.style.textDecoration = "underline";
      }
      input.setAttribute("type", "text");
      input.value = value;
      input.className = "alvedit" + " " + cc.className;;
      if (className.indexOf("gvError") != -1)
      {
        input.className = dom_addClass(input.className, "gvError");
      }
      input.setAttribute("tabIndex", -1);
      its_eMgr.registerEvent(input, "change", obj.fChange);
      if (cc.nodeName == "A")
      {
        input.setAttribute("href", cc.getAttribute("href"));
        fClick = function(evt) { its_gvMgr.click(evt, obj); };
        its_eMgr.registerEvent(input, "click", fClick);
      }
      if (ialign)
      {
        input.style.textAlign = ialign;
      }
      if (imaxlength)
      {
        input.maxLength = imaxlength;
      }
    }
    node.style.paddingTop = 0;
    node.style.paddingLeft = 0;
    input.style.width = node.offsetWidth - 1;
    node.innerHTML = "";
    node.appendChild(input);
  }
  return input;
}
// </its_gridviewManager::renderInputField>


/** <its_gridviewManager::displaySearchHelpButton>
  *
  *   display the cells searchhelp button
  *   params:
  *     obj  - Object - the gridview json object
  *     node - Object - the td object to render the input field
  */
its_gridviewManager.prototype.displaySearchHelpButton = function(obj, node)
{
  node.style.overflow = "hidden";
  if (obj.searchHelpButton == undefined)
  {
    obj.searchHelpButton = document.createElement("DIV");
    obj.searchHelpButton.id = obj.name + "_SH";
  }
  var div = dom_getChildNodeByNodeName(node, "DIV");
  if (!div)
  {
    div = dom_getChildNodeByNodeName(node, "INPUT");
  }
  if (div)
  {
    if (div.style.textAlign == "right" || div.className.indexOf("gvR") > -1)
    {
      node.style.paddingTop = node.style.paddingBottom = node.style.paddingLeft = 0;
      node.style.styleFloat = "right";
      div.className = dom_addClass(div.className, "gvR");
      obj.searchHelpButton.className = "gvSearchHelpL";
      node.insertBefore(obj.searchHelpButton, div);
    }
    else
    {
      node.style.paddingTop = node.style.paddingBottom = node.style.paddingRight = 0;
      node.style.styleFloat = "left";
      div.className = dom_addClass(div.className, "gvL");
      obj.searchHelpButton.className = "gvSearchHelpR";
      node.insertBefore(obj.searchHelpButton, null);
    }
    obj.searchHelpButton.style.display = "block";
    div.style.paddingTop = "1px";
    div.style.width = (node.offsetWidth -
                       obj.searchHelpButton.offsetWidth - 3).toString() + "px";
    obj.searchHelpButton.removed = false;
  }
}
// </its_gridviewManager::displaySearchHelpButton>


/** <its_gridviewManager::hideSearchHelpButton>
  *
  *   hide the cells searchhelp button
  *   params:
  *     obj  - Object - the gridview json object
  *     node - Object - the td object to render the input field
  */
its_gridviewManager.prototype.hideSearchHelpButton = function(obj, node)
{
  var shb = obj.searchHelpButton;
  if (shb && (shb.removed == undefined || shb.removed == false))
  {
    shb.style.display = "none";
    if (shb.parentNode == node)
      node.removeChild(shb);
    var div = dom_getChildNodeByNodeName(node, "DIV");
    if (!div)
      div = dom_getChildNodeByNodeName(node, "INPUT");
    if (div)
    {
      if (div.nodeName == "INPUT")
        div.style.width = node.offsetWidth - 1;
      else
        div.style.width = "";
      div.style.paddingTop = "";
    }
    shb.removed = true;
  }
}
// </its_gridviewManager::hideSearchHelpButton>


/** <its_gridviewManager::scroll>
  *
  *   process the scroll event on a gridview
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj  - Object      - the gridview json object
  */
its_gridviewManager.prototype.scroll = function(evt, obj)
{
  var e = new its_event(evt);
  if (e)
  {
    var scrollTop = 0;
    var scrollLeft = 0;
    var target = e.target;
    if (its_ua.gecko)
    {
      target = e.currentTarget;
    }
    // Sync only differing DOM offsets; do not defer or skip form-field updates.
    // Read current nodes each time so partial refreshes cannot leave a stale cache.
    // change scrolling context
    if (obj.tpScrollContext != null)
      obj.tpScrollContext.value = GV_SCROLL_TO_POSITION;
    if (target == obj.fixBodyContainer)
    {
      scrollTop = obj.fixBodyContainer.scrollTop;
      if (obj.freeBodyContainer)
      {
        if (obj.freeBodyContainer.scrollTop !== scrollTop)
          obj.freeBodyContainer.scrollTop = scrollTop;
      }
      // remember scroll position
      if (obj.tpScrollTop)
      {
        obj.tpScrollTop.value = scrollTop;
      }
    }
    else if (target == obj.freeBodyContainer)
    {
      scrollTop = obj.freeBodyContainer.scrollTop;
      scrollLeft = obj.freeBodyContainer.scrollLeft;
      if (obj.freeHeaderContainer)
      {
        if (obj.freeHeaderContainer.scrollLeft !== scrollLeft)
          obj.freeHeaderContainer.scrollLeft = scrollLeft;
      }
      if (obj.fixBodyContainer)
      {
        if (obj.fixBodyContainer.scrollTop !== scrollTop)
          obj.fixBodyContainer.scrollTop = scrollTop;
      }
      // remember scroll positions
      if (obj.tpScrollTop && obj.tpScrollLeft)
      {
        obj.tpScrollTop.value = scrollTop;
        obj.tpScrollLeft.value = scrollLeft;
      }
    }
    delete(e);
  }
}
// </its_gridviewManager::scroll>


/** <its_gridviewManager::change>
  *
  *   process the change event on a gridview
  *
  *   params:
  *     evt - Oject(Event) - for mozilla (only) to give the event
  *     obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.change = function(evt, obj)
{
  dbg3("gridview", "<change>");
  if (evt.type != undefined && evt.type == "itsevent")
  {
    obj.selection.trackModified(evt.rowId, evt.column, evt.value);
  }
  else
  {
    var e = new its_event(evt);
    if (e.valid)
    {
      var input = e.target;
      if (input.nodeName == "INPUT" || input.nodeName == "SELECT")
      {
        var node = dom_getParentNodeByNodeName(input, "TD");
        if (node)
        {
          var rowColumn = this.getRowColumn(node);
          if (rowColumn)
          {
            var rowId = rowColumn.rowId;
            var column = rowColumn.column;
            if (rowColumn)
            {
              if (rowId != "" && column > 0)
              {
                var value = input.value;
                if (typeof value != "undefined")
                {
                  obj.selection.trackModified(rowId, column, value);
                }
              }
            }
          }
        }
      }
      delete(e);
    }
  }
  if (obj.events & GV_EVT_MODIFIED)
  {
    this.fireEvent(obj, "modified", "");
  }
  dbg3("gridview", "</change>");
}
// </its_gridviewManager::change>


/** <its_gridviewManager::setScrollPositionOnLoad>
  *
  *   set the gridviews scroll position on load and registers the scroll event
  *   handler
  *
  *   params:
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.setScrollPositionOnLoad = function(obj)
{
  var scrollTop = -1;
  var scrollLeft = -1;

  if (obj.tpScrollTop != null)
    scrollTop = parseInt(obj.tpScrollTop.value, 10);
  if (obj.tpScrollLeft != null)
    scrollLeft = parseInt(obj.tpScrollLeft.value, 10);
  if (obj.tpScrollContext != null)
    scrollContext = parseInt(obj.tpScrollContext.value, 10);

  switch (scrollContext)
  {
    case GV_SCROLL_TO_CELL :
      break;
    case GV_SCROLL_TO_ROW :
      var oTable = its_gvMgr.getContainingBodyTable(obj, 1);
      if (oTable)
      {
        var oRow = oTable.rows[obj.firstVisibleRow];
        if (oRow)
        {
          scrollTop = oRow.offsetTop;
        }
      }
      break;
    case GV_SCROLL_TO_COLUMN :
      break;
    case GV_SCROLL_TO_POSITION :
      break;
  }

  if (scrollTop != -1)
  {
    if (obj.fixBodyContainer)
      obj.fixBodyContainer.scrollTop = scrollTop;
    if (obj.freeBodyContainer)
      obj.freeBodyContainer.scrollTop = scrollTop;
  }
  if (scrollLeft != -1)
  {
    if (obj.freeHeaderContainer)
      obj.freeHeaderContainer.scrollLeft = scrollLeft;
    if (obj.freeBodyContainer)
      obj.freeBodyContainer.scrollLeft = scrollLeft;
  }

  // remember position
  obj.tpScrollTop.value = scrollTop;
  obj.tpScrollLeft.value = scrollLeft;
}
// </its_gridviewManager::setScrollPositionOnLoad>


/** <its_gridviewManager::headerMousedown>
  *
  *   process the mousedown on a header cell
  *
  *   params:
  *     obj  - Object - the gridview json object
  *     e    - Object - the its_event object
  *     node - Object - the th tag/node to process
  */
its_gridviewManager.prototype.headerMousedown = function(obj, e, node)
{
  var switched = false;
  if (obj.selection.all && !e.ctrlKey)
  {
    this.switchEntireSelection(obj, false);
    switched = true;
  }

  var rowColumn = this.getRowColumn(node);
  var columnNo = rowColumn.column;
  var columnSelected = obj.selection.columnSelected(columnNo);
  obj.selection.currentRow = -1;
  obj.selection.currentCell = -1;

  if (e.target.className.indexOf("gvHeaderColresize") == 0)
  {
    this.colResizeStart(e.event, obj);
  }
  else
  {
    this.unsetCurrentCell(obj);
    obj.selection.tpCurrentCellRow.value = 0;
    obj.selection.tpCurrentCellColumn.value = columnNo;
    // mousedown on the mark all header cell?
    if (node.className.indexOf("gvHeaderMarkCell") == 0)
    {
      if (!switched)
      {
        this.switchEntireSelection(obj);
      }
    }
    // mousedown on a common header cell
    else if (node.className.indexOf("gvHeader") == 0)
    {
      if (obj.selection.cells != GV_SEL_MODE_MULTIPLE)
      {
        this.resetCellSelection(obj);
      }
      if (e.shiftKey)
      {
        if (obj.selection.currentColumn > -1)
        {
          for (var i = Math.min(obj.selection.currentColumn, columnNo);
               i <= Math.max(obj.selection.currentColumn, columnNo);
               i++)
          {
            this.switchColumnSelection(obj, i, true);
          }
        }
        else
        {
          this.switchColumnSelection(obj, columnNo, true);
        }
        obj.selection.currentColumn = columnNo;
      }
      else if (e.ctrlKey)
      {
        if (this.switchColumnSelection(obj, columnNo))
        {
          obj.selection.currentColumn = columnNo;
        }
        else
        {
          // transform row selection to cell selection
//          this.transformRowSelection(obj, -1, columnNo, true);
        }
      }
      else if (!columnSelected)
      {
        this.resetColumnSelection(obj);
        this.resetRowSelection(obj);
        this.resetCellSelection(obj);
        this.switchColumnSelection(obj, columnNo);
        obj.selection.currentColumn = columnNo;
      }
    }
  }
}
// </its_gridviewManager::headerMousedown>


/** <its_gridviewManager::markCellMousedown>
  *
  *   process the mousedown on a row mark cell
  *
  *   params:
  *     obj  - Object - the gridview json object
  *     e    - Object - the its_event object
  *     node - Object - the td tag/node to process
  */
its_gridviewManager.prototype.markCellMousedown = function(obj, e, node)
{
  this.unsetCurrentCell(obj);
  if (obj.selection.cells != GV_SEL_MODE_MULTIPLE)
  {
    this.resetCellSelection(obj);
  }
  if (obj.selection.all)
  {
    if(!e.ctrlKey)
    {
      this.switchEntireSelection(obj, false);
    }
    else if (e.ctrlKey)
    {
      this.resetColumnSelection(obj);
    }
  }
  var tr = dom_getParentNodeByNodeName(node, "TR");
  if (tr)
  {
    var r = tr.getAttribute("r");
    if (r)
    {
      var rowNo = parseInt(r, 10);
      var rowSelected = obj.selection.rowSelected(rowNo);
      obj.selection.currentColumn = -1;
      obj.selection.currentCell = -1;
      obj.selection.tpCurrentCellRow.value = rowNo;
      obj.selection.tpCurrentCellColumn.value = 0;

      if (e.shiftKey && obj.selection.rows == GV_SEL_MODE_MULTIPLE)
      {
        if (obj.selection.currentRow > -1)
        {
          obj.selection.SelectedRowsRanges[0]++;
          for (var i = Math.min(obj.selection.currentRow, rowNo);
               i <= Math.max(obj.selection.currentRow, rowNo);
               i++)
          {
            this.switchRowSelection(obj, i, true, true);
            obj.selection.SelectedRowsRanges[i] = obj.selection.SelectedRowsRanges[0];
          }
        }
        else
        {
          this.switchRowSelection(obj, rowNo, true, true);
          obj.selection.SelectedRowsRanges[rowNo] = ++obj.selection.SelectedRowsRanges[0];
        }
        obj.selection.currentRow = rowNo;
      }
      else if (e.ctrlKey && obj.selection.rows == GV_SEL_MODE_MULTIPLE)
      {
        if (this.switchRowSelection(obj, rowNo, undefined, true))
        {
          obj.selection.currentRow = rowNo;
          obj.selection.SelectedRowsRanges[rowNo] = ++obj.selection.SelectedRowsRanges[0];
        }
        else
        {
          obj.selection.SelectedRowsRanges[rowNo] = 0;
        }
      }
      else if (!rowSelected)
      {
        this.resetColumnSelection(obj);
        this.resetRowSelection(obj);
        this.resetCellSelection(obj);
        this.switchRowSelection(obj, rowNo, undefined, true)
        obj.selection.currentRow = rowNo;
        obj.selection.SelectedRowsRanges[rowNo] = ++obj.selection.SelectedRowsRanges[0];
      }
      var prev = 0;
      var range = false;
      var str = "";
      for (var i = 1; i <= obj.selection.SelectedRowsRanges.length; i++)
      {
        if (obj.selection.SelectedRowsRanges[i] > 0)
        {
          if (obj.selection.SelectedRowsRanges[i] == prev)
            range = true;
          else
          {
            if (range)
            {
              str += "-" + (i - 1).toString() + ";" + i.toString();
              range = false;
            }
            else
            {
              str += ";" + i.toString();
            }
            prev = obj.selection.SelectedRowsRanges[i];
          }
        }
        else
        {
          if (prev != 0 && range)
          {
            str += "-" + (i - 1).toString();
            range = false;
          }
          prev = 0;
        }
      }
      obj.selection.tpRows.value = str + ";";
    }
  }
  obj.selection.all = false;
}
// </its_gridviewManager::markCellMousedown>


/** <its_gridviewManager::bodyMousedown>
  *
  *   process the mousedown on a body cell
  *
  *   params:
  *     obj  - Object - the gridview json object
  *     e    - Object - the its_event object
  *     node - Object - the td tag/node to process
  */
its_gridviewManager.prototype.bodyMousedown = function(obj, e, node)
{
  var cellNo = this.getRowColumn(node);
  var rowNo, columnNo;
  var rowNo2, columnNo2;

  if (cellNo)
  {
    rowNo = cellNo.row;
    columnNo = cellNo.column;
  }
  if (rowNo && columnNo)
  {
    if (obj.selection.cells != GV_SEL_MODE_NONE)
    {
      if (obj.selection.cells == GV_SEL_MODE_SINGLE)
      {
        this.resetRowSelection(obj);
        this.resetColumnSelection(obj);
        this.resetCellSelection(obj);
      }
      else
      {
        var cellSelected = obj.selection.cellSelected(rowNo, columnNo);
        if (e.shiftKey)
        {
          if (obj.selection.currentCell > -1)
          {
            rowNo2 = parseInt(obj.selection.tpCurrentCellRow.value, 10);
            columnNo2 = parseInt(obj.selection.tpCurrentCellColumn.value, 10);
            if (rowNo2 > 0 && columnNo2 > 0)
            {
              this.switchCellRangeSelection(obj, rowNo, columnNo, rowNo2, columnNo2);
            }
          }
          else if (obj.selection.currentRow > -1)
          {
            rowNo2 = parseInt(obj.selection.currentRow, 10);
            this.switchRowSelection(obj, rowNo2, false, true);
            this.switchCellRangeSelection(obj, rowNo, columnNo, rowNo2, columnNo);
          }
          else if (obj.selection.currentColumn > -1)
          {
            var columnNo2 = parseInt(obj.selection.currentColumn, 10);
//            this.switchColumnSelection(obj, columnNo2, false);
            this.switchCellRangeSelection(obj, rowNo, columnNo, rowNo, columnNo2);
          }
          else
          {
            this.switchCellSelection(obj, rowNo, columnNo, true);
          }
          obj.selection.currentCell = 1;
        }
        else if (e.ctrlKey)
        {
          if (obj.selection.tpCells.value == ";")
          {
            rowNo2 = parseInt(obj.selection.tpCurrentCellRow.value, 10);
            columnNo2 = parseInt(obj.selection.tpCurrentCellColumn.value, 10);
            if (rowNo2 > 0 && columnNo2 > 0)
            {
              this.switchCellSelection(obj, rowNo2, columnNo2, true);
            }
          }
          if (this.switchCellSelection(obj, rowNo, columnNo))
          {
            obj.selection.currentCell = 1;
          }
          else if (obj.selection.rowSelected(rowNo) ||
                   obj.selection.columnSelected(columnNo))
          {
            // transform row and column selection to cell selection
            this.transformRowSelection(obj, rowNo, columnNo, false);
            this.transformColumnSelection(obj, rowNo, columnNo, false);
          }
        }
        else
        {
          this.resetColumnSelection(obj);
          this.resetRowSelection(obj);
          this.resetCellSelection(obj);
          obj.selection.currentCell = 1;
        }
      }
    }
    else if (obj.selection.rows != GV_SEL_MODE_NONE)
    {
      this.markCellMousedown(obj, e, node);
    }
  }
  this.setCurrentCell(obj, node, GV_FOCUS_FOCUS, false);
}
// </its_gridviewManager::bodyMousedown>


/** <its_gridviewManager::switchEntireSelection>
  *
  *  switch the selection of all rows
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.switchEntireSelection = function(obj, mode)
{
  var objh = new Array();
  var objb = new Array();
  var c, r;
  var select = mode;

  var p = obj.container.parentNode;
  var n = obj.container.nextSibling;
  p.removeChild(obj.container);

  if (typeof select == "undefined")
  {
    select = !obj.selection.all;
  }
  if (obj.fixHeaderTable && obj.fixHeaderTable.rows)
  {
    for (c = (0+obj.markCell); c < obj.fixHeaderTable.rows[0].cells.length; c++)
    {
      objh.push(obj.fixHeaderTable.rows[0].cells[c]);
    }
  }
  if (obj.freeHeaderTable && obj.freeHeaderTable.rows)
  {
    for (c = 0; c < obj.freeHeaderTable.rows[0].cells.length; c++)
    {
      objh.push(obj.freeHeaderTable.rows[0].cells[c]);
    }
  }
  if (obj.fixBodyTable && obj.fixBodyTable.rows)
  {
    for (r = 0; r < obj.fixBodyTable.rows.length; r++)
    {
      for (c = 0; c < obj.fixBodyTable.rows[r].cells.length; c++)
      {
        objb.push(obj.fixBodyTable.rows[r].cells[c]);
      }
    }
  }
  if (obj.freeBodyTable && obj.freeBodyTable.rows)
  {
    for (r = 0; r < obj.freeBodyTable.rows.length; r++)
    {
      for (c = 0; c < obj.freeBodyTable.rows[r].cells.length; c++)
      {
        objb.push(obj.freeBodyTable.rows[r].cells[c]);
      }
    }
  }
  if (select)
  {
    this.addClassNames(objh, "gvHeaderSelected");
    this.addClassNames(objb, "gvBodySelected");
    obj.selection.resetAll();
    obj.selection.trackRows("1-" + obj.rows.toString(), true);
    for (c = 1; c <= obj.columns; c++)
    {
      obj.selection.trackColumns(c.toString(), true);
    }
  }
  else
  {
    this.removeClassNames(objh, "gvHeaderSelected");
    this.removeClassNames(objb, "gvBodySelected");
    obj.selection.resetAll();
  }
  p.insertBefore(obj.container, n);
  obj.selection.all = !obj.selection.all;
  obj.selection.changed = true;
}
// </its_gridviewManager::switchEntireSelection>


/** <its_gridviewManager::resetColumnSelection>
  *
  *  reset the selection of all columns
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.resetColumnSelection = function(obj)
{
  if (obj.selection.tpColumns.value.length > 0)
  {
    var columns = obj.selection.tpColumns.value.split(";");
    var i;
    for (i = 0; i < columns.length; i++)
    {
      if (columns[i].length > 0)
      {
        this.switchColumnSelection(obj, parseInt(columns[i], 10), false);
      }
    }
    obj.selection.resetColumns();
  }
}
// </its_gridviewManager::resetColumnSelection>


/** <its_gridviewManager::resetRowSelection>
  *
  *  reset the selection of all rows
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.resetRowSelection = function(obj)
{
  if (obj.selection.tpRows.value.length > 0)
  {
    var rows = obj.selection.tpRows.value.split(";");
    var i;
    for (i = 0; i < rows.length; i++)
    {
      if (rows[i].length > 0)
      {
        if (rows[i].indexOf("-") > -1)
        {
          this.switchRowRangeSelection(obj, rows[i], false, true);
        }
        else
        {
          this.switchRowSelection(obj, parseInt(rows[i], 10), false, true);
          obj.selection.tpRows.value = "";
          obj.selection.SelectedRowsRanges = [];
          obj.selection.SelectedRowsRanges[0] = 0;
        }
      }
    }
    obj.selection.resetRows();
  }
}
// </its_gridviewManager::resetRowSelection>


/** <its_gridviewManager::resetCellSelection>
  *
  *  reset the selection of all cells
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.resetCellSelection = function(obj)
{
  if (obj.selection.tpCells.value.length > 1)
  {
    var cells = obj.selection.tpCells.value.split(";");
    var i, rowColumn, row, column, table, virtualColumn;
    var objs = new Array();
    for (i = 0; i < cells.length; i++)
    {
      if (cells[i].length > 0)
      {
        rowColumn = cells[i].split(",");
        row = parseInt(rowColumn[0], 10);
        if (row >= obj.topRow && row <= obj.bottomRow)
        {
          if (row > obj.rowsPerPage)
          {
            row -= (obj.currentPage - 1) * obj.rowsPerPage;
          }
          column = parseInt(rowColumn[1], 10);
          table = this.getContainingBodyTable(obj, column);
          virtualColumn = this.getVirtualColumnNo(obj, column);
          objs.push(table.rows[row-1].cells[virtualColumn]);
        }
      }
    }
    if (objs.length > 0)
    {
      this.removeClassNames(objs, "gvBodySelected");
    }
    obj.selection.resetCells();
  }
}
// </its_gridviewManager::resetCellSelection>


/** <its_gridviewManager::switchColumnSelection>
  *
  *  switch the columns selection status
  *
  *   params:
  *     obj      - Object  - the gridview json object
  *     columnNo - Number  - the column number
  *     mode     - Boolean - set the mode (select/deselect) independet from the
  *                columns selection status
  *     notrack  - Boolean - track the selection change?
  */
its_gridviewManager.prototype.switchColumnSelection = function(obj, columnNo, mode, notrack)
{
  var bodyTable = this.getContainingBodyTable(obj, columnNo);
  var headerTable = this.getContainingHeaderTable(obj, columnNo);
  var virtualColumnNo = this.getVirtualColumnNo(obj, columnNo);
  var selected = obj.selection.columnSelected(columnNo);

  var select = mode;
  if (typeof select == "undefined")
  {
    select = !selected;
  }

  // track selection
  if (typeof notrack == "undefined")
  {
    obj.selection.trackColumns(columnNo, select);
    if (!select)
    {
      obj.selection.trackColumnCells(columnNo, false);
    }
  }

  // body cell(s)
  var bc = new Array();
  // header cell
  var hc = null;
  if (headerTable && headerTable.rows.length == 1)
  {
    hc = headerTable.rows[0].cells[virtualColumnNo];
    if (select)
    {
      if (hc)
      {
        hc.className = dom_addClass(hc.className, "gvHeaderSelected");
      }
    }
    else
    {
      if (hc)
      {
        hc.className = dom_removeClass(hc.className, "gvHeaderSelected");
      }
    }
  }
  if (bodyTable && bodyTable.rows)
  {
    rowCount = bodyTable.rows.length;
    for (var i = 0; i < rowCount; i++)
    {
      if (!obj.selection.rowSelected(i+1))
      {
        var cells = bodyTable.rows[i].cells;
        if (cells && cells[virtualColumnNo])
        {
          bc.push(cells[virtualColumnNo]);
        }
      }
    }
    if (select)
    {
      this.addClassNames(bc, "gvBodySelected");
    }
    else
    {
      this.removeClassNames(bc, "gvBodySelected");
    }
  }
  delete bc;
  delete hc;

  obj.selection.changed = true;
  return select;
}
// </its_gridviewManager::switchColumnSelection>


/** <its_gridviewManager::switchRowSelection>
  *
  *  switch the rows selection status
  *
  *   params:
  *     obj     - Object  - the gridview json object
  *     rowNo   - Number  - the row number
  *     mode    - Boolean - set the mode (select/deselect) independet from the
  *               rows selection status
  *     notrack - Boolean - track the selection change?
  */
its_gridviewManager.prototype.switchRowSelection = function(obj, rowNo, mode, notrack)
{
  var selected = obj.selection.rowSelected(rowNo);
  var select = mode;
  var row = null;
  var objs = new Array();
  if (typeof select == "undefined")
  {
    select = !selected;
  }

  // track selection
  if (typeof notrack == "undefined")
  {
    obj.selection.trackRows(rowNo, select);
    if (!select)
    {
      obj.selection.trackRowCells(rowNo, false);
    }
  }

  if (rowNo >= obj.topRow && rowNo <= obj.bottomRow)
  {
    if (rowNo > obj.rowsPerPage)
    {
      rowNo -= (obj.currentPage - 1) * obj.rowsPerPage;
    }

    // get the cells to be selected/deselected
    if (obj.fixBodyTable && obj.fixBodyTable.rows)
    {
      for (var i = 0; i < obj.fixBodyTable.rows[rowNo-1].cells.length; i++)
      {
        if (!obj.selection.columnSelected(i+1-obj.markCell))
        {
          objs.push(obj.fixBodyTable.rows[rowNo-1].cells[i]);
        }
      }
    }
    if (obj.freeBodyTable && obj.freeBodyTable.rows)
    {
      for (var i = 0; i < obj.freeBodyTable.rows[rowNo-1].cells.length; i++)
      {
        if (!obj.selection.columnSelected(i+obj.fixColumns+1))
        {
          objs.push(obj.freeBodyTable.rows[rowNo-1].cells[i]);
        }
      }
    }
    if (objs.length > 0)
    {
      if (select)
      {
        this.addClassNames(objs, "gvBodySelected");
      }
      else
      {
        this.removeClassNames(objs, "gvBodySelected");
      }
    }
  }
  obj.selection.changed = true;
  return select;
}
// </its_gridviewManager::switchRowSelection>


/** <its_gridviewManager::updateRowSelection>
  *
  *  updates the row selection when selection mode is GV_SEL_MODE_SINGLE as
  *  the row selection moves together with the current cell
  *
  *   params:
  *     obj     - Object - the gridview json object
  *     newCell - Object - the new current cell
  */
its_gridviewManager.prototype.updateRowSelection = function(obj, newCell)
{
  if (obj.selection.rows >= GV_SEL_MODE_SINGLE)
  {
    this.resetRowSelection(obj);
    rowColumn = this.getRowColumn(newCell);
    this.switchRowSelection(obj, rowColumn.row, true);
  }
  obj.selection.changed = true;
}
// </its_gridviewManager::updateRowSelection>


/** <its_gridviewManager::switchRowRangeSelection>
  *
  *  switch the selection status of an entire row range
  *
  *   params:
  *     obj     - Object  - the gridview json object
  *     range   - String  - the row range
  *     mode    - Boolean - set the mode (select/deselect) independet from the
  *               rows selection status
  *     notrack - Boolean - track the selection change?
  */
its_gridviewManager.prototype.switchRowRangeSelection = function(obj, range, mode, notrack)
{
  var rows = range.split("-");
  if (rows.length == 2)
  {
    var row1 = parseInt(rows[0], 10);
    var row2 = parseInt(rows[1], 10);
    var rowMin = Math.min(row1, row2);
    var rowMax = Math.max(row1, row2);
    if (rowMax > obj.bottomRow)
    {
      rowMax = obj.bottomRow;
    }
    if (rowMin < obj.topRow)
    {
      rowMin = obj.topRow;
    }
    if (obj.currentPage > 1)
    {
      rowMin -= (obj.currentPage - 1) * obj.rowsPerPage;
      rowMax -= (obj.currentPage - 1) * obj.rowsPerPage;
    }
    if (rowMin > 0 && rowMax > 0)
    {
      var selected = obj.selection.rowSelected(rowMin);
      var select = mode;
      var objs = new Array();
      var i, r;
      if (typeof select == "undefined")
      {
        select = !selected;
      }

      // track selection
      if (typeof notrack == "undefined")
      {
        obj.selection.trackRows(range, select);
      }

      // get the cells to be selected/deselected
      if (obj.fixBodyTable && obj.fixBodyTable.rows)
      {
        for (r = rowMin; r <= rowMax; r++)
        {
          for (i = 0; i < obj.fixBodyTable.rows[r-1].cells.length; i++)
            objs.push(obj.fixBodyTable.rows[r-1].cells[i]);
        }
      }
      if (obj.freeBodyTable && obj.freeBodyTable.rows)
      {
        for (r = rowMin; r <= rowMax; r++)
        {
          for (i = 0; i < obj.freeBodyTable.rows[r-1].cells.length; i++)
            objs.push(obj.freeBodyTable.rows[r-1].cells[i]);
        }
      }

      if (objs.length > 0)
      {
        if (select)
        {
          this.addClassNames(objs, "gvBodySelected");
        }
        else
        {
          this.removeClassNames(objs, "gvBodySelected");
        }
      }
    }
  }
  delete objs;
  obj.selection.changed = true;
  return select;
}
// </its_gridviewManager::switchRowRangeSelection>


/** <its_gridviewManager::switchCellSelection>
  *
  *  switch the celss selection status
  *
  *   params:
  *     obj      - Object  - the gridview json object
  *     rowNo    - Number  - the column number
  *     columnNo - Number  - the row number
  *     mode     - Boolean - set the mode (select/deselect) independet from the
  *                cells selection status
  *     notrack  - Boolean - track the selection change?
  */
its_gridviewManager.prototype.switchCellSelection = function(obj, rowNo, columnNo, mode, notrack)
{
  var selected = obj.selection.cellSelected(rowNo, columnNo);
  var select = mode;

  if (typeof select == "undefined")
  {
    select = !selected;
  }

  // track selection
  if (typeof notrack == "undefined")
  {
    obj.selection.trackCells(rowNo, columnNo, select);
  }

  var table = this.getContainingBodyTable(obj, columnNo)
  var virtualColumn = this.getVirtualColumnNo(obj, columnNo);

  if (rowNo > obj.rowsPerPage)
  {
    rowNo -= (obj.currentPage - 1) * obj.rowsPerPage;
  }

  // get the cells to be selected/deselected
  if (table)
  {
    var cell = table.rows[rowNo-1].cells[virtualColumn];
    if (cell)
    {
      if (select)
      {
        cell.className = dom_addClass(cell.className, "gvBodySelected");
      }
      else
      {
        cell.className = dom_removeClass(cell.className, "gvBodySelected");
      }
    }
  }
  obj.selection.changed = true;
  return select;
}
// </its_gridviewManager::switchCellSelection>


/** <its_gridviewManager::switchCellRangeSelection>
  *
  *  switch the cell range selection status
  *
  *   params:
  *     obj       - Object  - the gridview json object
  *     rowNo1    - Number  - the column number
  *     columnNo1 - Number  - the row number
  *     rowNo2    - Number  - the column number
  *     columnNo2 - Number  - the row number
  */
its_gridviewManager.prototype.switchCellRangeSelection = function(obj, rowNo1, columnNo1, rowNo2, columnNo2)
{
  var c, r;
  var minRow = Math.min(rowNo1, rowNo2);
  var maxRow = Math.max(rowNo1, rowNo2);
  var minColumn = Math.min(columnNo1, columnNo2);
  var maxColumn = Math.max(columnNo1, columnNo2);
  var objs = new Array();
  var column;
  var table = null;
  var offset = 0;

  if (minRow > obj.rowsPerPage || maxRow > obj.rowsPerPage)
  {
    offset = (obj.currentPage - 1) * obj.rowsPerPage;
    minRow -= offset;
    maxRow -= offset;
  }

  for (r = minRow; r <= maxRow; r++)
  {
    for (c = minColumn; c <= maxColumn; c++)
    {
      if (c > obj.fixColumns)
      {
        column = c - obj.fixColumns - 1;
        table = obj.freeBodyTable;
      }
      else
      {
        column = c - 1 + obj.markCell;
        table = obj.fixBodyTable;
      }
      if (table)
      {
        objs.push(table.rows[r-1].cells[column]);
      }
      obj.selection.trackCells(r + offset, c, true);
    }
  }
  if (objs.length > 0)
  {
    this.addClassNames(objs, "gvBodySelected");
  }
  delete objs;
  obj.selection.changed = true;
}
// </its_gridviewManager::switchCellRangeSelection>


/** <its_gridviewManager::switchSelectionOnLoad>
  *
  *  switch the selection on load
  *
  *   params:
  *     obj      - Object  - the gridview json object
  */
its_gridviewManager.prototype.switchSelectionOnLoad = function(obj)
{
  var i, r, c;
  var rows = obj.selection.tpRows.value.split(";");
  var columns = obj.selection.tpColumns.value.split(";");
  var cells = obj.selection.tpCells.value.split(";");
  var objsH = new Array();
  var objsB = new Array();
  var table;
  var row;
  var column;
  var cell;
  var selectedRows = 0;
  var selectedColumns = 0;
  // rows
  for (i = 0; i < rows.length; i++)
  {
    if (rows[i].length > 0)
    {
      if (rows[i].indexOf("-") > -1)
      {
        var range = rows[i].split("-");
        if (range.length == 2)
        {
          var row1 = parseInt(range[0], 10);
          var row2 = parseInt(range[1], 10);
          var rowMin = Math.min(row1, row2);
          var rowMax = Math.max(row1, row2);
          if (rowMin < obj.topRow)
          {
            rowMin = obj.topRow;
          }
          if (rowMax > obj.bottomRow)
          {
            rowMax = obj.bottomRow;
          }
          if (rowMin > obj.rowsPerPage)
          {
            rowMin -= (obj.currentPage - 1) * obj.rowsPerPage;
            rowMax -= (obj.currentPage - 1) * obj.rowsPerPage;
          }
          if (rowMin > 0 && rowMax > 0)
          {
            selectedRows += rowMax - rowMin + 1;
            if (obj.fixBodyTable)
            {
              for (r = rowMin; r <= rowMax; r++)
              {
                for (c = 0; c < obj.fixBodyTable.rows[r-1].cells.length; c++)
                {
                  objsB.push(obj.fixBodyTable.rows[r-1].cells[c]);
                }
              }
            }
            if (obj.freeBodyTable)
            {
              for (r = rowMin; r <= rowMax; r++)
              {
                for (c = 0; c < obj.freeBodyTable.rows[r-1].cells.length; c++)
                {
                  objsB.push(obj.freeBodyTable.rows[r-1].cells[c]);
                }
              }
            }
          }
        }
      }
      else
      {
        row = parseInt(rows[i], 10);
        if (row >= obj.topRow && row <= obj.bottomRow)
        {
          selectedRows++;
          if (row > obj.rowsPerPage)
          {
            row -= (obj.currentPage - 1) * obj.rowsPerPage;
          }
          if (obj.fixBodyTable)
          {
            for (c = 0; c < obj.fixBodyTable.rows[row-1].cells.length; c++)
            {
              objsB.push(obj.fixBodyTable.rows[row-1].cells[c]);
            }
          }
          if (obj.freeBodyTable)
          {
            for (c = 0; c < obj.freeBodyTable.rows[row-1].cells.length; c++)
            {
              objsB.push(obj.freeBodyTable.rows[row-1].cells[c]);
            }
          }
        }
      }
    }
  }
  // columns
  for (i = 0; i < columns.length; i++)
  {
    if (columns[i].length > 0)
    {
      column = parseInt(columns[i], 10);
      if (column > 0)
      {
        selectedColumns++;
        // header
        c = (column > obj.fixColumns)? column - obj.fixColumns - 1 : column - 1 + obj.markCell;
        table = (column > obj.fixColumns)? obj.freeHeaderTable : obj.fixHeaderTable;
        if (table)
        {
          objsH.push(table.rows[0].cells[c]);
        }
        // body
        table = (column > obj.fixColumns)? obj.freeBodyTable : obj.fixBodyTable;
        if (table)
        {
          for (r = 0; r < table.rows.length; r++)
          {
            if (table.rows[r].cells[c])
            {
              objsB.push(table.rows[r].cells[c]);
            }
          }
        }
      }
    }
  }
  // cells
  for (i = 0; i < cells.length; i++)
  {
    if (cells[i].length > 0)
    {
      cell = cells[i].split(",");
      if (cell.length == 2)
      {
        row = parseInt(cell[0], 10);
        column = parseInt(cell[1], 10);
        if (row >= obj.topRow && row <= obj.bottomRow && column >= 1 && column <= obj.columns)
        {
          row -= obj.topRow;
          c = (column > obj.fixColumns)? column - obj.fixColumns - 1 : column - 1 + obj.markCell;
          table = (column > obj.fixColumns)? obj.freeBodyTable : obj.fixBodyTable;
          if (table && table.rows[row].cells[c])
          {
            objsB.push(table.rows[row].cells[c]);
          }
        }
      }
    }
  }
  if (selectedRows == obj.rows && selectedColumns == obj.columns)
  {
    obj.selection.all = true;
  }
  this.addClassNames(objsH, "gvHeaderSelected");
  this.addClassNames(objsB, "gvBodySelected");
  delete objsH;
  delete objsB;
}
// </its_gridviewManager::switchSelectionOnLoad>


/** <its_gridviewManager::setCurrentCellOnLoad>
  *
  *   set the current cell on load event of document
  *
  *   params:
  *     obj - Object - the gridview json object
  */
its_gridviewManager.prototype.setCurrentCellOnLoad = function(obj)
{
  if (typeof webguiShButtonManager != "undefined" &&
      typeof webguiShButtonManager.New != "undefined")
  {
    webguiShButtonManager.New("gridviewSearchHelpButton", its_gvMgr.hideSearchHelpButton, null, null);
  }
  row = parseInt(obj.selection.tpCurrentCellRow.value, 10);
  column = parseInt(obj.selection.tpCurrentCellColumn.value, 10);
  if (row >= obj.topRow && row <= obj.bottomRow && column >= 1 && column <= obj.columns)
  {
    if (row > obj.rowsPerPage)
    {
      row -= (obj.currentPage - 1) * obj.rowsPerPage;
    }
    if (row > 0 && column > 0)
    {
      c = (column > obj.fixColumns)? column - obj.fixColumns - 1 : column - 1 + obj.markCell;
      table = (column > obj.fixColumns)? obj.freeBodyTable : obj.fixBodyTable;
      cell = table.rows[row-1].cells[c];
      if (cell)
      {
        var focusType = (obj.controlFocus)? GV_FOCUS_SELECT : GV_FOCUS_NONE;
        var scrollIntoView = (obj.tpScrollContext != null && obj.tpScrollContext.value == "cell");
        its_gvMgr.setCurrentCell(obj, cell, focusType, scrollIntoView);
      }
    }
  }
}
// </its_gridviewManager::setCurrentCellOnLoad>


/** <its_gridviewManager::transformRowSelection>
  *
  *  transforms the entire row selection to a cell selection
  *
  *   params:
  *     obj      - Object  - the gridview json object
  *     rowNo    - Number  - the number of the row that has changed its status
  *     columnNo - Number  - the number of the column that has changed its single
  *     all      - Boolean - imply all or only a single row in the transformation
  */
its_gridviewManager.prototype.transformRowSelection = function(obj, rowNo, columnNo, all)
{
  var rows = obj.selection.tpRows.value.split(";");
  var row = 0;
  var vrow;
  var c, r;
  for (r = 0; r < rows.length; r++)
  {
    if (rows[r].indexOf("-") > -1)
    {
      this.transformRowRangeSelection(obj, rows[r], rowNo, columnNo, all);
    }
    else
    {
      row = parseInt(rows[r], 10);
      if (row > 0)
      {
        if (all || rowNo == row)
        {
          // deselect row mark cell
          if (obj.fixBodyTable && obj.markCell)
          {
            vrow = row;
            if (vrow > obj.rowsPerPage)
            {
              vrow -= (obj.currentPage - 1) * obj.rowsPerPage;
            }
            var cell = obj.fixBodyTable.rows[vrow-1].cells[0];
            cell.className = dom_removeClass(cell.className, "gvBodySelected");
          }
          for (c = 1; c <= obj.columns; c++)
          {
            if (c != columnNo)
            {
              obj.selection.trackCells(rows[r], c, true);
            }
          }
          if (!all)
          {
            obj.selection.trackRows(rowNo, false);
          }
        }
      }
    }
  }
  if (all)
  {
    obj.selection.resetRows();
  }
}
// </its_gridviewManager::transformRowSelection>


/** <its_gridviewManager::transformRowRangeSelection>
  *
  *  transforms the entire row selection to a cell selection
  *
  *   params:
  *     obj    - Object - the gridview json object
  *     column - Number - the number of the column that has changed its status
  *     all      - Boolean - imply all or only a single row in the transformation
  */
its_gridviewManager.prototype.transformRowRangeSelection = function(obj, range, row, column, all)
{

  var r, c, values, row1, row2, virtuallRow;
  var values = range.split("-");
  if (values.length == 2)
  {
    obj.selection.trackRows(range, false);
    row1 = parseInt(values[0], 10);
    row2 = parseInt(values[1], 10);
    for (r = Math.min(row1, row2); r <= Math.max(row1, row2); r++)
    {
      if (all || row == r)
      {
        // deselect row mark cell
        if (obj.fixBodyTable && obj.markCell)
        {
          vrow = r;
          if (vrow > obj.rowsPerPage)
          {
            vrow -= (obj.currentPage - 1) * obj.rowsPerPage;
          }
          var cell = obj.fixBodyTable.rows[vrow-1].cells[0];
          cell.className = dom_removeClass(cell.className, "gvBodySelected");
        }
        for (c = 1; c <= obj.columns; c++)
        {
          if (c != column)
          {
            obj.selection.trackCells(r, c, true);
          }
        }
      }
      else
      {
        obj.selection.trackRows(r, true);
      }
    }
  }
}
// </its_gridviewManager::transformRowRangeSelection>


/** <its_gridviewManager::transformColumnSelection>
  *
  *  transforms the entire column selection to a cell selection
  *
  *   params:
  *     obj      - Object  - the gridview json object
  *     rowNo    - Number  - the number of the row that has changed its status
  *     columnNo - Number  - the number of the column that has changed its status
  *     all      - Boolean - imply all or only a single row in the transformation
  */
its_gridviewManager.prototype.transformColumnSelection = function(obj, rowNo, columnNo, all)
{
  var columns = obj.selection.tpColumns.value.split(";");
  var column = 0;
  var c, r;
  for (c = 0; c < columns.length; c++)
  {
    column = parseInt(columns[c], 10);
    if (column > -1)
    {
      if (all || columnNo == column)
      {
        var headerTable = this.getContainingHeaderTable(obj, column);
        var bodyTable = this.getContainingBodyTable(obj, column);
        var virtualColumn = this.getVirtualColumnNo(obj, column);
        if (headerTable)
        {
          var cell = headerTable.rows[0].cells[virtualColumn];
          cell.className = dom_removeClass(cell.className, "gvHeaderSelected");
        }
        if (bodyTable)
        {
          for (r = 1; r <= obj.rows; r++)
          {
            if (r != rowNo || (columnNo == -1 || column != columnNo))
              obj.selection.trackCells(r, column, true);
          }
        }
        if (!all)
        {
          obj.selection.trackColumns(columnNo, false);
        }
      }
    }
  }
  if (all)
  {
    obj.selection.resetColumns();
  }
}
// </its_gridviewManager::transformColumnSelection>


/** <its_gridviewManager::addClassNames>
  *
  *  add the attribute className to all elements of the array of html objects
  *
  *   params:
  *     objs      - Array  - the objects to change the classname
  *     className - Strnig - the the classname to add
  */
its_gridviewManager.prototype.addClassNames = function(objs, className)
{
  var oldName = "";
  var newName = "";
  var i;
  for (i = 0; i < objs.length; i++)
  {
    if (objs[i].className != oldName)
    {
      oldName = objs[i].className;
      newName = objs[i].className = dom_addClass(objs[i].className, className);
    }
    else
    {
      objs[i].className = newName;
    }
  }
}
// </its_gridviewManager::addClassNames>


/** <its_gridviewManager::removeClassNames>
  *
  *  remove the attribute className from all elements of the array of html
  *  objects
  *
  *   params:
  *     objs      - Array  - the objects to change the classname
  *     className - Strnig - the the classname to add
  */
its_gridviewManager.prototype.removeClassNames = function(objs, className)
{
  var oldName = "";
  var newName = "";
  var i;
  for (i = 0; i < objs.length; i++)
  {
    if (objs[i].className != oldName)
    {
      oldName = objs[i].className;
      newName = objs[i].className = dom_removeClass(objs[i].className,
                                                    className);
    }
    else
    {
      objs[i].className = newName;
    }
  }
}
// </its_gridviewManager::removeClassNames>


/** <its_gridviewManager::getRowColumn>
  *
  *
  *   params:
  *     node - Object - the node to get the rc from
  */
its_gridviewManager.prototype.getRowColumn = function(node)
{
  var r = null;
  var row = 0;
  var column = 0;
  var rc = node.getAttribute("rc");
  var tr = dom_getParentNodeByNodeName(node, "TR");
  if (rc)
  {
    var rowColumn = rc.split(",");
    if (rowColumn && rowColumn.length >= 2)
    {
      row = parseInt(rowColumn[0], 10);
      column = parseInt(rowColumn[1], 10);
      if (row >= 0 && column >= 0)
      {
        r = new Object();
        r.row = row;
        r.column = column;
        if (rowColumn.length == 3)
          r.hotspot = true;
        else
          r.hotspot = false;
      }
    }
    if (tr)
    {
      rowId = tr.getAttribute("rowid");
      if (rowId && r)
      {
        r.rowId = parseInt(rowId, 10);
      }
    }
  }
  return r;
}
// </its_gridviewManager::getRowColumn>


/** <its_gridviewManager::getVirtualColumnNo>
  *
  *   get the virtual column number in consideration of the fix/free columns
  *   and the appropriate containers; the number is equivalent to the columns
  *   number in the html table object.
  *
  *   params:
  *     obj      - Object - the gridview json object
  *     columnNo - Number - the real number of the columns
  */
its_gridviewManager.prototype.getVirtualColumnNo = function(obj, columnNo)
{
  if (obj.fixColumns > 0 && columnNo <= obj.fixColumns)
  {
    return columnNo - 1 + obj.markCell;
  }
  return columnNo - obj.fixColumns - 1;
}
// </its_gridviewManager::getVirtualColumnNo>


/** <its_gridviewManager::getContainingHeaderTable>
  *
  *   get the table (fix/free) that contains column columnNo
  *   params:
  *     obj      - Object - the gridview json object
  *     columnNo - Number - the real number of the columns
  */
its_gridviewManager.prototype.getContainingHeaderTable = function(obj, columnNo)
{
  if (obj.fixColumns > 0)
  {
    if (columnNo <= obj.fixColumns)
    {
      return obj.fixHeaderTable;
    }
  }
  return obj.freeHeaderTable;
}
// </its_gridviewManager::getContainingHeaderTable>


/** <its_gridviewManager::getContainingBodyTable>
  *
  *   get the table (fix/free) that contains column columnNo
  *   params:
  *     obj      - Object - the gridview json object
  *     columnNo - Number - the real number of the columns
  */
its_gridviewManager.prototype.getContainingBodyTable = function(obj, columnNo)
{
  if (obj.fixColumns > 0)
  {
    if (columnNo <= obj.fixColumns)
    {
      return obj.fixBodyTable;
    }
  }
  return obj.freeBodyTable;
}
// </its_gridviewManager::getContainingBodyTable>


/** <its_gridviewManager::getCurrentCell>
  *
  *  Get the current cell; if unset get the first cell in row/col
  *
  *   params:
  *     obj      - Object - the gridview json object
  */
its_gridviewManager.prototype.getCurrentCell = function(obj)
{
  if (obj.currentCell)
  {
    return obj.currentCell;
  }
  else
  {
    if (obj.selection.currentRow > 0 && obj.selection.currentColumn == -1)
    {
      var table = this.getContainingBodyTable(obj, 1);
      return table.rows[obj.selection.currentRow-1].cells[obj.markCell];
    }
    else if (obj.selection.currentColumn > 0 && obj.selection.currentRow == -1)
    {
      var table = this.getContainingBodyTable(obj, obj.selection.currentColumn);
      var columnNo = this.getVirtualColumnNo(obj, obj.selection.currentColumn);
      return table.rows[0].cells[columnNo];
    }
  }
}
// </its_gridviewManager::getCurrentCell>

/** <its_gridviewManager::getParentCell>
  *
  *  Get the containing cell of an element
  *
  *   params:
  *     node - Object - the node to get the parent cell (td/th) from
  */
its_gridviewManager.prototype.getParentCell = function(node)
{
  var cell     = node;
  var maxDepth = 4;
  var depth    = 0;
  while (depth < maxDepth)
  {
    if (cell.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      if (cell.nodeName == "TH" || cell.nodeName == "TD")
      {
        return cell;
      }
      else
      {
        cell = cell.parentNode;
        depth++;
      }
    }
    else
    {
      return null;
    }
  }
  return null;
}
// </its_gridviewManager::getParentCell>


/** <its_gridviewManager::getInputField>
  *
  *  get the input field from a td that is not hidden or disabled, otherwise
  *  return null
  *
  *   params:
  *     node - Object - the td to search for the input field
  */
its_gridviewManager.prototype.getInputField = function(node)
{
  var input = null;
  var i     = 0;
  while (i < node.childNodes.length)
  {
    input = node.childNodes[i];
    if (input.nodeType           == DOM_NODE_TYPE_ELEMENT &&
        ((input.nodeName         == "INPUT" &&
        input.type.toUpperCase() != "HIDDEN") ||
        (input.nodeName          == "SELECT") ||
        (input.nodeName          == "BUTTON")) &&
        input.disabled           == false)
    {
      return input;
    }
    i++;
  }
  return null;
}
// </its_gridviewManager::getInputField>


if (its_gvMgr == null)
{
  its_gvMgr = new its_gridviewManager();
}
// </its_gridviewManager::getInputField>


its_gridviewManager.prototype.fireEvent = function(obj, event, params)
{
  dbg3("gridview", "<fireEvent " + event + ", params=" + params + " />");
  var mainWindow;

  if (this.eventFired)
    return;

  this.eventFired = true;

  mainWindow = getMainWindow();

  if (mainWindow == self)
    raiseEvent(obj.controlId, event, params);
  else
    mainWindow.raiseEvent(obj.controlId, event, params);
}
// </its_gridviewManager::fireEvent>


/** <its_gridviewManager::postToolbarEvent>
  *
  *   handles the events called from toolbarctrl.js
  *
  *   params:
  *     obj  - Object - the gridview json object
  */
its_gridviewManager.prototype.postToolbarEvent = function(obj, eventName)
{
  var row = obj.selection.tpRows.value;
  if (!row || row == ";")
  {
    row = parseInt(obj.selection.tpCurrentCellRow.value, 10);
    if (row < 1)
    {
      row = null;
    }
  }
  if (row)
  {
    this.fireEvent(obj, eventName, "strRowID=" + row);
  }
}
// </its_gridviewManager::postToolbarEvent>


/** <its_gridviewManager::resetBrowserSelection>
  *
  *
  *   params:
  */
its_gridviewManager.prototype.resetBrowserSelection = function()
{
  if (document.selection)
  {
    document.selection.empty();
  }
  else if (window.getSelection)
  {
    window.getSelection().removeAllRanges();
  }
}
// </its_gridviewManager::resetBrowserSelection>


/** <its_gridviewManager::colResizeStart>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  *   obj - Object       - the gridview json object
  */
its_gridviewManager.prototype.colResizeStart = function(evt, obj)
{
  e = new its_event(evt);
  if (e)
  {
    var node = e.target;
    var th = node;
    while (th && th.nodeName != "TH")
    {
      th = th.parentNode;
    }
    var rowColumn = this.getRowColumn(th);
    its_gvMgr.cr = new its_gridviewColumnResizeObject();
    its_gvMgr.cr.obj              = obj;
    its_gvMgr.cr.initialX         = e.pageX;
    its_gvMgr.cr.initialY         = e.pageY;
    its_gvMgr.cr.initialWidth     = th.offsetWidth;
    its_gvMgr.cr.controlId        = obj.controlId;
    its_gvMgr.cr.columnIndex      = rowColumn.column - 1;

    its_gvMgr.cr.hTable = dom_getParentNodeByNodeName(th, "TABLE");
    its_gvMgr.cr.hTableIW = parseInt(its_gvMgr.cr.hTable.offsetWidth, 10);

    colgroup = dom_getChildNodeByNodeName(its_gvMgr.cr.hTable, "COLGROUP");
    its_gvMgr.cr.hCol = dom_getChildNodeByIndex(colgroup, th.cellIndex);
    its_gvMgr.cr.hColIW = parseInt(its_gvMgr.cr.hCol.offsetWidth, 10);

    its_gvMgr.cr.hDivText = dom_getChildNodeByNodeName(th, "DIV");
    its_gvMgr.cr.hDivTextIW = parseInt(its_gvMgr.cr.hDivText.offsetWidth, 10);

    if (its_gvMgr.cr.hTable == obj.fixHeaderTable)
    {
      its_gvMgr.cr.bTable = obj.fixBodyTable;
    }
    else if (its_gvMgr.cr.hTable == obj.freeHeaderTable)
    {
      its_gvMgr.cr.bTable = obj.freeBodyTable;
    }
    if (its_gvMgr.cr.bTable)
    {
      its_gvMgr.cr.bTableIW = its_gvMgr.cr.bTable.offsetWidth;

      colgroup = dom_getChildNodeByNodeName(its_gvMgr.cr.bTable, "COLGROUP");
      its_gvMgr.cr.bCol = dom_getChildNodeByIndex(colgroup, th.cellIndex);
      its_gvMgr.cr.bColIW = parseInt(its_gvMgr.cr.bCol.offsetWidth, 10);

      if (its_gvMgr.cr.hTable == obj.fixHeaderTable)
      {
        its_gvMgr.cr.hLayoutDiv = dom_getParentNodeByNodeName(its_gvMgr.cr.hTable, "DIV");
        its_gvMgr.cr.hLayoutDivIW = parseInt(its_gvMgr.cr.hLayoutDiv.offsetWidth, 10);

        its_gvMgr.cr.hLayoutTd = dom_getParentNodeByNodeName(its_gvMgr.cr.hLayoutDiv, "TD");
        its_gvMgr.cr.hLayoutTdIW = parseInt(its_gvMgr.cr.hLayoutTd.offsetWidth, 10);

        its_gvMgr.cr.gLayoutTable = dom_getParentNodeByNodeName(its_gvMgr.cr.hLayoutTd, "TABLE");
        its_gvMgr.cr.gLayoutTableIW = parseInt(its_gvMgr.cr.gLayoutTable.offsetWidth, 10);

        its_gvMgr.cr.bLayoutDiv = dom_getParentNodeByNodeName(its_gvMgr.cr.bTable, "DIV");
        its_gvMgr.cr.bLayoutDivIW = parseInt(its_gvMgr.cr.bLayoutDiv.offsetWidth, 10);

        its_gvMgr.cr.bLayoutTd = dom_getParentNodeByNodeName(its_gvMgr.cr.bLayoutDiv, "TD");
        its_gvMgr.cr.bLayoutTdIW = parseInt(its_gvMgr.cr.bLayoutTd.offsetWidth, 10);

        its_gvMgr.cr.bLayoutTable = dom_getParentNodeByNodeName(its_gvMgr.cr.bLayoutTd, "TABLE");;
        its_gvMgr.cr.bLayoutTableIW = parseInt(its_gvMgr.cr.bLayoutTable.offsetWidth, 10);
      }
    }
    document.onmousemove = its_gvMgr.colResize;
    document.onmouseup   = its_gvMgr.colResizeStop;
    delete(e);
  }
}
// </its_gridviewManager::colResizeStart>

function dom_getChildNodeByIndex(element, index)
{
  var i = -1;
  element = element.childNodes[0];
  while (element && i < index)
  {
    if (element.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      i++;
    }
    if (i != index)
    {
      element = element.nextSibling;
    }
  }
  return element;
}

/** <its_gridviewManager::colResize>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_gridviewManager.prototype.colResize = function(evt)
{
  e = new its_event(evt);
  if (e)
  {
    its_gvMgr.cr.deltaX = e.pageX - its_gvMgr.cr.initialX;

    if ((its_gvMgr.cr.hColIW + its_gvMgr.cr.deltaX) < 30)
    {
      its_gvMgr.cr.deltaX = its_gvMgr.cr.hColIW * (-1) + 30;
    }
    its_gvMgr.cr.hCol.style.width = its_gvMgr.cr.hColIW + its_gvMgr.cr.deltaX;
    its_gvMgr.cr.hTable.style.width = its_gvMgr.cr.hTableIW + its_gvMgr.cr.deltaX;
    its_gvMgr.cr.hDivText.style.width = its_gvMgr.cr.hDivTextIW + its_gvMgr.cr.deltaX;
    if (its_gvMgr.cr.hLayoutDiv)
    {
      width = its_gvMgr.cr.hLayoutTdIW + its_gvMgr.cr.deltaX;
      if (width >= 0)
      {
        its_gvMgr.cr.hLayoutTd.style.width = its_gvMgr.cr.hLayoutTdIW + its_gvMgr.cr.deltaX;
      }
      width = its_gvMgr.cr.gLayoutTableIW + its_gvMgr.cr.deltaX;
      if (width >= 0)
      {
        its_gvMgr.cr.gLayoutTable.style.width = width;
      }
      width = its_gvMgr.cr.hLayoutDivIW + its_gvMgr.cr.deltaX;
      if (width >= 0)
      {
        its_gvMgr.cr.hLayoutDiv.style.width = width;
      }
    }
    if (its_gvMgr.cr.bTable)
    {
      its_gvMgr.cr.bTable.style.width = its_gvMgr.cr.bTableIW + its_gvMgr.cr.deltaX;
      its_gvMgr.cr.bCol.style.width = its_gvMgr.cr.bColIW + its_gvMgr.cr.deltaX;
    }
    if (its_gvMgr.cr.bLayoutDiv)
    {
      its_gvMgr.cr.bLayoutTd.style.width = its_gvMgr.cr.bLayoutTdIW + its_gvMgr.cr.deltaX;
      its_gvMgr.cr.bLayoutDiv.style.width = its_gvMgr.cr.bLayoutDivIW + its_gvMgr.cr.deltaX;
    }

    e.cancel();
    delete(e);
  }
}
// </its_gridviewManager::colResize>


/** <its_gridviewManager::colResizeStop>
  *
  *
  *   params:
  *   evt - Oject(Event) - for mozilla (only) to give the event
  */
its_gridviewManager.prototype.colResizeStop = function(evt)
{
  e = new its_event(evt)
  if (e)
  {
    e.cancel();
/*
    colObject = null;
*/
    document.onmousemove = null;
    document.onmouseup   = null;
    delete its_gvMgr.cr.slider;
    if (typeof its_gvMgr.cr.deltaX != "undefined" && its_gvMgr.cr.deltaX != 0)
    {
      var newWidth = ((its_gvMgr.cr.initialWidth + its_gvMgr.cr.deltaX) / 7);
      newWidth = (newWidth < 3)? 3 : newWidth;
      its_gvMgr.fireEvent(its_gvMgr.cr.obj,
                          "resizecol",
                          "colindex=" + its_gvMgr.cr.columnIndex +
                          "&" +
                          "width=" + newWidth);
    }
    delete(e);
  }
}
// </its_gridviewManager::colResizeStop>



/** <its_gridviewSelectionObject::its_gridviewSelectionObject>
  *
  *   constructor for the class gridviewSelectionObject
  *     gridviewSelectionObject is used to keep the data of the gridview
  *     selection that is processed by its_gridviewManager.
  *
  */
function its_gridviewSelectionObject(obj)
{
  this.all                  = false;
  this.currentColumn        = -1;
  this.currentRow           = -1;
  this.currentCell          = -1;
  this.columns              = GV_SEL_MODE_NONE;
  this.tpColumn             = document.getElementById(obj.name + "-SelectedCol");
  this.tpColumns            = document.getElementById(obj.name + "xSelectedCols");
  if (this.tpColumns && this.tpColumns.value == "")
  {
    this.tpColumns.value = ";";
  }
  this.rows                 = GV_SEL_MODE_NONE;
  this.tpRow                = document.getElementById(obj.name + "-SelectedRow");
  this.tpRows               = document.getElementById(obj.name + "xSelectedRows");
  if (this.tpRows && this.tpRows.value == "")
  {
    this.tpRows.value = ";";
  }
  this.cells                = GV_SEL_MODE_NONE;
  this.tpCells              = document.getElementById(obj.name + "xSelectedCells");
  if (this.tpCells && this.tpCells.value == "")
  {
    this.tpCells.value = ";";
  }
  this.tpCurrentCellRow     = document.getElementById(obj.name + "-CurCellRow");
  this.tpCurrentCellColumn  = document.getElementById(obj.name + "-CurCellCol");
  this.tpModified           = document.getElementById(obj.name + "xModCells");
  if (this.tpModified && this.tpModified.value == "")
  {
    this.tpModified.value = ";";
  }
  switch (obj.selectionMode)
  {
    case "rowscols":
      this.columns = GV_SEL_MODE_MULTIPLE;
      this.rows    = GV_SEL_MODE_MULTIPLE;
      this.cells   = GV_SEL_MODE_SINGLE;
      break;
    case "singlerows":
      this.columns = GV_SEL_MODE_MULTIPLE;
      this.rows    = GV_SEL_MODE_SINGLE;
      this.cells   = GV_SEL_MODE_NONE;
      break;
    case "multirows":
      this.columns = GV_SEL_MODE_MULTIPLE;
      this.rows    = GV_SEL_MODE_MULTIPLE;
      this.cells   = GV_SEL_MODE_NONE;
      break;
    case "free":
      this.columns = GV_SEL_MODE_MULTIPLE;
      this.rows    = GV_SEL_MODE_MULTIPLE;
      this.cells   = GV_SEL_MODE_MULTIPLE;
      break;
    default:
      this.columns = GV_SEL_MODE_NONE;
      this.rows    = GV_SEL_MODE_NONE;
      this.cells   = GV_SEL_MODE_NONE;
      break;
  }
  this.SelectedRowsRanges = new Array();
  this.SelectedRowsRanges[0] = 0;
  var values = this.tpRows.value.split(";");
  for (var i = 0; i < values.length; i++)
  {
    if (values[i].indexOf("-") != -1)
    {
      var range = values[i].split("-");
      var rangeMin = Math.min(range[0], range[1]);
      var rangeMax = Math.max(range[0], range[1]);
      if (typeof rangeMin == "number" && typeof rangeMax == "number")
      {
        this.SelectedRowsRanges[0] += 1;
        for (var j = rangeMin; j <= rangeMax; j++)
        {
          this.SelectedRowsRanges[j] = this.SelectedRowsRanges[0];
        }
      }
    }
    else if (values[i].length > 0 && values[i] != ";")
    {
      this.SelectedRowsRanges[0] += 1;
      var value = parseInt(values[i], 10);
      if (typeof value == "number")
        this.SelectedRowsRanges[value] = this.SelectedRowsRanges[0];
    }
  }
}
// </its_gridviewSelectionObject>


/** <its_gridviewSelectionObject::resetAll>
  *
  *   reset the entire selection status
  *
  */
its_gridviewSelectionObject.prototype.resetAll = function()
{
  this.tpColumns.value = this.tpRows.value = this.tpCells.value = ";";
  this.tpColumn.value = this.tpRow.value = "";
}
// </its_gridviewSelectionObject::resetAll>


/** <its_gridviewSelectionObject::resetColumns>
  *
  *   reset the column selection status
  *
  */
its_gridviewSelectionObject.prototype.resetColumns = function()
{
  this.tpColumns.value = ";";
  this.tpColumn.value = "";
}
// </its_gridviewSelectionObject::resetColumns>


/** <its_gridviewSelectionObject::resetRows>
  *
  *   reset the row selection status
  *
  */
its_gridviewSelectionObject.prototype.resetRows = function()
{
  this.tpRows.value = ";";
  this.tpRow.value = "";
}
// </its_gridviewSelectionObject::resetRows>


/** <its_gridviewSelectionObject::resetCells>
  *
  *   reset the cell selection status
  *
  */
its_gridviewSelectionObject.prototype.resetCells = function()
{
  this.tpCells.value = ";";
}
// </its_gridviewSelectionObject::resetCells>


/** <its_gridviewSelectionObject::addPattern>
  *
  *   adds a pattern to the tracking value
  *
  */
its_gridviewSelectionObject.prototype.addPattern = function(field, pattern, check)
{
  if (typeof check == "undefined" || check == true)
  {
    pos = field.value.indexOf(";" + pattern + ";");
  }
  else
  {
    pos = -1;
  }
  if (pos == -1)
  {
    field.value += pattern + ";";
  }
}
// </its_gridviewSelectionObject::addPattern>


/** <its_gridviewSelectionObject::removePattern>
  *
  *   removes a pattern from the tracking value
  *
  */
its_gridviewSelectionObject.prototype.removePattern = function(field, pattern)
{
  var i, r;
  var qpattern = ";" + pattern + ";";
  i = field.value.indexOf(qpattern);
  if (i > -1)
  {
    field.value = field.value.substr(0, i) +
                  field.value.substr(i + pattern.length + 1,
                                     field.value.length -
                                     (i + pattern.length + 1));
  }
  else if (field.value.indexOf("-") > -1)
  {
    var value = parseInt(pattern, 10);
    var newPattern = ";";
    var values = field.value.split(";");
    for (i = 0; i < values.length; i++)
    {
      if (values[i].length > 0)
      {
        if (values[i].indexOf("-") > -1)
        {
          var range = values[i].split("-");
          if (range.length == 2)
          {
            var min = Math.min(range[0], range[1]);
            var max = Math.max(range[0], range[1]);
            if (value >= min && value <= max)
            {
              for (r = min; r <= max; r++)
              {
                if (r != value)
                {
                  newPattern += r.toString() + ";";
                }
              }
            }
            else
            {
              newPattern += values[i] + ";";
            }
          }
        }
        else
        {
          newPattern += values[i] + ";";
        }
      }
    }
    field.value = newPattern;
  }
}
// </its_gridviewSelectionObject::removePattern>


/** <its_gridviewSelectionObject::trackColumns>
  *
  *   track the column selection
  *     column - Number  - the column to be tracked
  *     select - Boolean - select/deselect
  *
  */
its_gridviewSelectionObject.prototype.trackColumns = function(column, select)
{
  if (select)
  {
    this.addPattern(this.tpColumns, column);
    this.tpColumn.value = column.toString();
  }
  else
  {
    this.removePattern(this.tpColumns, column.toString());
    this.tpColumn.value = "";
  }
}
// </its_gridviewSelectionObject::trackColumns>


/** <its_gridviewSelectionObject::trackRows>
  *
  *   track the row selection
  *     row    - Number  - the row to be tracked
  *     select - Boolean - select/deselect
  */
its_gridviewSelectionObject.prototype.trackRows = function(row, select)
{
  if (select)
  {
    this.addPattern(this.tpRows, row);
    if (row.toString().indexOf("-") == -1)
    {
      this.tpRow.value = row.toString();
    }
  }
  else
  {
    this.removePattern(this.tpRows, row.toString());
    this.tpRow.value = "";
  }
}
// </its_gridviewSelectionObject::trackRows>


/** <its_gridviewSelectionObject::trackCells>
  *
  *   track the row selection
  *     row    - Number  - the row to be tracked
  *     column - Number  - the column to be tracked
  *     select - Boolean - select/deselect
  */
its_gridviewSelectionObject.prototype.trackCells = function(row, column, select)
{
  if (select)
  {
    this.addPattern(this.tpCells, row.toString() + "," + column.toString());
  }
  else
  {
    this.removePattern(this.tpCells, row.toString() + "," + column.toString());
  }
}
// </its_gridviewSelectionObject::trackCells>


/** <its_gridviewSelectionObject::trackRowCells>
  *
  *   track the cells selection wihtin a row
  *     row    - Number  - the row to be tracked
  *     select - Boolean - select/deselect
  */
its_gridviewSelectionObject.prototype.trackRowCells = function(row, select)
{
  var newCells = new Array();
  var cells = this.tpCells.value.split(";");
  if (select)
  {
    for (i = 0; i < cells.length; i++)
    {
      if (cells[i].indexOf(row.toString() + ",") > -1)
      {
        newCells.push(cells[i]);
      }
    }
  }
  else
  {
    for (i = 0; i < cells.length; i++)
    {
      if (cells[i].indexOf(row.toString() + ",") == -1)
      {
        newCells.push(cells[i]);
      }
    }
  }
  this.tpCells.value = newCells.join(";");
}
// </its_gridviewSelectionObject::trackRowCells>


/** <its_gridviewSelectionObject::trackColumnCells>
  *
  *   track the cells selection wihtin a column
  *     column - Number  - the row to be tracked
  *     select - Boolean - select/deselect
  */
its_gridviewSelectionObject.prototype.trackColumnCells = function(column, select)
{
  var newCells = new Array();
  var cells = this.tpCells.value.split(";");
  if (select)
  {
    for (i = 0; i < cells.length; i++)
    {
      if (cells[i].indexOf("," + column.toString()) > -1)
      {
        newCells.push(cells[i]);
      }
    }
  }
  else
  {
    for (i = 0; i < cells.length; i++)
    {
      if (cells[i].indexOf("," + column.toString()) == -1)
      {
        newCells.push(cells[i]);
      }
    }
  }
  this.tpCells.value = newCells.join(";");
}
// </its_gridviewSelectionObject::trackColumnCells>


/** <its_gridviewSelectionObject::trackModified>
  *
  *   track the cells selection wihtin a column
  *     column - Number  - the row to be tracked
  *     select - Boolean - select/deselect
  */
its_gridviewSelectionObject.prototype.trackModified = function(row, column, value)
{
  dbg3("gridview", "<trackModified row/column/value: " + row + "/" + column + "/" + value + " />");
  this.addPattern(this.tpModified, row.toString() + "," +
                                   column.toString() + "," +
                                   "\"" + value + "\"", false);
}
// </its_gridviewSelectionObject::trackModified>


/** <its_gridviewSelectionObject::columnSelected>
  *
  *   returns whether a column is selected or not
  *     column - Number - the column to be checked
  *
  */
its_gridviewSelectionObject.prototype.columnSelected = function(column)
{
  return (this.tpColumns.value.indexOf(";" + (column).toString() + ";") > -1)
}
// </its_gridviewSelectionObject::columnSelected>


/** <its_gridviewSelectionObject::rowSelected>
  *
  *   returns whether a row is selected or not
  *     row - Number - the row to be checked
  *
  */
its_gridviewSelectionObject.prototype.rowSelected = function(row)
{
  var r = (this.tpRows.value.indexOf(";" + (row).toString() + ";") > -1);
  if (r)
  {
    return true;
  }
  else if (this.tpRows.value.indexOf("-") > -1)
  {
    var ranges = this.tpRows.value.split(";");
    var i, values, row1, row2;
    for (i = 0; i < ranges.length; i++)
    {
      values = ranges[i].split("-");
      if (values.length == 2)
      {
        row1 = parseInt(values[0], 10);
        row2 = parseInt(values[1], 10);
        if (row1 > 0 && row2 > 0)
        {
          if (row >= Math.min(row1, row2) && row <= Math.max(row1, row2))
          {
            return true;
          }
        }
      }
    }
  }
  return false;
}
// </its_gridviewSelectionObject::rowSelected>


/** <its_gridviewSelectionObject::cellSelected>
  *
  *   returns whether a cell is selected or not
  *     row    - Number - the row to be checked
  *     column - Number - the column to be checked
  *
  */
its_gridviewSelectionObject.prototype.cellSelected = function(row, column)
{
  var cell = (this.tpCells.value.indexOf(";" + row.toString() + "," + column.toString() + ";") > -1);
  var r = this.rowSelected(row);
  var c = this.columnSelected(column);
  if (cell || (r || c))
  {
    return true;
  }
  else
  {
    return false;
  }
}
// </its_gridviewSelectionObject::cellSelected>


/** <its_gridviewColumnResizeObject>
  *
  *   cunstructor for the class its_columnResizeObject
  *     its_columnResizeObject is used to keep the data of a resize event that
  *     is processed by its_tablecontrolManager.
  *
  *   params:
  */
function its_gridviewColumnResizeObject()
{
  this.obj              = null;
  this.initialX         = 0;
  this.initialY         = 0;
  this.initialWidth     = 0;
  this.currentWidth     = 0;
  this.controlId        = null;
  this.columnIndex      = 0;
  this.slider           = null;
  this.sliderOffsetLeft = 0;

  // the following vars hold the elements and their resize data while dragging
  // the colresizer:
  // abbreviations:
  // g = entire grid
  // h = header
  // b = body
  // IW = initial width
  this.hTable           = null;
  this.hTableIW         = 0;
  this.hCol             = null;
  this.hColIW           = 0;
  this.hDivText         = null;
  this.hDivTextIW       = 0;
  this.hLayoutTd        = null;
  this.hLayoutTdIW      = 0;
  this.gLayoutTable     = null;
  this.gLayoutTableIW   = 0;
  this.hLayoutDiv       = null;
  this.hLayoutDivIW     = 0;
  this.bTable           = null;
  this.bTableIW         = 0;
  this.bCol             = null;
  this.bColIW           = 0;
  this.bLayoutTd        = null;
  this.bLayoutTdIW      = 0;
  this.bLayoutTable     = null;
  this.bLayoutTableIW   = 0;
  this.bLayoutDiv       = null;
  this.bLayoutDivIW     = 0;

  this.deltaX           = 0;
  this.deltaY           = 0;
}
// </its_gridviewColumnResizeObject::its_gridviewColumnResizeObject>
