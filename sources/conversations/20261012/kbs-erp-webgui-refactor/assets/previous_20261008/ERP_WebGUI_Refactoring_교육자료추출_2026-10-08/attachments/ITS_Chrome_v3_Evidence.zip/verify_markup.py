from pathlib import Path
from html.parser import HTMLParser
import json,re,posixpath
W=Path(__file__).parent
class Parse(HTMLParser):
 def __init__(self): super().__init__(convert_charrefs=True);self.scripts=[];self.tags=[];self.styles=[];self.handlers=[];self.script=None;self.style=None;self.inputs=[]
 def handle_starttag(self,tag,attrs):
  d=dict(attrs);self.tags.append([tag,d])
  if tag=='script': self.script={'attrs':d,'text':''};self.scripts.append(self.script)
  if tag=='style': self.style=[];self.styles.append(self.style)
  if tag=='input': self.inputs.append([d.get('name'),d.get('value','')])
  for k,v in attrs:
   if k.startswith('on'):self.handlers.append({'tag':tag,'event':k,'code':v or ''})
 def handle_data(self,data):
  if self.script is not None:self.script['text']+=data
  if self.style is not None:self.style.append(data)
 def handle_endtag(self,tag):
  if tag=='script':self.script=None
  if tag=='style':self.style=None
 def handle_comment(self,data):
  if self.script is not None:self.script['text']+='<!--'+data+'-->'
def parse(p):
 x=Parse();x.feed(p.read_bytes().decode('latin1'));return x
inventory={};baselines={};orig=0;mods=0;dependencies=[]
for p in sorted((W/'modified/SYSTEMGUI/HTML').glob('*')):
 f=p.name;old=parse(W/'baseline/SYSTEMGUI/HTML'/f);new=parse(p);baselines[f]=old.scripts
 assert [(t,d.get('id'),d.get('name'))for t,d in old.tags]==[(t,d.get('id'),d.get('name'))for t,d in new.tags],f+' DOM IDs/name/tag sequence changed'
 assert re.findall(r'<!DOCTYPE[^>]*>',p.read_text('latin1'),re.I)==re.findall(r'<!DOCTYPE[^>]*>',(W/'baseline/SYSTEMGUI/HTML'/f).read_text('latin1'),re.I)
 inventory[f]={'scripts':new.scripts,'handlers':new.handlers,'styles':[''.join(s)for s in new.styles],'tags':new.tags}
 for tag,d in new.tags:
  if tag=='script' and d.get('src') or tag=='link' and d.get('href'):
   url=d.get('src')or d.get('href');url=posixpath.normpath(posixpath.join('/mimes/system/sl/page/',url)) if not url.startswith('/') else url
   path=url.split('/mimes/')[-1];parts=path.split('/');provided=None
   if len(parts)>3 and parts[0] in ('system','webgui'):
    bucket={'script':'JS','scripts':'JS','style':'CSS'}.get(parts[2]);
    if bucket: provided=(W/'modified'/('SYSTEMGUI' if parts[0]=='system' else 'WEBGUI')/bucket/parts[-1]).exists() and parts[1]=='sl'
   dependencies.append({'page':f,'url':url,'included':provided})
# Existing CSS bytes must be an exact prefix: only reviewed non-geometric focus rules were added.
css=[]
for p in sorted((W/'modified').rglob('*.css')):
 a=(W/'baseline'/p.relative_to(W/'modified')).read_bytes();b=p.read_bytes();assert b.startswith(a),str(p)+' existing CSS rule modified';css.append({'file':str(p.relative_to(W/'modified')),'existingRulesByteIdentical':True,'focusRuleAdded':a!=b})
serialized=json.loads((W/'serialization_cases.json').read_text());
for case in serialized:
 x=Parse();x.feed(case['html']);assert x.inputs==case['expected'],(x.inputs,case['expected'])
(W/'baseline_scripts.json').write_text(json.dumps(baselines,ensure_ascii=True,indent=2))
(W/'html_inventory.json').write_text(json.dumps(inventory,ensure_ascii=True,indent=2))
result={'htmlFiles':len(inventory),'tagIDNameSequencePreserved':True,'doctypePreserved':True,'css':css,'serializationHTMLParserCases':len(serialized),'dependencies':dependencies,'emptyPages':[f for f in inventory if not (W/'modified/SYSTEMGUI/HTML'/f).stat().st_size]}
(W/'markup_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'html':len(inventory),'css':len(css),'serialized':len(serialized),'unprovidedScriptCSS':[x for x in dependencies if x['included']is False]},indent=2))
