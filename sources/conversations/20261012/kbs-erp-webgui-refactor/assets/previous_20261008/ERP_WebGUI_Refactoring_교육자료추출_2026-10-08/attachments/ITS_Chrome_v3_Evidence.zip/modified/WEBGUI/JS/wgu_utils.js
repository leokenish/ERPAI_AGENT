////////////////////////////////////////////////////////////////////////////////
//
// wgu_utils.js
// (c) 2002, SAP AG
//
// WGU Javascript Utilities
//
// created 2002-03-26, tj
//
// 050222  hp  xbrowser func
// 050421  tj  Event handler returns rc of exec func
//
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//
// Toolbox
//
////////////////////////////////////////////////////////////////////////////////

// global object webgui carrying webgui specific information and properties
if (typeof(webgui) == "undefined")
  webgui = new Object();

function wgu_getAbsolutePosition( in_element, in_toElement )
{
  var elem = in_element, formerElem = null,
      toElem,
      brtl = isBidiRTL(),
      pos  = { x: 0, y: 0 };

  toElem = (null != in_toElement) ? in_toElement : document.body;

  if (null == document.all)
  {
    pos.x = elem.clientLeft;
    pos.y = elem.clientTop;
  }

  while (elem != toElem)
  {
    /*alert( "wguutils_getAbsolutePosition()\n\n x = " + pos.x + "\n y = " + pos.y + "\n "
            + elem.outerHTML.substr(0, 80)
            + "\n elem.style.left = " + elem.style.left + "\n elem.style.top = " + elem.style.top
            + "\n\n elem.offsetLeft = " + elem.offsetLeft + "\n elem.offsetTop = " + elem.offsetTop
            + "\n elem.clientLeft = " + elem.clientLeft + "\n elem.clientTop = " + elem.clientTop
            + "\n\n elem.tagName = " + elem.tagName);
    */
    if (null == formerElem || elem == formerElem.offsetParent)
    {
      if (elem != toElem && null != document.all && null != elem.clientLeft)
      {
        pos.x += elem.offsetLeft + elem.clientLeft;
        pos.y += elem.offsetTop  + elem.clientTop;
      }
      else
      {
        pos.x += elem.offsetLeft;
        pos.y += elem.offsetTop;
      }
    }

    // do not include the scrollpositon of the body as it leads to wrong
    // position in iac/ewt; within webgui body´s scrollposition is always 0
    if (elem != document.body)
    {
      if (elem.scrollTop)
        pos.y -= elem.scrollTop;
      if (elem.scrollLeft)
      {
        if (brtl && null != document.all)
        {
          pos.x -= (elem.scrollLeft - (elem.scrollWidth - elem.clientWidth))
        }
        else
          pos.x -= elem.scrollLeft;
      }
    }

    formerElem = elem;
    elem = elem.parentNode;  //elem.offsetParent;
  } // while
  //alert( "wguutils_getAbsolutePosition()\n\n RETURN\n x = " + pos.x + "\n y = " + pos.y);
  return pos;
} // wguutils_getAbsolutePosition()



/*********************************************************************
* function wgu_AddStyleSheet(doc, url)
*
*  add stylesheet to page header dynamically
*  works crossbrowser (ie /m moz)
*  he.pi 2005022
*/

function wgu_AddStyleSheet(doc, url){
  if(document.createStyleSheet) {
    //ie
    doc.createStyleSheet(url);
  }
  else {
    //moz
    SS=document.createElement('link');
    SS.rel='stylesheet';
    SS.href='data:text/css,'+escape(url);
    doc.getElementsByTagName("head")[0].appendChild(SS);
  }

}

/*********************************************************************
* Object and constructor wguObjFrame()
*  formerly called by its_accessIframe(iframeName)
*
*  usage:
*    myIframe = new its_accessIframe(iframeName);
*    iframeNode = myIframe.iframe;
*    iframeDoc  = myIframe.doc;
*
*  object, provides:
*    frame   - the node of the frame/iframe
*    win     - the window object
*    doc     - the node of the document inside an iframe
*    isValid - is object valid?
*/

function wguObjFrame ( in_arg )
{
  var fname, fobj, f, fdoc;

  this.isValid = false;

  if (null != in_arg)
  {
     fname = fobj = f = fdoc = null;

    if ("object" == typeof in_arg)
    {
      if ("IFRAME" == in_arg.nodeName) fobj = in_arg;    // <frame> or <iframe> object
      else if (null != in_arg.location)                  // window object
      {
        f = in_arg;
        fobj = f.frameElement;
      }
    }
    else if ("string" == typeof in_arg)
    {
      fname = in_arg;
      fobj  = document.getElementById(in_arg);           // <iframe id>, id of frame/iframe
    }

    if (null != fobj)
    {
      if (null == f) { f = fobj.contentWindow; }
      fdoc = (null != fobj.contentDocument) ? fobj.contentDocument : f.document;
    }

    if (null != fobj && null != f && null != fdoc)
    {
      this.htmlObj = fobj;
      this.win     = f;
      this.doc     = fdoc;
      this.isValid = true;
    }
  }
} // wguObjFrame()


wguObjFrame.prototype.IsValid         = function () { return (this.isValid ? true         : false); }
wguObjFrame.prototype.GetWindowObject = function () { return (this.isValid ? this.win     : null); }
wguObjFrame.prototype.GetHTMLObject   = function () { return (this.isValid ? this.htmlObj : null); }
wguObjFrame.prototype.GetDocument     = function () { return (this.isValid ? this.doc     : null); }





/*********************************************************************
* function wgu_parseWidth/Height(element, value)
*/

function wgu_parseWidth(element, value)
{
  var intValue = parseInt(value);
  if (intValue > 0)
  {
    if (value.indexOf("%") >= 0)
    {
      //unit: percentage
      return parseInt(element.parentNode.clientWidth/100*intValue);
    }
    else
    {
      //unit: pixel
      return intValue;
    }
  }
  else
    return 0;
}

function wgu_parseHeight(element, value)
{
  var intValue = parseInt(value);
  if (intValue > 0)
  {
    if (value.indexOf("%") >= 0){
      //unit: percentage
      return parseInt(element.parentNode.clientHeight/100*intValue);
    }
    else
    {
      //unit: pixel
      return intValue;
    }
  }
  else
    return 0;
}


////////////////////////////////////////////////////////////////////////////////
//
// Class wguObjCookie
//
//
// Interface:
//    Constructor wguObjCookie ()
//    Methods:    wguObjCookie.IsCookieEnabled ()
//                wguObjCookie.Set ()
//                wguObjCookie.Get ()
//                wguObjCookie.Delete ()
//                wguObjCookie.EvalExpDays ()
//    static      wguCookieIsEnabled ()
//
////////////////////////////////////////////////////////////////////////////////

if (typeof(document.getElementById) == "undefined")
  document.getElementById = document.all;

// Test if cookies are enabled
//  Returns: true, false or "na"
function wguCookieIsEnabled ()
{
  var rc = (navigator.cookieEnabled != null) ? navigator.cookieEnabled : "na";  // not available
  if (rc == "na") {
    if (document.cookie.length > 0) rc = true;
  }
  return rc;
} // wguObjCookieIsEnabled()


////////////////////////////////////////
// Constructor of class wguObjCookie
//
function wguObjCookie ()
{
  this.isCookieEnabled = wguCookieIsEnabled();

  return this;
} // constructor wguObjCookie()

function wguObjCookieEnabled ()
{
  return (this.isCookieEnabled != false);
} // wguObjCookieEnabled()

function wguObjCookieSet ( in_name, in_value, in_expires, in_path, in_domain, in_secure )
{
  if (this.isCookieEnabled != false) {
    in_secure = (in_secure != null) ? in_secure : false;
    document.cookie = in_name + "=" + escape( in_value)
      + ((in_expires  == null) ? "" : ("; expires=" + in_expires.toGMTString()))
      + ((in_path   == null) ? "" : ("; path=" + in_path))
      + ((in_domain == null) ? "" : ("; domain=" + in_domain))
      + ((in_secure == true) ? "; secure" : "");
  } // if (isCookieEnabled)
}

// Get cookie value of

  function wguObjCookieGet_getValue( in_cookie, in_offset )
  {
    var pos = in_cookie.indexOf (";", in_offset);
    if (pos == -1)
      pos = in_cookie.length;
    return unescape( in_cookie.substring( in_offset, pos));
  }

function wguObjCookieGet ( in_name )
{
  var rval    = null;
  if (this.IsCookieEnabled()) {
    var nameeq    = in_name + "=";
    var nameeqlen = in_name.length;
    var cookielen = document.cookie.length;
    var i = 0;
    while (i < cookielen) {
      var j = i + nameeqlen + 1;
      if (document.cookie.substring( i, j) == nameeq) {
        rval = wguObjCookieGet_getValue( document.cookie, j);
        break;
      }
      i = document.cookie.indexOf( " ", i) + 1;
      if (i == 0) break;
    } // while (i)
  } // if (isCookieEnabled)
  return rval;
} // wguObjCookieGet()

function wguObjCookieDelete ( in_name, in_path, in_domain, in_secure )
{
  if (this.IsCookieEnabled()) {
    var exp = new Date();
    exp.setTime( exp.getTime() - 1);
    var cval = this.Get( in_name);
    document.cookie = in_name + "=" + cval + "; expires=" + exp.toGMTString()
      + ((in_path   == null) ? "" : ("; path=" + in_path))
      + ((in_domain == null) ? "" : ("; domain=" + in_domain))
      + ((in_secure == true) ? "; secure" : "");
  } // if (isCookieEnabled)
} // wguObjCookieDelete()



// Evaluate cookie expiration in no. of days in_nodays
//  Returns: Date object or null
function wguObjCookieEvalExpDays ( in_nodays )
{
  var rval = null;
  if (in_nodays != null) {
    var exp = new Date();
    exp.setTime( exp.getTime() + (in_nodays * 24 * 3600 * 1000));
    rval = exp;
  } // if (in_nodays)
  return rval;
} // wguObjCookieEvalExpDays

wguObjCookie.prototype.IsCookieEnabled  = wguObjCookieEnabled;
wguObjCookie.prototype.Set        = wguObjCookieSet;
wguObjCookie.prototype.Get        = wguObjCookieGet;
wguObjCookie.prototype.Delete     = wguObjCookieDelete;
wguObjCookie.prototype.EvalExpDays    = wguObjCookieEvalExpDays;



////////////////////////////////////////////////////////////////////////////////
// Class wguObjCookie END
////////////////////////////////////////////////////////////////////////////////








////////////////////////////////////////////////////////////////////////////////
//
// User Agent Information
//
// Interface:
//    Functions:    wgu_GetUserAgentType ()
//                  wgu_GetUserAgentVersion ()
//                  wgu_GetUserAgentPlatform ()
//                  wgu_IsUserAgentW3CDOM ()
//
////////////////////////////////////////////////////////////////////////////////


function wgu_GetUserAgentType ()  { return _wguUtil_getUserAgentInfo().type; }
function wgu_GetUserAgentVersion () { return _wguUtil_getUserAgentInfo().version; }
function wgu_GetUserAgentPlatform (){ return _wguUtil_getUserAgentInfo().platform; }
function wgu_IsUserAgentW3CDOM () { return _wguUtil_getUserAgentInfo().W3CDOM; }


// internal function
function _wguUtil_getUserAgentInfo()
{
  if (_wguUtil_getUserAgentInfo.infoRec == 0) {
    var _enum = {
      OTHER   : 0,  MSIE    : 1,  NETSCAPE: 2,  MOZILLA : 2,
      OPERA   : 3,  NOKIA   : 4,  UP      : 5,  ERICSSON: 6,
      MSPIE   : 7,  PALM    : 8,

      OTHER_PLATFORM : 0, NT_PLATFORM    : 1,   WIN_PLATFORM   : 2,
      MAC_PLATFORM   : 3, LINUX_PLATFORM : 4,   WAP_PLATFORM   : 5,
      PDA_PLATFORM   : 6
    } // enum UserAgents

    var lUA   = navigator.userAgent;
    var laMatch = lUA.match( /(Netscape|Gecko|MSIE )([\d|\.|\/]*)/ );

    // initialize record

    _wguUtil_getUserAgentInfo.infoRec = {
      type    : "unknown",
      version   : "0",
      platform  : "unknown",
      W3CDOM    : false
    }

    // determine platform

    if (lUA.indexOf("Win") != -1)
      _wguUtil_getUserAgentInfo.infoRec.platform = (lUA.indexOf("WinNT") != -1 || lUA.indexOf("WindowsNT") != -1)
         ? "WinNT" : "Win";
    else if (lUA.indexOf("Mac") != -1)    _wguUtil_getUserAgentInfo.infoRec.platform = "Mac";
    else if (lUA.indexOf("Linux") != -1)  _wguUtil_getUserAgentInfo.infoRec.platform = "Linux";

    // determine user agent type

    if (window.opera)
      _wguUtil_getUserAgentInfo.infoRec.type = "Opera";
    else if (laMatch.length == 3) {
        switch (laMatch[1]) {
            case "MSIE"     : _wguUtil_getUserAgentInfo.infoRec.type = "IE"; break;
            case "Netscape" :
        case "Gecko"    : _wguUtil_getUserAgentInfo.infoRec.type = "NN"; break;
        default :
          if    (lUA.indexOf("MSIE") != -1)     _wguUtil_getUserAgentInfo.infoRec.type = "IE";
          else if (lUA.indexOf("Opera") != -1)    _wguUtil_getUserAgentInfo.infoRec.type = "Opera";
          else if (lUA.indexOf("Mozilla") != -1)    _wguUtil_getUserAgentInfo.infoRec.type = "Mozilla";
          else if (lUA.indexOf("Lynx") != -1)     _wguUtil_getUserAgentInfo.infoRec.type = "other";
          else if (lUA.indexOf("amaya") != -1)    _wguUtil_getUserAgentInfo.infoRec.type = "other";
          else if (lUA.indexOf("Nokia") != -1)    _wguUtil_getUserAgentInfo.infoRec.type = "Nokia";
          else if (lUA.indexOf("Ericsson") != -1)   _wguUtil_getUserAgentInfo.infoRec.type = "Ericsson";
          else                    _wguUtil_getUserAgentInfo.infoRec.type = "other";
          break;
        }
        _wguUtil_getUserAgentInfo.infoRec.version = parseFloat( laMatch[2]);
    }

    // determine W3C DOM conformity

    if (document.getElementById != null)
      _wguUtil_getUserAgentInfo.infoRec.W3CDOM = true;
  } // if (infoRec == 0)

  return _wguUtil_getUserAgentInfo.infoRec;
} // _wguTool_userAgentInfo()
_wguUtil_getUserAgentInfo.infoRec = 0;
_wguUtil_getUserAgentInfo();

////////////////////////////////////////////////////////////////////////////////
// User Agent Information END
////////////////////////////////////////////////////////////////////////////////









////////////////////////////////////////////////////////////////////////////////
//
// Event Handler Registration
//
// Interface:
//    Constructor:    wguObjEventHandler
//    Functions:      RegisterHandler()
//                    UnregisterHandler()
//                    HandleEvent()
//
////////////////////////////////////////////////////////////////////////////////



   /*********************************************************************
     * Event Handler Object
     * Register, unregister event handler
     * and execute list of event handler
     */

    function _objEventHandlerListElement ( in_handler, in_handlerID, in_priority, in_ahandlerparms )
    {
      var rv = null;
      if (in_handler) {
        this._handler   = in_handler;
        this._handlerID = in_handlerID;

        this._handlerParms = in_ahandlerparms;

        this._priority     = in_priority ? in_priority : 0;

        // this list is implemented as a ring (!)
        this._prev         = this;
        this._next         = this;
        rv = this;
      }
      return rv;
    } // _objEventHandlerListElement()


    _objEventHandlerListElement.prototype.Append = function ( /* _objEventHandlerListElement */ in_listelem )
    {
      in_listelem._next = this._next;
      this._next = in_listelem;
      in_listelem._prev = this;

      return this;
    } // _objEventHandlerListElement.Append()


    _objEventHandlerListElement.prototype.InsertBefore = function ( /*_objEventHandlerListElement */ in_listelem )
    {
      this._prev._next = in_listelem;
      in_listelem._prev = this._prev;
      this._prev = in_listelem;
      in_listelem._next = this;
      return this;
    } // _objEventHandlerListElement.InsertBefore()


    _objEventHandlerListElement.prototype.Find = function ( in_handlerID )
    {
      var rv = null;
      var isfound = false;
      do {

      } while (isfound || el == this);

      return rv;
    } // _objEventHandlerListElement.Find()


    _objEventHandlerListElement.prototype.Unlink = function ()
    {
      this._prev._next = this._next;
      this._next._prev = this._prev;
      // delete this has to be done from outside
    } // _objEventHandlerListElement.Unlink()


    _objEventHandlerListElement.prototype.Delete = function ()
    {
      var el = this;
      if (this._handlerParms)
        delete this._handlerParms;
      delete el;
    } // _objEventHandlerListElement.Delete()


    _objEventHandlerListElement.prototype.Call = function ( in_event )
    {
      var rc      = null;
      var parms   = this._handlerParms;
      var l       = parms ? parms.length : 0;

      if (l == 0) {       // zero parameter -> quick call of event handler
        if (in_event)
          rc = this._handler( in_event);
        else
          rc = this._handler();
      }
      else if (l == 1) {  // one parameter -> quick call of event handler
        if (in_event)
          rc = this._handler( in_event, parms[ 0]);
        else
          rc = this._handler( parms[ 0]);
      }
      else {
        // Preserve the handler receiver and argument order without generating source text.
        try {
          rc = this._handler.apply(this, in_event ? [in_event].concat(parms) : parms);
        } catch (err) {}
      }
      return rc;
    } // _objEventHandlerListElement.Call()


   /*********************************************************************
    * Help object: Event handler list object
    *  _event       : type of event
    *  _handler     : list of event handler for _event
    *  _handlerParms: list of parameters for _handler
    */
    function _objEventHandlerList( in_event )
    {
      var rv = null;
      if (in_event && typeof in_event == "string") {
        this._event        = in_event.toLowerCase();
        this._handlerList  = null;
        rv = this;
      }
      return rv;
    } // _objEventHandlerList();

    _objEventHandlerList.prototype.Length = function ()
    {
      var rv = 0;
      if (this._handlerList) {
        var firstel = this._handlerList;
        var el      = firstel;
        do {
          rv++;
          el = el._next;
        } while (el != firstel);
      }
      return rv;
    } // _objEventHandlerListElement.Length()




    /* Lookup first element with priority <= in_priority in list
     *  In:      in_priority: value of priority to lookup
     *  Returns: reference to element found in list or null
     */
    _objEventHandlerList.prototype.FindElementByPriority = function ( in_priority )
    {
      var rv = null;
      if (this._handlerList) {
        var el = this._handlerList;
        if (in_priority == 0) {
          if (el._priority != 0) {
            while (el._prev._priority == 0)
              el = el._prev;
            rv = el;
          }
          else
            rv = null;
        }
        else if (in_priority < 0 || in_priority < el._prev._priority)
          rv = null;
        else if (in_priority >= el._priority)
          rv = el;
        else {
          while (in_priority < el._priority)
            el = el._next;
          rv = el;
        }
      }
      return rv;
    } // _objEventHandlerListElement.FindElementByPriority()


    _objEventHandlerList.prototype.AddHandler = function ( in_handler, in_handlerID, in_priority, in_ahandlerparms )
    {
//alert("AddHandler " + in_handlerID + " with priority " + in_priority);
      var rv = null;
      if (in_handler) {
        var prio = (in_priority && (in_priority > 0)) ? in_priority : 0;
        var el   = new _objEventHandlerListElement( in_handler, in_handlerID, prio, in_ahandlerparms);
        if (!this._handlerList)
          this._handlerList = el;
        else {
          var listelem = this.FindElementByPriority( prio - 1);
          if (listelem) {
            listelem.InsertBefore( el);
            if (listelem == this._handlerList && listelem._priority < el._priority)
              this._handlerList = el;
          }
          else
            this._handlerList.InsertBefore( el);
        }
        rv = el;
      }
      return rv;
    } // _objEventHandlerList();


    _objEventHandlerList.prototype.RemoveHandler = function ( in_handler, in_handlerID)
    {
      var rv       = null;
      var firstel  = this._handlerList;
      var el       = firstel;
      var len      = this.Length();
      var el_del;

      if (in_handler || in_handlerID) {

        for (var i = 0; firstel && i < len; i++) {
          el_del = null;

          if (in_handler && !in_handlerID && el._handler == in_handler)             // only reference to handler provided
            el_del = el;
          else if (!in_handler && in_handlerID && el._handlerID == in_handlerID)    // only ID of handler provided
            el_del = el;
          else if (el._handler == in_handler && el._handlerID == in_handlerID)      // both, handler and ID provided
            el_del = el;

          el = el._next;

          if (el_del) {
             el_del.Unlink();
             if (el_del == firstel) {
               if (firstel._next == el_del)     // the only remaining object
                 firstel = this._handlerList = null;
               else
                 firstel = this._handlerList = el;
             }
             el_del.Delete();
          }
        } // for
      }
      return rv;
    } // _objEventHandlerList();


    _objEventHandlerList.prototype.CallHandlerList = function ( in_event )
    {
      var rc = null;
      var firstel = this._handlerList;
      var el      = firstel;
      if (firstel) {
        do {
          rc = el.Call( in_event);
          el = el._next;
        } while (el != firstel && this._handlerList);
      }
    return rc;
    } // _objEventHandlerList.CallHandlerList()


    _objEventHandlerList.prototype.Write = function ()
    {
      var firstel = this._handlerList;
      var el      = firstel;
      if (firstel) {
        document.writeln( "<p style=\"font: normal 7pt sans-serif; border: solid 1px #036; background-color: #CCC;\">");
        document.writeln( "<span style=\"font-weight:bold; font-size: 8pt;\">Event: " + this._event + "</span>");
        document.writeln( "&nbsp;&nbsp;(No of handler: " + this.Length() + ")");
        document.writeln( "<table><tr>");
        do {
          document.writeln( "<td><table style=\"font: normal 7pt sans-serif; color: #036; border: solid 1px #003;\">");
          document.writeln( "<tr><td colspan=\"2\" style=\"border-bottom: 1pt solid #333;\">ID: " + el._handlerID + "</td></tr>");
          document.writeln( "<tr><td colspan=\"2\" style=\"border-bottom: 1pt solid #999;\">Priority: " + el._priority + "</td></tr>");
          document.writeln( "<tr><td>Prev:</td><td>" + el._prev._handlerID + "</td></tr><tr><td>Next:<td>" + el._next._handlerID + "</td></tr>");
          document.writeln( "</table>");
          if (el != el._next && el._next != firstel)
            document.writeln( "<td style=\"white-space: nowrap;\">--></td></td>");
          else
            document.writeln( "</td>");
          el = el._next;
        } while (el != firstel);
        document.writeln( "</tr></table></p>");
      }
    } // _objEventHandlerList.write()



   /*********************************************************************
    *
    */
    function wguObjEventHandler ()
    {
      /* Array of event handler list objects
       */
      this._aHandlerList = null;

      return this;
    } // wguObjEventHandler()


    /* Register event handler to list of handler routines
     * Arguments:
     *   in_handlerid : identifier of registered handler in list
     *   in_handler   : event handler to be registered
     *   ...          : static arguments for event handler
     */
    wguObjEventHandler.prototype.RegisterHandler = function ( in_event, in_handlerID, in_priority, in_handler, in_parm )
    {
      var handlerobj = null;
      var i, l;
      var argparmidx = 4;
      var aParms;
      var handlerel;

      if (in_event && in_handlerID && in_handler) {
        /* For first event the event handler list object
         * must be created
         */
        if (this._aHandlerList == null)
          this._aHandlerList = new Array();

        if (this._aHandlerList) {
          if (typeof this._aHandlerList[ in_event] == "undefined")
            this._aHandlerList[ in_event] = new _objEventHandlerList( in_event);

          handlerobj = this._aHandlerList[ in_event];
          if (handlerobj) {
            // first, copy handler parameters to argument list
            if ((l = arguments.length) > argparmidx) {
              if (aParms = new Array()) {
                for (i = argparmidx; i < l; i++)
                  aParms[ i-argparmidx] = arguments[ i];
              }
            }

            // second, add handler to handler list
            handlerobj.AddHandler( in_handler, in_handlerID, in_priority, aParms);

          } // if (handlerobj)
        } // if (this._aHandlerList)
      } // if (in_event)
      return this;
    } // wguObjEventHandler.RegisterHandler()


    /*
     * IN: in_handler - reference to event handler
     *     in_handlerID
     */
    wguObjEventHandler.prototype.UnregisterHandler = function ( in_event, in_handler, in_handlerID )
    { var i, l;
      if (in_event && this._aHandlerList) {
        var handlerobj = this._aHandlerList[ in_event];
        if (handlerobj) {
          handlerobj.RemoveHandler( in_handler, in_handlerID);
          // also delete event handler object if no handler available
          if (!handlerobj._handlerList) {
            delete handlerobj._event;
            delete handlerobj;
          }
        } // if (handlerobj)
      } // if (args provided)
      return this;
    } // wguObjEventHandler.UnregisterHandler()


    wguObjEventHandler.prototype.HandleEvent = function ( in_evt )
    {
      var rc = null;
      var evt;
      var eventtype;
      if (in_evt) {
        if (typeof in_evt == "string")
          eventtype = in_evt;
        else
          evt = in_evt;
      }
      else
        evt = (window.event) ? window.event : null;

      if (evt)
        eventtype = evt.type;

//alert("HandleEvent( " + in_evt + " )\n eventtype = " + eventtype);

      if (eventtype && this._aHandlerList != null) {
        var handlerobj = this._aHandlerList[ eventtype.toLowerCase()];
        if (handlerobj != null) {
          rc = handlerobj.CallHandlerList();
        }
      }
      return rc;
    } // wguObjEventHandler.HandleEvent()


    wguObjEventHandler.prototype.HandleEvent_withEvent = function ( in_event )
    {
      var rc = null;
      var evt;
      var eventtype;
      if (in_event) {
        if (typeof in_event == "object")
          evt = in_event;
        else
          eventtype = in_event;
      }
      else
        evt = (window.event) ? window.event : null;

      if (evt)
        eventtype = evt.type;

//alert("HandleEvent_withEvent( " + in_evt + " )\n eventtype = " + eventtype);

      if (eventtype && this._aHandlerList != null) {
        var handlerobj = this._aHandlerList[ eventtype.toLowerCase()];
        if (handlerobj != null) {
          rc = handlerobj.CallHandlerList( evt );
        }
      }
      return rc;
    } // wguObjEventHandler.HandleEvent()


    wguObjEventHandler.prototype.Write = function ()
    {
      var handlerobj;
      for (var ev in this._aHandlerList) {
        handlerobj = this._aHandlerList[ ev];
        if (handlerobj != null) {
          handlerobj.Write();
        }
      }
    } // wguObjEventHandler.HandleEvent()


////////////////////////////////////////////////////////////////////////////////
// Event Handler Registration END
////////////////////////////////////////////////////////////////////////////////










////////////////////////////////////////////////////////////////////////////////
//
// Trace
//
// Interface:
//    Functions:    wgu_Trace ()
//
////////////////////////////////////////////////////////////////////////////////



var __wgu_ringbuffer_static = {
  _dfltMaxEntries : 50
}


function wguObjRingBuffer ( in_maxEntries )
{
  this._buffer    = null;                     // storage
  this._maxEntries  = 0;                      // max no of entries in current ring buffer
  this._defltmax    = _wgu_ringbuffer_static._dfltMaxEntries;   // default max no
  this._idx     = 0;                      // actual index
  this._idxstart    = 0;                      // index of first element

  this.Reset( in_maxEntries);

  return this;
} // wguObjRingBuffer ()


wguObjRingBuffer.prototype.Reset = function ( in_maxEntries ) {
  buffer = null;
  if ( in_maxEntries ) {
    this._maxEntries = in_maxEntries;
    this._buffer = new Array( this._maxEntries);
  }
  else {
    this._maxEntries = this._dfltmax;
    this._buffer = new Array( this._maxEntries);
  }
  this._idx   = 0;
  this._idxstart  = 0;

  return this;
} // wguObjRingBuffer.Reset()


wguObjRingBuffer.prototype.IndexSubtract = function ( in_index, in_operand ) {
  var m = this._maxEntries;
  var i = (in_index - in_operand) % m;
  return (i < 0) ? m + i : i;
} // wguObjRingBuffer.IndexSubtract()


wguObjRingBuffer.prototype.IndexAdd = function ( in_index, in_operand ) {
  return (in_index + in_operand) % this._maxEntries;
} // wguObjRingBuffer.IndexAdd()



wguObjRingBuffer.prototype.GetNoEntries = function () {
  var noEntries = 0;
  var idx1 = this._idx,
    idx0 = this._idxstart;

  if (idx0 >= 0)
    noEntries = (idx1 + (idx1 <= idx0) ? this._maxEntries : 0) - idx0;

  return noEntries;
} // wguObjRingBuffer.GetNoEntries()


// Use ring buffer as queue

wguObjRingBuffer.prototype.Read = function () {
  var data;
  if (this.GetNoEntries() > 0)
    data =  this._buffer[ this._idxstart];
  else
    data = null;

  return data;
} // wguObjRingBuffer.Read()

wguObjRingBuffer.prototype.Dequeue = function () {
  var data;

  if (this.GetNoEntries() > 0) {
    data = this._buffer[ this._idxstart];
    this._buffer[ this._idxstart] = null;
    this._idxstart = (this._idxstart + 1) % this._maxEntries;
  }
  else
    data = null;

  return data;
} // wguObjRingBuffer.Dequeue()

wguObjRingBuffer.prototype.Enqueue = function ( in_data ) {
  this._buffer[ this._idx] = in_data;
  this._idx = (this._idx + 1) % this._maxEntries;
} // wguObjRingBuffer.Enqueue()


// use ring buffer as stack

wguObjRingBuffer.prototype.Pop = function () {
  var data;

  if (this.GetNoEntries() > 0) {
    data = this._buffer[ --this._idx];
    this._buffer[ this._idx] = null;
    this._idxstart = (this._idxstart + 1) % this._maxEntries;
  }
  else
    data = null;

  return data;
} // wguObjRingBuffer.Pop()


wguObjRingBuffer.prototype.Push = function ( in_data ) {
  this.Enqueue( in_data);
} // wguObjRingBuffer.Push()


/*
wguObjRingBuffer.prototype. = function () {

} // wguObjRingBuffer.()


wguObjRingBuffer.prototype. = function () {

} // wguObjRingBuffer.()


wguObjRingBuffer.prototype. = function () {

} // wguObjRingBuffer.()


wguObjRingBuffer.prototype. = function () {

} // wguObjRingBuffer.()


wguObjRingBuffer.prototype. = function () {

} // wguObjRingBuffer.()

*/


  function wguObjTrace_setoption ( in_option, in_value, in_default, in_use_default )
  { var obj = new Object();
    obj.value   = in_value;
    obj.deflt   = in_default;
    obj.usedeflt  = in_use_default;
    return obj;
  } // setoption()


function wguObjTrace ()
{
  this._tracewindow   = null;
  this._winname     = "";
  this._accessable    = false;
  this._tempbuf     = new Array();
  this._tempbufidx    = 0;
  this._tempbuffirstidx = 0;

  // options for trace window
  this._arropts = new Array();
  this._arropts[in_option] = wguObjTrace_setoption( "title",     null, "WGUTrace", true);
  this._arropts[in_option] = wguObjTrace_setoption( "maxentries",  null, "50",   false);

  return this;
} // Constructor wguObjTrace()


wguObjTrace.prototype.GetAccessable = function ()     { return this._accessable; }                // is trace window accessable
wguObjTrace.prototype.SetAccessable = function (in_bool)  { this._accessable = in_bool; return this._accessable; }  // must be called by trace window


wguObjTrace.prototype.ResetOptions = function () {
  var opt;
  for (opt in this._arropts) {
    this._arropts[ opt].value = null;
  } // for (opt)
} // wguObjTrace.ResetOptions()

wguObjTrace.prototype.GetOptions = function () {
  var opt;
  var stropt = "";
  var obj;
  for (opt in this._arropts) {
    obj = this._arropts[ opt];
    if (stropt == "") stropt = "?";
    else stropt = "&";
    stropt =+ stropt + opt;
    if (obj.value != null) stropt += stropt + obj.value;
    else if (obj.usedeflt) stropt += stropt + obj.deflt;
  } // for (opt)
  return stropt;
} // wguObjTrace.GetOptions()

wguObjTrace.prototype.OpenWindow = function () {
  this._winname = "wguwin_trace"; //wgu_NewUniqueWindowName();
  this._tracewindow = window.open( "../page/wgutrace.html",
                                   this._winname,
                                   "location=no,menubar=no,resizable=yes,toolbar=no,titlebar=no");
} // wguObjTrace.OpenWindow()



function _wgu_TraceBuffer ()
{

}


function _wgu_TraceData ()
{

} // _wgu_TraceData()


function _wgu_Trace ( in_str )
{
  var meta;
  var fnregex = /function (\w+\(.*\))/;
  fnregex.exec( _wgu_Trace.caller);

  meta = RegExp.$1;
  if ( in_meta ) meta += ": " + in_meta;

  this._tracewindow = null;
  this._winname   = "";
  this._accessable  = false;
  this._tempbuf   = new Array();
  this._tempbufidx  = 0;
  this._tempbuffirstidx = 0;

  if (this._accessable) {
    //if
    //_wgutrc_append( '', meta, in_str );
  }
  else {
    _
  }
} // wgu_Trace()

wguObjTrace.prototype.Trace = _wgu_Trace;


function _wgutrc_append ( in_time, in_meta, in_str )
{ var div = document.getElementById("wguIDBody").firstChild;
  if (div) {
    var now     = new Date();
    var newdiv    = div.cloneNode( true);
    var strmeta;

    if ( in_time )  strmeta = in_time;
    else      strmeta = now.toGMTString().substr(0,25);
    if ( in_meta ) strmeta = strmeta + "  :  " + in_meta;

    newdiv.firstChild.firstChild.nodeValue = strmeta;
    newdiv.lastChild.firstChild.nodeValue = in_str;

    newdiv.style.display = "block";
    document.getElementById("wguIDBody").insertBefore( newdiv, div);
  } // if (div)
} // _wgutrc_append()

function wguTrace_trace ( in_str, in_meta )
{ var meta;
  var fnregex = /function (\w+\(.*\))/;
  fnregex.exec( wguTrace.caller);

  meta = RegExp.$1;
  if ( in_meta ) meta += ": " + in_meta;
  _wgutrc_append( '', meta, in_str );
} // wguTrace()



////////////////////////////////////////////////////////////////////////////////
// Trace END
////////////////////////////////////////////////////////////////////////////////




function wgudbg_alertEvent( in_event )
{
  var ev;
  var alertstr;

  if (in_event == null) {
    /* MSIE */
    if (typeof window.event != "undefined")
      ev = window.event;
  }
  else
    ev = in_event;

  if (ev != null) {
    alertstr = "Event:\n type = " + ev.type + "\n";
    for (var i in ev) {
      alertstr += " " + i + " = " + ev[ i] + "\n";
      if ((i == "fromElement" || i == "srcElement" || i == "toElement") && ev[ i])
        alertstr += "  " + ev[i].outerHTML.substr( 0, 40) + "\n\n";
    }
    alert( alertstr);
  }
} // alertEvent()



////////////////////////////////////////////////////////////////////////////////

/*******************************************************************************
 *
 * Class <I T S _ U S E R A G E N T>
 *
 * Description: browser independent event class
 * Date       : 2004/11/03
 * Author     : Simon Kruska
 *
 * History    :
 * yyyy/mm/dd id description
 * 2004/11/03 sk initial implementation
 *
 ******************************************************************************/
/** <its_useragent>
  *
  *   constructor for the its_useragent class.
  */
function its_useragent()
{
  var agent = navigator.userAgent.toLowerCase();
  var major = parseInt(navigator.appVersion);
  var minor = parseFloat(navigator.appVersion);
  // Chromium also says 'like Gecko'; only Trident identifies IE 11.
  var ieAsOf11 = (agent.indexOf('trident/') != -1);

  this.gecko  = ( !ieAsOf11 && agent.indexOf('gecko') != -1);

  this.ie     = (((agent.indexOf("msie") != -1) || ieAsOf11) &&
                 (agent.indexOf("opera") == -1));
  this.ie3    = (this.ie && (major < 4));
  this.ie4    = (this.ie && (major == 4) && (agent.indexOf("msie 4")!=-1) );
  this.ie5    = (this.ie && (major == 4) && (agent.indexOf("msie 5.0")!=-1) );
  this.ie55   = (this.ie && (major == 4) && (agent.indexOf("msie 5.5") !=-1));
  this.ie55up = (this.ie && !this.ie3 && !this.ie4 && !this.ie5);
  this.ie6    = (this.ie && (major == 4) && (agent.indexOf("msie 6.")!=-1) );
  this.ie6up  = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55);
  this.ie7    = (this.ie && (major == 4) && (agent.indexOf("msie 7.")!=-1) && (agent.indexOf("trident")== -1));
  this.ie7up  = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55 && !this.ie6);
  this.ie8    = (this.ie && (major == 4) && agent.indexOf("trident/4.") != -1 );
  this.ie8up  = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55 && !this.ie6 && !this.ie7);
  this.ie9    = this.ie && agent.indexOf("trident/5.") != -1;
  this.ie9up  = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55 && !this.ie6 && !this.ie7 && !this.ie8);
  this.ie10   = this.ie && agent.indexOf("trident/6.") != -1;
  this.ie10up = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55 && !this.ie6 && !this.ie7 && !this.ie8 && !this.ie9);
  this.ie11   = this.ie && agent.indexOf("trident/7.") != -1;
  this.ie11up = (this.ie && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie55 && !this.ie6 && !this.ie7 && !this.ie8 && !this.ie9 && !this.ie10);

}
// </its_useragent>


var its_ua = new its_useragent();

// </I T S _ U S E R A G E N T>


/*******************************************************************************
 *
 * <D O M T O O L S>
 *
 * Description: Several methods for working on a documents DOM
 *
 * Date       : 2004/12/09
 * Author     : Simon Kruska
 *
 * History    :
 * YYYY/MM/DD ID DESCRIPTION
 * 2004/11/22 sk initial implementation
 *
 ******************************************************************************/

// some DOM related constants
DOM_NODE_TYPE_ELEMENT        = 1;
DOM_NODE_TYPE_ATTRIBUTE      = 2;
DOM_NODE_TYPE_TEXT           = 3;
DOM_NODE_TYPE_CDATA_SECTTION = 4;
DOM_NODE_TYPE_COMMENT        = 9;

// DOM attributes that differ with the useragent
DOM_ATTRIBUTE_CLASS = "class";

if (its_ua.gecko)
{

}
else
{
  DOM_ATTRIBUTE_CLASS = "className";
}

/* its_utils */
/** <dom_getChildNodeByAttrAndValue>
  *
  *   get the very next element that has attribute=value
  *
  *   params:
  *   element   - Object - the source element
  *   attribute - String - the attribute to check for
  *   value     - String - the value the attribute must have
  *
  */
function dom_getChildNodeByAttrAndValue(element, attribute, value)
{
  if (element)
  {
    if (element.childNodes.length > 0)
    {
      var i = 0;
      while (i < element.childNodes.length)
      {
        if (element.childNodes[i].nodeType == DOM_NODE_TYPE_ELEMENT)
        {
            v = element.childNodes[i].getAttribute(attribute);
            if (v == value)
            {
              return element.childNodes[i];
            }
        }
        i++
      }
    }
  }
  return null;
}
// </dom_getChildNodeByAttrAndValue>


/** <dom_getChildNodeByNodeName>
  *
  *   get the very next element that has the approriate nodeName
  *
  *   params:
  *   element  - Object - the source element
  *   nodeName - String - the name of the childnode
  *
  */
function dom_getChildNodeByNodeName(element, nodeName)
{
  if (element)
  {
    if (element.childNodes.length > 0)
    {
      var i = 0;
      while (i < element.childNodes.length)
      {
        if (element.childNodes[i].nodeType == DOM_NODE_TYPE_ELEMENT &&
            element.childNodes[i].nodeName == nodeName)
        {
          return element.childNodes[i];
        }
        i++
      }
    }
  }
  return null;
}
// </dom_getChildNodeByNodeName>


/** <dom_getChildNodeByIndex>
  *
  *   get the child node with the appropriate index
  *
  *   params:
  *   node  - Object - the source element
  *   index - Number - the index of the element
  *
  */
function dom_getChildNodeByIndex(node, index)
{
  var i = -1;
  node = node.childNodes[0];
  while (node && i < index)
  {
    if (node.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      i++;
    }
    if (i != index)
    {
      node = node.nextSibling;
    }
  }
  return node;
}
// </dom_getChildNodeByIndex>


/** <dom_getParentNodeByNodeName>
  *
  *   get the parent element that has the approriate nodeName
  *
  *   params:
  *   node     - Object - the source node
  *   nodeName - String - the node name of the parent node
  *
  */
function dom_getParentNodeByNodeName(node, nodeName)
{
  if (node)
  {
    node = node.parentNode;
    while (node)
    {
      if (node.nodeType == DOM_NODE_TYPE_ELEMENT &&
          node.nodeName == nodeName)
      {
        return node;
      }
      node = node.parentNode;
    }
  }
  return null;
}
// </dom_getParentNodeByNodeName>


/** <dom_getParentNodeByAttrAndValue>
  *
  *   get the very previous element that has attribute=value
  *
  *   params:
  *   element   - Object - the source element
  *   attribute - String - the attribute to check for
  *   value     - String - the value the attribute must have
  *
  */
function dom_getParentNodeByAttrAndValue(element, attribute, value)
{
  while (element)
  {
    if (element.nodeType == DOM_NODE_TYPE_ELEMENT)
    {
      v = element.getAttribute(attribute);
      if (v == value)
      {
        return element;
      }
      else
      {
        element = element.parentNode;
      }
    }
    else
    {
      element = element.parentNode;
    }
  }
  return null;
}
// </dom_getParentNodeByAttrAndValue>


/** <dom_contains>
  *
  *   checks whether the parent node is or containes the child node.
  *
  *   params:
  *   parentNode - Object - the node that possibly contains the ...
  *   childNode  - Object - child node that possibly is contained by the
  *                           parentNode or even is the parentNode
  *
  */
function dom_contains(parentNode, childNode)
{
  while (childNode)
  {
    if (childNode == parentNode)
      return true;
    childNode = childNode.parentNode;
  }
  return false;
}
// </dom_contains>


/** <dom_addClass>
  *
  *   add a class to an elements class attribute
  *
  *   params:
  *   className - String - the current class attribute
  *   add       - String - the class to be added to the class attribute
  *
  */
function dom_addClass(className, add)
{
  classes = className.split(" ");
  for (i in classes)
  {
    if (classes[i] == add)
      return className;
  }
  classes.push(add);
  return classes.join(" ");
}
// </dom_addClass>


/** <dom_removeClass>
  *
  *   remove a class from an elements class attribute
  *
  *   params:
  *   className - String - the current class attribute
  *   remove    - String - the class to be remove to the class attribute
  *
  */
function dom_removeClass(className, remove)
{
  classes = className.split(" ");
  newClasses = new Array();
  for (i in classes)
  {
    if (classes[i] != remove)
      newClasses.push(classes[i]);
  }
  return newClasses.join(" ");
}
// </dom_removeClass>


/** <dom_getXPos>
  *
  *   gets the horizontal position of an element on the entire page
  *
  *   params:
  *   obj - Object - the element whose position is to be determined
  *
  */
function dom_getXPos(obj)
{
  var x = 0, parentElement;

  parentElement = obj.offsetParent;
  if (parentElement != null)
  {
    x = dom_getXPos(parentElement);
  }
  if (obj.clientLeft)
  {
    return x + obj.offsetLeft + obj.clientLeft;
  }
  else
  {
    return x + obj.offsetLeft;
  }
}
// </dom_getXPos>


/** <dom_getYPos>
  *
  *   gets the vertical position of an element on the entire page
  *
  *   params:
  *   obj - Object - the element whose position is to be determined
  *
  */
function dom_getYPos(obj)
{
  var y = 0, parentElement;

  parentElement = obj.offsetParent;
  if (parentElement != null)
  {
    y = dom_getYPos(parentElement);
  }
  if (obj.clientTop)
  {
    return y + obj.offsetTop + obj.clientTop;
  }
  else
  {
    return y + obj.offsetTop;
  }
}
// </dom_getYPos>


webgui._focusStatus = 0;
webgui._focusElement = null;
webgui._focusDelay = 50;
webgui._focusTimeoutId = 0;

/** <dom_focus>
  *
  *   Sets the focus to a node and checks whether the node has a focus method
  *   or not. Although this method seemd to be very useless it does really make
  *   sense: .focus() and .select() should not be called directly from within
  *   an event handler but through a window.setTimeout call to prevent scripts
  *   from doing strange unexpected things (see http://www.mozilla.org/access/
  *   keyboard/tabindex.html). Furthermore you will get an javascript error in
  *   "line 0" and "No source code available" error in JS debugger if one
  *   occurs while calling window.setTimeout("focusItem.focus()", 0); for
  *   instance if focusItem does not have a .focus() method. As you have a fix
  *   piece of source code you can set breakpoints and debug.
  *
  *   params:
  *   node - Object - the node to set the focus to
  *
  */
function dom_focus(node)
{
  if (null != node && null != node.tagName)
    dbg2("focus", "<dom_focus> tagName=" + node.tagName + ", id=" + node.id + ", class=" + node.className + ", name=" + node.name);
  else
    dbg2("focus", ["<dom_focus> node of type ", typeof node, "(", node.nodeType, ")"].join(""));

  var _rv = false;
  if (webgui._focusStatus > 0)
  {
    try
    {
      if (node.focus)
      {
        node.focus();
        _rv = true;
      }
    }
    catch (error)
    {
      err("focus", "Setting focus failed!");
      _rv = false;
    }
  }
  else
  {
    dbg2("focus", " --> focus event postponed, already within onload...");
    webgui._focusElement = node;
  }
  dbg2("focus", "</dom_focus>");
  return _rv;
}
// </dom_focus>


/** <dom_delayedFocus>
  *
  *   delay wrapper for dom_focus
  *
  *   params:
  *   node  - Object - the node to set the focus to
  *   delay - Number - delay in ms
  *
  */
function dom_delayedFocus(node, delay)
{
  dbg2("focus", "<dom_delayedFocus>");
  var _rv = false;
  window.clearTimeout(webgui._focusTimeoutId);
  if (typeof(node) != "undefined")
  {
    webgui._focusElement = node;
    if (typeof(delay) == "undefined")
      var delay = webgui._focusDelay;
    webgui._focusTimeoutId = window.setTimeout("dom_focus(webgui._focusElement);", delay);
    _rv = true;
  }
  else
  {
    warn("no focus element defined");
  }
  dbg2("focus", "</dom_delayedFocus>");
  return _rv;
}
// </dom_delayedFocus>


/** <dom_select>
  *
  *   Selects the node (which should be an something that could be selected, e.
  *   g. an input field) content and checks whether the node has a select method
  *   or not. Although this method seemd to be very useless it does really make
  *   sense: .focus() and .select() should not be called directly from within
  *   an event handler but through a window.setTimeout call to prevent scripts
  *   from doing strange unexpected things (see http://www.mozilla.org/access/
  *   keyboard/tabindex.html). Furthermore you will get an javascript error in
  *   "line 0" and "No source code available" error in JS debugger if one
  *   occurs while calling window.setTimeout("selectItem.select()", 0); for
  *   instance if selectItem does not have a .select() method. As you have a fix
  *   piece of source code you can set breakpoints and debug.
  *
  *   params:
  *   node - Object - the node to set the select to
  *
  */
function dom_select(node)
{
  dbg2("focus", "<dom_select> tagName=" + node.tagName + ", id=" + node.id + ", class=" + node.className + ", name=" + node.name);
  var _rv = false;
  if (webgui._focusStatus > 0)
  {
    try
    {
      if (node.select)
      {
        node.select();
        _rv = true;
      }
    }
    catch (error)
    {
      err("focus", "Setting select failed!");
      _rv = false;
    }
  }
  else
  {
    dbg2("focus", " --> focus event postponed, already within onload...");
    webgui._focusElement = node;
  }
  dbg2("focus", "</dom_select>");
  return _rv;
}
// </dom_select>


/** <dom_delayedSelect>
  *
  *   delay wrapper for dom_select
  *
  *   params:
  *   node  - Object - the node to set the select to
  *   delay - Number - delay in ms
  *
  */
function dom_delayedSelect(node, delay)
{
  dbg2("focus", "<dom_delayedSelect>");
  var _rv = false;
  window.clearTimeout(webgui._focusTimeoutId);
  if (typeof(node) != "undefined")
  {
    webgui._focusElement = node;
    if (typeof(delay) == "undefined")
      var delay = webgui._focusDelay;
    webgui._focusTimeoutId = window.setTimeout("dom_select(webgui._focusElement);", delay);
    _rv = true;
  }
  else
  {
    warn("no select element defined");
  }
  dbg2("focus", "</dom_delayedSelect>");
  return _rv;
}
// </dom_delayedSelect>


/** <dom_focusOnLoad>
  *
  *   Helper funtion to buffer the focus on load to assure that focus is set
  *   only once; this function is called as last function in the onload process
  *
  *   params:
  *   node - Object - the node to set the select to
  *
  */
function dom_focusOnLoad()
{
  dbg2("focus", "<dom_focusOnLoad>");
  var _rv = false;
  webgui._focusStatus = 1;
  if (webgui._focusElement)
  {
    _rv = dom_focus(webgui._focusElement)
  }
  dbg2("focus", "</dom_focusOnLoad>");
  return _rv;
}
// </dom_focusOnLoad>


// </D O M T O O L S>

/*******************************************************************************
 *
 * Class <I T S _ E V E N T>
 *
 * Description: wrapper class for handling events browser independent
 *
 * Date       : 2004/11/03
 * Author     : Simon Kruska
 *
 * History    :
 * yyyy/mm/dd id description
 * 2004/11/03 sk initial implementation
 *
 ******************************************************************************/

// javascript keycode constants
EVT_KEY_BCKSPC = 8;
EVT_KEY_TAB    = 9;
EVT_KEY_RETURN = 13;
EVT_KEY_ESCAPE = 27;
EVT_KEY_SPACE  = 32;
EVT_KEY_PGUP   = 33;
EVT_KEY_PGDOWN = 34;
EVT_KEY_END    = 35;
EVT_KEY_POS1   = 36;
EVT_KEY_LEFT   = 37;
EVT_KEY_UP     = 38;
EVT_KEY_RIGHT  = 39;
EVT_KEY_DOWN   = 40;
EVT_KEY_INS    = 45;
EVT_KEY_DEL    = 46;
EVT_KEY_F1     = 112;
EVT_KEY_F2     = 113;
EVT_KEY_F3     = 114;
EVT_KEY_F4     = 115;
EVT_KEY_F5     = 116;
EVT_KEY_F6     = 117;
EVT_KEY_F7     = 118;
EVT_KEY_F8     = 119;
EVT_KEY_F9     = 120;
EVT_KEY_F10    = 121;

// javascript mouse button constants
EVT_MB_INVALID = -1;
EVT_MB_LEFT = 1;
EVT_MB_RIGHT = 2;
EVT_MB_MIDDLE = 4;

if (its_ua.gecko)
{
  ITS_EVENT_GLOBAL_RECEIVER = window;
}
else if (its_ua.ie55up)
{
  ITS_EVENT_GLOBAL_RECEIVER = document;
}

/** <its_event>
  *
  *   constructor for the its_event class.
  *
  *   params:
  *     browserEvent - Object(Event) - for mozilla only; the event
  */
function its_event(browserEvent)
{
  // Inline legacy handlers may omit the argument even on Chrome.
  browserEvent = browserEvent || window.event;
  if ((typeof event == "undefined" || event == null) && !browserEvent)
  {
    // no event, no processing
    this.valid = false;
  }
  else
  {
    this.valid = true;

    // browser dependent initialization
    if (its_ua.gecko)
    {
      this.event   = browserEvent;
      this.target  = browserEvent.target;
      this.offsetX = null;
      this.offsetY = null;
      this.pageX   = browserEvent.pageX;
      this.pageY   = browserEvent.pageY;
      this.currentTarget = browserEvent.currentTarget;
      this.relatedTarget = browserEvent.relatedTarget;
      if (browserEvent.type == "mousedown" || browserEvent.type == "mouseup" ||
          browserEvent.type == "click" || browserEvent.type == "dblclick")
      {
        switch (browserEvent.button)
        {
          case 0:
            this.button = EVT_MB_LEFT;
            break;
          case 1:
            this.button = EVT_MB_MIDDLE;
            break;
          case 2:
            this.button = EVT_MB_RIGHT;
            break;
          default:
            this.button = EVT_MB_INVALID;
            break;
        }
      }
    }
    if (its_ua.ie55up)
    {
      this.event   = browserEvent = (window.event ? window.event : browserEvent);
      this.target  = browserEvent.srcElement;
      this.offsetX = browserEvent.offsetX;
      this.offsetY = browserEvent.offsetY;
      this.button  = browserEvent.button;
    }

    // browser independent initialization
    this.altKey       = browserEvent.altKey;
    this.ctrlKey      = browserEvent.ctrlKey;
    this.cancelBubble = browserEvent.cancelBubble;
    this.clientX      = browserEvent.clientX;
    this.clientY      = browserEvent.clientY;
    this.keyCode      = browserEvent.keyCode;
    this.screenX      = browserEvent.screenX;
    this.screenY      = browserEvent.screenY;
    this.pageX        = browserEvent.clientX;
    this.pageY        = browserEvent.clientY;
    this.shiftKey     = browserEvent.shiftKey;
    this.type         = browserEvent.type;
  }
}
// </its_event>

/** <provideOffsetXY>
  *
  *   calculates offsetX and offsetY from clientX and clientY minus its sibling
  *   and parent elements for gecko browsers.
  *
  */
its_event.prototype.provideOffsetXY = function()
{
  if (this.event && typeof this.event.offsetX == "number" && typeof this.event.offsetY == "number")
  {
    this.offsetX = this.event.offsetX;
    this.offsetY = this.event.offsetY;
    return;
  }
  if (its_ua.gecko)
  {
    var x = this.clientX;
    var y = this.clientY;
    var element = this.target;

    while (element != null && element.name != "BODY")
    {
      x -= element.offsetLeft;
      y -= element.offsetTop;
      element = element.offsetParent;
    }
    this.offsetX = x + 1 - 10;
    this.offsetY = y + 1 - 10;
  }
}
// </provideOffsetXY>


/** <preventDefault>
  *
  *   prevents the event bubbeling from executing its default action, i. g.
  *   prevent the browsers context menu on a right mouse click.
  *
  */
its_event.prototype.preventDefault = function()
{
  if (its_ua.gecko)
  {
    this.event.preventDefault();
  }
  else if (its_ua.ie55up)
  {
    this.event.returnValue = false;
  }
}
// </preventDefault>


/** <stopPropagation>
  *
  *   stop the propagation of the current event.
  *
  *
  */
its_event.prototype.stopPropagation = function()
{
  if (its_ua.gecko)
  {
    this.event.stopPropagation();
  }
  else if (its_ua.ie55up)
  {
    this.event.cancelBubble = true;
  }
}
// </stopPropagation>


/** <cancel>
  *
  *   cancel the entire event, including stopPropagation and preventDefault.
  *
  *
  */
its_event.prototype.cancel = function()
{
  this.stopPropagation();
  this.preventDefault();
}
// </cancel>



/** <raiseevent>
  *
  *   raise a new javascipt event
  *
  */
its_event.prototype.raiseevent = function ( in_evtype, in_element, in_parms )
{
  var el, ev;

  if (typeof in_element == "string")
  {
    el = document.getElementById(in_element);
  }

  if (null != el && in_evtype)
  {
    if (document.createEvent)
    {
      ev = document.createEvent("Events");
      ev.initEvent(in_evtype, true, true);
      el.dispatchEvent(evt);
    }
    else if (document.createEventObject)
    {
      ev = document.createEventObject();
      el.fireEvent("on" + in_evtype, ev);
    }
  }
}
// </raiseevent>


/** <getGlobalEventReceiver>
  *
  *   returns the upper event receiver, for mozilla itÃƒâ€šÃ‚Â´s the window object, for
  *   internet explorer itÃƒâ€šÃ‚Â´s the document
  *
  */
its_event.prototype.getGlobalEventReceiver = function()
{
  if (its_ua.gecko)
  {
    return window;
  }
  else if (its_ua.ie55up)
  {
    return document;
  }
}
// </getGlobalEventReceiver>


/** <dump>
  *
  *   dump the event data as alert window or within a table in the document
  *
  *   params:
  *     asAlert - Bool - when true, the dump is displayed in an alert window,
  *                      when false, the dump is displayed wihtin a table in the
  *                      document
  */
its_event.prototype.dump = function(asAlert)
{
  this.provideOffsetXY();
  eventArray = new Array();
  eventArray["ALTKEY"] = this.altKey;
  eventArray["CANCELBUBBLE"] = this.cancelBubble;
  eventArray["CLIENTX"] = this.clientX;
  eventArray["CLIENTY"] = this.clientY;
  eventArray["KEYCODE"] = this.keyCode;
  eventArray["SCREENX"] = this.screenX;
  eventArray["SCREENY"] = this.screenY;
  eventArray["SHIFTKEY"] = this.shiftKey;
  eventArray["TYPE"] = this.type;
  eventArray["OFFSETX"] = this.offsetX;
  eventArray["OFFSETY"] = this.offsetY;
  eventArray["TARGET"] = this.target.tagName;

  if (asAlert)
  {
    var eventString = "";
    for (var i in eventArray)
    {
      eventString += i + " = " + eventArray[i] + "\n";
    }
    alert("EVENT FROM its_event:\n\n" + eventString);
  }
  else
  {
    var table = document.getElementById("its_eventDump");
    if (!table)
    {
      var body = document.getElementsByTagName("body")[0];
      table = document.createElement("table");
      table.setAttribute("id", "its_eventDump");
      body.appendChild(table);
    }
    else
    {
      while (table.childNodes.length > 0)
      {
        table.removeChild(table.childNodes[0]);
      }
    }
    var tbody = document.createElement("tbody");
    table.appendChild(tbody);
    for (var i in eventArray)
    {
      var tr = document.createElement("tr");
      tr.style.height = "20px";
      tbody.appendChild(tr);
      var td1 = document.createElement("td");
      var td2 = document.createElement("td");
      td1.innerHTML = i;
      td2.innerHTML = eventArray[i];
      tr.appendChild(td1);
      tr.appendChild(td2);
    }
  }
}
// </dump>
// </I T S _ E V E N T>

/*******************************************************************************
 *
 * Class <I T S _ E V E N T M A N A G E R>
 *
 * Description: register and unregister events for html elements browser
 *              independent
 * Date       : 2004/11/03
 * Author     : Simon Kruska
 *
 * History    :
 * yyyy/mm/dd id description
 * 2004/11/03 sk initial implementation
 *
 ******************************************************************************/
/** <its_eventManager>
  *
  *   constructor for the its_eventManager class.
  *
  */
function its_eventManager()
{
}
// </its_eventManager>

/** <registerEvent>
  *
  *   register an event for a html element
  *
  *   params:
  *     in_element   : the element on which the event should be registered
  *     in_evtName   : name of the event to be registered (e. g. "click" or
  *                    "mouseover")
  *     in_evtHandler: a function that is to be called on the appropriate event
  *
  */
its_eventManager.prototype.registerEvent = function(in_element, in_evtName, in_evtHandler)
{
  if (null != in_element && null != in_evtName && null != in_evtHandler)
  {
    if (in_element.addEventListener)
    {
        in_element.addEventListener(in_evtName, in_evtHandler,
          in_evtName == "wheel" || in_evtName == "mousewheel" ? {passive:false} : false);
    }
    else if (in_element.attachEvent)
    {
        in_element.attachEvent("on" + in_evtName, in_evtHandler);
    }
  }
}
// </registerEvent>

/** <unregisterEvent>
  *
  *   unregister an event for a html element
  *
  *   params:
  *     in_element   : the element on which the event should be unregistered
  *     in_evtName   : name of the event to be unregistered (e. g. "click" or
  *                    "mouseover")
  *     in_evtHandler: a function that is to be called on the appropriate event
  *
  */
its_eventManager.prototype.unregisterEvent = function(in_element, in_evtName, in_evtHandler)
{
  if (null != in_element && null != in_evtName && null != in_evtHandler)
  {
    if (in_element.removeEventListener)
    {
        in_element.removeEventListener(in_evtName, in_evtHandler, false);
    }
    else if (in_element.detachEvent)
    {
        in_element.detachEvent("on" + in_evtName, in_evtHandler);
    }
  }
}
// </unregisterEvent>

/* global instance */
var its_eMgr = new its_eventManager();

// </I T S _ E V E N T M A N A G E R>





////////////////////////////////////////////////////////////////////////////////
//
//    Frame position
//
//
////////////////////////////////////////////////////////////////////////////////


var cUP    = 0x01,
    cRIGHT = 0x02,
    cDOWN  = 0x04,
    cLEFT  = 0x08;


function objPositionSize()
{
  this.x      = null;  this.y        = null;
  this.h      = null;  this.w        = null;
  this.bMoved = false; this.bResized = false;
}


function calcFramePositionResize ( in_Fw, in_Fh,
                                   in_Bx, in_By, in_Bw, in_Bh,
                                   in_openDir,
                                   in_allowedMoveDirs,
                                   in_parentContainer,
                                   in_Ww, in_Wh )
{
  var rv = null,
      oFramePS = new objPositionSize(),           // position and size of frame to be opened
      bAllowUpMove, bAllowRightMove, bAllowDownMove, bAllowLeftMove,
      bRTL = isBidiRTL(),
      parCnt,
      defaultFrameDir = bRTL ? 0x0C : 0x06,       // open frame to bottom right (ltr) / bottom left (rtl)
      opendir,
      ftop, fright, fbottom, fleft,               // positions of frame edges (top, bottom = y; left, right = x)
      rightLimit, bottomLimit,
      xy, wh
      ;

  parCnt = (null != in_parentContainer) ? in_parentContainer : document.getElementsByTagName("body")[0];

  if (   null != in_Fw && null != in_Fh
      && null != in_Bx && null != in_By
      && null != parCnt
     )
  {
    // parent window size
    if (null == in_Wh) in_Wh = parCnt.clientHeight;
    if (null == in_Ww) in_Ww = parCnt.clientWidth;

    // button size
    if (null == in_Bh) in_Bh = 0;
    if (null == in_Bw) in_Bw = 0;

    // frame is allowed to be moved in which directions?
    if (null != in_allowedMoveDirs)
    {
      bAllowUpMove    = cUP    == (cUP    & in_allowedMoveDirs); // 1 up
      bAllowRightMove = cRIGHT == (cRIGHT & in_allowedMoveDirs); // 2 right
      bAllowDownMove  = cDOWN  == (cDOWN  & in_allowedMoveDirs); // 4 down
      bAllowLeftMove  = cLEFT  == (cLEFT  & in_allowedMoveDirs); // 8 left
    }
    else
    {
      bAllowUpMove = bAllowRightMove = bAllowDownMove = bAllowLeftMove = true;
    }

    opendir = (null == in_openDir) ? defaultFrameDir : in_openDir;

    rightLimit  = in_Ww - 1;
    bottomLimit = in_Wh - 1;

    // does the frame need to be resized?
    //
    // first, we try to determine the height left for the frame

    fleft   = (cLEFT & opendir) != false ? in_Bx + in_Bw - in_Fw : in_Bx;
    fright  = fleft + in_Fw;
    ftop    = (cUP & opendir) != false   ? in_By - in_Fh         : in_By + in_Bh;
    fbottom = ftop + in_Fh;

    with (oFramePS) { x = fleft; y = ftop; h = in_Fh; w = in_Fw; }

    alongsideButton = 0;                              // is frame opened left or right from button?
    supsubButton    = (cUP & opendir) != false ? cUP : cDOWN;  // is frame opened above or below from button? (UP means ABOVE, DOWN means BELOW)

    if (ftop <= 0)
    {
      ftop = 1;
      if (bAllowDownMove && (bAllowLeftMove || bAllowRightMove))
      {
        fbottom = (1 + in_Fh <= bottomLimit) ? 1 + in_Fh : bottomLimit;
        xy = in_By + in_Bw;
        if (fbottom < xy)
        {
          fbottom = (bottomLimit < xy) ? bottomLimit : xy;
          ftop = (fbottom - in_Fh > 0) ? fbottom - in_Fh : 1;
        }
        xy = (bAllowLeftMove && ((cLEFT & opendir) != false || ((cRIGHT & opendir) != false && !bAllowRightMove)))
             ? (((cLEFT & opendir) != false)
                ? -in_Bw
                : -in_Fw
               )
             : (((cLEFT & opendir) != false)
                ? in_Fw
                : in_Bw
               )
             ;
        fleft  += xy;
        fright += xy;
        alongsideButton = (cLEFT & opendir) != false ? cLEFT : cRIGHT;   // we move the frame alongside to button
        supsubButton    = 0;                                    // and from above or below
      }
    }
    if (fbottom > bottomLimit)
    {
      fbottom = bottomLimit;
      if (bAllowUpMove && (bAllowLeftMove || bAllowRightMove))
      {
        ftop = (fbottom - in_Fh > 0) ? fbottom - in_Fh : 1;
        if (ftop > in_By)
        {
          ftop = (0 < in_By) ? in_By : 1;
          fbottom = (ftop + in_Fh <= bottomLimit) ? ftop + in_Fh : bottomLimit;
        }
        xy = (bAllowLeftMove && ((cLEFT & opendir) != false || ((cRIGHT & opendir) != false && !bAllowRightMove)))
             ? (((cLEFT & opendir) != false)
                ? -in_Bw
                : -in_Fw
               )
             : (((cLEFT & opendir) != false)
                ? in_Fw
                : in_Bw
               )
             ;
        fleft  += xy;
        fright += xy;
        alongsideButton = (cLEFT & opendir) != false ? cLEFT : cRIGHT;   // we move the frame alongside to button
        supsubButton    = 0;                                    // and from above or below
      }
    }

    if (fleft <= 0)
    {
      fleft = 1;
      if (bAllowRightMove)
      {
        if (cLEFT == alongsideButton        // think about flipping frame horizontally at button
            && in_Bx + in_Bw > 0)           // might happen in RTL if scrolled to the left to show button
        {
          wh = rightLimit - (in_Bx + in_Bw);// space right to the right of button
          if (in_Bx - 1 < wh)               // where is the larger space left, left or right from button?
          {                                 // on the right of the button more space left
            if (wh > in_Fw)                 // enough for frame
              fleft  = in_Bx + in_Bw;
            else
              fleft = (rightLimit - in_Fw > 0) ? rightLimit - in_Fw : 1;
          }
        }
        fright = (fleft + in_Fw <= rightLimit) ? fleft + in_Fw : rightLimit;
      }
    }
    if (fright > rightLimit)
    {
      fright = rightLimit;
      if (bAllowLeftMove)
      {
        if (cRIGHT == alongsideButton)
        {
          wh = rightLimit - (in_Bx + in_Bw);// space right to the right of button
          if (in_Bx - 1 > wh)
          {
            if (in_Bx - 1 > in_Fw)
              fright = in_Bx;
            else
              fright = (in_Fw + 1 < in_Ww) ? in_Fw + 1 : in_Ww - 1;
          }
        }
        fleft = (fright - in_Fw > 0) ? fright - in_Fw : 1;
      }
    }

    if (fbottom < ftop) fbottom = ftop;
    if (fright < fleft) fright = fleft;

    with (oFramePS)
    {
      if (x != fleft || y != ftop) bMoved = true;
      if (w != fright - fleft || h != fbottom - ftop) bResized = true;
      x = fleft; y = ftop; w = fright - fleft; h = fbottom - ftop;
    }

    rv = oFramePS;
  }

  return rv;

} // calcFramePositionResize()






////////////////////////////////////////////////////////////////////////////////
//
//    BIDI support
//
//
////////////////////////////////////////////////////////////////////////////////


function isBidiRTL()
{
  var rv;

  if (null == (rv = isBidiRTL.static_isRTL))
  {
    rv = document.getElementsByTagName("body")[0].getAttribute("dir");

    rv                     =
    isBidiRTL.static_isRTL = (null != rv) ? ("rtl" == rv.toLowerCase()) : false;
  }

  return rv;
}
isBidiRTL.static_isRTL = null;







////////////////////////////////////////////////////////////////////////////////
//
//    Iterator
//
//
////////////////////////////////////////////////////////////////////////////////


function wguObjIterator ( in_arrFunction, in_rvFunction )
{
  var isValid = "function" == typeof in_arrFunction;

  this._fArrFunction    = isValid ? in_arrFunction : function(){return [];};
  this._fRetValFunction = ("function" == typeof in_rvFunction) ? in_rvFunction : null;
  this._array           = null;
  this._len             = 0;
  this._iCurrIdx        = 0;

  this._isValid         = isValid;

  if (isValid)
  {
    this._array = in_arrFunction();
    this._len   = !!this._array ? this._array.length : 0;
    this._iCurrIdx = 0;

    if (!this._len)
      this._isValid = false;
    else
      rc = true;
  }

} // class wguObjIterator


wguObjIterator.prototype.IsValid = function ()
{
  return this._isValid;
};  // wguObjIterator.IsValid()


wguObjIterator.prototype.getValue = function ( in_key )
{
  var rv = null;

  if (this._isValid && null != in_key)
    rv = (!!this._fRetValFunction) ? this._fRetValFunction(in_key) : in_key;

  return rv;
};  // wguObjIterator.GetValue()


wguObjIterator.prototype.First = function ()
{
  var rv = null;

  this._iCurrIdx = 0;
  if (this._isValid)
  {
    rv = this.getValue(this._array[0]);
  }

  return rv;
};  // wguObjIterator.First()


wguObjIterator.prototype.HasNext = function ()
{
  var rc = false,
      it;

  if (this._isValid && this._iCurrIdx < this._len-1)
  {
    rc = true;
  }

  return rc;
};  // wguObjIterator.HasNext()


wguObjIterator.prototype.Next = function ()
{
  var rv = null;

  with (this)
  {
    if (_isValid && ++_iCurrIdx < _len)
    {
      rv = getValue(_array[_iCurrIdx]);
    }
  }

  return rv;
};  // wguObjIterator.Next()


wguObjIterator.prototype.Current = function ()
{
  var rv = null;

  with (this)
  {
    if (_isValid && _iCurrIdx < _len)
    {
      rv = getValue(_array[_iCurrIdx]);
    }
  }

  return rv;
};  // wguObjIterator.Current()


wguObjIterator.prototype.Finish = function ()
{
  var i;
  for (i in this)
  {
    this[i] = null;
    this._isValid = false;
  }
};  // wguObjIterator.Finish()






/*******************************************************************************
 *
 * dbg
 *
 *   tiny debug interface to trace debug information to browser/debugger
 *   console; toggle dbgLevel through STRG+ALT+SHIFT[NUMPLUS/NUMMINUS]
 *   (processed in gui_event.js)
 */

webgui._dbgComponents = new Array();
webgui._dbgLevel = 0;

/** <::dbgAdd>
  *
  *   enable a certain component to output debug information
  */
function dbgAdd(component)
{
  webgui._dbgComponents[component] = 1;
}

/** <::dbgSetLevel>
  *
  *   set the current dbg level
  */
function dbgSetLevel(level)
{
  webgui._dbgLevel = level;
}

/** <::dbgIncLevel>
  *
  *   increase the current dbg level
  */
function dbgIncLevel(level)
{
  webgui._dbgLevel++;
  if (webgui._dbgLevel > 3)
    webgui._dbgLevel = 3;
}

/** <::dbgDecLevel>
  *
  *   decrease the current dbg level
  */
function dbgDecLevel(level)
{
  webgui._dbgLevel--;
  if (webgui._dbgLevel < 0)
    webgui._dbgLevel = 0;
}

/** <::dbg1>
  *
  *   out debug information with level 1
  */
function dbg1(component, msg)
{
  dbg(component, msg, 1);
}

/** <::dbg2>
  *
  *   out debug information with level 2
  */
function dbg2(component, msg)
{
  dbg(component, msg, 2);
}

/** <::dbg3>
  *
  *   out debug information with level 3
  */
function dbg3(component, msg)
{
  dbg(component, msg, 3);
}

/** <::err>
  *
  *   out error information
  */
function err(component, msg)
{
  dbg(component, "ERROR: " + msg, 1);
}

/** <::warn>
  *
  *   out warning information
  */
function warn(component, msg)
{
  dbg(component, "WARNING: " + msg, 1);
}

/** <::dbg>
  *
  *   out debug information
  */
function dbg(component, msg, level)
{
  if (typeof level == "undefined")
    level = 1;
  if (level <= webgui._dbgLevel && webgui._dbgComponents[component] == 1)
  {
    //window.console support for firefox / companjon support for msie
    //for using firefox dump feature enable browser.dom.window.dump.enabled and start firefox with parameter -console
    if (typeof indent == "undefined")
      indent = "";
    if (msg.charAt(1) == "/")
      indent = indent.substr(0, indent.length-2);
    if (window.console)
      console.log( indent + msg ); //output to firebug or js companjon console
    else if (its_ua.gecko)
      dump( indent + msg + '\n'); //enable old school console in firefox with browser.dom.window.dump.enabled
    if ((typeof(Debug) !== 'undefined') && Debug.writeln) {
      Debug.writeln( indent + msg );
    }
    if (msg.charAt(0) == "<" && msg.charAt(1) != "/" && msg.length > 1 && msg.charAt(msg.length - 2) != "/")
      indent += "  ";
  }
}

dbgAdd("focus");



/** @class
 * DOM Analyzer for more detailed information about the current page.
 * Especially nesting depth, nesting of tables
 *
 * @author Malte Wedel
 *
 * Numbers:
 * Max Nesting: The maximal  nesting level that appears in the document
 * Avg Nesting: The average nesting level
 * Max Table Nesting: Somhow clear what that means (more that 24 the browser stops rendering)
 * Max Critical Nesting: Nesting of tags that have a height and width specified. (More than 40 the browser stops rendering)
 */
function NestingAnalyzer() {

  this.iCount = 0;
  this.iElementCount = 0;
  this.iTextCount = 0;
  this.mTagCount = {};
  this.aLevelCount = [];

  this.iNesting = 0;
  this.iMaxNesting = 0;
  this.iNestingSum = 0;
  this.fAvgNesting = 0;

  this.iTableNesting = 0;
  this.iMaxTableNesting = 0;

  this.iCritNesting = 0;
  this.iMaxCritNesting = 0;
  this.aCritNesting = [];

  this.iTime = 0;

};

/**
 * Trigger DOM Analyzer
 */
NestingAnalyzer.prototype.trigger = function() {
  this.reset();
  this.iTime = new Date().valueOf();
  this.analyze(document.documentElement);
  this.iTime = new Date().valueOf() - this.iTime;
  this.fAvgNesting = Math.floor(10 * this.iNestingSum / this.iElementCount) / 10;
  var sText = this.createReport();
  alert(sText);
  sText = this.createLevelReport();
  alert(sText);
};

/**
 * Traverse DOM and collect
 *
 * @param {DOMElement} node
 */
NestingAnalyzer.prototype.analyze = function(node) {

  var bIsTable, bIsCritical, sTagName;

  this.iCount++;
  if (this.iNesting > this.iMaxNesting) this.iMaxNesting = this.iNesting;
  if (this.iTableNesting > this.iMaxTableNesting) this.iMaxTableNesting = this.iTableNesting;
  if (this.iCritNesting > this.iMaxCritNesting) {
    this.iMaxCritNesting = this.iCritNesting;
    this.sMaxCritNesting = this.aCritNesting.join("\n");
  }

  var nodeType = node.nodeType;
  switch (nodeType) {
    case 1: // ELEMENT_NODE

      sTagName = node.tagName;
      sId = node.getAttribute("id");
      sCt = node.getAttribute("ct");
      bIsTable = (sTagName == "TABLE");
      bIsCritical = node.currentStyle && (node.currentStyle.height != "auto" || node.currentStyle.width != "auto");

      this.iElementCount++;
      this.iNestingSum += this.iNesting;

      if (!this.mTagCount[sTagName]) this.mTagCount[sTagName] = 0;
      this.mTagCount[sTagName]++;

      if (!this.aLevelCount[this.iNesting]) this.aLevelCount[this.iNesting] = 0;
      this.aLevelCount[this.iNesting]++;

      this.iNesting++;
      if (bIsTable) this.iTableNesting++;
      if (bIsCritical) {
        this.iCritNesting++;
        this.aCritNesting.push(sTagName + (sCt ? ", " + sCt + " \"" + sId + "\"": ""));
      }

      for (var i = 0; i < node.childNodes.length; i++) {
        this.analyze(node.childNodes[i]);
      }

      this.iNesting--;
      if (bIsTable) this.iTableNesting--;
      if (bIsCritical) {
        this.iCritNesting--;
        this.aCritNesting.pop();
      }

      break;
    case 3: // TEXT_NODE
      this.iTextCount++;
      break;
    case 8: // COMMENT_NODE
  }

};

NestingAnalyzer.prototype.reset = function() {
  this.iCount = 0;
  this.iElementCount = 0;
  this.iTextCount = 0;
  this.mTagCount = {};

  this.iNesting = 0;
  this.iMaxNesting = 0;
  this.iNestingSum = 0;
  this.fAvgNesting = 0;

  this.iTableNesting = 0;
  this.iMaxTableNesting = 0;

  this.iCritNesting = 0;
  this.iMaxCritNesting = 0;
  this.aCritNesting = [];
};

NestingAnalyzer.prototype.createReport = function() {
  var sReport = "";
  sReport += "Nesting depth of elements in the HTML DOM\n\n";
  sReport += "Maximum Nesting Depth: " + this.iMaxNesting + "\n";
  sReport += "(should not exceed 60)\n\n";
  sReport += "Average Nesting Depth: " + this.fAvgNesting + "\n";
  sReport += "(should not exceed 40)\n\n";
  sReport += "Maximum Table Nesting Depth: " + this.iMaxTableNesting + "\n";
  sReport += "(should not exceed 10, must not exceed 25)\n\n";
  sReport += "Maximum Critical Nesting Depth: " + this.iMaxCritNesting + "\n";
  sReport += "(should not exceed 20, must not exceed 40)\n\n";
  sReport += "Maximum Critical Nesting Elements:\n\n" + this.sMaxCritNesting + "\n\n";
  return sReport;
};

NestingAnalyzer.prototype.createLevelReport = function() {
  var iMaxCount = 0,
    iElementCount,
    iNormalizedCount;
  for (var i = 0; i < this.aLevelCount.length; i++) {
    iElementCount = this.aLevelCount[i];
    if (iElementCount > iMaxCount) iMaxCount = iElementCount;
  }

  var sReport = "Distribution of elements at the different nesting levels\n\n";
  for (var i = 0; i < this.aLevelCount.length; i++) {
    if (i < 10) sReport += "  ";
    sReport += i + ": ";
    iNormalizedCount = Math.ceil(this.aLevelCount[i] / iMaxCount * 80);
    for (var j = 0; j < iNormalizedCount; j++) sReport += "|";
    sReport += " (" + this.aLevelCount[i] + ")\n";
  }
  return sReport;
};

/** @class
 * Helper class to illustrate nesting of the HTML by giving them an 1px border
 *
 *
 */
function ContainerOutliner()
{
  this.bRunning = false;
}

ContainerOutliner.prototype.trigger = function ()
{
  var stylesheet = document.styleSheets[0];
  if (!this.bRunning)
  {
    stylesheet.addRule("DIV", "border:1px solid blue");
    stylesheet.addRule("SPAN", "border:1px solid green");
    stylesheet.addRule("TABLE", "border:1px solid red");
    this.bRunning = true;
  }
  else
  {
    stylesheet.removeRule(stylesheet.rules.length - 1);
    stylesheet.removeRule(stylesheet.rules.length - 1);
    stylesheet.removeRule(stylesheet.rules.length - 1);
    this.bRunning = false;
  }
};


////////////////////////////////////////////////////////////////////////////////
//
// hardcopy utility functions
//
////////////////////////////////////////////////////////////////////////////////

function UpDownGetTopModalWinRectAll(x_applet, y_applet, width, height, isFirefoxOnMac)
{
  var rect = { x: 0, y: 0, width: 0, height: 0 };
  var actdynproframe = null;
  var agent = navigator.userAgent.toLowerCase();
  var bIsIE = ((agent.indexOf("msie") != -1) || (agent.indexOf("trident") != -1));
  var bIsFF = (agent.indexOf("firefox") != -1);

  if ( true == ITS_Frameset("IS_ACTIVE") )
    actdynproframe = ITS_Frameset("FRAME");
  if ( actdynproframe == null)
    actdynproframe = window;

  if ( bIsIE )
  {
    // get top modal window coordinates
    rect.x      = actdynproframe.screenLeft;
    rect.y      = actdynproframe.screenTop;
    rect.width  = actdynproframe.document.body.clientWidth;
    rect.height = actdynproframe.document.body.clientHeight;
  }
  else
  {
    if ( !bIsFF )
    {
      // take absolute screen coordinates from applet calculation and substract relative
      // applet coordinates from javacript calculation to get absolute webgui screen coordinates
      var xapp = parseInt( x_applet );
      var yapp = parseInt( y_applet );

      var app = document.applets[0];
      var pos = wgu_getAbsolutePosition( app );

      // set rectangle to the left upper corner of the webgui window.
      rect.x      = xapp - pos.x;
      rect.y      = yapp - pos.y;
      rect.width  = actdynproframe.innerWidth;
      rect.height = actdynproframe.innerHeight;
    }
    else
    {
      // set rectangle to the left upper corner of the webgui window.
      rect.x      = actdynproframe.screen.left + actdynproframe.mozInnerScreenX;
      rect.y      = actdynproframe.screen.top + actdynproframe.mozInnerScreenY;
      rect.width  = actdynproframe.innerWidth;
      rect.height = actdynproframe.innerHeight;
    }
  }

  // coordinates should be inside the screen area, otherwise we get black borders
  if (rect.x < 0 )
    rect.x = 0;
  if (rect.y < 0 )
    rect.y = 0;
  if ((rect.x + rect.width) >  screen.availWidth)
    rect.width = screen.availWidth - rect.x;
  if ((rect.y + rect.height) >  screen.availHeight)
    rect.height = screen.availHeight - rect.y;

  rectstring = rect.x + ":" + rect.y + ":" + rect.width + ":" + rect.height;
  return rectstring;
}

function UpDownGetTopModalWinRect(x_applet, y_applet, width, height)
{
  return UpDownGetTopModalWinRectAll(x_applet, y_applet, width, height, false)
}

function UpDownGetTopModalWinRectMac(x_applet, y_applet, width, height)
{
  return UpDownGetTopModalWinRectAll(x_applet, y_applet, width, height, true)
}


function GetUserAgentString()
{
  return navigator.userAgent;
}


function wguObjUpdown (webgui_updown_appletUrl, webgui_updown_debug, webgui_updown_printwitholdapi)
{
  this.webgui_updown_appletUrl = webgui_updown_appletUrl;
  this.webgui_updown_debug =  (webgui_updown_debug == "") ? false : true;
  this.webgui_updown_printwitholdapi = (webgui_updown_printwitholdapi == "") ? false : true;

  return this;
} // wguObjUpdown()



wguObjUpdown.prototype.webguiDoHardCopy = function ()
{
  var w = window,
      hardcopyid  = "CONTHARDCOPY",
      hardcopydiv,
      myel;
  if (w.webguiIsPopup)
    w = w.parent;
  hardcopydiv = w.document.getElementById(hardcopyid);
  if (null == hardcopydiv)
  {
    // create div
    if (null != document.all)
    {
      myel = w.document.createElement('<div id="' + hardcopyid + '" name="' + hardcopyid + '">');
    }
    else
    {
      myel = w.document.createElement("div");
      myel.setAttribute("id",   hardcopyid);
      myel.setAttribute("name", hardcopyid);
    }
    myel = w.document.body.appendChild(myel);
  }

appletsource='<applet name="HardCopy.class" MAYSCRIPT archive="ws.jar" CODEBASE="' + wgu_global_updown.webgui_updown_appletUrl + '"';
appletsource+='code="HardCopy.class" '+' height=0 width=0>\n';
appletsource+='<param name=cabbase value="">';
appletsource+='<param name=useslibrarycodebase value="' + wgu_global_updown.webgui_updown_appletUrl + '">';
appletsource+='<param name="java_code" value="HardCopy.class">';
appletsource+='<param name="java_codebase" value="' + wgu_global_updown.webgui_updown_appletUrl + '">';
appletsource+='<param name="java_type" value="application/x-java-applet;version=1.3">';
appletsource+='<param name="java_archive" value="ws.jar">';
appletsource+='<param name="classloader_cache" value="false">';
if (wgu_global_updown.webgui_updown_debug)
  appletsource+='<param name=updowndebug value="X">';

if (wgu_global_updown.webgui_updown_printwitholdapi)
  appletsource+='<param name=updownprintwitholdapi value="X">';

appletsource+='</applet>\n';

//setting applet to load withing div tags
w.document.getElementById(hardcopyid).innerHTML=appletsource;
}
