/**************************************
 *
 * SAP Security client framework
 *
 * v1.0 tj/100401
 * v1.1 tj/100924
 * v1.2 tj/101221  handling local anchors
 * v1.3 tj/120920  correction for Chrome, itsp/session_id_path, ...
 *
 **************************************/

if ("undefined" == typeof oSAPSecu)
{
  oSAPSecu = {

    // CONSTANTS //////////////////////

    CONST : {
      TOKEN_SESS_ID        : "SEC_SESSTOKEN",   //                  <- server
      TOKEN_SESS_INPUT_ID  : "~SEC_SESSTOKEN",  // input field name -> server (ITS)
//    TOKEN_SESS_INPUT_ID  : "SESSION_TOKEN",   // input field name -> server (BSP)
      LINK_SET_ATTRIB      : "TOKSET",

      ERR : {
        OK                          : [    0, "OK"],
        OBJECT_NOT_VALID            : [    9, "SAP Security Object not valid"],
        INIT_FAILED                 : [   10, "SAP Security initialization failed"],
        TOKEN_SESS_UNDEFINED        : [ 1000, "Session Token undefined"],
        TOKEN_SESS_CREATION_FAILED  : [ 1005, "Session Token creation failed"],
        ERR_WRONG_PUSH_CALL         : [50010, "Wrong error call"]
      },  // CONST.ERR
      TEXTS : {
        ERR_ALERT_PREFIX     : "ERROR Status: ",
        ERR_ALERT_LIST_EMPTY : "No errors occured"
      } // CONST.TEXTS
    },  // CONST


    // GET URL TAG LIST ///////////////

    // to be modified by each framework to meet their requirements

    // insert token as GET parameter into the following tags/attributes
    //                tag       attribute  eval path?
    _a_link_list : [ ["a",      "href",    true],
                     ["area",   "href",    true],
                     // ["frame",  "src",     true],
                     // ["iframe", "src",     true],
                     // ["img",    "src",     true]
                     // ["embed",  "src",     true]
                     null
                   ],

    _o_path_eval_lists : {
        // paths with the following pattern are eligable candidates for appending the token to the URL
        include : [ /^(\/(\w+\/)*\w+(?=(\(|\%28))|\.(\/\S*)?|[^\/]+|\?.*)/,  null ],    // <-- THIS EVENTUALLY MUST BE MODIFIED BY THE FRAMEWORK!

        // paths with the following pattern must be ignored
        exclude : [ /^\/\w+(?!(\(|\%28))/,  /sap\/public/,  /^\/$/,  null ]     // <-- THIS EVENTUALLY MUST BE MODIFIED BY THE FRAMEWORK!
    },


    // ATTRIBUTES /////////////////////

    _is_valid       : false,
    _is_initialized : false,

    // Tokens
    _s_token_sess : null,

    // server/session URL
    _s_session_url : { hostname : location.hostname, /* hostserver : location.hostname.match(/^[^\.]* /), hostdomain : location.hostname.match(/\..*$/), */ port : location.port, pathname : decodeURIComponent(location.pathname) },

    // Error handling
    _a_err_list          : [],
    _is_err_alert_active : false,

    // development support
    _is_debugmode_active : false,


    // PRIVATE METHODS ////////////////

    _initialize : function ()
    {
      var rc = false;

      if (this._set_session_token())
      {
        this._is_valid = true;
        this._create_session_token_reqfield();
        this._modify_link_tags();        // try it. It may fail if this script was included before any <form>
      }

      // register onload event handler to continue initialization
      var initOnload = function(in_obj){return function(){in_obj._initialize_onload();}};
      if ("undefined" == typeof document.attachEvent)
      {
        window.addEventListener("load", initOnload(this), true);
      }
      else
      {
        window.attachEvent("onload", initOnload(this));
      }

      this._is_initialized = true;

      rc = true;
      this._is_valid = rc;

      return rc;
    },  // initialize()

    _initialize_onload : function ()
    {
      var rc   = false;

      if (this._set_session_token())
      {
        this._is_valid = true;
        rc = this._create_session_token_reqfield();
        rc = this._modify_link_tags() && rc;
        if (!rc)
        {
          this._error(this.CONST.ERR.TOKEN_SESS_CREATION_FAILED);
          rc = false;
        }
      }
      else
      {
        this._error(this.CONST.ERR.TOKEN_SESS_UNDEFINED);
      }

      this._is_valid = rc;

      return rc;
    },  // _initialize_onload()

    _set_session_token : function ()
    {
      var rc = false,
          sName = this.CONST.TOKEN_SESS_ID,
          i,
          sToken = null;

      if (null == this._s_token_sess)
      {
        // was the token transported as a Javascript variable?
        if ("string" == eval("typeof self."+sName))
        {
          sToken = eval("self."+sName);
          rc = true;
        }

        if (null == sToken)
        {
          if (null != (i = document.getElementById(sName))
              || (null != (i = document.getElementsByTagName(sName))
                  && 0 < i.length && null != (i = i[0])
                  )
              )
          {
            sToken = i.getAttribute("value");
            rc = true;
          }
          else
          {
            this._error(this.CONST.ERR.TOKEN_SESS_UNDEFINED);
          }
        }

        if (rc) this._s_token_sess = sToken;
      }
      else
        rc = true;

      return rc;
    },  // _set_session_token()


    _get_session_token : function ()
    {
      rv = null;
      if (this._is_valid && !!this._s_token_sess)
        rv = this._s_token_sess;

      return rv;
    },  // _get_session_token()


    _create_session_token_reqfield : function ( in_bo_setAllLinks )
    {
      var rc = false,
          oform = document.getElementsByTagName("form"),
          i, l, a, r,
          bo = !!in_bo_setAllLinks;

      if (this._is_valid)
      {
        if (!!this._s_token_sess)
        {
          for (i = 0, l = oform.length; i < l; i++)
          {
            if (bo || "1" != oform[i].getAttribute(this.CONST.LINK_SET_ATTRIB))
            {
              if (this._create_hiddeninput_field(oform[i], this.CONST.TOKEN_SESS_INPUT_ID, this._s_token_sess))
                rc = true;
              oform[i].setAttribute(this.CONST.LINK_SET_ATTRIB, "1");

              /* /tj/110202/ delete parameter in action (we have set it in an input field) */
              if (!(a = oform[i].getAttribute("action")))
              {
                a = document.location.href;
              }
              if (!!a && 0 < a.indexOf(this.CONST.TOKEN_SESS_INPUT_ID))
              {
                r = new RegExp(this.CONST.TOKEN_SESS_INPUT_ID + "=[^&#]*", "gi");
                a = a.replace(r, "");
                oform[i].setAttribute("action", a);
              }
            }
            else
              rc = true;
          }
        }
        else
        {
          this._error(this.CONST.ERR.TOKEN_SESS_UNDEFINED);
        }
      }
      else
      {
        this._error(this.CONST.ERR.OBJECT_NOT_VALID);
      }

      return rc;
    },  // _create_session_token_reqfield()

    _create_hiddeninput_field : function ( in_form, in_name, in_value )
    {
      var rc = false,
          s, newel = null,
          i, l, inpflds;

      if (null != in_form && null != in_name)
      {
        if (null == in_value)
          in_value = "";

        for (i = 0, inpflds = in_form.getElementsByTagName("input"), l = inpflds.length; i < l; i++)
        {
          if (inpflds[i].getAttribute("name") == in_name)
          {
            newel = inpflds[i];
            break;
          }
        }

        if (null == newel)      // input field does not exist yet
        {
          // <input
          owguDOM.HTMLCreateElement("input", {"name":in_name, "type":"hidden", "value":in_value}, self.document, 3, in_form);
        }
        else
        {
          newel.setAttribute("value", in_value);
        }
        rc = true;
      }

      return rc;
    },  // _create_hiddeninput_field()


    _is_eligible_url : function ( in_url )
    {
      var rc = false,
          aLocation, sHost, sPort, sPathname, sPath, sProt, sParam, sAnchor,
          aip, p, i, boCont;

      if ("string" == typeof in_url)
      {

        in_url = decodeURIComponent(in_url);  // Firefox needs some tweaking

        // get host, port and pathname from in_url

        //                           passwd                             @    protocol ://      nnn.mmm.iii.jjj      server     : port    /  path  ?  params anchor
        aLocation = in_url.match(/^(([a-zA-Z0-9-_\.!~\*'\(\)%;&=\+\$,]*)@)?((([^:\.]+):\/\/)?((\d+\.\d+\.\d+\.\d+)|([^:/]*))?(:(\d+))?)?((\/?[^?#]*)\??([^#]*)(#\S*)?)?$/);
        //                         1 2                                   | 3 4 5           | 6 7                   8       | 9 10     | 11 12          13     14
        if (null != aLocation)
        {
          sProt     = aLocation[ 5] || "";
          sHost     = aLocation[ 7] || (aLocation[8] || "");
          sPort     = aLocation[10] || "";
          sPath     = aLocation[11] || "";
          sPathname = aLocation[12] || "";
          sParam    = aLocation[13] || "";
          sAnchor   = aLocation[14] || "";
        }

        // compare url parts with our host etc.

        if (!!sHost)  // host name provided - absolute URL
        {
          if (!sProt)
          {
            rc = false;
          }
          else if (sHost == this._s_session_url.hostname)
          {
            if ((!sPort && "80" == this._s_session_url.port) || sPort == this._s_session_url.port)  // port parity
            {
              rc = true;
            }
          }
        }
        else if (!!sPathname)  // relative URL
        {
          if ("javascript:" != sPathname.substr(0, 11).toLowerCase())
            rc = true;
        }

        // now check for pathname
        if (true == rc && !!sPath)
        {
          // first, check for the link pointing to a *local* anker (same path, no parameters -> no REQ)
          if (!!sAnchor && !sParam && (!sPathname || sPathname == this._s_session_url.pathname))
          {
            rc = false;
          }
          // then, it could be a mailto: URL
          else if (0 === in_url.search(/^mailto\:/))
          {
            rc = false;
          }
          else if (null != (aip = this._o_path_eval_lists.include))

          // here the pathnames should be compared
          //   NOTE: take into account the differences from current path to generated paths in a tags!

          {
            // let us check the path for an "include pattern", if existant (!)
            for (i=0, aip = this._o_path_eval_lists.include; null != aip[i]; i++)
            {
              if (0 > sPath.search(aip[i]))
              {
                rc = false;
              }
              else
              {
                rc = true;
                break;
              }
            }
          }
          else if (null != (aip = this._o_path_eval_lists.exclude))
          {
            // else (!), we check for pure mime paths ("exclude pattern") that we must not touch
            for (i = 0, aip = this._o_path_eval_lists.exclude; null != aip[i]; i++)
            {
              if (0 <= sPath.search(aip[i]))
              {
                rc = false;
                break;
              }
            }
          }
        }
        else if (!sHost && !sPathname)
        {
          rc = true;
        }
      }

      return rc;
    },  // _is_eligible_url()

    _modify_link_tags : function ( in_bo_setAllLinks )
    {
      var rc = false,
          all, ailu, attr,
          otag, el, r, s, aLocation,
          i, j, k, l,
          bo   = !!in_bo_setAllLinks,
          boIE = null != document.all;

      if (this._is_valid)
      {
        if (!!this._s_token_sess)
        {
          for (k=0, all=this._a_link_list; null != (ailu = all[k]); k++)
          {
            otag = document.getElementsByTagName(ailu[0]);
            l = otag ? otag.length : 0;
            if (l > 0 && (bo || "1" != otag[l-1].getAttribute(this.CONST.LINK_SET_ATTRIB)))
            {
              attr = ailu[1];
              for (i = 0, l = otag.length; i < l; i++)
              {
                el = otag[i];
/*              // // get URL out of src | href attribute
                s = ["(", attr, "=\\\"([^\\\"]*)\\\")|(", attr, "='([^']*)')"].join("");
                r = el.outerHTML.match(new RegExp(s));
                if (r && (bo || !!("1" != el.getAttribute(this.CONST.LINK_SET_ATTRIB)))
                      && (s = r[2] || r[3])
                   )
*/
                if (bo || !!("1" != el.getAttribute(this.CONST.LINK_SET_ATTRIB))  // has element already been checked?
                      && null != (s = el.getAttribute(attr, 2))                   // source attribut set?
                      && !("" === s && boIE && s === el.getAttribute(attr))       // IE: anchors look like links with href="", baah!
                   )
                {
                  if (null != (s = this._modify_url(s, true)))
                  {
                    el.setAttribute(attr, s);
                  }
                  el.setAttribute(this.CONST.LINK_SET_ATTRIB, "1");
                }
              }
            }
          }
          rc = true;
        }
        else
        {
          this._error(this.CONST.ERR.TOKEN_SESS_UNDEFINED);
        }
      }
      else
      {
        this._error(this.CONST.ERR.OBJECT_NOT_VALID);
      }

      return rc;
    },  // _modify_link_tags()

    _modify_url : function ( in_url, in_boReturnNullIfUnmodified )
    {
      var rv = null,
          s, aLocation;

      if (!!this._s_token_sess)
      {
        if (null != in_url && this._is_eligible_url(in_url))
        {
          aLocation = in_url.match(/^((([a-zA-Z]+)\:\/\/)?(([^:\/#?]+)?:?(\d+)?)?(\/[^#?]*)?\??([^#]*)?)?(#?.+)?$/);
          // [0] complete URL, [1] URL excluding anchor, [3] Protocol, [5] Server, [6] Port, [7] Path, [8] Parameter, [9] Anchor
          if (null != aLocation)
          {
            if (!!aLocation[8]) rv = [aLocation[1], "&", this.CONST.TOKEN_SESS_INPUT_ID, "=", this._s_token_sess, aLocation[9]].join("");
            else                rv = [aLocation[1], "?", this.CONST.TOKEN_SESS_INPUT_ID, "=", this._s_token_sess, aLocation[9]].join("");
          }
          else
          {
            rv = [in_url, "?", this.CONST.TOKEN_SESS_INPUT_ID, "=", this._s_token_sess].join("");
          }
        }
      }
      else
      {
        this._error(this.CONST.ERR.TOKEN_SESS_UNDEFINED);
      }

      if (!in_boReturnNullIfUnmodified && null == rv)
        rv = in_url;

      return rv;
    },  // _modify_link_tags()


    // Error handling and messaging

    _error : function ( in_error )
    {
      this._err_push_new_error(in_error);
      this._err_alert_last_error();
    },  // _error()

    _err_get_error_text : function ( in_error )
    {
      var rv = null;
      if (null != in_error)
      {
        if ("object" == typeof in_error)
          rv = in_error[1];
        else
          rv = in_error.toString();
      }
      return rv;
    },  // _err_get_error_text()

    _err_push_new_error : function ( in_error )
    {
      if (null != in_error)
      {
        this._a_err_list.push(in_error);
      }
      else
      {
        this._err_push_new_error(this.CONST.ERR_WRONG_PUSH_CALL);
      }
    },  // _err_push_new_error()

    _err_alert : function ( in_s_err_text )
    {
      if (this._is_err_alert_active || true == this._is_debugmode_active)
      {
        alert(in_s_err_text);
      }
    },  // _err_alert()

    _err_alert_last_error : function ()
    {
      var i, err;
      if (0 < (i = this._a_err_list.length))
      {
        err = this._a_err_list[i-1];
        this._err_alert(this.CONST.TEXTS.ERR_ALERT_PREFIX + this._err_get_error_text(err));
      }
      else
      {
        this._err_alert(this.CONST.TEXTS.ERR_ALERT_PREFIX + this._err_get_error_text(this.CONST.TEXTS.ERR_ALERT_LIST_EMPTY));
      }
    },  // _err_alert_last_error()

    _err_alert_errors : function ( in_max_count, in_force )
    {
      var i, l, s = this.CONST.TEXTS.ERR_ALERT_PREFIX,
          dm = this._is_debugmode_active;

      if (!!in_force)
        this._is_debugmode_active = true;

      if (0 < (l = this._a_err_list.length))
      {
        if (null == in_max_count || 100 < in_max_count) in_max_count = 100; // list only the last 100 errors
        if (l > in_max_count) l = in_max_count;
        for (i = l; i > 0; )
        {
          s = [s, "\n", i--, ": ", this._err_get_error_text(this._a_err_list[i])].join("");
        }
        this._err_alert(s);
      }
      else
      {
        this._err_alert(this.CONST.TEXTS.ERR_ALERT_PREFIX + this.CONST.TEXTS.ERR_ALERT_LIST_EMPTY);
      }

      this._is_debugmode_active = dm;
    },  // _err_alert_last_error()


    _initializeFormsDelayed : function ( in_delay, in_inseries )
    {
      var bo_firstcall = in_inseries !== true,
          delay        = (null != in_delay ? in_delay : 1),
          tk, i, l, arel, bo;

      if (bo_firstcall)
      {
        if (null != this._initializeFormsDelayed_timer)
          clearTimeout(this._initializeFormsDelayed_timer);
        this._initializeFormsDelayed_timer = setTimeout(["oSAPSecu._initializeFormsDelayed(", delay, ", true)"].join(""), delay);
      }
      else
      {
        clearTimeout(this._initializeFormsDelayed_timer);
        this._initializeFormsDelayed_timer = null;
        if (this._is_valid)
        {
          tk = this._s_token_sess;
          for (arel=document.getElementsByName("~sec_sesstoken"), i= 0, l=arel.length, bo=false; i < l; i++)
          {
            if (arel[i].getAttribute("value") != tk)
            {
              bo = true;
              break;
            }
          }
          if (bo)
            this._create_session_token_reqfield(true);
          else
            this._initializeFormsDelayed(50, false);
        }
      }
    },  // _initializeFormsDelayed()

    _initializeFormsDelayed_timer : null,

    // END OF OBJECT //////////////////

    nul : null

  };  // Object oSAPSecu



  // DOM methods ////////////////////

  if ("undefined" === typeof owguDOM)
  {
    owguDOM = {
      // Attributes
      CONST : { EnumAction : { "DONT":0, "REPLACE":1, "INSERT":2, "APPEND":3 } },
      boUseInjection : false,     // use injection (innerHTML) for creating elements
      iCreateMethod  : false,     // 1 for old IE style {foo = document.createElement("<div id=\"id\" ...>")}

      // Methods

      SetCreateMethod : function ( in_boUseInnerHTML )
      {
        this.boUseInjection = !!in_boUseInnerHTML;
        return this;
      } // owguDOM.SetCreateMethod()
      ,

      /* HTMLCreateElement
         Arguments:
            in_element        : HTML element to be created, e. g. "div" or "form"
            in_aAttributes    : optional; array of name-value objects { "name-of-attribute" : "value-of-attribute" }
            in_document       : optional (default self.document); document used to create element
            in_action         : optional (default 3);  { see CONST.EnumAction }
            in_parentElement  : optional; if in_action, then parentNode that in_element is attached to
       */
      HTMLCreateElement : function ( in_element, in_aAttributes, in_document, in_action, in_parentElement, in_out_string )
      {
        var rv = null,
            ty, el, s, str, i, l, e, o;

        if (null != in_element)
        {
          if (null === (o = in_aAttributes)) ty = 0;
          else
          {
            switch (typeof o)
            {
              case "object"    :
                ty = o instanceof Array ? 8 : (o instanceof Error ? 10 : (o instanceof RegExp ? 4 : (o instanceof Date ? 5 : 9)));
                break;
              case "string"    : ty = 3; break;
              default          : ty = 0; break;    // not allowed
            }
          }

          if ((this.boUseInjection && null != in_parentElement) || null != in_out_string)
          {
            s = "<" + in_element;
            if (9 === ty)   // arr
            {
              for (e in o)
              {
                s = [s, " ", e, "=\"", o[e], "\" "].join("");
              }
            }
            else if (3 === ty)    // str
            {
              s = [s, " ", o].join("");
            }
            s = s + ">";

            if (null != in_out_string)
            {
              in_out_string = s;
            }

            if (null != in_parentElement)
            {
              switch (in_action)
              {
                case 3 : // this.CONST.EnumAction["APPEND"] :
                  in_parentElement.innerHTML = [in_parentElement.innerHTML, s].join("");
                  rv = in_parentElement.lastChild;
                  break;
                case 1 : // this.CONST.EnumAction["REPLACE"] :
                  in_parentElement.innerHTML = s;
                  break;
                case 2 : // this.CONST.EnumAction["INSERT"] :
                  in_parentElement.innerHTML = [s, in_parentElement.innerHTML].join("");
                  rv = in_parentElement.firstChild;
                  break;
                default :
                  break;
              }
            }
          }
          else
          {
            if (1 == this._DetermineCreateMethod())
            {
              s = "<"+in_element;
              if (9 === ty)   // ob
              {
                for (e in o)
                {
                  s = [s, " ", e, "=\"", o[e], "\""].join("");
                }
              }
              else if (3 === ty)    // str
              {
                s = [s, " ", o].join("");
              }
              s = s + ">";
              try
              {
                el = (null != in_document ? in_document : self.document).createElement(s);
              }
              catch (ex) {}
            }
            else
            {
              if (null != (el = (null != in_document ? in_document : self.document).createElement(in_element)))
              {
                if (9 === ty)   // obj
                {
                  for (e in o) el.setAttribute(e, o[e])
                }
                else if (8 === ty)    // arr
                {
                  for (i = 0, l = in_aAttributes.length; i < l; i++)
                  {
                    for (e in (o = in_aAttributes[i]))
                    {
                      el.setAttribute(e, o[e]);
                    }
                  }
                }
              }
            } // if this._DetermineCreateMethod()

            if (null != el)
            {
              if (null != in_parentElement)
              {
                try
                {
                  switch (in_action)
                  {
                    case 3 : // this.CONST.EnumAction["APPEND"] :
                      el = in_parentElement.appendChild(el);
                      break;
                    case 1 : // this.CONST.EnumAction["REPLACE"] :
                      in_parentElement.innerHTML = el.outerHTML;
                      break;
                    case 2 : // this.CONST.EnumAction["INSERT"] :
                      if (in_parentElement.hasChildNodes)
                      {
                        el = in_parentElement.insertBefore(el, in_parentElement.firstChild);
                        break;
                      }
                    default :
                      break;
                  }

                rv = el;
                }
                catch (ex)
                {
                }
              }
              else
              {
                rv = el;
              }
            }
          } // if (useInjection) else
        } // if (in_element)

        return rv;
      } // owguDOM.HTMLCreateElement()
      ,

        _DetermineCreateMethod : function ()
        {
          var rv = 2; // default W3C way

          if (!this.iCreateMethod)
          {
            try
            {
              document.createElement("<div id=\"__MYTESTDIV__\">");
              rv = this.iCreateMethod = 1;
            }
            catch (ex)
            {
              rv = this.iCreateMethod = 2;
            }
          }
          this._DetermineCreateMethod = function(){return this.iCreateMethod;}

          return rv;

        } // owguDOM._DetermineCreateMethod()
        ,

        Initialize : function ()
        {
        } // owguDOM.Initialize()

      };  // owguDOM

  } // if (owguDOM is undefined)




  // PUBLIC METHODS /////////////////

  // Methods without parameters
  oSAPSecu.Initialize             = oSAPSecu._initialize;
  oSAPSecu.GetSessionToken        = oSAPSecu._get_session_token;
  oSAPSecu.InitializeNewForms     = oSAPSecu._create_session_token_reqfield;
  oSAPSecu.InitializeForms        = function () { oSAPSecu._create_session_token_reqfield(true); };
  oSAPSecu.InitializeNewLinks     = oSAPSecu._modify_link_tags;
  oSAPSecu.InitializeLinks        = function () { oSAPSecu._modify_link_tags(true); };
  oSAPSecu.ErrorAlert             = oSAPSecu._err_alert_errors;
  oSAPSecu.URLAppendToken         = oSAPSecu._modify_url;

  // Methods with one parameter

  // Usage: oSAPSecu.InitializeFormsDelayed()  or  oSAPSecu.InitializeFormsDelayed(delay)
  //        with delay providing the number of milliseconds until execution
  oSAPSecu.InitializeFormsDelayed = function ( in_delay ) { oSAPSecu._initializeFormsDelayed(in_delay); };


  if (!oSAPSecu.Initialize())
  {
    oSAPSecu.ErrorAlert(100, false);

    if ("undefined" == typeof document.attachEvent)
    {
      window.addEventListener("unload", function(){oSAPSecu.Initialize = oSAPSecu._initialize = null; oSAPSecu = null;}, false);
    }
    else
    {
      window.attachEvent("onunload", function(){oSAPSecu.Initialize = oSAPSecu._initialize = null; oSAPSecu = null;});
    }

  }
}
