
/* he.pi 20050124 this file doesn't seem to be included anywhere.
   the functions in this file also exist inside of (d_)control.js,
   so I will disable the functions inside this file

// ==========================================================
// Utilitities
// ==========================================================

function isIE5()
{
	if (navigator.appVersion.indexOf("MSIE 5.0") != -1)
		return true;
	
	return false;
}

// ----------------------------------------------------------

function isIE4()
{
	if (navigator.appVersion.indexOf("MSIE 4.0") != -1)
		return true;
	
	return false;
}


// ==========================================================
// Workarounds for browser bugs
// ==========================================================

function controlFixAlignHorizontal(element)
{
	if (isIE4() || isIE5())
	{
		if (element.style.overflow == "scroll")
			element.style.pixelWidth += controlGetScrollbarWidth();
		else if (element.style.overflow == "auto")
		{
			if (element.scrollWidth <= element.offsetWidth)
				element.style.pixelWidth = 
					element.offsetWidth + controlGetScrollbarWidth();
		}
	}

}

// ----------------------------------------------------------

function controlGetScrollbarWidth()
{
	if (isIE4())
		return 18;
	else if (isIE5())
		return 11;
	else
		return 0;
}


// ==========================================================
// Here Controls can add one eventhandler which will be exceted
// at onload (after sizing operations by docking/splitter) 
// ==========================================================

var CFWonFinalSizeHandlers = new Array(120); // currently size is limited to 120 entries; 
var CFWonFinalSizeHandlersCnt = 0; 

function CFWAddonFinalSizeHandler(jsfnname)
{	if ( CFWonFinalSizeHandlersCnt >= 120 ) 
	{  alert("Skipping OnFinalSizeHandlers:"+ jsffnname + "() skipped; Size(120) exceeded!"); 
	   return -1; 
	}
	CFWonFinalSizeHandlers[CFWonFinalSizeHandlersCnt] = jsfnname; 
	++CFWonFinalSizeHandlersCnt;  
	return 0; 
}

// ----------------------------------------------------------

// CallOnFinalSizeHandler
function CFWExeconFinalSizeHandlers()
{
  for ( var i = 0; i < CFWonFinalSizeHandlersCnt; ++i ) 
  {	 var str = 	CFWonFinalSizeHandlers[i]+"()"; 		    
	 eval(str); 
  }

  if (CFWonFinalSizeHandlersCnt > 0)
    webguiRedrawOnIE4(webguiUserArea);
}

// ----------------------------------------------------------

function controlOnLoad()
{
    var
        redraw = false;
        
    if (window.dockOnLoad)
    {
        dockOnLoad() ;
        redraw = true;
    }
	
    controlUpdateAlignment() ;
	
    if (window.splitterOnLoad)
    {
        splitterOnLoad();
        redraw = true;
    }

    if (redraw)
        webguiRedrawOnIE4(webguiUserArea);
}

// ----------------------------------------------------------

function controlDoResize(in_event, immediate)
{
    if (!window.dockDoResize && !window.splitterDoResize)
        return;

    if (window.dockDoResize)
        dockDoResize() ;

    if (window.splitterDoResize)
        splitterDoResize() ;

    webguiRedrawOnIE4(webguiUserArea);
}


// ==========================================================
// Docking 
// ==========================================================


// ==========================================================
// Alignment
// ==========================================================

function controlSetAlignment(element, halign, valign)
{
	if (element && element.style && (halign || valign))
	{
		if (!window.alignments)
			window.alignments = new Array();
		
		window.alignments[window.alignments.length] = element;
	
		element.style.userHAlign = halign;
		element.style.userVAlign = valign;
	}
}

// ----------------------------------------------------------

function controlUpdateAlignment()
{
	if (window.alignments)
	{
		for (var i = 0; i < window.alignments.length; i++)
		{
			controlAlignHorizontal(window.alignments[i], window.alignments[i].style.userHAlign);
			controlAlignVertical(window.alignments[i], window.alignments[i].style.userVAlign);
		}
	}
}

// ----------------------------------------------------------

function controlAlignHorizontal(element, align)
{
	if (element && align && align == "right")
	{
		element.style.pixelWidth = 
			element.parentElement.offsetWidth - element.offsetLeft - 
			(element.parentElement.offsetWidth - element.parentElement.clientWidth);
		controlFixAlignHorizontal(element)

		element.style.userHAlign = "right";
	}
}

// ----------------------------------------------------------

function controlAlignVertical(element, align)
{
	if (element && align && align == "bottom")
	{
		element.style.pixelHeight = element.parentElement.offsetHeight - element.offsetTop -
			(element.parentElement.offsetHeight - element.parentElement.clientHeight);
		element.style.userVAlign = "bottom";
	}
}

// ----------------------------------------------------------

function controlUpdateVerticalAlignment(element)
{
	if (element.children)
	{
		for (var i = 0; i < element.children.length; i++)
		{
			if (element.children[i])
			{
				if (element.children[i].style.userVAlign == "bottom")
				{
					controlAlignVertical(element.children[i], "bottom");
				}
			}
		}
	}
}

// ----------------------------------------------------------

function controlUpdateHorizontalAlignment(element)
{
	if (element.children)
	{
		for (var i = 0; i < element.children.length; i++)
		{
			if (element.children[i])
			{
				if (element.children[i].style.userHAlign == "right")
				{
					controlAlignHorizontal(element.children[i], "right");
				}
			}
		}
	}
}

// ----------------------------------------------------------

function controlUpdateOverflow(pane)
{
	if (pane)
	{
		for (var i = 0; i < pane.children.length; i++)
		{
			var
				child = pane.children[i];

			if (child && child.tagName == "DIV")
			{
				var
					overflow,
                    			width,
					height;
					
				if (child.style.controloverflow)
					overflow = child.style.controloverflow;
				else
					overflow = child.style.overflow;
				
				// Save original dimensions
	                	if (!child.controlPixelWidth)
				{
                	    		child.controlPixelWidth = child.offsetWidth;
                		}
				if (!child.controlPixelHeight)
	                	{
					child.controlPixelHeight = child.offsetHeight;
                		}
                
				if (child.offsetLeft + child.controlPixelWidth > pane.offsetWidth)
				{
					if (overflow == "auto" || overflow == "fixed")
					{
						if (!webguiDockLocalResize)
							child.style.pixelWidth = pane.offsetWidth - child.offsetLeft;
					}
					else
						pane.style.overflow = "auto"
				}

				if (child.offsetTop + child.controlPixelHeight > pane.offsetHeight)
				{
					if (overflow == "auto" || overflow == "fixed")
					{
						if (!webguiDockLocalResize)
							child.style.pixelHeight = pane.offsetHeight - child.offsetTop;
					}
					else
						pane.style.overflow = "auto"
				}
			}
		}
	}
}


he.pi 20050124 */