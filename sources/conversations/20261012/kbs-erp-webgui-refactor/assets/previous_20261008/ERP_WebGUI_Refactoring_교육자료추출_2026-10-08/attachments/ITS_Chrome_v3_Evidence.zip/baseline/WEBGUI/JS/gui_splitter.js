////////////////////////////////////////////////////////////////////////////////
//
// SAP GUI for HTML Splitter Control
//
// Interface:
//    Variable:       window.gwguSplitters      - object of all splitter controls
//
//    Functions:      wguSplitterInitialize()
//                    splitterUpdateAll()       - compatibility
//
// Version 2.2
//   completely revised 060602; also controlling Docking control
//   061116  tj  DOCK_ROOM
//   070202  tj  Infinity
//   071025  tj  fixed size cells
//   080722  tj  move sash outside boundary fix
//   110331  tj  persistent splitter cell resize only on user action
//
////////////////////////////////////////////////////////////////////////////////






/*********************************************************************
 * SAP GUI for HTML / Splitter Interface
 */

function wguSplitterInitialize ()
{
  window.gwguSplitters =
  window.splitters     =  new wguObjSplitterControls();
    // window.splitters for compatibility
}

// compatibility functions
//

function splitterDoResize ( in_immediate )
{
  splitterUpdateAll( in_immediate );
} // splitterDoResize()


function splitterUpdateAll ( in_immediate )
{
  if (typeof window.gwguSplitters != "undefined")
  {
    if (true == in_immediate)
    {
      _splitterUpdateAllHelper();
    }
    else
    {
      var t = window.gwguSplitters._timeout;
      window.gwguSplitters._timeout = null;
      // first we stop waiting updates
      if (null != t)
      {
        window.clearTimeout(t);
      }
      // now, we issue another (real) update
      window.gwguSplitters._timeout = window.setTimeout("_splitterUpdateAllHelper()", 125);
    }
  }
} // splitterUpdateAll()


function _splitterUpdateAllHelper ()
{
  if (typeof window.gwguSplitters != "undefined")
  {
    var dock, el;
    window.gwguSplitters._timeout = null;
    if (null != (dock = window.gwguSplitters._firstDock))
    {
      if (null != (el = document.getElementById("webguiContainer")))
      {
        dock.SetWidth(el.offsetWidth);
        dock.SetHeight(el.offsetHeight);
      }
    }
    window.gwguSplitters.Update();

    // window.setTimeout("window.gwguSplitters.Debug()", 250);
  }
} // _splitterUpdateAllHelper()





////////////////////////////////////////////////////////////////////////////////
//
// SAP GUI for HTML Splitter Control object
//
// Interface:
//    Constructors:   wguObjSplitterControls
//                    wguObjSplitter
//                    wguObjSplitterPane
//                    wguObjSplitterSash
//    Functions:      xxx()
//                    ()
//                    ()
//
////////////////////////////////////////////////////////////////////////////////



var
  SPLITTER_CHILD_PREFIX     = "Chld",
  SPLITTER_SASH_SUFFIX      = "Sash",
  SPLITTER_SASH_ROW_SUFFIX  = "SashRow",
  SPLITTER_SASH_COL_SUFFIX  = "SashCol",
  SPLITTER_SASH_RESIZED_DIM = "-ResizedDim";
  SPLITTER_SASH_RESIZED_ABSDIM = "-ResizedAbsDim";

var
  SPLITTER_SASH_SIZE     = 6,       // height of horizontal, width of vertical sash in pixel
  SPLITTER_SASH_HALFSIZE = SPLITTER_SASH_SIZE / 2,
  SPLITTER_THRESHOLD     = 5;       // distance to move sash without effect

var
  DOCK_ROOM              = 18;      // minimum distance between two docking control sashes

var
  SPLITTER_DIR_HORZ      = "h",
  SPLITTER_DIR_VERT      = "v",
  SPLITTER_MODE_ABS      = "a",
  SPLITTER_MODE_REL      = "r";

var
  SPLITTER_TYPE_SPLITTERS = "0",
  SPLITTER_TYPE_SPLITTER  = "1",
  SPLITTER_TYPE_DOCKING   = "2",
  SPLITTER_TYPE_PANE      = "10",
  SPLITTER_TYPE_SASH      = "20";






/*******************************************************************@@
 * Splitter Controls Object
 * Central manager of all Splitter Controls
 *
 ********************************************************************/




wguObjSplitterControls = function ()
{
  // Array of all splitters
  this._type      = SPLITTER_TYPE_SPLITTERS;
  this._aSplitter = new Array();
  this._count     = 0;
  this._timeout   = null;

  // for docking controls (manage sash moving limits)
  this._firstDock   = null;
  this._countDockV  = 0;
  this._countDockH  = 0;
  this._aDocksV     = null;
  this._aDocksH     = null;

  this._boInitialResize = true;

  return this;
};  // Constructor wguObjSplitterControls()


wguObjSplitterControls.prototype.Debug = function ()
{
  var i, j, l, m,
      sp, spel, p, pel,
      str = "";

  for (i = 0, l = this._count; i < l; i++)
  {
    sp   = this._aSplitter[i];
    spel = sp._htmlObj;
    str += (sp.IsDockingControl())
        ?  ("Docker (" + sp._dock + ")")
        : "Splitter";
    str += " " + sp._id + ": "
        +  "( x" + spel.offsetLeft + ", y" + spel.offsetTop
        +  ", w" + spel.offsetWidth + ", h" + spel.offsetHeight
        +  " )    \n";
    for (j = 0, m = sp._rows*sp._cols; j < m; j++)
    {
      p   = sp._aPanes[j];
      pel = p._htmlObj;
      str += "  " + j + ": "
          +  "( x" + pel.offsetLeft + ", y" + pel.offsetTop
          +  ", w" + pel.offsetWidth + ", h" + pel.offsetHeight
          +  " )    \n";
    } // for (splitter.panes)

    str += "--------------------\n";
  } // for (splitter)

  alert(str);

  return this;

};  // wguObjSplitterControls.Debug()


wguObjSplitterControls.prototype.Add = function ( in_splitterId, in_rows, in_cols )
{
  if (in_splitterId != null && in_rows && in_cols)
  {
    var n  = this._count,
        el = new wguObjSplitter(in_splitterId, in_rows, in_cols);

    if (el && el.IsValid())
    {
      this._aSplitter[n] = el;
      this._count++;

      /* Docking control special
       */
      if (el.IsDockingControl())
      {
        if (this._countDockV == 0 && this._countDockH == 0)
          this._firstDock = el;
        if (in_rows == 1)   // one row, two columns -> vertical docking control
        {
          this._countDockV++;
        }
        else               // two rows, one column -> horizontal docking control
        {
          this._countDockH++;
        }
      }
    }
  }
  return this;
};  // wguObjSplitterControl.Add()


wguObjSplitterControls.prototype.Get = function ( in_splitterId )
{
  var rc = null;

  if (in_splitterId != null)
  {
    if (null == (rc = window[in_splitterId + "_this"]))
    {
      var i,
          l   = this._count,
          arr = this._aSplitter;

      for (i = 0; i < l; i++)
      {
        if (in_splitterId == arr[i].GetId())
        {
          rc = arr[i];
          break;
        }
      }
    }
  }
  return rc;
};  // wguObjSplitterControl.Get()


wguObjSplitterControls.prototype.Update = function ()
{
  var i, l, lvl, vlo, vhi, hlo, hhi, sp, spr;

//  for (i = this._count - 1; i >= 0; --i)
  for (i = 0, l = this._count; i < l; i++)
  {
    this._aSplitter[i].Update(this._boInitialResize);
  }

  // CFWExeconFinalSizeHandlers() called in splitter.Update()->splitter.Resize()->splitter.UpdatePanes()


  /* Docking control sash moving limits
   */

  if (this._aDocksV == null && this._aDocksH == null && (this._countDockV > 0 || this._countDockH > 0))
  {
    if (this._countDockV > 0) this._aDocksV = new Array();
    if (this._countDockH > 0) this._aDocksH = new Array();

    vlo = hlo = lvl = 0;    // indeces
    vhi = this._countDockV;
    hhi = this._countDockH;
    for (i = 0, l = this._count; i < l; i++)
    {
      if (null != (sp = this._aSplitter[i]) && sp.IsDockingControl())
      {
        switch (sp._dock)
        {
          case "l" : this._aDocksV[vlo++] = sp; break;
          case "r" : this._aDocksV[--vhi] = sp; break;
          case "t" : this._aDocksH[hlo++] = sp; break;
          case "b" : this._aDocksH[--hhi] = sp; break;
        }
        sp.SetDockLevel(lvl++);
      }
    } // for (i)
    for (i = 0, l = this._countDockV; i < l; i++)
    {
      sp  = ((i > 0)   ? this._aDocksV[i-1] : null);
      spr = ((i < l-1) ? this._aDocksV[i+1] : null);
      this._aDocksV[i].InitDockingData(sp, spr);
    }
    for (i = 0, l = this._countDockH; i < l; i++)
    {
      sp  = ((i > 0)   ? this._aDocksH[i-1] : null);
      spr = ((i < l-1) ? this._aDocksH[i+1] : null);
      this._aDocksH[i].InitDockingData(sp, spr);
    }

  } // if (exist docker)

  this._boInitialResize = false;

  return this;

};  // wguObjSplitterControl._Update()





/*******************************************************************@@
 * Splitter Control Object
 * Manage one particular Splitter Control and its panes
 *
 ********************************************************************/




wguObjSplitter = function ( in_splitterId, in_rows, in_cols )
{
  var rc = null,
      el;

  if (in_splitterId != null && in_rows && in_cols)
  {
    if (null != (el = document.getElementById(in_splitterId)))
    {
      var i, j, l, s, p;

      this._id          = in_splitterId;      // the HTML object id
      this._htmlObj     = el;                 // the specific HTML object (<div>)
      this._type        = this._EvalType();   // type SPLITTER
      this._rows        = in_rows;            // number of rows in splitter
      this._cols        = in_cols;            // number of columns
      this._colMode     = (el.getAttribute("columnMode") == "relative") ? "r" : "a";
      this._rowMode     = (el.getAttribute("rowMode") == "relative") ? "r" : "a";

      this._raster      = new wguObjRaster(el, isBidiRTL());

      this._height      = el.clientHeight;    // size in pixel
      this._width       = el.clientWidth;
      this._fixed       = el.getAttribute("FixedSize");   // not yet implemented
      this._fixedh      = "right"  != el.getAttribute("halign") && !el.parentNode.getAttribute("fullscreencnt");
      this._fixedv      = "bottom" != el.getAttribute("valign") && !el.parentNode.getAttribute("fullscreencnt");
      this._noVertSash  = 0;                  // count vertical sashes
      this._noHorzSash  = 0;                  // count horizontal sashes
      this._noDefHeight = 0;                  // count panes with default height (no application provided height)
      this._noDefWidth  = 0;                  // count panes with default width
      this._definedH    = 0;                  // sum of height in pixel of all panes with defined height
      this._definedW    = 0;                  // sum of height in pixel of all panes with defined height

      window[[this._id,"_this"].join("")] = this;
      this._htmlObj.isSplitter = true;

      this._localResize = (this._htmlObj.getAttribute("splitterControlId") == "abap") ? false : window.webguiSplitterLocalResize;

      /* Docking control
       */

      if (this._type == SPLITTER_TYPE_DOCKING)
      {
        this._dock = this._htmlObj.getAttribute("dock");
        switch (this._dock)
        {
          case "left"  : this._dock = "l"; break;
          case "right" : this._dock = "r"; break;
          case "top"   : this._dock = "t"; break;
          case "bottom": this._dock = "b"; break;
        }

//      // special resize handling if docking control on list
//      if (transactionType == "LIST")
          this._localResize = false;
      }

      /* create panes objects
       */
      this._aPanes  = new Array();
      l = in_rows * in_cols;
      for (i = 0; i < l; i++)
      {
        p = new wguObjSplitterPane(this, i);  // i is index and corresponds to HTML id "xxxchldi"
        if (!p || !p.IsValid())
          p = null;
        this._aPanes[i] = p;

        if (p != null)                        // now, count sashes and sum defined dimensions
        {
          if (p.HasDefaultHeight())  this._noDefHeight++;  else  this._definedH += p.GetHeight();
          if (p.HasDefaultWidth())   this._noDefWidth++;   else  this._definedW += p.GetWidth();
        }
      }

      /* create sash objects
       */
      this._aRowSashes = new Array();                 // row sashes
      l = in_rows - 1;
      for (i = 0; i < l; i++)
      {
        p = new wguObjSplitterSash(this, i, "h");
        if (!p || !p.IsValid())  p = null;  else  this._noHorzSash++;
        this._aRowSashes[i] = p;
      }
      this._aColSashes = new Array();                 // col sashes
      l = in_cols - 1;
      for (i = 0; i < l; i++)
      {
        p = new wguObjSplitterSash(this, i, "v");
        if (!p || !p.IsValid())  p = null;  else  this._noVertSash++;
        this._aColSashes[i] = p;
      }

      this._selectedSash = null;                // current selected sash (on touch and move)


      /* Initialize components
       */

      this.UpdatePanes();                       // set positions and sizes of all panes
      this.UpdateSashes();                      // set positions of sashes based on pane positions

      // we want to provide the dimension information any time //tj/070702
      // if (this.IsDockingControl())
      {
        l = in_rows * in_cols;
        for (i = 0; i < l; i++)
          this._aPanes[i].UpdateFormSize(true, true);
      }

      this._boRefresh = false;                  // if set to true the splitter needs to be updated (resized)
      this._inUserAction = false;

      rc = this;
    }
  }

  if (rc == null)
    this._boNotValid = true;                    // for IsValid()

  return rc;
};  // wguObjSplitter() Constructor




/**************************************************************
 *
 * Internal functions of wguObjSplitter
 *
 */


wguObjSplitter.prototype._GetDefaultDim = function ( in_dir )
{
  //!!!

};  // wguObjSplitter._GetDefaultDim()


wguObjSplitter.prototype._EvalType = function ()
{
  var rv = null;
  if (this._htmlObj != null && this._htmlObj.className.substr(0, 4) == "dock")
    rv = SPLITTER_TYPE_DOCKING;
  else
    rv = SPLITTER_TYPE_SPLITTER;
  return rv;
};  // wguObjSplitter._EvalType()



/**************************************************************
 *
 * Set Routines
 *
 */


wguObjSplitter.prototype.SetWidth = function ( in_width )
{
  if (in_width != null)
  {
    this._htmlObj.style.width = in_width + "px";
    this._width = this._htmlObj.offsetWidth;
  }
  return this;
};  // wguObjSplitter.SetWidth()


wguObjSplitter.prototype.SetHeight = function ( in_height )
{
  if (in_height != null)
  {
    this._htmlObj.style.height = in_height + "px";
    this._height = this._htmlObj.offsetHeight;
  }
  return this;
};  // wguObjSplitter.SetHeight()


wguObjSplitter.prototype.SetSelectedSash = function ( in_sashObj )
{
  this._selectedSash = in_sashObj;
  return this;

};  // wguObjSplitter.SetSelectedSash()


wguObjSplitter.prototype.ResetSelectedSash = function ()
{
  this._selectedSash = null;
  return this;
};  // wguObjSplitter.ResetSelectedSash()


wguObjSplitter.prototype.InitDockingData = function ( in_leftDock, in_rightDock )
{
  if (this._rows == 1)
  {
    this._dockLSash = (in_leftDock != null)  ? in_leftDock._aColSashes[0] : null;
    this._dockRSash = (in_rightDock != null) ? in_rightDock._aColSashes[0] : null;
  }
  else
  {
    this._dockLSash = (in_leftDock != null)  ? in_leftDock._aRowSashes[0] : null;
    this._dockRSash = (in_rightDock != null) ? in_rightDock._aRowSashes[0] : null;
  }

  return this;
};  // wguObjSplitter.ResetSelectedSash()


wguObjSplitter.prototype.SetDockLevel = function ( in_level )
{
  this._dockLevel = in_level;
  return this;

};  // wguObjSplitter.SetDockLevel()



/**************************************************************
 *
 * Get Routines
 *
 */


wguObjSplitter.prototype.IsValid = function ()
{
  return (true != this._boNotValid);

};  // wguObjSplitter.IsValid()


wguObjSplitter.prototype.GetType = function ()
{
  return this._type;

};  // wguObjSplitter.GetType()


wguObjSplitter.prototype.IsSplitterControl = function ()
{
  return (this._type == SPLITTER_TYPE_SPLITTER);

};  // wguObjSplitter.IsSplitterControl()


wguObjSplitter.prototype.IsDockingControl = function ()
{
  return (this._type == SPLITTER_TYPE_DOCKING);

};  // wguObjSplitter.IsSplitterControl()


wguObjSplitter.prototype.GetId = function ()
{
  return this._id;
};  // wguObjSplitter.GetId()


wguObjSplitter.prototype.GetHTMLObj = function ()
{
  return this._htmlObj;
};  // wguObjSplitter.GetHTMLObj()


wguObjSplitter.prototype.GetColumnMode = function ()
{
  return this._colMode;         // either "r" or "a" (relative or absolute)

};  // wguObjSplitter.GetColumnMode()


wguObjSplitter.prototype.GetRowMode = function ()
{
  return this._rowMode;         // either "r" or "a" (relative or absolute)

};  // wguObjSplitter.GetRowMode()


wguObjSplitter.prototype.GetRows = function ()
{
  return this._rows;
};  // wguObjSplitter.GetRows()


wguObjSplitter.prototype.GetColumns = function ()
{
  return this._cols;
};  // wguObjSplitter.GetColumns()


wguObjSplitter.prototype.GetHeight = function ()
{
  return this._height;
};  // wguObjSplitter.GetHeight()


wguObjSplitter.prototype.GetWidth = function ()
{
  return this._width;
};  // wguObjSplitter.GetWidth()


wguObjSplitter.prototype.GetSelectedSash = function ()
{
  return this._selectedSash;

};  // wguObjSplitter.SetSelectedSash()


wguObjSplitter.prototype.CalcPaneDefaultHeight = function ()
{
  var rc = 0;
  if (this._noDefHeight > 0)
  {
    var h = this._htmlObj.offsetHeight - this._definedH;
    rc = h / this._noDefHeight;
  }
  return rc;
};  // wguObjSplitter.CalcPaneDefaultHeight()


wguObjSplitter.prototype.CalcPaneDefaultWidth = function ()
{
  var rc = 0;
  if (this._noDefWidth > 0)
  {
    var h = this._htmlObj.offsetWidth - this._definedW;
    rc = h / this._noDefWidth;
  }
  return rc;
};  // wguObjSplitter.CalcPaneDefaultWidth()


wguObjSplitter.prototype.GetSashesForPane = function ( in_paneIdx, in_dir, out_asashes )
{
  var rc = null;
  var i;

  if (in_dir && in_paneIdx != null && out_asashes && 0 < this._cols)
  {
    // the sash index for horizontal sashes is the first pane of row in_sashIdx*this._cols
    if (in_dir == "h")
    {
      i = floor(in_paneIdx / this._cols) - 1;
      out_asashes[0] = (i >= 0)                      ? this._aRowSashes[i] : null;
      i++;
      out_asashes[1] = (i < this._aRowSashes.length) ? this._aRowSashes[i] : null;
    }
    // the sash index for vertical sashes is the column pane of the first row
    else
    {
      i = floor(in_paneIdx % this._cols) - 1;
      out_asashes[0] = (i >= 0)                      ? this._aColSashes[i] : null;
      i++;
      out_asashes[1] = (i < this._aColSashes.length) ? this._aColSashes[i] : null;
    }
    rc = this;
  }

  return rc;

};  // wguObjSplitter.GetSashesForPane()


wguObjSplitter.prototype.GetPanesForSash = function ( in_sashIdx, in_dir, out_apanes )
{
  var rc = null;

  if (in_dir && in_sashIdx != null && out_apanes)
  {
    // the sash index for horizontal sashes is the first pane of row in_sashIdx*this._cols
    if (in_dir == "h")
    {
      out_apanes[0] = this._aPanes[ in_sashIdx   *this._cols];
      out_apanes[1] = this._aPanes[(in_sashIdx+1)*this._cols];
    }
    // the sash index for vertical sashes is the column pane of the first row
    else
    {
      out_apanes[0] = this._aPanes[ in_sashIdx   ];
      out_apanes[1] = this._aPanes[(in_sashIdx+1)];
    }
    rc = this;
  }

  return rc;
};  // wguObjSplitter.IsValid()


wguObjSplitter.prototype.GetDockLevel = function ()
{
  return this._dockLevel;

};  // wguObjSplitter.GetDockLevel()


wguObjSplitter.prototype.GetFixedOverride = function ()
{
  return this._dockLevel;

};  // wguObjSplitter.GetDockLevel()




/**************************************************************
 *
 * Update Routines
 *
 */


wguObjSplitter.prototype.Update = function ( in_boUpdateOnlyPanes )
{
  this.Resize(null, null, null, in_boUpdateOnlyPanes);

  return this;

};  // wguObjSplitter.Update()


/* function wguObjSplitter.Resize()
 *
 * Called on mouse move and movement of sash
 *
 */

wguObjSplitter.prototype.Resize = function ( in_width, in_height, in_boRelative, in_boUpdateOnlyPanes )
{
  var w, h, boRel;
  var i, l,
      bocmrel = (this._colMode == "r"),
      bormrel = (this._rowMode == "r"),
      p;
  var dw, dh;

  if (null != this._htmlObj && null != this._htmlObj.parentNode)
  {
    if (false == in_boUpdateOnlyPanes)
    {
      if (!this._fixedh && this._htmlObj.parentNode.offsetWidth > 0)  { this._htmlObj.style.width  = "100%"; }
      if (!this._fixedv && this._htmlObj.parentNode.offsetHeight > 0) { this._htmlObj.style.height = "100%"; }
    }
  }
  else
  {
    this._htmlObj.style.width = this._htmlObj.style.height = "100%";
  }

  boRel = (in_boRelative != null) ? in_boRelative : false;
  w     = (in_width != null)      ? in_width      : (this._htmlObj.offsetWidth);
  h     = (in_height != null)     ? in_height     : (this._htmlObj.offsetHeight);

  var dim = boRel ? "%" : "px";
  with (this._htmlObj.style)
  {
    width = w + dim;
    height = h + dim;
  }
  with (this)
  {
    _width  = _htmlObj.offsetWidth;
    _height = _htmlObj.offsetHeight;
  }

  l = this._rows * this._cols;

  // reset relative sized panes (columnmode / rowmode == "relative")
  if (bocmrel || bormrel)
  {
    // reset all panes to 'official' sizes if modes are relative
    for (i = 0; i < l; i++)
    {
      p = this._aPanes[i];
      if (p)
      {
        if (bocmrel && bormrel)
          p.SetHTMLPaneNewRelPosDim(null, null, p.GetCurrWidth(), p.GetCurrHeight());
        else
        {
          if (bocmrel) p.SetHTMLPaneNewRelPosDim(null, null, p.GetCurrWidth(), null);
          if (bormrel) p.SetHTMLPaneNewRelPosDim(null, null, null, p.GetCurrHeight());
        }
        p.UpdateCurrDimData();
      }
    }
  }

  // now we have to resize the panes
  this.UpdatePanes();
  this.UpdateSashes();

  // we want to provide the dimension information any time //tj/070702
  // if (this.IsDockingControl())
  {
    for (i = 0; i < l; i++)
      this._aPanes[i].UpdateFormSize(true, true);
  }

  return this;
};  // wguObjSplitter.Resize()


wguObjSplitter.prototype.UpdateSashes = function ()
{
  var rc = this;
  var i, j, l,
      pane,
      sash,
      x, y, w, h;

  w = this._width;
  h = null;             // don't set it (-> CSS)

  for (i = 0, l = this._rows - 1; i < l; i++)
  {
    if (null != (sash = this._aRowSashes[i]))
    {
      j = i * this._cols;
      pane = this._aPanes[j];
      y = pane ? (pane.GetTopPosition() + pane.GetHeight() - SPLITTER_SASH_HALFSIZE) : 0;
      sash.SetPosition(0, y, w, h);
      sash.Update();
    }
  }

  w = null;             // don't set it (-> CSS)
  h = this._height;

  for (i = 0, l = this._cols - 1; i < l; i++)
  {
    if (null != (sash = this._aColSashes[i]))
    {
      pane = this._aPanes[i];
      x = pane ? (pane.GetLeftPosition() + pane.GetWidth() - SPLITTER_SASH_HALFSIZE) : 0;
      sash.SetPosition(x, 0, w, h);
      sash.Update();
    }
  }

  return rc;
};  // wguObjSplitter.CalcPaneDefaultHeight()


/* function wguObjSplitter.UpdatePanesAtSash()
 *
 * Called on finished movement of splitter sash
 * (the panes are updated in relation of the sash)
 *
 */

wguObjSplitter.prototype.UpdatePanesAtSash = function ( in_sash )
{

  if (in_sash)
  {
    var i, l, k, rowcol,
        cols = this._cols,
        rows = this._rows,
        sashx, sashy,
        p,
        adim, x1, x2, y1, y3, w1, w2, h1, h2;

    rowcol = in_sash.GetIndex();
    sashx  = (0 > (sashx = in_sash.GetLeftPosition())) ? 0 : sashx;
    sashy  = (0 > (sashy = in_sash.GetTopPosition())) ? 0 : sashy;

    if (in_sash.GetOrientation() == "h")        // rows have to be updated
    {
      // update row above and below sash
      for (i = l = k = rowcol * cols, l += cols; i < l; i++)
      {
        p = this._aPanes[i];
        adim = p.GetPosDim();
        x1 = adim[0];
        w1 = adim[2];
        if (i == k)
        {
          y1 = adim[1];
          h1 = sashy - y1 + SPLITTER_SASH_HALFSIZE;
          h2 = adim[3] - h1;
        }
        p.SetHTMLPaneNewPosDim(x1, y1, w1, h1);
        if (this.IsSplitterControl()) p.UpdateFormSize(false, true);
        controlUpdateOverflow(p.GetHTMLObj());

        p = this._aPanes[i + cols];
        if (i == k)
        {
          y2 = y1 + h1;
          h2 += p.GetHeight();
        }
        p.SetHTMLPaneNewPosDim(x1, y2, w1, h2);
        p.UpdateFormSize(false, true);
        controlUpdateOverflow(p.GetHTMLObj());

        /* for debugging
        alert("S(x,y) = (" + sashx + "," + sashy + ") - "
                      + "P1(x,y,w,h) = (" + x1 + "," + y1 + "," + w1 + "," + h1 + ") - "
                      + "P2(x,y,w,h) = (" + x1 + "," + y2 + "," + w1 + "," + h2 + ")"
             );
        */
      }
    }
    else                                        // update columns
    {
      // update columns to the left and right of the sash
      for (i = rowcol, l = rows*cols; i < l; i += cols)
      {
        p = this._aPanes[i];
        adim = p.GetPosDim();
        y1 = adim[1];
        h1 = adim[3];
        if (i == rowcol)
        {
          x1 = adim[0];
          w1 = sashx - x1 + SPLITTER_SASH_HALFSIZE;
          w2 = adim[2] - w1;
        }
        p.SetHTMLPaneNewPosDim(x1, y1, w1, h1);
        if (this.IsSplitterControl()) p.UpdateFormSize(true, false);
        controlUpdateOverflow(p.GetHTMLObj());

        p = this._aPanes[i+1];
        if (i == rowcol)
        {
          x2 = x1 + w1;
          w2 += p.GetWidth();
        }
        p.SetHTMLPaneNewPosDim(x2, y1, w2, h1);
        p.UpdateFormSize(true, false);
        controlUpdateOverflow(p.GetHTMLObj());

        /* for debugging
        alert("S(x,y) = (" + sashx + "," + sashy + ") - "
                      + "P1(x,y,w,h) = (" + x1 + "," + y1 + "," + w1 + "," + h1 + ") - "
                      + "P2(x,y,w,h) = (" + x2 + "," + y1 + "," + w2 + "," + h1 + ")"
             );
        */
      }
    }
  }

};  // wguObjSplitter.UpdatePanesAtSash()


/* function wguObjSplitter.UpdatePanes()
 *
 * Called for splitter initialization and splitter resize
 * (the panes are updated in relation of other panes and the splitter)
 *
 */

  function wguObjSplitter_UpdatePanes_objPosDim ( in_x, in_y, in_w, in_h )
  {
    this.x = (in_x > 0) ? in_x : 0;
    this.y = (in_y > 0) ? in_y : 0;
    this.w = (in_w > 0) ? in_w : 0;
    this.h = (in_h > 0) ? in_h : 0;
  }
  wguObjSplitter_UpdatePanes_objPosDim.prototype.SetPosDim = function ( in_x, in_y, in_w, in_h )
  {
    if (in_x != null) this.x = (in_x > 0) ? in_x : 0;
    if (in_y != null) this.y = (in_y > 0) ? in_y : 0;
    if (in_w != null) this.w = (in_w > 0) ? in_w : 0;
    if (in_h != null) this.h = (in_h > 0) ? in_h : 0;
  }

wguObjSplitter.prototype.UpdatePanes = function ()
{
  var rc = 0;
  var row, rows, col, cols, c, r, i, n, p, hw, pos;
  var spaceall, spaceset, spacesashes, spacefree;
  var aRowsCols = new Array(),
      oPosDim;
  var dw, dh;

  rows = this._rows;
  cols = this._cols;

  /* first, we reset the sizes of default height/width panes
   */

  dw = this._htmlObj.clientWidth;
  dh = this._htmlObj.clientHeight;
  for (i = 0, n = rows*cols; i < n; i++)
  {
    p = this._aPanes[i];
    if (p)
    {
      if (!p.HasDefaultWidth())  dw -= p.GetWidth();
      if (!p.HasDefaultHeight()) dh -= p.GetHeight();
    }
  }
  if (cols > 0 && this._noDefWidth  > 0) dw /= this._noDefWidth;  else dw = 0;
  if (rows > 0 && this._noDefHeight > 0) dh /= this._noDefHeight; else dh = 0;

  /* second, we update the rows
   */

  spaceall    = this._htmlObj.clientHeight;
  spacesashes = this._noHorzSash * SPLITTER_SASH_SIZE;
  spaceset    = spacesashes;
  spacefree   = spaceall - spaceset;
  pos         = 0;

  for (row = 0; row < rows; row++)
  {
    // col*row is index of first pane in a row
    if (null != (p = this._aPanes[cols * row]))
    {
      if (p.HasDefaultHeight())
        hw = dh;
      else
        hw = p.GetHeight();
      n  = p.GetNoOfRowSashes() * SPLITTER_SASH_HALFSIZE;
      spaceset  -= n;
      spacefree += n;
      if (hw < n) hw = n;
      if (hw > spacefree)
      {
        hw = (spacefree > 0) ? spacefree : 0;
      }
      else if (row == (rows - 1))
      {
        hw = spacefree;
      }
    }
    else
    {
      hw = 0;
    }
    aRowsCols[row] = new wguObjSplitter_UpdatePanes_objPosDim(0, pos, 0, hw);
    pos += hw;
    spacefree -= hw;
  }

  /* now, we update the columns
   */

  spaceall    = this._htmlObj.clientWidth;
  spacesashes = this._noVertSash * SPLITTER_SASH_SIZE;
  spaceset    = spacesashes;
  spacefree   = spaceall - spaceset;
  pos         = 0;

  for (col = 0; col < cols; col++)
  {
    // col is index of first pane in a column
    if (null != (p = this._aPanes[col]))
    {
      if (p.HasDefaultWidth())
        hw = dw;
      else
        hw = p.GetWidth();
      n  = p.GetNoOfColSashes() * SPLITTER_SASH_HALFSIZE;
      spaceset  -= n;
      spacefree += n;
      if (hw < n) hw = n;
      if (hw > spacefree)
      {
        hw = (spacefree > 0) ? spacefree : 0;
      }
      else if (col == (cols - 1))
      {
        hw = spacefree;
      }
    }
    else
    {
      hw = 0;
    }
    if (col >= aRowsCols.length)
      aRowsCols[col] = new wguObjSplitter_UpdatePanes_objPosDim(pos, 0, hw, 0);
    else
      aRowsCols[col].SetPosDim(pos, null, hw, null);
    pos += hw;
    spacefree -= hw;
  }

  /* finally, update all panes
   */

  for (row = 0; row < rows; row++)
  {
    r = aRowsCols[row];
    for (col = 0, i = row * cols; col < cols; i++, col++)
    {
      p = this._aPanes[i];
      c = aRowsCols[col];
      p.SetHTMLPaneNewPosDim(c.x, r.y, c.w, r.h);

      controlUpdateOverflow(p.GetHTMLObj());

    } // for (col)
  } // for (row)

  CFWExeconFinalSizeHandlers();

  return rc;
};  // wguObjSplitter.UpdatePanes()




/**************************************************************
 *
 * Event Handling
 *
 */


wguObjSplitter.prototype.nop = function () { return false; };

wguObjSplitter.prototype.SetSplitterEvents = function ()
{
  var its_event = new its_eventManager();
  var sphtmlobj = this.GetHTMLObj();

  if (sphtmlobj)
  {
    its_event.registerEvent(sphtmlobj, "mousemove", this.onMouseMoveHdl);
    its_event.registerEvent(sphtmlobj, "mouseup",   this.onMouseUpHdl);
    its_event.registerEvent(sphtmlobj, "mouseout",  this.onMouseOutHdl);
    its_event.registerEvent(document.body, "dragstart", this.nop);
    its_event.registerEvent(document.body, "selectstart", this.nop);
    document.body.style.MozUserSelect = "none";

    /*var spblock = sphtmlobj.id + "Block";
    if (null != (spblock = document.getElementById(spblock)))
    {
      its_event.registerEvent(spblock, "mouseout",  this.onMouseOutHdl);
    }*/
  }

  return this;

};  // wguObjSplitter.SetSplitterEvents()


wguObjSplitter.prototype.ResetSplitterEvents = function ()
{
  var its_event = new its_eventManager();
  var sphtmlobj = this.GetHTMLObj();

  if (sphtmlobj)
  {
    its_event.unregisterEvent(sphtmlobj, "mousemove", this.onMouseMoveHdl);
    its_event.unregisterEvent(sphtmlobj, "mouseup",   this.onMouseUpHdl);
    its_event.unregisterEvent(sphtmlobj, "mouseout",  this.onMouseOutHdl);
    its_event.unregisterEvent(document.body, "dragstart", this.nop);
    its_event.unregisterEvent(document.body, "selectstart", this.nop);
    document.body.style.MozUserSelect = "";

    /*var spblock = sphtmlobj.id + "Block";
    if (null != (spblock = document.getElementById(spblock)))
      its_event.unregisterEvent(spblock, "mouseout",  this.onMouseOutHdl);*/
  }

  return this;

};  // wguObjSplitter.ResetSplitterEvents()


wguObjSplitter.prototype.onMouseDownHdl = function ( in_event )
{
  var ev;
  var el, sash, sp;
  var block;

  if (null != (ev = in_event ? in_event : window.event))
  {
    el = ev.target ? ev.target : ev.srcElement;

    if (el)
    {
      if (ev.stopPropagation) ev.stopPropagation(); ev.cancelBubble = true;

//      sash = el.This;               // the mouse down event happens on the sash
      sash = window[[el.id,"_this"].join("")];
      sp   = sash._splitterObj;     // this

      sp._inUserAction = true;

      sp.SetSelectedSash(sash);
      sash.DoSelect();

      sash._mouseX      = ev.screenX;
      sash._mouseY      = ev.screenY;
      sash._mouseStartX = sash._htmlObj.offsetLeft;
      sash._mouseStartY = sash._htmlObj.offsetTop;
      sp.SetSplitterEvents();

      if (ev.setCapture)
      {
        ev.setCapture();
      }
      block = document.getElementById(sp._id + "Block");
      if (block != null)
      {
        block.style.display = "block";
      }

      if (sash._dir == "h")
      {
        sash._htmlObj.className = "SplitterSash RowSashSelected";
      }
      else
      {
        sash._htmlObj.className = "SplitterSash ColumnSashSelected";
      }

      /* Docking control
       */

      if (sp.IsDockingControl())
        sash.SetMoveLimits();
    }
  }

  return sash;

};  // wguObjSplitterSash.onMouseDown()



wguObjSplitter.prototype.onMouseMoveHdl = function ( in_event )
{
  var rc = null;
  var ev;
  var el, sash, sp;
  var x, y, d,
      xycurr, xymin, xymax,
      style;

  if (null != (ev = in_event ? in_event : window.event))
  {
    el = ev.target ? ev.target : ev.srcElement;

    if (el)
    {
      if (!el.SPPAR)
      {
        sp = el;
        while (sp && !sp.isSplitter && !sp.SPPAR) sp = sp.parentNode;
        if (sp)
        {
          sp = sp.isSplitter ? sp : sp.SPPAR;
          el.SPPAR = sp;
        }
      }
      else
      {
        sp = el.SPPAR;
      }

      if (sp && null != (sp = window[[sp.id,"_this"].join("")]) && null != (sash = sp._selectedSash))
      {
        ev.cancelBubble = true; if (ev.stopPropagation) ev.stopPropagation();

        x = ev.screenX;
        y = ev.screenY;

        if (sash._dir == "h")
        {
          xycurr = sash._mouseStartY + y - sash._mouseY;
          y = ((xycurr > sash.LimitMinY) ? ((xycurr < sash.LimitMaxY) ? xycurr : sash.LimitMaxY) : sash.LimitMinY) + "px";
          sash._style.top = (y > sash.LimitMaxY - SPLITTER_SASH_SIZE) ? sash.LimitMaxY - SPLITTER_SASH_SIZE : y;

          // set cursor
          sash._style.cursor = (this._moveY < xycurr) ? "s-resize" : "n-resize";
          this._moveY = xycurr;
        }
        else
        {
          xycurr = sash._mouseStartX + x - sash._mouseX;
          x = ((xycurr > sash.LimitMinX) ? ((xycurr < sash.LimitMaxX) ? xycurr : sash.LimitMaxX) : sash.LimitMinX) + "px";
          sash._style.left = (x > sash.LimitMaxX - SPLITTER_SASH_SIZE) ? sash.LimitMaxX - SPLITTER_SASH_SIZE : x;
        }

        rc = sp;
      }
    }
  }

  return rc;

};  // wguObjSplitterSash.onMouseDown()



wguObjSplitter.prototype.onMouseUpHdl = function ( in_event )
{
  var rc = null;
  var ev;
  var el, sash, sp,
      i, l, s;
  var block;

  if (null != (ev = in_event ? in_event : window.event))
  {
    el = ev.target ? ev.target : ev.srcElement;

    if (el)
    {
      if (!el.SPPAR)
      {
        sp = el;
        while (sp && !sp.isSplitter && !sp.SPPAR)
        {
          sp = sp.parentNode;
        }
        if (sp)
        {
          sp = sp.isSplitter ? sp : sp.SPPAR;
          el.SPPAR = sp;
        }
      }
      else
      {
        sp = el.SPPAR;
      }

      if (sp && null != (sp = window[[sp.id,"_this"].join("")]) && null != (sash = sp._selectedSash))
      {
        sp.ResetSelectedSash();
        sp.ResetSplitterEvents();
        sash.DoDeselect();
        sash.UpdatePosition();
        sp.UpdatePanesAtSash(sash);

        if (sp._localResize)
        {
          CFWExeconFinalSizeHandlers();

          if (ev.releaseCapture)
          {
            ev.releaseCapture();
          }
          block = document.getElementById(sp._id + "Block");
          if (block != null)
          {
            block.style.display = "none";
          }

          if (sash._dir == "h")
          {
            // update this and its neighbor sashes
            for (i = (0 < (i = sash.GetIndex()-1)) ? i : 0, l = i + 3; i < l; i++)
            {
              if (null != (s = sp._aRowSashes[i])) s.Update();
            }

            sash._htmlObj.className = "SplitterSash RowSash";
          }
          else
          {
            // update this and its neighbor sashes
            for (i = (0 < (i = sash.GetIndex()-1)) ? i : 0, l = i + 3; i < l; i++)
            {
              if (null != (s = sp._aColSashes[i])) s.Update();
            }

            sash._htmlObj.className = "SplitterSash ColumnSash";
          }
        } // if (this._localResize)
        else
        {
          if (   sp._type == SPLITTER_TYPE_DOCKING
              || "abap" == sp._htmlObj.getAttribute("splitterControlId")
             )
          {
            // s = (null != (s = sp._aPanes[0]._formField) ? s.value : "");
            // raiseEvent(sp._htmlObj.dockingControlId, "OnResize", s);
            var myevent = new its_event(in_event);
            myevent.cancel();
            if (document.selection)
              document.selection.clear();
            // setOkCode("/0");
            setOkCode("\ ");
          }
        }

      sp._inUserAction = false;
      }

      rc = sp;
    }
  }

  // window.setTimeout("window.gwguSplitters.Debug()", 250);

  return rc;

};  // wguObjSplitter.onMouseUp()


/* let the sash go when the mouse leaves the splitter/docker area
 */
wguObjSplitter.prototype.onMouseOutHdl = function ( in_event )
{
  var rc = null;
  var ev;
  var el, sash, sp;

  if (null != (ev = in_event ? in_event : window.event))
  {
    el = ev.target ? ev.target : ev.srcElement;

    if (el)
    {
      if (!el.SPPAR)
      {
        sp = el;
        while (sp && !sp.isSplitter && !sp.SPPAR) sp = sp.parentNode;
        if (sp)
        {
          sp = sp.isSplitter ? sp : sp.SPPAR;
          el.SPPAR = sp;
        }
      }
      else
      {
        sp = el.SPPAR;
      }

      if (null != sp
         && [sp.id, "Block"].join("") == el.id
         && null != (sp = sp.This) && null != sp.onMouseUpHdl)
      {
        rc = sp.onMouseUpHdl(in_event);
      }
    }
  }

  return rc;

};  // wguObjSplitterSash.onMouseOutHdl()






/*******************************************************************@@
 *
 * Splitter Control Pane Object
 *
 ********************************************************************/




/**************************************************************
 *
 * Splitter Pane Constructor
 *
 */


wguObjSplitterPane = function ( in_splitter, in_paneIdx )
{
  var rc = null;
  var splitterId = null,
      paneId     = null,
      el,
      s, s2;

  if (in_splitter != null && in_paneIdx != null)
  {
    splitterId = in_splitter.GetId();
    paneId = splitterId + SPLITTER_CHILD_PREFIX + in_paneIdx;
  }

  if (paneId && null != (el = document.getElementById(paneId)))
  {
    this._id              = paneId;
    this._type            = SPLITTER_TYPE_PANE;           // type SPLITTER PANE
    this._splitterId      = splitterId;
    this._splitterObj     = in_splitter;
    this._paneIdx         = in_paneIdx;
    this._htmlObj         = el;

//  this._htmlObj.This    = this;
    window[[this._id,"_this"].join("")] = this;

    this._boDefaultHeight = (el.getAttribute("splitterDefaultHeight") == "1");
    this._boDefaultWidth  = (el.getAttribute("splitterDefaultWidth") == "1");
    this._boFixedHeight   = (el.getAttribute("fixh") == "1");
    this._boFixedWidth    = (el.getAttribute("fixw") == "1");
    this._orgWidth        =                               // original width and
    this._currWidth       = parseInt(el.style.width);     // current width (either in % or px, dependend on this._splitterObj.GetColumnMode())
    this._orgHeight       =                               // original height and
    this._currHeight      = parseInt(el.style.height);    // current height (either in % or px, dependend on this._splitterObj.GetRowMode())

    this._rasterChild     = this._splitterObj._raster.AddChild(this._htmlObj, this);
    this._rasterChildIdx  = this._rasterChild.GetChildIndex();

    this._currTop         = parseInt(el.style.top);
    this._currLeft        = parseInt(el.style.left);

    if (this._orgHeight < 11) this._htmlObj.style.overflow = "hidden";
    if (this._orgWidth  < 11) this._htmlObj.style.overflow = "hidden";
    this.UpdateDimensionData();

    this._noRowSashes     = 0;
    this._noColSashes     = 0;

    // form field for submitting size changes
    if (this._splitterObj.IsSplitterControl())
    {
      s  = splitterId + SPLITTER_CHILD_PREFIX + in_paneIdx;
      this._formFieldAbs = document.getElementById(s + SPLITTER_SASH_RESIZED_ABSDIM);
    }
    else
    {
      s = splitterId;
    }
    this._formField = document.getElementById(s + SPLITTER_SASH_RESIZED_DIM);

    this._boRefresh = false;                    // if set to true this pane needs to be updated (resized)

    rc = this;

  }
  else
    this._boNotValid = true;                    // for IsValid()

  return rc;
};  // wguObjSplitterPane() Constructor




/**************************************************************
 *
 * Set Routines
 *
 */


wguObjSplitterPane.prototype.SetHTMLPaneNewPosDim = function ( in_x, in_y, in_w, in_h )
{
  var x, y, w, h;
  if (in_x != null) { x = ((in_x > 0) ? in_x : 0); }
  if (in_y != null) { y = ((in_y > 0) ? in_y : 0); }
  if (in_w != null) { w = ((in_w > 0) ? in_w : 0); }
  if (in_h != null) { h = ((in_h > 0) ? in_h : 0); }
  this._rasterChild.SetPosDim(new Array(x, y, w, h), "px");

  this.UpdateDimensionData();
  this.UpdateCurrDimData();

  return this;
};  // wguObjSplitterPane.SetHTMLPaneNewPosDim()


wguObjSplitterPane.prototype.SetHTMLPaneNewRelPosDim = function ( in_x, in_y, in_w, in_h )
{
  var s = this._htmlObj.style;

  /* this is badly needed because of a bug of the IE -
     after setting a relative value the size is set to 0px ! :-(((
   */
  var el = this._htmlObj,
      wp = (el.parentNode) ? el.parentNode.offsetWidth : 0,
      hp = (el.parentNode) ? el.parentNode.offsetHeight : 0;

  var x, y, w, h;
  x = y = w = h = null;
  if (in_x != null) { x = ((in_x > 0) ? in_x : 0); }
  if (in_y != null) { y = ((in_y > 0) ? in_y : 0); }
  if (in_w != null) { w = ((in_w > 0) ? in_w : 0); }
  if (in_h != null) { h = ((in_h > 0) ? in_h : 0); }
  this._rasterChild.SetPosDim(new Array(x, y, w, h), "%");

  if (el.offsetHeight < (h = (hp * in_h / 100) - 5)) this._rasterChild.SetHeight(h, "px");
  if (el.offsetWidth  < (w = (wp * in_w / 100) - 5)) this._rasterChild.SetWidth(w, "px");

  this.UpdateDimensionData();

  return this;
};  // wguObjSplitterPane.SetPosDimUncond()


wguObjSplitterPane.prototype.SetTopPosition = function ( in_top )
{
  this._top = in_top;

};  // wguObjSplitterPane.SetTopPosition()


wguObjSplitterPane.prototype.SetLeftPosition = function ( in_left )
{
  this._left = in_left;

};  // wguObjSplitterPane.SetLeftPosition()


wguObjSplitterPane.prototype.SetWidth = function ( in_width )
{
  var w;

  // we have to take the sashes into account
  w = this._noColSashes * SPLITTER_SASH_HALFSIZE;
  this._width = (in_width < w) ? w : in_width;

};  // wguObjSplitterPane.SetWidth()

wguObjSplitterPane.prototype.SetHeight = function ( in_height )
{
  var h;

  // we have to take the sashes into account
  h = this._noRowSashes * SPLITTER_SASH_HALFSIZE;
  this._height = (in_height < h) ? w : in_height;

};  // wguObjSplitterPane.SetHeight()


wguObjSplitterPane.prototype.AddSash = function ( in_sash, in_dir, in_idx )
{
  if (in_sash && in_dir && in_idx != null)
  {
    if (in_dir == "h")                          // row sash
    {
      if (this._noRowSashes < 2) this._noRowSashes++;
    }
    else                                        // column sash
    {
      if (this._noColSashes < 2) this._noColSashes++;
    }
  }

  return this;

};  // wguObjSplitterPane.AddSash()




/**************************************************************
 *
 * Get Routines
 *
 */


wguObjSplitterPane.prototype.IsValid = function ()
{
  return (true != this._boNotValid);

};  // wguObjSplitterPane.IsValid()


wguObjSplitterPane.prototype.GetHTMLObj = function ()
{
  return this._htmlObj;

};  // wguObjSplitterPane.GetHTMLObj()


wguObjSplitterPane.prototype.GetPosDim = function ( inout_aPosDim)
{
  var rc = (inout_aPosDim) ? inout_aPosDim : new Array();

  rc[0] = this._left;
  rc[1] = this._top;
  rc[2] = this._width;
  rc[3] = this._height;
  return rc;

};  // wguObjSplitterPane.GetPosDim()


wguObjSplitterPane.prototype.GetTopPosition = function ()
{
  return this._top;

};  // wguObjSplitterPane.GetTopPosition()


wguObjSplitterPane.prototype.GetLeftPosition = function ()
{
  return this._left;

};  // wguObjSplitterPane.GetLeftPosition()


wguObjSplitterPane.prototype.GetCurrWidth = function ()
{
  return this._currWidth;

};  // wguObjSplitterPane.GetCurrWidth()


wguObjSplitterPane.prototype.GetCurrHeight = function ()
{
  return this._currHeight;

};  // wguObjSplitterPane.GetCurrHeight()


wguObjSplitterPane.prototype.GetWidth = function ()
{
  var rv = (true == this._boFixedWidth) ? this.GetAbsOrgWidth() : this._width;
  return rv;

};  // wguObjSplitterPane.GetWidth()


wguObjSplitterPane.prototype.GetHeight = function ()
{
  var rv = (true == this._boFixedHeight) ? this.GetAbsOrgHeight() : this._height;
  return rv;

};  // wguObjSplitterPane.GetHeight()


wguObjSplitterPane.prototype.GetAbsOrgWidth = function ()
{
  var rv = ("r" == this._splitterObj.GetColumnMode())
           ? this.CalcAbsPaneWidth(this._orgWidth)
           : this._orgWidth;
  return rv;

};  // wguObjSplitterPane.GetAbsOrgWidth()


wguObjSplitterPane.prototype.GetAbsOrgHeight = function ()
{
  var rv = ("r" == this._splitterObj.GetRowMode())
           ? this.CalcAbsPaneHeight(this._orgHeight)
           : this._orgHeight;
  return rv;

};  // wguObjSplitterPane.GetAbsOrgHeight()


wguObjSplitterPane.prototype.GetNoOfRowSashes = function ()
{
  return this._noRowSashes;

};  // wguObjSplitterPane.GetNoOfRowSashes()


wguObjSplitterPane.prototype.GetNoOfColSashes = function ()
{
  return this._noColSashes;

};  // wguObjSplitterPane.GetNoOfColSashes()


wguObjSplitterPane.prototype.CalcRelativePaneWidth = function ( in_width )
{
  var rc,
      w = this._splitterObj.GetWidth();

  if (0 != w)
    rc = (100 * ((in_width != null) ? in_width : this.GetWidth()) / w);
  else
    rc = 0;

  return rc;

};  // wguObjSplitterPane.CalcRelativePaneWidth()


wguObjSplitterPane.prototype.CalcRelativePaneHeight = function ( in_height )
{
  var rc,
      h = this._splitterObj.GetHeight();

  if (0 != h)
    rc = (100 * ((in_height != null) ? in_height : this.GetHeight()) / h);
  else
    rc = 0;

  return rc;

};  // wguObjSplitterPane.CalcRelativePaneHeight()


wguObjSplitterPane.prototype.CalcAbsPaneWidth = function ( in_relwidth )
{
  var rv;

  rv = this._splitterObj.GetWidth() * (((in_relwidth != null) ? in_relwidth : this.GetWidth()) / 100);

  return rv;

};  // wguObjSplitterPane.CalcRelativePaneWidth()


wguObjSplitterPane.prototype.CalcAbsPaneHeight = function ( in_relheight )
{
  var rv;

  rv = this._splitterObj.GetHeight() * (((in_relheight != null) ? in_relheight : this.GetHeight()) / 100);

  return rv;

};  // wguObjSplitterPane.CalcRelativePaneHeight()


wguObjSplitterPane.prototype.HasDefaultWidth = function ()
{
  return this._boDefaultWidth;

};  // wguObjSplitterPane.HasDefaultWidth()


wguObjSplitterPane.prototype.HasDefaultHeight = function ()
{
  return this._boDefaultHeight;

};  // wguObjSplitterPane.HasDefaultHeight()




/**************************************************************
 *
 * Other stuff
 *
 */


wguObjSplitterPane.prototype.CalcRelToAbsPaneWidth = function ( in_width )
{
  var rc;

  rc = (in_width * this._splitterObj.GetWidth()) / 100;

  return rc;

};  // wguObjSplitterPane.CalcRelToAbsPaneWidth()


wguObjSplitterPane.prototype.CalcRelToAbsPaneHeight = function ( in_height )
{
  var rc;

  rc = (in_height * this._splitterObj.GetHeight()) / 100;

  return rc;

};  // wguObjSplitterPane.CalcRelToAbsPaneHeight()




/**************************************************************
 *
 * Update Routines
 *
 */


wguObjSplitterPane.prototype.UpdateDimensionData = function ()
{
  var el = this._htmlObj;

  // actual width, height, top, left of cell container
  this._width  = el.offsetWidth;
  this._height = el.offsetHeight;
  this._top    = this._rasterChild.GetYPos();   // el.offsetTop;
  this._left   = this._rasterChild.GetXPos();   // el.offsetLeft;

  // actual user area (UA) dimensions inside cell container;
  //
  // these are friendly parameters used also by wguObjSplitter !
  //
  this.UAWidth  = (0 != el.clientWidth)  ? el.clientWidth  : this._width;   // we need to do this this complicated way because of an IE bug
  this.UAHeight = (0 != el.clientHeight) ? el.clientHeight : this._height;
  this.UATop    = this._top   + (el.getAttribute("splitterNorthResize") ? SPLITTER_SASH_HALFSIZE : 0);
  this.UABottom = this.UATop  + this.UAHeight - (el.getAttribute("splitterSouthResize") ? 0.99 : 0);
  this.UALeft   = this._left  + (el.getAttribute("splitterWestResize")  ? SPLITTER_SASH_HALFSIZE : 0);
  this.UARight  = this.UALeft + this.UAWidth - (el.getAttribute("splitterEastResize") ? 0.99 : 0);

  if (this.UABottom > this._splitterObj._height)
    this.UABottom = this._splitterObj._height;
  if (this.UARight > this._splitterObj._width)
    this.UARight = this._splitterObj._width;

  return this;

};  // wguObjSplitterPane.UpdateDimensionData()


// update 'official' size parameters
//
wguObjSplitterPane.prototype.UpdateCurrDimData = function ()
{
  this._currWidth = ((this._splitterObj.GetColumnMode() == "r")
                    ? Math.round(this.CalcRelativePaneWidth())
                    : this.GetWidth());
  this._currHeight = ((this._splitterObj.GetRowMode() == "r")
                     ? Math.round(this.CalcRelativePaneHeight())
                     : this.GetHeight());

  return this;

};  // wguObjSplitterPane.UpdateCurrDimData()


wguObjSplitterPane.prototype.UpdateFormSize = function ( in_boW, in_boH )
{
  var v  = (null != this._formField) ? this._formField.value : null,
      sp = this._splitterObj,
      sw, swabs, sh, shabs;

  if (null != v && sp._inUserAction)
  {
    // this.UpdateCurrDimData();

    if (this._splitterObj.IsSplitterControl())
    {
      if (!in_boW && (v == "" || v.indexOf("X:") != -1))
      {
        sw = swabs = "X";
      }
      else if (true == this._boFixedWidth)
      {
        sw = "X";
        swabs = "" + ((this._htmlObj.offsetWidth < 7) ? this._htmlObj.clientWidth : this._htmlObj.offsetWidth);
      }
      else
      {
        sw    = "" + (("a" == sp._colMode && this._currWidth <= SPLITTER_SASH_HALFSIZE*this.GetNoOfColSashes()) ? 0 : this._currWidth);
        swabs = "" + ((this._htmlObj.offsetWidth < 7) ? this._htmlObj.clientWidth : this._htmlObj.offsetWidth);
      }
      if (!in_boH && (v == "" || v.indexOf(":X") != -1))
      {
        sh = shabs = "X";
      }
      else if (true == this._boFixedHeight)
      {
        sh = "X";
        shabs = "" + ((this._htmlObj.offsetHeight < 7) ? this._htmlObj.clientHeight : this._htmlObj.offsetHeight);
      }
      else
      {
        sh    = "" + (("a" == sp._rowMode && this._currHeight <= SPLITTER_SASH_HALFSIZE*this.GetNoOfRowSashes()) ? 0 : this._currHeight);
        shabs = "" + ((this._htmlObj.offsetHeight < 7) ? this._htmlObj.clientHeight : this._htmlObj.offsetHeight);
      }

    }     // if (is Splitter)
    else  // if (is Docker)
    {
      var p;

      if (sp._dock == "l" || sp._dock == "t") p = this._splitterObj._aPanes[0];
      else                                    p = this._splitterObj._aPanes[1];
      if (p != null && (null != (p = p._htmlObj)))
      {
        sw = "" + p.offsetWidth;
        sh = "" + p.offsetHeight;
      }
    }

    if (this._splitterObj.IsDockingControl() || (false == this._boFixedWidth || false == this._boFixedHeight))
    {
      this._formField.value = "" + sw + ":" + sh;
    }
    if (null != this._formFieldAbs)
    {
      this._formFieldAbs.value = "" + swabs + ":" + shabs;
    }
// alert("Update Formfield to " + this._formField.value);
  }
  return this;

};  // wguObjSplitterPane.UpdateFormSize()






/*******************************************************************@@
 *
 * Splitter Control Sash Object
 *
 ********************************************************************/




/**************************************************************
 *
 * Splitter Sash Constructor
 *
 */


wguObjSplitterSash = function ( in_splitter, in_idx, in_dir, in_fixed )
{
  var rc = null;
  var splitterId = null,
      sashId     = null,
      el,
      s,
      i;

  if (in_splitter && in_idx != null  && in_dir)
  {
    splitterId = in_splitter.GetId();
    sashId = splitterId + ((in_dir == "h") ? SPLITTER_SASH_ROW_SUFFIX : SPLITTER_SASH_COL_SUFFIX) + in_idx;
  }

  if (sashId != null && null != (el = document.getElementById(sashId)))
  {
    this._id          = sashId;
    this._type        = SPLITTER_TYPE_SASH;               // type SPLITTER SASH
    this._splitterId  = splitterId;
    this._splitterObj = in_splitter;
    this._sashIdx     = in_idx;
    this._dir         = in_dir;       // orientation of sash ("h" or "v")
    this._htmlObj     = el;
    this._style       = el.style;
    this._paneBefore  = null;
    this._paneAfter   = null;

    this._fixed       = in_fixed;

    this._rasterChild     = this._splitterObj._raster.AddChild(this._htmlObj, this);
    this._rasterChildIdx  = this._rasterChild.GetChildIndex();

    this._left        = 0;            // (x, y) position, not yet set
    this._top         = 0;

    this._selected    = false;        // set on mouse down
    this._moveX       = 0;            // set on sash move
    this._moveY       = 0;
    this._mouseX      = 0;
    this._mouseY      = 0;
    this._mouseStartX = 0;
    this._mouseStartY = 0;

    // friendly properties used by wguObjSplitter
    this.LimitMinX   = 0;
    this.LimitMaxX   = 0;
    this.LimitMinY   = 0;
    this.LimitMaxY   = 0;

//  this._htmlObj.This = this;
    window[[this._id,"_this"].join("")] = this;

    this.SetNeighborPanes();
    this.InitEvents();

    this.Update();

    rc = this;
  }
  else
    this._boNotValid = true;

  return rc;

};  // wguObjSplitterSash() Constructor




/**************************************************************
 *
 * Set routines
 *
 */


wguObjSplitterSash.prototype.SetPosition = function ( in_left, in_top, in_width, in_height )
{
  var style = this._htmlObj.style;

  if (in_top != null)
  {
    this._top = in_top;
    this._rasterChild.SetYPos(in_top, "px");  // style.top = in_top + "px";
  }
  if (in_left != null)
  {
    this._left = in_left;
    this._rasterChild.SetXPos(in_left, "px");  // style.left = in_left + "px";
  }
  if (in_width != null && in_width >= 0)
  {
    style.width = in_width + "px";
  }
  if (in_height != null && in_height >= 0)
  {
    style.height = in_height + "px";
  }

  return this;
};  // wguObjSplitterSash.DoPositionSash()


wguObjSplitterSash.prototype.SetMoveLimits = function ()
{
  var sp = this._splitterObj;

  this.LimitMinX = this._paneBefore.UALeft;
  this.LimitMaxX = this._paneAfter.UARight - SPLITTER_SASH_SIZE;
  this.LimitMinY = this._paneBefore.UATop;
  this.LimitMaxY = this._paneAfter.UABottom - SPLITTER_SASH_SIZE;

  if (sp != null && sp.IsDockingControl())
  {
    var s1  = sp._dockLSash,
        s2  = sp._dockRSash,
        lvl = sp.GetDockLevel(),
        pos,
        dr1, dr2;    // Docking minimum room

    if (sp._dock == "l" || sp._dock == "r")
    {
      // the docking container must have a minimum size, not the dynpro
      if (sp._dock == "l") { dr1 = DOCK_ROOM; dr2 = 0; }
      else                 { dr1 = 0; dr2 = DOCK_ROOM; }

      if (s1 != null)
      {
        if (s1._splitterObj != null && s1._splitterObj.GetDockLevel() > lvl)
             pos = s1.GetLeftPositionAbsRel(sp.GetId());
        else pos = this._paneBefore.UALeft;
      }
      this.LimitMinX = ((s1 != null) ? pos + SPLITTER_SASH_SIZE + dr1
                                     : this._paneBefore.UALeft);

      if (s2 != null)
      {
        if (s2._splitterObj != null && s2._splitterObj.GetDockLevel() > lvl)
             pos = s2.GetLeftPositionAbsRel(sp.GetId());
        else pos = this._paneAfter.UARight - SPLITTER_SASH_SIZE - DOCK_ROOM;
      }
      this.LimitMaxX = ((s2 != null) ? pos - dr2
                                     : this._paneAfter.UARight - SPLITTER_SASH_SIZE - dr2);
      if (this.LimitMinX < DOCK_ROOM) this.LimitMinX = dr1;
      if (this.LimitMaxX < DOCK_ROOM) this.LimitMaxX = dr2;
    }
    else
    {
      if (sp._dock == "t") { dr1 = DOCK_ROOM; dr2 = 0; }
      else                 { dr1 = 0; dr2 = DOCK_ROOM; }

      if (s1 != null)
      {
        if (s1._splitterObj != null && s1._splitterObj.GetDockLevel() > lvl)
             pos = s1.GetTopPositionAbsRel(sp.GetId());
        else pos = this._paneBefore.UATop;
      }
      this.LimitMinY = ((s1 != null) ? pos + SPLITTER_SASH_SIZE + dr1
                                     : this._paneBefore.UATop);

      if (s2 != null)
      {
        if (s2._splitterObj != null && s2._splitterObj.GetDockLevel() > lvl)
             pos = s2.GetTopPositionAbsRel(sp.GetId());
        else pos = this._paneAfter.UABottom - SPLITTER_SASH_SIZE - dr2;
      }
      this.LimitMaxY = ((s2 != null) ? pos - dr2
                                     : this._paneAfter.UABottom - SPLITTER_SASH_SIZE - dr2);
      if (this.LimitMinY < DOCK_ROOM) this.LimitMinY = dr1;
      if (this.LimitMaxY < DOCK_ROOM) this.LimitMaxY = dr2;
    }
  }

  return this;
};  // wguObjSplitterSash.SetMoveLimits()


wguObjSplitterSash.prototype.SetFixed = function ( in_boFixed )
{
  this._fixed = in_boFixed;

};  // wguObjSplitterSash.SetFixed()


wguObjSplitterSash.prototype.SetNeighborPanes = function ()     // called once from constructor
{
  var sp = this._splitterObj;
  var ap = new Array();

  sp.GetPanesForSash(this._sashIdx, this._dir, ap);
  this._paneBefore = ap[0];
  this._paneAfter  = ap[1];

  if (ap[0]) ap[0].AddSash(this, this._dir, 0);
  if (ap[1]) ap[1].AddSash(this, this._dir, 1);

};  // wguObjSplitterSash.SetNeighborPanes()







/**************************************************************
 *
 * Get routines
 *
 */


wguObjSplitterSash.prototype.IsValid = function ()
{
  return (true != this._boNotValid);

};  // wguObjSplitterSash.IsValid()


wguObjSplitterSash.prototype.GetOrientation = function ()
{
  return this._dir;

};  // wguObjSplitterSash.GetOrientation()


wguObjSplitterSash.prototype.GetIndex = function ()
{
  return this._sashIdx;

};  // wguObjSplitterSash.GetIndex()


wguObjSplitterSash.prototype.GetTopPosition = function ()
{
  return this._top;

};  // wguObjSplitterSash.GetTopPosition()


wguObjSplitterSash.prototype.GetLeftPosition = function ()
{
  return this._left;

};  // wguObjSplitterSash.GetTopPosition()


wguObjSplitterSash.prototype.GetTopPositionAbsRel = function ( in_contId )
{
  var cid = ((in_contId != null) ? in_contId : "webguiUserArea"),   // container id
      y   = 0,
      p   = this._htmlObj;
  while (p != null && p.id != cid)
  {
    y += p.offsetTop;
    p = p.parentNode;
  }
  return y;
};  // wguObjSplitterSash.GetTopPositionAbsRel()


wguObjSplitterSash.prototype.GetLeftPositionAbsRel = function ( in_contId )
{
  var cid = ((in_contId != null) ? in_contId : "webguiUserArea"),   // container id
      x = 0,
      p = this._htmlObj;
  while (p != null && p.id != cid)
  {
    x += p.offsetLeft;    // *** Check for BIDI RTL !
    p = p.parentNode;
  }
  return x;
};  // wguObjSplitterSash.GetLeftPositionAbsRel()


wguObjSplitterSash.prototype.GetNeighborPanes = function ()
{
  var rc = new Array();
  rc[0] = this._paneBefore;
  rc[1] = this._paneAfter;

  return rc;

};  // wguObjSplitterSash.GetNeighborPanes()




/**************************************************************
 *
 * Other stuff
 *
 */


wguObjSplitterSash.prototype.DoSelect = function ()
{
  this._selected = true;
  return this;

};  // wguObjSplitterSash.DoSelect()


wguObjSplitterSash.prototype.DoDeselect = function ()
{
  this._selected = false;
  return this;

};  // wguObjSplitterSash.DoDeselect()




/**************************************************************
 *
 * Update routines
 *
 */


wguObjSplitterSash.prototype.UpdatePosition = function ()
{
  var sashhtmlobj = this._htmlObj;

  this._left = this._rasterChild.GetXPos();    // sashhtmlobj.offsetLeft;
  this._top  = this._rasterChild.GetYPos();    // sashhtmlobj.offsetTop;

  if (!this._selected)
  {
    this._moveX       = 0;
    this._moveY       = 0;
    this._mouseX      = 0;
    this._mouseY      = 0;
    this._mouseStartX = 0;
    this._mouseStartY = 0;
  }

  return this;

};  // wguObjSplitterSash.UpdatePosition()


wguObjSplitterSash.prototype.Update = function ()
{
  this.SetMoveLimits();

  return this;

};  // wguObjSplitterSash.Update()





/**************************************************************
 *
 * Event handler
 *
 */


wguObjSplitterSash.prototype.InitEvents = function ()
{
  if (!this._fixed)
  {
    var its_event = new its_eventManager();

    // the sash catches only the mousedown event;
    // all other events are *then* catched by the splitter

    its_event.registerEvent(this._htmlObj, "mousedown", this._splitterObj.onMouseDownHdl);
  }

  return this;

};  // wguObjSplitterSash.InitEvents()
