const fs=require('fs'),path=require('path'),vm=require('vm');
const box={exports:{}};box.module={exports:box.exports};
vm.runInNewContext(process.binding('natives')['internal/deps/acorn/acorn/dist/acorn'],box);
const acorn=box.exports;
function walk(n,fn,parent=null){if(!n||!n.type)return;fn(n,parent);for(const k of Object.keys(n)){const v=n[k];if(Array.isArray(v))for(const x of v)walk(x,fn,n);else if(v&&v.type)walk(v,fn,n)}}
function getAST(s,version=3){return acorn.parse(s,{ecmaVersion:version,allowReserved:true,locations:true})}
function analyze(dir){return fs.readdirSync(dir).filter(x=>x.endsWith('.js')).sort().map(file=>{
 const s=fs.readFileSync(path.join(dir,file)).toString('latin1');let ast,es3=true,error=null;
 try{ast=getAST(s)}catch(e){es3=false;try{ast=getAST(s,5)}catch(e2){error=e2.message}}
 const f={file,bytes:Buffer.byteLength(s,'latin1'),es3,error,functions:[],topLevel:[],assignments:[],calls:[],strings:[],styleWrites:[],events:[],timers:[],nodeCount:0};
 if(ast){
 for(const n of ast.body){if(n.type==='VariableDeclaration')f.topLevel.push(...n.declarations.map(x=>s.slice(x.id.start,x.id.end)));if(n.type==='FunctionDeclaration')f.topLevel.push(n.id.name)}
 walk(ast,(n,p)=>{f.nodeCount++;
 if(/Function/.test(n.type)){let name=n.id?n.id.name:p&&p.type==='AssignmentExpression'?s.slice(p.left.start,p.left.end):p&&p.type==='VariableDeclarator'?s.slice(p.id.start,p.id.end):'<anonymous>';f.functions.push({name,params:n.params.map(x=>s.slice(x.start,x.end)),start:n.start,end:n.end,line:n.loc.start.line});}
 if(n.type==='AssignmentExpression'){const target=s.slice(n.left.start,n.left.end);f.assignments.push(target);if(/style|className|innerHTML|outerHTML/.test(target))f.styleWrites.push({target,value:s.slice(n.right.start,n.right.end),line:n.loc.start.line});}
 if(n.type==='CallExpression'||n.type==='NewExpression'){const callee=s.slice(n.callee.start,n.callee.end);f.calls.push({callee,line:n.loc.start.line});if(/Event|Handler/.test(callee))f.events.push(s.slice(n.start,n.end));if(/Timeout|Interval/.test(callee))f.timers.push(s.slice(n.start,n.end));}
 if(n.type==='Literal'&&typeof n.value==='string')f.strings.push(n.value);
 });}
 return f;
})}
if(require.main===module){const dir=process.argv[2]||'work/webgui_v2/original/WEBGUI/JS';const result=analyze(dir);fs.writeFileSync('work/webgui_v2/ast_inventory.json',JSON.stringify(result,null,2));console.log(result.map(x=>({file:x.file,es3:x.es3,error:x.error,functions:x.functions.length,nodes:x.nodeCount,styleWrites:x.styleWrites.length,timers:x.timers.length})));}
module.exports={getAST,walk,analyze};
