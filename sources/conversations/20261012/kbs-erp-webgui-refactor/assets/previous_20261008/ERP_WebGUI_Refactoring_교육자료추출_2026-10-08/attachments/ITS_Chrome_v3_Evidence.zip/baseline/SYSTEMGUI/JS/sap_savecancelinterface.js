// =======================================================================================
// SAP_SaveCancelInterface.js
// -------------------------
// SAP SaveCancel interface
//

// --------------------------------------------------------------------------------------
// SAP_SaveCancelInterface() - INTERFACE
// ------------------------------------
// declares the SAP Save and Calcel Interface 
//

var SAP_SaveCancelInterface = {
    id:             "SAP_SaveCancelInterface",
    save:           SAP_SaveCancelInterface_save,
    saveImmediate:	SAP_SaveCancelInterface_saveImmediate,
    cancel:      SAPWF_fnop
}
// 	changed	: ... save: SAPWF_fnop ... 
// 	into	: ... save: SAP_SaveCancelInterface_save ...


function  SAP_SaveCancelInterface_saveImmediate(targetFrameName){
	return;
}

//==============================================================================
// 	changed by	: 	Jens Glander
// 	date		:	/07/2000
// 	comment		:	save()-Function should do the same thing as saveImmediate()
// 		
//	more		: 
//==============================================================================

function  SAP_SaveCancelInterface_save(targetFrameName){
	return;
}
