
function getXPos( obj )
{
	var x = 0, parentElement;

	parentElement = obj.offsetParent;
	if( parentElement != null ) x = getXPos( parentElement );
	if ( obj.clientLeft )
		return x + obj.offsetLeft + obj.clientLeft ;
	else
		return x + obj.offsetLeft;
}
function getYPos( obj )
{
	var y = 0, parentElement;
	parentElement = obj.offsetParent;
	if( parentElement != null ) y = getYPos( parentElement );
	if ( obj.clientTop )
		return y + obj.offsetTop + obj.clientTop;
	else
		return y + obj.offsetTop;
}


function SAPCB_getElementById( id )
{
	if (webguiIsIE4())
		wgf = document.all[ "webguiform"];
	else
		wgf = document.getElementById("webguiform");
	return wgf;
}


function SAP_logoffOnClick( object )
{
	var rootPage = SAPWF_getServiceRootPage();
	if( rootPage != null )
	{
		if( SAPWF_getInterface("SAP_TerminateInterface").isOk() )
		{
			SAPWF_getInterface("SAP_TerminateInterface").terminate( SAP_gVarExitUrl );
			SAPWF_raiseEvent( "SAP_TerminateEvent" );
		}
	}
	else
	{
		alert("SAP_getServiceRootPage failed");
	}
}

function SAP_TemplateLaunchHelp()
//used in: ewt_header, ewt_popupheader
{	var wgform = SAPCB_getElementById( "webguiform" );
	if(wgform != null  ||  document.forms["webguiform"] != null)
		setOkCode("?-HLD", "", "~keeprfccontext=1");
}


/* CheckChange ********************************************************
 */

var checkChangeOnloadFields = new Array();
var checkChangeFlag = false;
var dataIsDirtyFlag = false;

function checkChangeSetState( array )
{
	var wgform = SAPCB_getElementById( "webguiform" );
	var i;
	var formElements = wgform.elements; 
	var formElementsLength = formElements.length;
	for( i=0; i < formElementsLength; i++ )
	{
		var elem = formElements[i];
		if( elem.type != "hidden" ) 
		{
			if( ( elem.type == "radio" ) || ( elem.type == "checkbox" ) ) array[ elem.name ] = elem.checked;
			else array[ elem.name ] = elem.value;
		}
	}
}

function checkChangeOnLoad()
{
	checkChangeFlag = true;
	checkChangeSetState( checkChangeOnloadFields );
} 

function checkChangeCompareArrays( array1, array2 )
{
	var changed = false;
	for( name in array1 )
	{
		if( array1[ name ] != array2[ name ] ) changed = true;
	}
	return changed;
}

function checkChangeCompare()
{
	var curFields = new Array();
	checkChangeSetState( curFields ); 
	return checkChangeCompareArrays( checkChangeOnloadFields, curFields );
}

function checkChangeGetOKCode()
{
	var targetObject = SAPCB_getElementById("webguiform");
	return targetObject.elements[formOkCodeIdx].value;
}

function checkChangeGetFCode()
{
	var targetObject = SAPCB_getElementById("webguiform");
	return targetObject.elements[formFKeyIdx].value;
}

function checkChangeOnBeforeUnload()
{
	if( checkChangeFlag )
	{
		alert("checkChange onbeforeunload");
	}
}

function checkChange()
{
}

function dataIsDirtyOnLoad()
{
	dataIsDirtyFlag = true;
}

