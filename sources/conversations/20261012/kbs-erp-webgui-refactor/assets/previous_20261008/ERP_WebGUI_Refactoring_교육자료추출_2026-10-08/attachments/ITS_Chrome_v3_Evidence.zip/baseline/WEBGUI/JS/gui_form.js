
//tj/2004-08-24/ overlay dynpro with transparent layer
function webguiCreateBusyDiv ( in_zindex )
{
  var bodytag  = document.getElementsByTagName("body");
  if (bodytag == null)
    bodytag = document.getElementsByTagName("frameset");   // hrmpf - some IACs just use framesets
  if (null != bodytag && null != (bodytag = bodytag[0]))
  {
    if (null == (stopdiv = document.getElementById("ITSBusyDiv")))
    {
      var stopdiv  = document.createElement("div");
      stopdiv.setAttribute( "id", "ITSBusyDiv");
      if (in_zindex > 0)
        stopdiv.style.zIndex = in_zindex;
      bodytag.insertBefore( stopdiv, bodytag.firstChild);
    }
    else
    {
      stopdiv.style.display = "block";
      stopdiv.style.visibility = "visible";
      if (in_zindex > 0)
        stopdiv.style.zIndex = in_zindex;
    }
  }
} // webguiCreateBusyDiv()

function webguiSetBusy()
{
  webguiIsBusy = true;

  if (!webguiSetBusyPage)
  {
    if (webguiRefreshPage)
    {
      var
        now = new Date(),
        startTime,
        count = 0;

      freezeOfficeControl();
      webguiCreateBusyDiv();

      toolbarLogo = document.getElementById("webguiCUATitleBarWait");
      if (toolbarLogo) {
        toolbarLogo.style.visibility = "visible";
      }

      toolbarLogo = document.getElementById("webguiToolbarLogo");
      if (toolbarLogo)
      {
        toolbarLogo.className = "WebguiBusyHeaderLogo";
      }

      startTime = now.valueOf();
      var is_ie60 = (navigator.appVersion.indexOf("MSIE 6.0") > -1);
      for (f = 0; f < document.forms.length; f++)
      { var form = document.forms[f];
        for (e = 0; e < form.elements.length; e++)
        { var elem = form.elements[e];
          if (is_ie60)
          {
            elem.ContentEditable = false;
          }
          else
            elem.disabled = true;
          count++;

          // If the form contains many elements disabling them
          // may take to much time. We stop disabling them
          // after a certain threshold.
          if ((count % WEBGUI_DISABLE_CHECK) == 0)
          { var diff;

            now = new Date();
            diff = now.valueOf() - startTime;

            if (diff > WEBGUI_DISABLE_TIMEOUT || diff < 0)
              break;
          }
        } // for (e)
      } // for (f)
    }

    return;
  }

  if (document.activeElement && document.activeElement != null && document.activeElement.blur)
  {
    if (document.activeElement.className && document.activeElement.className != "ListItem")
      document.activeElement.blur();
  }

  if (document.getElementById("webguiPage") != null )
    document.getElementById("webguiPage").style.visibility = "hidden" ;

  if ( webguiStartupBanner != null && webguiStartupBannerText != null )
  {
    webguiStartupBanner.innerHTML = webguiStartupBannerText  ;
    webguiStartupBanner.style.visibility = "visible" ;
  }

  if ( webguiSearchhelpButton != null )
    webguiShButtonManager.Update(null);
  if ( webguiComboBox != null )
    webguiComboBox.style.visibility = "hidden" ;
}

function webguiIsActive()
{
  return !webguiIsBusy && !webguiIsInactive;
}

function webguiResetForm()
{
  targetObject = eval('document.webguiform');

  if (targetObject)
  {
    targetObject.elements[formOkCodeIdx].value = "";
    targetObject.elements[formFocusfieldIdx].value = "";
    targetObject.elements[formFKeyIdx].value = "";
    targetObject.elements[formSearchHelpIdx].value = "";
    targetObject.elements[formMenuItemIdx].value = "";
    targetObject.elements[formControlIdx].value = "";
    targetObject.elements[formEventIdx].value = "";
    targetObject.elements[formEventPrmIdx].value = "";
    if (targetObject.elements[formWebguiUserAreaHeight]
        && targetObject.elements[formWebguiUserAreaHeight].name.indexOf("~webgui")==0)
      targetObject.elements[formWebguiUserAreaHeight].value = "";
    if (targetObject.elements[formWebguiUserAreaWidth]
        && targetObject.elements[formWebguiUserAreaWidth].name.indexOf("~webgui")==0)
      targetObject.elements[formWebguiUserAreaWidth].value = "";
    targetObject.elements[formDynproTypeIdx].value = "";
    targetObject.elements[formWebguiModalWindow].value = "";

    if(webguiModalNo>0 && !webguiFullScreenPopup)
      targetObject.target = "_parent";
    else
      targetObject.target = "_self";

    webguiSetBusyPage = WEBGUI_BUSY_PAGE;
    webguiIsBusy = false;
    webguiRefreshPage = true;
  }
}

function submitForm(params, in_bNoR3Submit)
{
  var i, j, el, arr, par;
  var p, s; // parent, self/string

  if (!webguiIsActive())
    return;

  // INFOCTRL - is the timer set? We don't need it anymore.
  if (window.timerctrl_timer)
  {
    clearTimeout(window.timerctrl_timer);
  }

  targetObject = eval('document.webguiform');

  if (webguiIsPopup
      || (!!targetObject && ((20 > targetObject.elements[formWebguiUserAreaHeight].value)
                          || (20 > targetObject.elements[formWebguiUserAreaWidth].value)) )
      )
    webguiSetUserArea();

  if (webguiDynpro && !webguiIsPopup)
    webguiGetDynproScrollPos();

  if ( targetObject.elements[formOkCodeIdx].value == "" )
  {
    if (document.toolbarform && document.toolbarform.elements["OKCodeField"])
    {
      targetObject.elements[formOkCodeIdx].value =
        document.toolbarform.elements["OKCodeField"].value;
    }

    if (targetObject.elements[formOkCodeIdx].value == "" && !in_bNoR3Submit)
      targetObject.elements[formOkCodeIdx].value = "/0" ;
  }

  if (params)
  {
    if (targetObject.saveAction)
      targetObject.action = targetObject.saveAction;
    else
      targetObject.saveAction = targetObject.action;

              targetObject.action += "?";
    targetObject.action += params;
  }

  // Update performance data
  if (document.webguiform)
  {
    if (document.webguiform.elements[formWebguiStartRequestTime] &&
      document.webguiform.elements[formWebguiStartRequestTime].name.indexOf("~webgui")==0)
    {
      var
        now = new Date();

      document.webguiform.elements[formWebguiStartRequestTime].value = now.valueOf();
    }
  }

  /* Set positions of all modal windows
   */

  if ( targetObject)
  {
    par = self;
    while (par.webguiIsPopup != false && par != par.parent)
    {
      par = par.parent;
    }
    if (par.webguiIsPopup == false && typeof par.webguiOnLoad != "undefined" && (arr = par.webguiOnLoad.a_popups) != null)
    {
      for (i in arr)
      {
        if (arr[ i].popupdocument != null)
        {
          if (arr[ i].webguiModalNo != webguiModalNo)
          {
            el = targetObject.elements[ formWebguiModalLeft].cloneNode( true);
            el.name  = "~webguiModalPixelLeft[" + arr[ i].webguiModalNo + "]";
            try {
              el.value = arr[ i].popupdocument.webguiform.elements[ formWebguiModalLeft].value;
              targetObject.appendChild( el);
            }
            catch (err)
            {
              el = null;
            }
            el = targetObject.elements[ formWebguiModalTop].cloneNode( true);
            el.name  = "~webguiModalPixelTop[" + arr[ i].webguiModalNo + "]";
            try {
              el.value = arr[ i].popupdocument.webguiform.elements[ formWebguiModalTop].value;
              targetObject.appendChild( el);
            }
            catch (err)
            {
              el = null;
            }
          }
        }
      }
    } // if (par.webguiIsPopup == false ...)
  }   // if (document.webguiform) // set position of modal windows

  // set position for editing (step loop) - determine caret position
  if (document.webguiform)
  {
    var el = window.event ? window.event.srcElement : null;
    var l = 999;
    if (el == null)
    {
      el = document.webguiform.elements[formFocusfieldIdx].value;
      if (el)
        (el = document.getElementById(el)) || (el = document.getElementsByName(el)[0]);
    }
    if (el)
    {
      /*  determine cursor position
       */

      // Mozilla Firefox
      s = el.getAttribute("type");
      if (s)
        s = s.toLowerCase();
      if (s && (s == "text" || s == "textarea" || s == "edit"))
      {
        if (typeof el.selectionStart != 'undefined')
          l = el.selectionStart;
      }

      // IE
      // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dhtmltechcol/cols/dnwebteam/webteam12032001.asp
      if (el.isTextEdit && ("input" == (s = el.tagName.toLowerCase()) || "textarea" == s) &&
          typeof document.selection != "undefined" && "none" == document.selection.type.toLowerCase())
      {
        var caretPos = document.selection.createRange();

        if (caretPos)
        {
          var dcaretPos = caretPos.duplicate();
          l = Math.abs(dcaretPos.move("character", -10000));
        }
      }

      if ( l != 999
         || ( ((l = el.getAttribute("value")) && (l = l.length))
            || (l = el.getAttribute("maxlength")) )
      )
      {
        document.webguiform.elements[formWebguiCursorCol].value = l;
        document.webguiform.elements[formWebguiCursorObj].value = document.webguiform.elements[formFocusfieldIdx].value;
      }
    }
  } // if (document.webguiform) -- determine caret position in input field

  // ~flickerfree
  if (self != parent && !(webguiIsPopup && parent.parent == parent)
      && self.webguiSmartView != null && self.webguiSmartView == true
      && ITS_Frameset("GET_SWAP_SETTING")
      && (targetObject.target == null || targetObject.target == ""
         || targetObject.target == "_self" || targetObject.target == "WebGuiDoc"
         || (targetObject.target == "_parent" && webguiIsPopup)
         )
     )
  {
    if (webguiIsPopup && !webguiFullScreenPopup && targetObject.target != "_self")
    {
      p = parent.parent;
      s = parent;
    }
    else {
      p = parent;
      s = self;
    }

    try
    {
      if (!!s.its_frame_mgr && s.name.match(/^itsframe[0-9]_/))
      {
        el = s.its_frame_mgr.FindOtherFrame();
        if (null != el)
          targetObject.target = el.name;
        else
        {
          el = s.its_frame_mgr.FindActiveFrame();
          if (null != el)
            targetObject.target = el.name;
        }
        document.body.style.cursor = "wait";
      }
    }
    catch(err) {}
  }

  // save form data for auto completion
  try
  {
    if (its_ua.ie55up)
    {
      if (document.webguiform)
        window.external.AutoCompleteSaveForm(document.webguiform);
      if (document.toolbarform)
        window.external.AutoCompleteSaveForm(document.toolbarform);
    }
    else if (its_ua.gecko && !its_ua.webkit)
    {
      if (document.toolbarform)
        document.toolbarform.submit();
    }
  }
  catch(err) {}

  targetObject.submit();

  if (document.body && webguiDynpro && targetObject.target == "_self")
    document.body.style.cursor = "wait";

  webguiSetBusy();
}

function webguiRaiseOkCodeField()
{
  setOkCode(document.toolbarform.elements["OKCodeField"].value,'');
}

function setOkCode(FCode,FieldName,params)
{
  targetObject = eval('document.webguiform');
  targetObject.elements[formOkCodeIdx].value = FCode;
  if ( FieldName && FieldName != "" )
    targetObject.elements[formFocusfieldIdx].value = FieldName ;

  submitForm(params);
}

function webguiRaiseFKey(keyid)
{
  targetObject = eval('document.webguiform');

  // Special case for FKey 0 (Enter):
  // Send an OkCode-Event if the OkCode field is not empty
  if (keyid == 0)
  {
    if (document.toolbarform && document.toolbarform.elements["OKCodeField"])
    {
      if (document.toolbarform.elements["OKCodeField"].value != "")
        return webguiRaiseOkCodeField();
    }

  }

  targetObject.elements[formFKeyIdx].value = keyid ;

  submitForm();
}

function webguiRaiseSearchhelp(Field)
{
  if (webguiOldSearchHelp)
  {
    targetObject = eval('document.webguiform');
    targetObject.elements[formSearchHelpIdx].value = Field;

    submitForm();
  }
  else {
    webguiRaiseFKey(4);
  }
}

function raiseEvent(control, event, params)
{
  targetObject = eval('document.webguiform');
  if (targetObject)
  {
    targetObject.elements[formControlIdx].value = control ;
    targetObject.elements[formEventIdx].value = event;

    submitForm(params);
  }
}

function webguiRaiseEvent(control, event, params, target)
{
  targetObject = eval('document.webguiform');
  if (targetObject)
    targetObject.target = target ;

  raiseEvent(control, event, params);
}

function webguiRaiseDataEvent(control, event, params, target)
{
  var
    oldTarget,
    oldRefreshPage,
    oldSetBusyPage;

  targetObject = eval('document.webguiform');
  targetObject.elements[formControlIdx].value = control ;
  targetObject.elements[formEventIdx].value = event;

  // Save old settings
  oldTarget = targetObject.target;
  oldSetBusyPage = webguiSetBusyPage;
  oldRefreshPage = webguiRefreshPage;

  if (target)
    targetObject.target = target;
  webguiSetBusyPage = false;
  webguiRefreshPage = false;

  submitForm(params);

  webguiRefreshPage = oldRefreshPage;
  webguiSetBusyPage = oldSetBusyPage;
  targetObject.target = oldTarget;
}

function webguiRaiseDynproDataEvent(control, dynproControlName, event, okcode, dynproControlType, target, params)
{
  if (!webguiIsActive())
    return;

  targetObject = eval('document.webguiform');
  targetObject.elements[formOkCodeIdx].value = okcode;
  targetObject.elements[formDynproTypeIdx].value = dynproControlType;

  if(params=="")
    params = "~webgui_name_dynprodata=" + dynproControlName;
  else
    params = "~webgui_name_dynprodata=" + dynproControlName + "&" + params;

  webguiRaiseDataEvent(control, event, params, target);
}

function webguiRaiseSelectTabStrip(Control, TabName, FCode, localTS, dynproControlName)
{
  if(localTS=="X")
  {
    if (!tsDataIFRAMEcreated)
      controlCreateDataIFRAME("tsData","display:none;","tabstrip","");

    webguiRaiseDynproDataEvent(Control, dynproControlName, "TabSelect", FCode, "TS", "tsData", "TabName=" + TabName);
    return;
  }

  targetObject = eval('document.webguiform');
  targetObject.elements[formOkCodeIdx].value = FCode;
  targetObject.elements[formControlIdx].value = Control ;
  targetObject.elements[formEventIdx].value = "TabSelect" ;

  // changing name of hidden values alters form elements collection
  // in NS61.  Add param to URL as workaround.
  //targetObject.elements[formEventPrmIdx].name = "TabName" ;
  //targetObject.elements[formEventPrmIdx].value = TabName ;

  submitForm("TabName="+TabName);
}

function webguiRaiseSelectTabStripFromMenu(Control, TabName, FCode, localTS, dynproControlName)
{
  if(localTS=="X")
  {
    if (!tsDataIFRAMEcreated)
      controlCreateDataIFRAME("tsData","display:none;","tabstrip","");

    webguiRaiseDynproDataEvent(Control, dynproControlName, "TabSelectFromMenu", FCode, "TS", "tsData", "TabName=" + TabName);
    return;
  }

  targetObject = eval('document.webguiform');
  targetObject.elements[formOkCodeIdx].value = FCode;
  targetObject.elements[formControlIdx].value = Control ;
  targetObject.elements[formEventIdx].value = "TabSelectFromMenu" ;
  // changing name of hidden values alters form elements collection
  // in NS61.  Add param to URL as workaround.
  //targetObject.elements[formEventPrmIdx].name = "TabName" ;
  //targetObject.elements[formEventPrmIdx].value = TabName ;

  submitForm("TabName="+TabName);
}

function webguiRaiseSelectMenuItem(menuitem)
{
  targetObject = eval('document.webguiform');
  targetObject.elements[formMenuItemIdx].value = menuitem;
  submitForm() ;
}
