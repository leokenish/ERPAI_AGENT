//<HTML><SCRIPT>
// =======================================================================================
// Sap_Its.js
// ---------
// SAP-Its specific JavaScript Functions
//


// --------------------------------------------------------------------------------------
// SAP__addPath()
// --------------
// internal function - do not use
//
function SAP__addPath( path ) {
	return ( (path == null) || (path == "") )? "": "/" + path;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_serviceUrl()
// ----------------
// 
// NEEDS:		String      serviceKey      name of the service
//
// RETURNS:		url to start the its service
//
function SAP_serviceUrl( serviceKey, language, client ) {
    return gvSAP_itsServiceBaseUrl + "/" + serviceKey + "/!";
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_wgateUrl()
// --------------
// see BHTML-function wgateURL
//
// NEEDS:		Object      nameValues      Object containing name/value pairs -
//                                          only object components of type number, 
//                                          string and boolean are considered
//
// RETURNS:		url pointing into the wgate object
//
function SAP_wgateUrl( nameValues ) {
    var lsResult = gvSAP_itsWGateBaseUrl;
    
    if ( (nameValues != null) && (nameValues.length != 0) ) {
        lsResult += "?" + SAPWF_objectToQueryString( nameValues );	
    }
    return lsResult;
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_mimeUrl()
// -------------
// see BHTML-function mimeURL
//
// NEEDS:		String		service		the ITS service
//				String		theme		the theme
//				String		language	the language
//				String		name		additional path and name				
//
// RETURNS:		url pointing into the mime part 
//
function SAP_mimeUrl( service, theme, language, name ) {
	return	gvSAP_itsMimeBaseUrl +
			SAP__addPath( service) +
			SAP__addPath( theme ) + 
			SAP__addPath( language ) + 
			SAP__addPath( name );
}
function SAP_mimeDesignUrl( service, theme, language, name ) {
	if( gvSAP_itsDesignLevel == "" )
	{
		return SAP_mimeUrl( service, theme, language, name );
	}
	else
	{
		if( gvSAP_itsDesign == "" )
		{
			return	SAP_mimeUrl( service, theme, language, name );
		}
		else
		{
			var stylePath = gvSAP_itsDesign + "/" + service + "/" + theme;
			if( gvSAP_itsDesignBaseURL == "" )
			{
				return SAP_mimeUrl( "designs", stylePath, "", name );
			}
			else
			{
				return gvSAP_itsDesignBaseURL + "/designs/" + stylePath + "/" + name;
			}
		}
	}
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_ITScacheImages()
// --------------------
// provides browser image caching 
//
// NEEDS:		String		service		service name
//				String		theme		service theme
//				String		language	service language
//				String		directory	directory relative to mime-path/service/theme/language/ 
//				String[]	imageArr	Array of gif-image-names including .gif or .jpg ...
//
// RETURNS:		nothing
//
function SAP_ITScacheImages( service, theme, language, directory, imageArr ) {
	SAP_cacheImages( SAP_mimeUrl( service, 
								  theme, 
								  language, 
							      directory ), 
					 imageArr );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_launchUrl()
// ---------------
// fires a SAP launch event with the give url
//
// NEEDS:		String      url             the url 
//              String      target          E { 'inplace', 'extern', 'hidden' } - default is inplace
//
// RETURNS:		Object                      the (perhaps modified) event object, if a handler was
//                                          found, null otherwise
//	
function SAP_launchUrl( url, target ) {
    return SAPWF_raiseEvent( "SAP_LaunchEvent", 
                              { serviceType:    "SAP_URL", 
                                url:            url,
                                target:         target
                              } 
                            );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_launchSimpleSAPDocumentation()
// ----------------------------------
// fires a SAP launch event with the give simple SAP docu url
//
// NEEDS:		String      url             the url pointing to the simple SAP documentation page
//              String      target          E { 'inplace', 'extern', 'hidden' } - default is inplace
//
// RETURNS:		Object                      the (perhaps modified) event object, if a handler was
//                                          found, null otherwise
//	
function SAP_launchSimpleSAPDocumentation( url, target ) {
    return SAPWF_raiseEvent( "SAP_LaunchEvent", 
                              { serviceType:    "SAP_SIMPLE_DOCU_URL", 
                                url:            url,
                                target:         target 
                              } 
                            );
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_launchSAPTransaction()
// -------------------------
// fires a SAP launch event with the give SAP transaction parameters
//
// NEEDS:       String      logSys          the Name of the SAP logical system
//              String      tCode           the Tx code
//              Object      paramObj        parameter object containing only number, string and boolean
//                                          components
//              String      target          E { 'inplace', 'extern', 'hidden' } - default is inplace
//
// RETURNS:		Object                      the (perhaps modified) event object, if a handler was
//                                          found, null otherwise
//	
function SAP_launchSAPTransaction( logSys, tCode, paramObj, target, noErrMsg ) {
    var loEvtResult = SAPWF_raiseEvent( "SAP_LaunchEvent", 
                                         { serviceType:        "SAP_TRANSACTION", 
                                           logSys:             logSys,
                                           tCode:              tCode, 
                                           params:             SAPWF_objectToQueryString( paramObj ),
                                           target:             target 
                                         } 
                                       );
    if (! noErrMsg) {
        if (loEvtResult == null) {
            alert( "Error in SAP_launchSAPTransaction\n\nUnable to find event handler for SAP_LaunchEvent" );
        } else if (loEvtResult.result == false) {
            alert( "Error in SAP_launchSAPTransaction\n\nUnable to find service url for transaction\n" +
                   "LogSys: " + logSys + "\nTCode:  " + tCode + "\nYou may not have the transaction in your roles." );
        }
    }
    
    return loEvtResult;    
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_WebFrameworkOnload()
// ------------------------
// page onload event handler
//
// NEEDS:		nothing
//
// RETURNS:		nothing
// 
function SAP_WebFrameworkOnload() {
}
// --------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------
// SAP_getWorkplaceInterface()
// ----------------------------
// returns the reference to the public Workplace Interface (if present)
//
// NEEDS:		nothing
//
// RETURNS:		reference to the public Workplace Interface or null, if the application
//              was not launched from the workplace (i.e. no workplace is present).
// 
function SAP_getWorkplaceInterface() {
    return SAPWF_queryInterfaceOutside( "SAP_WorkplaceInterface" );
}
// --------------------------------------------------------------------------------------

// =======================================================================================
