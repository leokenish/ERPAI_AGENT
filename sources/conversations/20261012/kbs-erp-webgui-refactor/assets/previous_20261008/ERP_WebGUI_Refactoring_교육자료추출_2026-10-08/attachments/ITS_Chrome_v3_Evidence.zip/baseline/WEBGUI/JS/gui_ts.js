/************************************************************************************
  SAP ITS
  Tabstrip Control Javascript Functions

  // tj

************************************************************************************/

// tab menu array has the structure: *(tab title, tab FCode, tab isLocal)
//

function TSMenuSet(tabStripName, tabObjectName, tabs, selected)
{
  var i,
      maxChars = 0,
      str="",
      menuStyle = document.getElementById("MenuFrame0").style,
      sel
      ;

  onkeydown = "onkeydown='keyNavMenu(event);' ";
  onfocus   = "onfocus='Hilight(event);' ";
  onhelp    = "onhelp='return false;' ";

  str = "<div id=\"scrollDIV\" style=\"height:99.99%;overflow-y:auto;overflow-x:hidden\""
      + onkeydown + onhelp + "tsname=\"" +tabObjectName+ "\" DEPTH=\"0\">";
  for (i = 0; i < tabs.length; i += 3)
  {
    // add 6px padding to compensate the space reserved for "check" symbol of regular menu
    str += "<div class=\"NewMenuItem\" style=\"padding-left:6px;height:" + cLineHeight + "\" "
         + onfocus
         + ((i/3 != selected)
            ? "onmouseover=\"Hilight(event);\" onmouseout=\"Lowlight(event);\" "
              + "onclick=\"parent.webguiRaiseSelectTabStripFromMenu('"
              + tabObjectName + "', '" + (i/3 + 1) + "', '" + tabs[i+1] + "','" + tabs[i+2] + "','"
              + tabStripName.substring(3) + "'); "
              + " parent.CloseMenus(0);\""
            : ""
           )
         + ">"
         + "<label style='display:none'>" + tabs[i] + " " + a11y_tabstriptab_type
         + ((i/3 == selected)
            ? " Active</label><b>" + tabs[i].replace(/ /g, "&nbsp;") + "</b>"
            : "</label>" + tabs[i].replace(/ /g, "&nbsp;")
           )
         + "</div>";

    if (i/3 == selected) sel = i/3;

    if (tabs[i].length > maxChars)
      maxChars = tabs[i].length;
  }
  str += "</div>";

  return {l: i / 3, w: maxChars, str: str, selected: sel};

} // TSMenuSet()


function TSMenuShow ( tabStripName )
{
  var
    menuFrame = document.getElementById("MenuFrame0"),
    menuDoc,
    menuBody,
    icon,
    body = document.getElementsByTagName("body")[0],
    v, x, y, sel,
    oPS = new objPositionSize();

  if (menuFrame.contentDocument)
  { //moz
    menuBody = (menuDoc = menuFrame.contentDocument).defaultView.document.body;
  }
  else if (menuFrame.contentWindow)
  { //ie
    menuBody = (menuDoc = menuFrame.contentWindow.document).body;
  }

  icon = document.getElementById(tabStripName + "-PULLDOWN").parentNode;
  if (null != icon)
  {
    v = wgu_getAbsolutePosition(icon, body);

    icon.absLeft = x = v.x;
    icon.absTop  = y = v.y;

    v = TSMenuSet(tabStripName, eval(tabStripName + "_OBJECT"), eval(tabStripName + "_TITLES"), eval(tabStripName + "_ACTIVE"));
    menuBody.innerHTML = v.str;
    sel = v.selected;

    menuFrame.style.width  = cCharWidth * v.w + 4 + "px";
    menuFrame.style.height = cLineHeight * v.l + 3 + "px";    // + 14 + 7

    oPS = calcFramePositionResize(menuFrame.offsetWidth, menuFrame.offsetHeight,
                                  x, y, icon.offsetWidth, icon.offsetHeight,
                                  null, null,
                                  body
                                 );

    with (menuFrame.style)
    {
      left = oPS.x; top = oPS.y; height = oPS.h; width = oPS.w;
      visibility = "visible";
      v = menuDoc.getElementById("scrollDIV");
      try
      {
        dom_focus(menuFrame.contentWindow);
        if (null != v)
        {
          dom_focus(v.childNodes[0]);
        }
      } catch(err) {}
    }
    menuFrame.keyNavIndex = sel;
    menuFrame.contentWindow.keyNavIndex = sel;
  }

} // TSMenuShow()


function TSMenuHide ( tabStripName )
{
  document.getElementById("MenuFrame0").style.visibility = "hidden";

} // TSMenuHide()
