// ==========================================================
// Event Handlers
// ==========================================================

var webguiSavedFocusObj = null;
var WEBGUI_FOCUS_TYPE_DYNPRO    = 1;
var WEBGUI_FOCUS_TYPE_TABLE     = 2;
var WEBGUI_FOCUS_TYPE_ALV       = 3;
var WEBGUI_FOCUS_TYPE_TEXTEDIT  = 4;
var WEBGUI_FOCUS_TYPE_TREE      = 5;

function webguiInitMenu()
{
 if (window.isMenu)
  startIt();
}


function webguiOnLoad()
{
  var i, j;

  webguiInitMenu();

  webguiResetOldFocus();

  if (document.getElementById("webguiPage") != null )
  {
    document.getElementById("webguiPage").style.visibility = "visible" ;
  }

  if (webguiModalNo != 0 && !webguiFullScreenPopup)
  {
    var
      modalFrame = parent.document.getElementsByName(window.name)[0];

    if (modalFrame != null)
      modalFrame.style.visibility = "visible";
  }
  if (!webguiIsPopup)
  {
    if (null != webguiOnLoad.a_popups
        && null != webguiOnLoad.a_popups[webguiOnLoad.a_popups.length-1]
        && null != (i = webguiOnLoad.a_popups[webguiOnLoad.a_popups.length-1].popupwindow)
       )
    {
      if (!window.webguiDontFocusThisWin)
      {
        dom_focus(i);
      }
      if (i.webguiSetFocus && null != i.webguiFocusField && "" != i.webguiFocusField)
         i.webguiSetFocus();
    }
  }

  webguiUserArea = document.getElementById("webguiUserArea");
  webguiDynpro = document.getElementById("webguiDynpro");
  popup = document.getElementById("webguiPopup");

  // workaround for IE5, resetting height for popup box
  if (popup && isIE5())
  {
    if(webguiNoPopupMargin)
    {
      popup.style.height=0;
      popup.style.height="100%";
    }
    else
    {
      popup.style.height=0;
      popup.style.height="80%";
    }
  }

  if (webguiUserArea)
  {
    var toolbar   = document.getElementById("webguiToolbar");
        container = webguiUserArea.parentNode,
        statusbar = document.getElementById("webguiStatusbarWrapperTable");

    if (null == toolbar)
      toolbar = document.getElementById("webguiCUA");
    if (null == statusbar)
      statusbar = document.getElementById("webguiStatusbar");

    if (null != toolbar && null != container)
    {
      if (true == webguiIsPopup)
      {
        webguiUserArea.style.height = container.clientHeight + "px";
      }
      else
      {
        try
        {
          if (statusbar)
          {
            webguiUserArea.style.height = (document.body.clientHeight - container.offsetTop - statusbar.offsetHeight) + "px";
          }
          else
          {
            webguiUserArea.style.height = (document.body.clientHeight - container.offsetTop) + "px";
          }
        }
        catch(err) {}
      }
    }
  }

  /*
     Fullscreen Control ?
  */

  if (null != webguiDynpro && null != webguiUserArea)
  {
    for (i = webguiDynpro, j = null;
         null != i && (1 != i.nodeType || null == (j = i.getAttribute("controlcontainer")));
         i = i.nextSibling
        )
      ;
    if (j != null && i.className != "INFOCTRL" && i.className != "")
    {
      i.style["-moz-box-sizing"] = "border-box";
      i.style["box-sizing"] = "border-box";
      i.style.height = "100%";
      i.style.width  = "100%";

      var c1, c2, c3, c4, c5;
      if (null != (c1 = document.getElementById("webguiPage")))
      {
        c2 = document.getElementById("webguiCUAtr");
        c3 = document.getElementById("webguiUAtd");
        c4 = document.getElementById("webguiStatusbartr");

        c3.style.height = webguiUserArea.clientHeight + "px";
        c3.style.width  = webguiUserArea.clientWidth  + "px";
//        c3.style.height = c1.clientHeight - ( c2.offsetHeight + c4.offsetHeight + 32) + "px";
//        c3.style.width  = c1.clientWidth - 12 + "px";

        c4 = document.getElementById("webguiUAtr");
        c4.style.height = c3.style.height;
        c4.style.width  = c3.style.width;
      }
    }
  }

  if (webguiModalNo > 0 && webguiDynpro && modalFrame && transactionType!="EWT")
  {

  //
  // resize modal window to hide scrollbars
  //
    var
      webguiDynproBorder = webguiDynpro.childNodes[0],
      modalButtonBar = document.getElementById("WebguiModalButtonBar"),
      modalToolbarHeight = document.getElementById("WebguiModalTitleBar").offsetHeight,
      modalTooBigShrinkPx = 30,
      modalScrollBarDim = 15;
      newModalWidth = modalFrame.clientWidth,
      newModalHeight = modalFrame.offsetHeight,
      addScrollbarWidth = false,
      addScrollbarHeight = false;

    if (modalButtonBar)
      modalToolbarHeight += 30;  // 30 = height of buttonbar

    if (newModalWidth > parent.document.body.offsetWidth && parent.document.body.offsetWidth > modalTooBigShrinkPx) //tj/2002-04-18
    {
      newModalWidth = parent.document.body.offsetWidth - modalTooBigShrinkPx;
      addScrollbarHeight = true;
    }
    else if (webguiDynproBorder.offsetWidth < parent.document.body.offsetWidth)
    {
      // for width, we always add extra spaces for the modal
      // and we're checking if adding extra spaces would make
      // modal too big
      if (webguiDynproBorder.offsetWidth < newModalWidth &&
        newModalWidth + 10 < parent.document.body.offsetWidth)
        newModalWidth += 10;
      else if (webguiDynproBorder.offsetWidth + 15 < parent.document.body.offsetWidth)
        newModalWidth = webguiDynproBorder.offsetWidth + 15;
    }

    var totalModalHeight = webguiDynproBorder.offsetHeight + parseInt(modalToolbarHeight);
    if (newModalHeight> parent.document.body.offsetHeight && parent.document.body.offsetHeight > modalTooBigShrinkPx) //tj/2002-04-18
    {
      newModalHeight = parent.document.body.offsetHeight - modalTooBigShrinkPx;
      addScrollbarWidth = true;
    }
    else if (totalModalHeight > newModalHeight && totalModalHeight + 10 < parent.document.body.offsetHeight)
      newModalHeight = totalModalHeight + 10;

    // If we shrink the modal, we need to anticipate extra
    // spaces used by vert. and hori. scrollbars
    if (addScrollbarHeight)
      newModalHeight += modalScrollBarDim;

    if (addScrollbarWidth)
      newModalWidth += modalScrollBarDim;

    if (newModalWidth != modalFrame.clientWidth || newModalHeight != modalFrame.offsetHeight)
    {
      if (modalFrame.style.width.match(/%$/) == null)
        modalFrame.style.width = newModalWidth;
      if (modalFrame.style.height.match(/%$/) == null)
        modalFrame.style.height = newModalHeight;
    }

  //
  // resize oversized-containers (containers with dimensions larger
  // than modal window) to avoid scrollbars
  //
    var
      container_count = 0,
      container_resize,
      curr_container,
      parent_container,
      container_arr = document.getElementsByName("webguictnr");

    if (container_arr)
      container_count = container_arr.length;
    else
      container_count = 0;

    for (i=0; i<container_count; i++)
    {
      curr_container = container_arr[i];

      parent_container = webguiGetContainer(curr_container.parentNode);

      container_resize = true;
      if (parent_container)
      {
        curr_container.cumulative_top = curr_container.style.pixelTop + parent_container.cumulative_top;
        curr_container.cumulative_left = curr_container.style.pixelLeft + parent_container.cumulative_left;
      }
      else
      {
        curr_container.cumulative_top = curr_container.style.pixelTop;
        curr_container.cumulative_left = curr_container.style.pixelLeft;
      }

      if (curr_container.cumulative_top + curr_container.offsetHeight <= modalFrame.offsetHeight &&
        curr_container.cumulative_left + curr_container.offsetWidth <= modalFrame.offsetWidth)
        continue;

      for (j=0; j<curr_container.childNodes.length; j++)
      {
        var
          curr_child = curr_container.childNodes[j],
          child_absTop, child_absLeft;

        if (curr_child.style != null)
        {
          child_absTop = curr_child.style.pixelTop + curr_container.style.pixelTop,
          child_absLeft = curr_child.style.pixelLeft + curr_container.style.pixelLeft;

          if (curr_child.tagName == "NOBR" && curr_child.childNodes.length > 0)
            curr_child = curr_child.childNodes[0];

          if ((curr_child.style.pixelTop + curr_container.cumulative_top > modalFrame.offsetHeight) ||
            (curr_child.style.pixelLeft + curr_container.cumulative_left > modalFrame.offsetWidth))
          {
            container_resize = false;
            break;
          }
        }  // if (curr_child.style != null)
      }
      if (container_resize)
      {
        curr_container.style.pixelHeight = webguiDynpro.offsetHeight - curr_container.cumulative_top - 10;
        curr_container.style.pixelWidth = webguiDynpro.offsetWidth - curr_container.cumulative_left - 10;
      }
    }
  }

<!-- ... -->

  if (window.controlOnLoad)
    window.controlOnLoad();

  //Errors w/multiple channels in workplace.  Document can be hidden
  //causing infinite loop in these calculatins see customer message 136928 2001
  if(document.body.clientWidth!=0)
  {
    webguiCUAresizeButtonBar();
  }
  webguiCUACreateLocalMenu();

  //tj/2003-03-06/ toggle Menusl OKCode field; function defined in d_generator.html
  if ( typeof( window.toggleMenuslOKCodeFieldOnload) != "undefined")
    toggleMenuslOKCodeFieldOnload();

  /* Now, set user area parameters
   */

  if (!webguiIsPopup)
  {
    webguiSetUserArea();
    if ((j = webguiOnLoad.a_popups) != null)
    {  // call webguiSetUserArea() of all popups
      for (i in j)
        (j[ i].webguiSetUserArea)();
    }
  }
  else
  { // else it's a popup - save information on base dynpro
    var par = parent;
    while (par.webguiIsPopup != false && par != par.parent)
      par = par.parent;
    if (par.webguiIsPopup == false && typeof par.webguiOnLoad != "undefined")
    {
      if (par.webguiOnLoad.a_popups == null)
        par.webguiOnLoad.a_popups = new Array();
      if (par.webguiOnLoad.a_popups != null)
      {
        l = par.webguiOnLoad.a_popups.length;
        l = (par.webguiOnLoad.a_popups[ l] = new Object());
        if ( l != null)
        {
          l.webguiSetUserArea    = webguiSetUserArea;
          l.webguiModalNo        = webguiModalNo;
          l.popupdocument        = self.document;
          l.popupwindow          = self;
        }
      }
    }
  }

  if ("string" == typeof window.webguiFocusWin && "" != window.webguiFocusWin)  // called from ITS_BROWSER_WINDOW_OPEN
  {
    window.webguiFocusWin = new wguObjExtWindow("", window.webguiFocusWin, webguiNewWindowAttributes, null, webguiNewWindowFocusTimerTime, webguiNewWindowLoadTimerTime);
  }
  else
  {
    window.webguiFocusWin = new Array();
    for (i = 0; null != webguiNewWindowUrl && i < webguiNewWindowUrl.length; i++)
    {
      if (webguiNewWindowUrl[i])
      {
        window.webguiFocusWin[i] = new wguObjExtWindow(webguiNewWindowUrl[i], webguiNewWindowName[i], webguiNewWindowAttributes, null, webguiNewWindowFocusTimerTime, webguiNewWindowLoadTimerTime);
      }
    }
  }

  // Collect performance data
  webguiPerfGetData();
  if (document.body)
    document.body.style.cursor = "";

} // webguiOnLoad()


/* -------------------------------------------------
  webguiDoClick - new crossbrowser implementation
  radiobuttons and checkboxes don't use webguidoclick
  any more
  he.pi 20050125
 ------------------------------------------------- */

function webguiDoClick(e, onList, in_target)
{

  if (!webguiIsActive())
    return;

  var
    altTypeClicked     = false,
    deleteOldSelection = true,
    selected           = false,
    selectedElement    = null,
    thisEvent          = (null != e || null != window.event) ? new its_event(e) : null,
    targetObject;

  if (null != thisEvent)
  {
    if (!thisEvent.target)
    {
      return;
    }
    selectedElement = thisEvent.target;
    thisEvent.stopPropagation();
  }
  else if (null != in_target)
  {
    selectedElement = in_target;
  }
  else return;

  var dynproElement = webguiFindSuperiorDynproElement(selectedElement);
  if (dynproElement != null)
  {
    selectedElement = dynproElement;
  }

  targetObject = getMainWindow().document.webguiform;

  if (onList)
  {
    webguiSelectListElement(selectedElement, thisEvent);
  }
  else
  {
    // unrecord clicked character position
    targetObject.elements[formWebguiCursorObj].value = "";
    targetObject.elements[formWebguiCursorCol].value = "";

    // Special logic for tabstrip pulldown menu as it is not a focus element
    if (null != selectedElement.className && selectedElement.className.substr(0,17) == "PULLDOWN-TABSTRIP")
    {
      webguiTSPulldownMenu = selectedElement;
      // Use MenuDowncheck to catch exceptions from IFRAME (e.g not fetched)
      MenuDowncheck(webguiTSPulldownMenu, e);
    }
    else if (webguiTSPulldownMenu)
    {
      TSMenuHide( webguiTSPulldownMenu.id.substring(0, webguiTSPulldownMenu.id.length-9) ); //substring not including '-PULLDOWN'
      webguiTSPulldownMenu = null;
    }

    if (webguiIsFocusElement(selectedElement))
    {
      var fObj = new webguiFocusObj(1, selectedElement);
      webguiSaveFocus(fObj);
      webguiSetDynproFocus(fObj);
      webguiSetSelClassOnDynproElement(selectedElement, thisEvent);
    }
    else
    {
      if (selectedElement.className && selectedElement.className == "OKCodeField")
      {
        targetObject.elements[formFocusfieldIdx].value = "";
        selectedElement = null;
      }
    }

     //if (selectedElement.getAttribute("ct") != "checkbox" && selectedElement.getAttribute("ct") != "radio")
     //  dom_focus(selectedElement);
    selected = true;




    if (selectedElement && selectedElement.getAttribute("sh") )
    {
            if (selectedElement.tagName == "INPUT")
                webguiEnableSearchhelpButton(selectedElement.name, e);
            else
                webguiEnableSearchhelpButton(selectedElement.id, e);
    }

    // search help focus field
    if (selectedElement &&
        selectedElement.className == "inputSelected" &&
        selectedElement.name.substring(0,15)  == "DDSHSELOPT-LOW[")
    {
        var shFocus = document.getElementsByName("~SEARCHHELPFOCUS")[0];
        if (shFocus)
            shFocus.value = selectedElement.name;
    }
  }
}


function webguiDoMouseDown ( in_event )
{
  // Disable modal resize for now
  if (webguiModalIsResizeEvent(in_event) && 0)
  {
    webguiModalDoMouseDown(in_event, true);
  }
}



function webguiDoDblClick(e)
{
  if (!webguiIsActive())
    return;

  var thisEvent          = new its_event(e);

  if (!thisEvent.target){
    //alert("debug: thisEvent.target is undefined");
    return;
  }

  thisEvent.stopPropagation;
  var selectedElement = thisEvent.target;


/* he.pi crossbrowser
  if(e)
    selectedElement = e.srcElement;
  else
  {
    selectedElement = window.event.srcElement;
    e = window.event;
  }
he.pi crossbrowser */

  if ( selectedElement == null )
    return ;

  if (selectedElement.className.substr(0,17) == "PULLDOWN-TABSTRIP")
  {
    webguiDoClick(e);
    //he.pi crobro to do
    thisEvent.cancel;

/* he.pi crossbrowser
    e.cancelBubble = true;
    e.returnValue = false;
*/

  return;
  }
   thisEvent.cancel;

/* he.pi crossbrowser
  e.cancelBubble = true;
  e.returnValue = false;
*/

  if ( selectedElement.tagName == "INPUT" )
  {
    targetObject = getMainWindow().document.webguiform;
    if (!!selectedElement.name)
      targetObject.elements[formFocusfieldIdx].value = selectedElement.name;
    else if (!!selectedElement.id)
      targetObject.elements[formFocusfieldIdx].value = selectedElement.id;

  }
  else
  {
    targetObject = getMainWindow().document.webguiform;
    var i = 0;
    while (selectedElement.id=="" && !!(selectedElement.parentNode) && i < 4)
    {
      selectedElement = selectedElement.parentNode;
      i++;
    }

    targetObject.elements[formFocusfieldIdx].value = selectedElement.id ;
  }

  webguiRaiseFKey(2);
}

function webguiDoFocus(e, fObj)
{
  var thisEvent = (null != e || null != window.event) ? new its_event(e) : null,
    targetObject,
    selectedElement,
    dynproElement;

  if (null != thisEvent)
  {
    if (!thisEvent.target)
    {
      return;
    }
    selectedElement = thisEvent.target;
    thisEvent.stopPropagation();
  }

  if (!!fObj)
  {
    if (fObj.focusType == 1)
      webguiSelectListElement(selectedElement, thisEvent);
    else
      webguiSaveFocus(fObj);
  }
  else
  {
    if (!!selectedElement && webguiIsFocusElement(selectedElement))
    {
      dynproElement = webguiFindSuperiorDynproElement(selectedElement);
      fObj = new webguiFocusObj(1, dynproElement);
      webguiSaveFocus(fObj);
      webguiSetDynproFocus(fObj);
      webguiSetSelClassOnDynproElement(selectedElement, thisEvent);
    }
  }
}

function webguiDoTabKey(eventHandler)
{
  if (eventHandler && eventHandler.srcElement)
    if (tc = webguiGetTC(eventHandler.srcElement))
    {
      eventHandler.cancelBubble = true;
      eventHandler.returnValue = false;
      webguiTCEmulateTab(tc, eventHandler.srcElement);
    }
}


function _webguiServerResize( in_event )
{
  if (!_webguiServerResize.fired)
  {
    if (webguiIsPopup && false === parent.webguiIsPopup)
    {
      if (parent.controlDoResize)
        parent.controlDoResize(in_event, true);      // true => resize immediately
      parent.webguiSetUserArea();
    }
    if (window.controlDoResize)
      window.controlDoResize(in_event, true);        // true => resize immediately
    webguiSetUserArea();

    //tj/120110/ send a blank instead of an ENTER for resize, note 1671794
//  setOkCode("/0");
    setOkCode("\ ");

    _webguiServerResize.fired = true;
  }
}
_webguiServerResize.timer = null;
_webguiServerResize.fired = false;


function webguiDoResize (in_event, immediate)
{
    // if (!immediate) {} /tj/deleted

    var ev = in_event ? in_event : window.event;
    var docbody = document.body;
    var w;

    //Errors w/multiple channels in workplace.  Document can be hidden
    //causing infinite loop in these calculatins see customer message 136928 2001

    if ((typeof docbody != "undefined" && docbody != null) && docbody.clientWidth != 0)
    {
      webguiCUAresizeButtonBar();
    }

  if (webguiUserArea)
  {
    var toolbar   = document.getElementById("webguiToolbar");
        container = webguiUserArea.parentNode,
        statusbar = document.getElementById("webguiStatusbarWrapperTable"),
        popup     = document.getElementById("webguiPopup");

    if (null == toolbar)
      toolbar = document.getElementById("webguiCUA");
    if (null == statusbar)
      statusbar = document.getElementById("webguiStatusbar");

    if (null != toolbar && null != container)
    {
      if (true == webguiIsPopup)
      {
        webguiUserArea.style.height = container.offsetHeight + "px";
      }
      else
      {
        try
        {
          if (statusbar)
          {
            webguiUserArea.style.height = (document.body.clientHeight - container.offsetTop - statusbar.offsetHeight) + "px";
          }
          else
          {
            webguiUserArea.style.height = (document.body.clientHeight - container.offsetTop) + "px";
          }
        }
        catch(err) {}
      }
    }
  }

  /* the server is doing the resize
   */
  if (!webguiIsPopup && !!webguiIsDynproServerResize && typeof ITS_Frameset != 'undefined' && !ITS_Frameset("ISACTIVATING"))
  {
    var t = _webguiServerResize.timer;
    _webguiServerResize.timer = null;
    if (null != t)
    {
      window.clearTimeout(t);
    }
    _webguiServerResize.timer = setTimeout("_webguiServerResize()", 250);
  }
  else
  {
    if (window.controlDoResize)
        window.controlDoResize(ev);
    webguiSetUserArea();
  }

  if (typeof ITS_Frameset != 'undefined')
    ITS_Frameset("RESETACTIVATINGFLAG");
} // webguiDoResize()


function webguiEventOnControl( in_evt )
{
  function _isControl( in_obj )
  {
    var rc = false;
    var objclass;
    if (in_obj)
    {
      objclass = in_obj.className;
      if (objclass != null)
      {
        //alert("webguiEventOnControl()._isControl(): Object(" + in_obj.tagName + ") class = " + objclass);
        for (var cl in garr_controlClasses)
        {
          if (garr_controlClasses[ cl] == objclass)
          {
            rc = true;
            break;
          }
        } // for
      }
    }
    return rc;
  } // _isControl()

  var rval = obj;
  var evt;
  var obj,
      parobj,
      rootobj = document.getElementsByTagName("body")[0];
  var isSearch = true;

  evt = in_evt ? in_evt : ((window.event) ? window.event : "");
  if (evt) {
    // look for control
    obj = event.srcElement;
    while (obj != rootobj) {
      if (_isControl( obj)) {
        //alert("webguiEventOnControl(): Object " + obj.tagName + "(" + obj.className + ") is a control");
        rval = obj;
        break;
      }
      obj = obj.parentNode;
    }
  }
  return rval;
} // webguiEventOnControl()




// ==========================================================
// Event Handlers
// ==========================================================

function webguiDoScroll ()
{
}

function webguiDoKeyDown(evt)
{
  var e = null;

  if (null != evt || null != window.event)
  {
    e = new its_event(((evt != null)? evt : window.event));

    if (navigator.appVersion.indexOf("MSIE") != -1)  // only for MSIE
    {
      // remap function keys to prevent browser activity
      var kc = Number(e.keyCode);
      if (kc > 111 && kc < 124)   // pressed a function key?
      {
        kc += 400;
        e.event.keyCode = (511 === kc ? 0 : kc);
        e.cancel();
      } // if (kc)
    } // if (MSIE)
  }

  if (webguiIsActive() && e)
  {
    if (e.keyCode == "13")
    {
      // cancel default submit
      e.cancel();

      // Searchhelp result can be selected by pressing "Enter"
      if (typeof(shResultFieldRowIdx) != "undefined")
      {
        shResultTableSelect(evt);
      }
      else
      {
        submitForm();
      }
      return;
    }
    else
    if (e.keyCode == 107) // numblock-[+]
    {
      if (e.ctrlKey && e.altKey && e.shiftKey)
      {
        dbgIncLevel();
        window.status = "dbg" + webgui._dbgLevel;
      }
    }
    else
    if (e.keyCode == 109) // numblock-[-]
    {
      if (e.ctrlKey && e.altKey && e.shiftKey)
      {
        dbgDecLevel();
        window.status = "dbg" + webgui._dbgLevel;
      }
    }
    else
/*
    if (e.keyCode == 78) // N
    {
      if (e.ctrlKey && e.altKey && e.shiftKey)
      {
        var oNA = new NestingAnalyzer();
        oNA.trigger();
        oNA.reset();
      }
    }
    else
    if (e.keyCode == 79) // O
    {
      if (e.ctrlKey && e.altKey && e.shiftKey)
      {
        if (!window.goOutliner)
          window.goOutliner = new ContainerOutliner();

        if (!!window.goOutliner) window.goOutliner.trigger();
      }
    }
    else
*/
    /* sk/20060711/suppress backspace on none editable elements to prevent
       unwanted server roundtrip and page has expired error
    */
    if (e.keyCode == "8")
    {
      if (e.target)
      {
        var type = e.target.type;
        if (!(e.target.nodeName == "INPUT" && !(!!e.target.readOnly && e.target.readOnly != "") && type && (type == "text" || type == "password") ||
            e.target.nodeName == "TEXTAREA"))
        {
          e.cancel();
        }
      }
    }

    if (webguiIsKeyDisabled(e.event))
    {
      //window.status = "browser shortcut key disabled";
      e.cancel();
      return false;
    }

    var vfcode = webguiKey2vfcode(e.event),
        el;
    if (vfcode != "")
    {
      if (null != (el = wguGuiMenu.getEntryByVfcode(vfcode)))
      {
        wguGuiMenu.execEntryFunction(el);
      }
      else if (vfcode == 4)
      {
        if (null != e.target)
        {
          e. cancel();
          if (e.target.tagName != "SELECT" && e.target.tagName != "DIV")
          {
            setOkCode("/"+vfcode, e.target.name);
          }
        }
      }
      else if (webguiIsActiveFCode("F"+vfcode))
      {
        e. cancel();
        if (e.target && e.target.name)
        {
          if (e.target.type != "radio")
          {
            setOkCode("/"+vfcode, e.target.name);
          }
          else
          {
            setOkCode("/"+vfcode, e.target.id);
          }
        }
        else
        {
          setOkCode("/"+vfcode);
        }
      }
      else if (vfcode == 10) // F10 -> menu
      {
        var menu = document.getElementById("CUAMnuMenuButton");
        if (menu)
        {
          try
          {
            dom_focus(menu);
            if (document.createEvent)
            {
              ev = document.createEvent("KeyboardEvent");
              ev.initKeyEvent("keydown", true, true, null, false, false, false, false, 40, 0);
              menu.dispatchEvent(evt);
            }
            else if (document.createEventObject)
            {
              ev = document.createEventObject();
              ev.setAttribute("keyCode", 40);
              menu.fireEvent("onKeyDown", ev);
            }
          }
          catch(exception)
          {
            window.status = exception.message;
          }
        }
      }
      else if (vfcode == 22) // shift + F10
      {
        webguiDoContextMenu (e);
      }
      else if (vfcode == 12 && webguiIsDialogboxPopup)
      {
        var closebut = document.getElementById("WebguiModalTitleBarClose");
        if (closebut)
        {
          closebut.click();
        }
      }
    }
  }
  if (1 === vfcode) return false;
}

function webguiListDoHotSpotClick(e)
{
    if (!webguiIsActive())
        return;

    webguiDoClick(e, true);
    webguiListDoDblClick(e);
}

function rollOver(iconName)
{
  var
    iconStyle = eval("document.getElementById('" + iconName + "').style");

 iconStyle.borderTopColor = "#F7F9FB";    /*"#B8C1CC"; org. frog */
 iconStyle.borderRightColor = "#4B8BC7";
 iconStyle.borderBottomColor = "#4B8BC7";
 iconStyle.borderLeftColor = "#F7F9FB";
 /*iconStyle.background = "#BFBFBF";
 iconStyle.borderTopColor = "#D9D9D9";
 iconStyle.borderRightColor = "#A6A6A6";
 iconStyle.borderBottomColor = "#A6A6A6";
 iconStyle.borderLeftColor = "#D9D9D9";
 iconStyle.background = "#BFBFBF";*/        /* frog2002 */
}

function down(iconName)
{
 var
  iconStyle = eval("document.getElementById('" + iconName + "').style");

 iconStyle.borderTopColor = "#4B8BC7";
 iconStyle.borderRightColor = "#F7F9FB";
 iconStyle.borderBottomColor = "#F7F9FB";
 iconStyle.borderLeftColor = "#4B8BC7";
 /*iconStyle.borderTopColor = "#A6A6A6";
 iconStyle.borderRightColor = "#D9D9D9";
 iconStyle.borderBottomColor = "#D9D9D9";
 iconStyle.borderLeftColor = "#A6A6A6";
 iconStyle.background = "#B5B5B5";*/    /* frog2002 */
}

function up(iconName)
{
 var
  iconStyle = eval("document.getElementById('" + iconName + "').style");

 iconStyle.borderTopColor = "#B8C1CC";
 iconStyle.borderRightColor = "black";
 iconStyle.borderBottomColor = "black";
 iconStyle.borderLeftColor = "#B8C1CC";
 /*iconStyle.borderTopColor = "#D9D9D9";
 iconStyle.borderRightColor = "#A6A6A6";
 iconStyle.borderBottomColor = "#A6A6A6";
 iconStyle.borderLeftColor = "#D9D9D9";
 iconStyle.background = "#BFBFBF";*/    /* frog2002 */
}

function rollOff(iconName)
{
 var
  iconStyle = eval("document.getElementById('" + iconName + "').style");

 iconStyle.borderWidth = "1px";                        /* frog2002 */
 iconStyle.borderColor = iconStyle.backgroundColor; /* frog2002 */
 /*iconStyle.borderTopColor = "#BFBFBF";
 iconStyle.borderRightColor = "#BFBFBF";
 iconStyle.borderBottomColor = "#BFBFBF";
 iconStyle.borderLeftColor = "#BFBFBF";
 iconStyle.background = "#BFBFBF";*/    /* frog2002 */
}

function WebguiDynproCheckBox(checkbox)
{
  if (!!checkbox && (!!checkbox.previousSibling && checkbox.previousSibling.tagName == "INPUT"))
  {
     var
      checked = checkbox.getAttribute("checked");
     inputField = checkbox.previousSibling;
     if (checked==1)
     {
      checkbox.className = "ListCheckboxUnchecked";
      checkbox.setAttribute("checked", 0);
      inputField.value = " ";
     }
     else
     {
      checkbox.className = "ListCheckboxChecked";
      checkbox.setAttribute("checked", 1);
      inputField.value = "1";
     }
  }
}

function RaiseTCJumpRowEvent(pTableName,event)
{
 if (event.keyCode == 13)
 {
  // cancel default submit
  event.cancelBubble = true;
  event.returnValue = false;

  raiseEvent(pTableName,'JumpRow');
 }
}

function RaiseSHJumpRowEvent(fieldname, controlid)
{
 var ifield,ifieldvalue, param;

 ifield = document.getElementById(fieldname);
 if (ifield)
 {
  ifieldvalue = ifield.value;
  param = "jumprow=" + ifieldvalue;
  window.raiseEvent(controlid, 'JumpRow', param);
 }
}

function setOptionSelected(element)
{
 if (element && element.options && element.selectedIndex >=0)
 {
  if (element.options[element.selectedIndex].specialItem)
  {
   if (!element.clicked)
   {
    element.options[0].selected = true;
    element.clicked = true;
   }
  }
 }

 if (accessibility)
  webguiDoFocus(element);
}

function webguiIsKeyDisabled(event)
{
 // list of disabled keyboard shortcuts
 //
 // alt  + left arrow(37),right arrow(39),Home(36)
 // ctrl + I(73),W(87),E(69),D(68),H(72),N(78)

 var keyDisabled = false;

 if (event.altKey)
 {
  if ( event.keyCode == "37" ||
       event.keyCode == "39" ||
       event.keyCode == "36" )
   keyDisabled = true;
 }
 else if (event.ctrlKey)
 {
  if ( event.keyCode == "73" ||
       event.keyCode == "87" ||
       event.keyCode == "69" ||
       event.keyCode == "68" ||
       event.keyCode == "72" ||
       event.keyCode == "78" )
   keyDisabled = true;
 }

 return keyDisabled;
}

function webguiKey2vfcode(event)
{
  var rv = null,
      vfcode = "",
      bmp, el;

 // Only mapping virtual function code 1-69
 // (shift and/or ctrl) + F1(112)-F12(123)
 // Ctrl+F|G|P (search, cont. search, print)
 //
 //
 // Special: ESC(27)
 //     ctrl + S(83)
 //     ctrl + shift + 0(48)

  bmp = wguGuiMenu.getKeybitmapByEvent(event);
  if (null != (el = wguGuiMenu.getEntryIdByKeybitmap(bmp)))
  {
    rv = wguGuiMenu.getVfcode(el);
  }
  else
  if (!(!( (event.keyCode >= "112" && event.keyCode <= "123")
       || (event.keyCode >= "512" && event.keyCode <= "523")
       ||  event.keyCode == "83"
       ||  event.keyCode == "48"
       ||  event.keyCode == "27"
       ||  event.keyCode == "70"
       ||  event.keyCode == "71"
       ||  event.keyCode == "80"
        )
       )
     )
  {
    var kc = Number( event.keyCode);
    if (!(event.altKey && event.ctrlKey))
    {
      if (event.shiftKey && event.ctrlKey)
      {
        if (kc >= 512 && kc <= 523)
          vfcode = "" + (kc - 475);
        else if (kc >= 112 && kc <= 123)
          vfcode = "" + (kc - 75);
        else if (kc == 48)
          vfcode = "22";
      }
      else if (event.ctrlKey)
      {
        if (kc >= 512 && kc <= 523)
          vfcode = "" + (kc - 487);
        else if (kc >= 112 && kc <= 123)
          vfcode = "" + (kc - 87);
        else if (kc == 83)
          vfcode = "11";
        else if (kc == 70)
        {
          vfcode = "71";
          if (null != document.all)
            event.keyCode = 0;
        }
        else if (kc == 71)
        {
          vfcode = "84";
          if (null != document.all)
            event.keyCode = 0;
        }
        else if (kc == 80)
        {
          vfcode = "86";
          if (null != document.all)
            event.keyCode = 0;
        }
      }
      else if (event.shiftKey)
      {
        if (kc >= 512 && kc <= 523)
          vfcode = "" + (kc - 499);
        else if (kc >= 112 && kc <= 123)
          vfcode = "" + (kc - 99);
      }
      else
      {
        if (kc >= 512 && kc <= 523)
          vfcode = "" + (kc - 511);
        else if (kc >= 112 && kc <= 123)
          vfcode = "" + (kc - 111);
        else if (kc == 27)
          vfcode = "12";
      }
    }
    rv = vfcode;
  }

  return rv;
}

function webguivfcode2key(vfcode)
{
  var rv = null,
      el, key;

  if (vfcode)
  {
    vfcode = parseInt(vfcode);

    if ((vfcode >= 37 && vfcode <= 48) || vfcode == 22)
    {
      if (vfcode == 37)
        key = "F1";
      else if (vfcode == 38)
        key = "F2";
      else if (vfcode == 39)
        key = "F3";
      else if (vfcode == 40)
        key = "F4";
      else if (vfcode == 41)
        key = "F5";
      else if (vfcode == 42)
        key = "F6";
      else if (vfcode == 43)
        key = "F7";
      else if (vfcode == 44)
        key = "F8";
      else if (vfcode == 45)
        key = "F9";
      else if (vfcode == 46)
        key = "F10";
      else if (vfcode == 47)
        key = "F11";
      else if (vfcode == 48)
        key = "F12";
      else if (vfcode == 22)
        key = "0"

      rv = "Ctrl+Shift+" + key;
    }
    else if (vfcode >= 25 && vfcode <= 36)
    {
      if (vfcode == 25)
        key = "F1";
      else if (vfcode == 26)
        key = "F2";
      else if (vfcode == 27)
        key = "F3";
      else if (vfcode == 28)
        key = "F4";
      else if (vfcode == 29)
        key = "F5";
      else if (vfcode == 30)
        key = "F6";
      else if (vfcode == 31)
        key = "F7";
      else if (vfcode == 32)
        key = "F8";
      else if (vfcode == 33)
        key = "F9";
      else if (vfcode == 34)
        key = "F10";
      else if (vfcode == 35)
        key = "F11";
      else if (vfcode == 36)
        key = "F12";

      rv = "Ctrl+" + key;
    }
    else if (vfcode >= 13 && vfcode <= 24)
    {
      if (vfcode == 13)
        key = "F1";
      else if (vfcode == 14)
        key = "F2";
      else if (vfcode == 15)
        key = "F3";
      else if (vfcode == 16)
        key = "F4";
      else if (vfcode == 17)
        key = "F5";
      else if (vfcode == 18)
        key = "F6";
      else if (vfcode == 19)
        key = "F7";
      else if (vfcode == 20)
        key = "F8";
      else if (vfcode == 21)
        key = "F9";
      else if (vfcode == 23)
        key = "F11";
      else if (vfcode == 24)
        key = "F12";

      rv = "Shift+" + key;
    }
    else
    {
      if (vfcode == 11)
        rv = "Ctrl+S";
      if (vfcode == 71)
        rv = "Ctrl+F";
      if (vfcode == 84)
        rv = "Ctrl+G";
      if (vfcode == 86)
        rv = "Ctrl+P";
      else if (vfcode == 0)
        rv = "Enter";
      else if (vfcode > 0 && vfcode < 13)
        rv = "F" + vfcode;
      else if (vfcode > 128)
      {
        if (!!(el = wguGuiMenu.getEntryByiVfcode(vfcode)))
          rv = wguGuiMenu.getEntryKey(el);
      }
      else
        rv = "";
    }
  }
  return rv;
}

function webguiIsActiveFCode(vfcode)
{
  var rv = false,
      i, l, el, a, arr = null,
      ivfcode, el;

  if (null != vfcode)
  {
    ivfcode = parseInt(vfcode.substr(1));

    //tj/2002-11-26/ enable searchhelp in popups
    if (ivfcode == 4)
      rv = true;
    else if (128 < ivfcode)
    {
      if (!!(el = wguGuiMenu.getEntryByVfcode(vfcode)))
        rv = wguGuiMenu.isActiveEntry(el);

    }
    else if (71 == ivfcode || 84 == ivfcode || 86 == ivfcode)
    {
      if (typeof arrMenu_stdButtonBar != "undefined" && null != arrMenu_stdButtonBar)
      {
        arr = arrMenu_stdButtonBar;
      }
      else
      {
        if (71 == ivfcode) { if (null != (el = document.getElementById("b_srch")) && el.className.match(/Enable/i)) rv = true; }
        if (84 == ivfcode) { if (null != (el = document.getElementById("b_srcc")) && el.className.match(/Enable/i)) rv = true; }
        if (86 == ivfcode) { if (null != (el = document.getElementById("f_prnt")) && el.className.match(/Enable/i)) rv = true; }
      }
    }
    else if (vfcode && typeof arrMenu_FM != "undefined" && null != arrMenu_FM)
    {
      arr = arrMenu_FM;
    }

    if (null != arr)
    {
      for (i = 5, l = arr.length; i < l; i += 6)
      {
        if (arr[i] == vfcode)
        {
          rv = true;
          break;
        }
      }
    }
  }

  return rv;
}

function webguiAnnounceError( iframeName, errorHTML )
{
 if(!iframeName || iframeName=="")
  return;

 errorIFrame = document.getElementById(iframeName);

 if(!errorIFrame)
  return;

 if(errorIFrame.style.display!="none")
  return;

 webguiIsBusy = false;
 webguiRaiseOkCodeField();
}




// ==========================================================
// Modal Windows
// ==========================================================

function webguiModalLoad(modalNo)
{
  return document.getElementById("webguiModalWindow" + modalNo).innerHTML;
}

function webguiModalDoMouseMove( in_event )
{
  var
    webguiMoveModal = window.webguiMoveModal,
    webguiModalElement;

  if (webguiMoveModal != null)
  {
    var
      pixelLeft, pixelTop, pixelWidth, pixelHeight,
      cursorLeft, cursorTop,
      offsetW, offsetH;

    webguiModalElement = webguiMoveModal.element;

    if (webguiMoveModal.resize)
    {
      pixelWidth = webguiMoveModal.windowWidth + in_event.screenX - webguiMoveModal.startX;
      pixelHeight = webguiMoveModal.windowHeight + in_event.screenY - webguiMoveModal.startY;

      webguiModalElement.style.width = pixelWidth + "px";
      webguiModalElement.style.height = pixelHeight + "px";
    }
    else
    {
      pixelLeft = webguiMoveModal.windowX + in_event.screenX - webguiMoveModal.startX;
      pixelTop = webguiMoveModal.windowY + in_event.screenY - webguiMoveModal.startY;

      if(webguiMoveModal.boundCursor)
      {
        cursorLeft = webguiModalElement.offsetLeft + in_event.clientX;
        cursorTop = webguiModalElement.offsetTop + in_event.clientY;
        offsetW = webguiModalElement.ownerDocument.body.offsetWidth - 5;
        offsetH = webguiModalElement.ownerDocument.body.offsetHeight - 5;
        if(cursorLeft > 0 && cursorLeft < offsetW && cursorTop > 0 && cursorTop < offsetH)
        {
          webguiModalElement.style.left = pixelLeft + "px";
          webguiModalElement.style.top = pixelTop + "px";
        }
      }
      else
      {
        webguiModalElement.style.left = pixelLeft + "px";
        webguiModalElement.style.top = pixelTop + "px";
      }
    }
    in_event.cancelBubble = true;
    in_event.returnValue = false;
  }
}

function webguiModalDoMouseUp ( in_event )
{
  if (window.webguiMoveModal != null)
  {
    var
      webguiModalElement = window.webguiMoveModal.element;

    if (window.webguiMoveModal.resize)
    {
      document.body.innerHTML = window.webguiMoveModal.innerHTML;
    }

    window.wgu_global_eventhandler.UnregisterHandler( "mousemove", "~popup", webguiModalDoMouseMove );
    window.wgu_global_eventhandler.UnregisterHandler( "mouseout",  "~popup", webguiModalDoMouseMove );
    window.wgu_global_eventhandler.UnregisterHandler( "mouseup",   "~popup", webguiModalDoMouseUp );

    in_event.cancelBubble = true;
    in_event.returnValue = false;

    if (document.webguiform && webguiModalElement)
    {
      if (document.webguiform.elements[formWebguiModalLeft])
      {
        //document.webguiform.elements[formWebguiModalLeft].value = webguiModalElement.style.pixelLeft;
        document.webguiform.elements[formWebguiModalLeft].value = webguiModalElement.offsetLeft;
      }
      if (document.webguiform.elements[formWebguiModalTop])
      {
        // document.webguiform.elements[formWebguiModalTop].value = webguiModalElement.style.pixelTop;
        document.webguiform.elements[formWebguiModalTop].value = webguiModalElement.offsetTop;
      }
    }

    window.webguiMoveModal = null;
  }
}

function webguiModalDoMouseDown ( in_event, resize )
{
  var
    webguiMoveModal,
    webguiModalElement;

  webguiModalElement = parent.document.getElementById(window.name);
  if (webguiModalElement)
  {
    webguiMoveModal = new Object;
    webguiMoveModal.startX = in_event.screenX;
    webguiMoveModal.startY = in_event.screenY;
    webguiMoveModal.windowX = webguiModalElement.offsetLeft;
    webguiMoveModal.windowY = webguiModalElement.offsetTop;
    webguiMoveModal.windowWidth = webguiModalElement.offsetWidth;
    webguiMoveModal.windowHeight = webguiModalElement.offsetHeight;

    webguiMoveModal.element = webguiModalElement;
    if (resize)
    {
      webguiMoveModal.resize = true;
      webguiMoveModal.innerHTML = document.body.innerHTML;
      document.body.innerHTML = "";
    }
    window.webguiMoveModal = webguiMoveModal;

    window.wgu_global_eventhandler.RegisterHandler( "mousemove", "~popup", 900, webguiModalDoMouseMove );
    window.wgu_global_eventhandler.RegisterHandler( "mouseup",   "~popup", 900, webguiModalDoMouseUp );

    // tj/2012-05-21/ now also for FF
    // if(isIE55_up())
    // {
      window.wgu_global_eventhandler.RegisterHandler( "mouseout", "~popup", 900, webguiModalDoMouseMove );
      webguiMoveModal.boundCursor = 1;
    // }
  }
}

function webguiModalIsResizeEvent(event)
{
  if (webguiIsPopup && webguiIsResizable)
  {
    if (event && event.srcElement && event.type == "mousedown")
    {
      if ((event.x >= event.srcElement.offsetWidth - WEBGUI_RESIZE_WIDTH)
       && (event.x <= event.srcElement.offsetWidth)
       && (event.y >= event.srcElement.offsetHeight - WEBGUI_RESIZE_WIDTH)
       && (event.y <= event.srcElement.offsetHeight))
      {
        return true;
      }
    }
  }

  return false;
}


/************************************
 ** radiobutton/checkbox behaviour **
*************************************/

function toggleChange(event, el)
{
  var elName = el.getAttribute("for");
  var classname = el.className;

  if (elName != "")
  {
    var elSubmitField = document.getElementsByName(elName)[0];
    if (elSubmitField == null)
    {
      var webguiform = document.getElementById("webguiform");
      elSubmitField = document.createElement("input");
      elSubmitField.type = "hidden";
      elSubmitField.setAttribute("name", elName);
      elSubmitField.setAttribute("id", elName);
      if (classname.indexOf("d_Checkbox_ON") >= 0 || classname.indexOf("d_CheckboxSelected_ON") >= 0)
        elSubmitField.value = "on";
      webguiform.appendChild(elSubmitField);
//      elSubmitField.style="display:none;";
    }
  }

  webguiSaveFocus(new webguiFocusObj(1, el));

  if (el.getAttribute("ct") == "checkbox")
  {
    if (elSubmitField.value=="on")
    {
      el.className = classname.replace(/d_Checkbox_ON/i, "d_Checkbox_OFF");
      if (!!el.webguiOldClassName)
        el.webguiOldClassName = el.webguiOldClassName.replace(/d_Checkbox_ON/i, "d_Checkbox_OFF");
      elSubmitField.value="";
    }
    else
    {
      el.className = classname.replace(/d_Checkbox_OFF/i, "d_Checkbox_ON");
      if (!!el.webguiOldClassName)
        el.webguiOldClassName = el.webguiOldClassName.replace(/d_Checkbox_OFF/i, "d_Checkbox_ON");
      elSubmitField.value="on";
    }
  }
  else
  {
    var prevElement = document.getElementById(elSubmitField.value + "_toggle");
    if (prevElement)
    {
      prevElement.className =
          prevElement.className.replace(/d_Radiobutton_ON/i, "d_Radiobutton_OFF");
      if (prevElement.webguiOldClassName)
        prevElement.webguiOldClassName =
            prevElement.webguiOldClassName.replace(/d_Radiobutton_ON/i,"d_Radiobutton_OFF");
      else
        prevElement.webguiOldClassName = "d_RadioButton_OFF";
    }

    el.className = el.className.replace(/d_Radiobutton_OFF/i, "d_Radiobutton_ON");
    if (prevElement)
      el.tabIndex = prevElement.tabIndex;
    else
      el.tabIndex = 0;
    if (prevElement && (el != prevElement)) prevElement.removeAttribute("tabIndex");
    if (el.webguiOldClassName)
      el.webguiOldClassName = el.webguiOldClassName.replace(/d_Radiobutton_OFF/i, "d_Radiobutton_ON");
    else
      el.webguiOldClassName = "d_RadioButton_ON";


    elSubmitField.setAttribute("value", el.id.replace(/_toggle/i, ""));
  }

  if (null != el.getAttribute("okcode") && el.getAttribute("okcode") != "" && prevElement != el)
    setOkCode(el.getAttribute("okcode"), el.id);
}

function toggleUp(event, el)
{
  if (el && webguiRBArray)
  {
    for (i = 0; i < webguiRBArray.length; i++)
    {
      if (webguiRBArray[i + 1] && webguiRBArray[i + 1] == el && webguiRBArray[i] && webguiRBArray[i].name == el.name)
      {
        toggleChange(event, webguiRBArray[i]);
        dom_focus(webguiRBArray[i]);
      }
    }
    //el.scrollIntoView(false);
  }
}

function toggleDown(event, el)
{
  if (el && webguiRBArray)
  {
    for (i = 0; i < webguiRBArray.length; i++)
    {
      if (webguiRBArray[i] && webguiRBArray[i] == el && webguiRBArray[i + 1] && webguiRBArray[i + 1].name == el.name)
      {
        toggleChange(event, webguiRBArray[i + 1]);
        dom_focus(webguiRBArray[i + 1]);
      }
    }
    //el.scrollIntoView(true);
  }
}

function toggleKeyDown(event, el)
{
  var e = new its_event(event);
  switch (e.keyCode)
  {
    case 32:
      toggleChange(event, el);
      break;
    case 38:
      if (!!el.getAttribute("ct") && el.getAttribute("ct") == "radio" ) toggleUp(event, el);
      break;
    case 40:
      if (!!el.getAttribute("ct") && el.getAttribute("ct") == "radio" ) toggleDown(event, el);
      break;
    default:
      return false;
  }
  e.stopPropagation();
  e.preventDefault();
  delete(e);
  return false;
}

/*********************************************************************
* function setFormFocusfieldIdx(name)
*
*  he.pi 20050217
*/

function setFormFocusfieldIdx(name){
  targetObject = getMainWindow().document.webguiform;
  targetObject.elements[formFocusfieldIdx].value = name;
  //alert("debug: " + name);
}


/*********************************************************************
* function webguiStopPropagation()
*
*  helper function needed to stop event bubbling on the current event
*  within event handler inside html tags
*  needed for crossbrowser webgui for correct behaviour in mozilla
*  he.pi 20050207
*/

function webguiStopPropagation(e){
  var eObj = new its_event(e);
  eObj.stopPropagation();
}

/*********************************************************************
* function webguiClearSelection()
*
* helper function to clear browser selection if needed
*
*/
function webguiClearSelection()
{
  var selObject;

  if(document.selection && document.selection.empty)
  {
    document.selection.empty() ;
  }
  else if(window.getSelection)
  {
    selObject=window.getSelection();
    if(selObject && selObject.removeAllRanges)
    {
      selObject.removeAllRanges() ;
    }
  }
}


function my_trace(msg){
        //window.console support for firefox / companjon support for msie
        //for using firefox dump feature enable browser.dom.window.dump.enabled and start firefox with parameter -console
        if (window.console) console.log( msg ); //output to firebug or js companjon console
        else if (its_ua.gecko) dump( msg + '\n'); //enable old school console in firefox with browser.dom.window.dump.enabled
        if ((typeof(Debug) !== 'undefined') && Debug.writeln) {
          Debug.writeln( msg );
        }
}



/*********************************************************************
* function webguiSetButtonDisabledState()
*
* helper function to enable/disable new implemented dynpro buttons
*
*/
function webguiSetButtonDisabledState(buttonobj, isDisabled)
{
  if (!buttonobj || !(buttonobj.getAttribute("ct")) || (buttonobj.getAttribute("ct") != "d_button"))
    return;

  if (isDisabled)
  {
    buttonobj.setAttribute("disabled", "disabled");
    if (!!buttonobj.getAttribute("onclick"))
    {
      buttonobj.ionclick = buttonobj.onclick;
      buttonobj.onclick = "return false";
    }
    if (!!buttonobj.getAttribute("onkeydown"))
    {
      buttonobj.ionkeydown = buttonobj.onkeydown;
      buttonobj.onkeydown = "return false";
    }

    buttonobj.className = "d_buttonInactive";
    if (buttonobj.firstChild != null && buttonobj.firstChild.tagName.toUpperCase() == "IMG")
      buttonobj.firstChild.className = "WebguiOpacity25";
  }
  else
  {
    buttonobj.removeAttribute("disabled");
    if (buttonobj.getAttribute("ionclick") != null && buttonobj.getAttribute("ionclick") != "")
      buttonobj.onclick = buttonobj.ionclick;
    if (buttonobj.getAttribute("ionkeydown") != null && buttonobj.getAttribute("ionkeydown") != "")
      buttonobj.onkeydown = buttonobj.ionkeydown;

    buttonobj.className = "d_button";
    if (buttonobj.firstChild != null && buttonobj.firstChild.tagName.toUpperCase() == "IMG")
      buttonobj.firstChild.className = "";
  }

}

/**********************************************************
*
* new focus handling
*
*  type: 1 - Dynpro
         2 - TableControl
         3 - AlvGrid
         4 - Textedit
         5 - TreeControl
*
*
*
*********************************************************/

function webguiFocusObj(focusType, focusObj)
{
    this.focusType = focusType;
    this.focusObj  = focusObj;
}

function webguiSetDynproFocus(fObj)
{
  var targetObject = getMainWindow().document.webguiform;
  if (!!fObj && fObj.focusType == 1 && !!fObj.focusObj && !!targetObject)
  {
    if (fObj.focusObj.tagName == "INPUT")
    {
      if (!!fObj.focusObj.name)
        webguiFocusField = targetObject.elements[formFocusfieldIdx].value = fObj.focusObj.name;
      else if (!!fObj.focusObj.id)
        webguiFocusField = targetObject.elements[formFocusfieldIdx].value = fObj.focusObj.id;
      else
        webguiFocusField = "";
    }
    else
    {
      webguiFocusField = targetObject.elements[formFocusfieldIdx].value = fObj.focusObj.id;
    }
  }
}

function webguiSaveFocus(fObj)
{
  webguiResetOldFocus();
  if (!!fObj)
  {
    if (!!fObj.focusObj)
    {
      switch (fObj.focusType)
      {
        case WEBGUI_FOCUS_TYPE_DYNPRO:
          fObj.focusObj.webguiOldClassName = fObj.focusObj.className;
          break;
        case WEBGUI_FOCUS_TYPE_TABLE:
          break;
        case WEBGUI_FOCUS_TYPE_ALV:
          fObj.focusObj.hasFocus = true;
          WebGUISetControlFocus(fObj.focusObj.controlId);
          break;
        case WEBGUI_FOCUS_TYPE_TREE:
          WebGUISetControlFocus(fObj.focusObj.controlId);
          break;
        case WEBGUI_FOCUS_TYPE_TEXTEDIT:
          WebGUISetControlFocus(fObj.focusObj._ControlId);
          break;
      }
      webguiSavedFocusObj = fObj;
    }
  }

}

function webguiResetOldFocus()
{
  if (!!webguiSavedFocusObj)
  {
    switch (webguiSavedFocusObj.focusType)
    {
      case WEBGUI_FOCUS_TYPE_DYNPRO:
        webguiDelSelClassOnDynproElement(webguiSavedFocusObj.focusObj);
        //webguiSavedFocusObj.focusObj.className = webguiSavedFocusObj.focusObj.webguiOldClassName;
        break;
      case WEBGUI_FOCUS_TYPE_TABLE:
        its_tcMgr.unsetCurrentCell(webguiSavedFocusObj.focusObj);
        break;
      case WEBGUI_FOCUS_TYPE_ALV:
        webguiSavedFocusObj.focusObj.hasFocus = false;
        //its_gvMgr.unsetCurrentCell(webguiSavedFocusObj.focusObj);
        break;
      case WEBGUI_FOCUS_TYPE_TEXTEDIT:
      case WEBGUI_FOCUS_TYPE_TREE:
        break;
    }
  }
  webguiShButtonManager.Update(null);
  WebGUISetControlFocus();
  webguiSavedFocusObj = null;
}

function webguiFindSuperiorDynproElement(sourceObj)
{
  var i = 0;
  while (sourceObj.getAttribute("ct") == null && i <= 4)
  {
    if (sourceObj.parentNode)
      sourceObj = sourceObj.parentNode;

    if (sourceObj == document || i >= 3)
    {
      return null;
    }

    i += 1;
  }
  return sourceObj;
}

function webguiDelSelClassOnDynproElement(el)
{
  if (!!el.webguiOldClassName && el.webguiOldClassName != "")
  {
    //delete required class and add it later, if value is empty and "ir" attribute is set
    el.className = el.webguiOldClassName.replace(/inputRequired/ig, "");;
    var classname = el.className.split(" ");
    if (classname[0].search(/Selected/i) > 0)
    {
      classname[0] = classname[0].replace(/Selected/i, "");
      el.className = classname.join(" ");
    }

    if (el.getAttribute("ir") == "X" && el.value == "")
    {
      el.className = el.className + " inputRequired";
    }
  }
  webguiShButtonManager.Update(null);
}

function webguiSetSelClassOnDynproElement(el, thisEvent)
{
  //have to check if button should be excluded
  //if (el.className != "" && el.getAttribute("ct") != "d_button" && !!!el.getAttribute("disabled") )
  if (el.className != "" && !!!el.getAttribute("disabled") )
  {
    el.className = el.className.replace(/inputRequired/ig, "");
    var classname = el.className.split(" ");
    if (classname[0].search(/Selected/i) < 0)
    {
      classname[0] += "Selected";
      el.className = classname.join(" ");
    }
  }
  if (el && el.getAttribute("sh") )
  {
    if (el.tagName == "INPUT")
      webguiEnableSearchhelpButton(el.name, thisEvent);
    else
      webguiEnableSearchhelpButton(el.id, thisEvent);
  }
}
