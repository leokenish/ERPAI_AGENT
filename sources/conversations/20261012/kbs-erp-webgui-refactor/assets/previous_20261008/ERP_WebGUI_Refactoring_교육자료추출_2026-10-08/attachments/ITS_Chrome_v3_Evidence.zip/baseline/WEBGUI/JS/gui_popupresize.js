/* PopupResize.js
 *
 * /tj/ created autumn 2007
 *
 */


var gPopupResizeLastObj = null;



/**************************************************************
 * Class / Object constructor
 */

obj_PopupResize = function ( in_frameid )
{
  var boValid = false,
      myf, myel;

  if (null != in_frameid)
  {
    // Base frame information
    myf = document.getElementById(in_frameid);

    if (null != myf)
    {
      this._bfId   = in_frameid;          // base frame id
      this._htmlbf = myf;                 // bf base frame
      this._bf_x   = myf.offsetLeft;      // position and dim of bf
      this._bf_y   = myf.offsetTop;
      this._bf_w   = myf.offsetWidth;
      this._bf_h   = myf.offsetHeight;

      this._mousex = null;
      this._mousey = null;
      this._thisx  = null;
      this._thisy  = null;
      this._thisw  = null;
      this._thish  = null;

      this._callbackfn = null;

      this._boInResize = false;
      this._popupmovetimer = null;

      this._htmlsz     = null;
      this._htmlszhdl  = null;
      this._htmlborder = this.CreateBorderFrame(this._bfId + "_Border");

      if (null != (myel = this.CreateSizerFrame(this._bfId + "_Sizer")) )
      {
        this._htmlsz = myel;
        this.MatchSizerFrame();
        this._htmlsz.objPopupResize = this;

        if (null != (myel = this.CreateSizerHdlFrame(this._bfId + "_SizerHdl")) )
        {
          this._htmlszhdl = myel;
          this._htmlszhdl.objPopupResize = this;

          myf.objPopupResize = this;

          // we need to know when the popup gets moved around
          (document.all)
            ? myf.attachEvent("onmousemove", this.EventHandleMovePopup)
            : myf.addEventListener("mousemove", this.EventHandleMovePopup, true);

          boValid = true;
        }
      }
    } // if (myf)
  }

  this._valid = boValid;

} // obj_PopupResize() constructor


obj_PopupResize.prototype.IsValid = function ()
{
  return (true == this._valid);

} // IsValid()





/**************************************************************
 * MAPI
 */


/* Register a callback function
 * This function gets called when the popup was resized;
 * the first argument is this
 */
obj_PopupResize.prototype.RegisterCallback = function ( in_function )
{
  this._callbackfn = in_function;
}


obj_PopupResize.prototype.GetSize = function ()
{
  var sizobj = { height : this._bf_h, width : this._bf_w };

  return sizobj;

} // GetSize()


obj_PopupResize.prototype.GetPopupFrame = function ()
{
  return this._htmlbf;

} // GetSize()





/**************************************************************
 * Setter
 */

obj_PopupResize.prototype.DetermineBFDimensions = function ()
{
  if (this.IsValid() && null != this._htmlbf)
  {
    var myf = this._htmlbf;
    this._bf_x   = myf.offsetLeft;      // position and dim of bf
    this._bf_y   = myf.offsetTop;
    this._bf_w   = myf.offsetWidth;
    this._bf_h   = myf.offsetHeight;
  }
} // DetermineBFDimensions()


/**************************************************************
 * Creating
 */

obj_PopupResize.prototype.CreateSizerFrame = function ( in_id )
{
  var rv = null,
      mydiv, mydivid,
      s;

  mydivid = in_id;

  if (null != mydivid && null == (mydiv = document.getElementById(mydivid)) )   // <div> does not exist
  {
    if (document.all)   // IE
    {
      s = "<div id=\"" + mydivid + "\" class=\"PopupResizeFrame\">";
      mydiv = document.createElement(s);
    }
    else
    {
      mydiv = document.createElement("div");
      mydiv.setAttribute("id", mydivid);
      mydiv.setAttribute("class", "PopupResizeFrame");
    }
    rv = this._htmlbf.parentNode.appendChild(mydiv);
  }
  else
    rv = mydiv;

  if (null != rv)
  {
    if (document.all)
    {
      mydiv.attachEvent("onmouseover", this.EventHandleOverSizerFrame);
      mydiv.attachEvent("onmouseout",  this.EventHandleOutSizerFrame);
      mydiv.attachEvent("onmousedown", this.EventHandleDownSizerFrame);
    }
    else
    {
      mydiv.addEventListener("mouseover", this.EventHandleOverSizerFrame, true);
      mydiv.addEventListener("mouseout",  this.EventHandleOutSizerFrame,  true);
      mydiv.addEventListener("mousedown", this.EventHandleDownSizerFrame, true);
    }
  }

  return rv;
} // CreateSizerFrame()


obj_PopupResize.prototype.CreateSizerHdlFrame = function ( in_id )
{
  var rv = null,
      mydiv, mydivid,
      s;

  mydivid = in_id;

  if (null != mydivid && null == (mydiv = document.getElementById(mydivid)) )   // <div> does not exist
  {
    if (document.all)   // IE
    {
      s = "<div id=\"" + mydivid + "\" class=\"PopupResizeHdlFrame\">";
      mydiv = document.createElement(s);
    }
    else
    {
      mydiv = document.createElement("div");
      mydiv.setAttribute("id", mydivid);
      mydiv.setAttribute("class", "PopupResizeHdlFrame");
    }
    rv = this._htmlbf.parentNode.appendChild(mydiv);
  }
  else
    rv = mydiv;

  if (null != rv)
  {
    (document.all)
      ? mydiv.attachEvent("onmouseup", this.EventHandleUpSizerFrame)
      : mydiv.addEventListener("mouseup", this.EventHandleUpSizerFrame, true);
  }

  return rv;
} // CreateSizerHdlFrame()


obj_PopupResize.prototype.CreateBorderFrame = function ( in_id )
{
  var rv = null,
      mydiv, mydivid,
      s;

  mydivid = in_id;

  if (null != mydivid && null == (mydiv = document.getElementById(mydivid)) )   // <div> does not exist
  {
    if (document.all)   // IE
    {
      s = "<div id=\"" + mydivid + "\" class=\"PopupResizeBorderFrame\">";
      mydiv = document.createElement(s);
    }
    else
    {
      mydiv = document.createElement("div");
      mydiv.setAttribute("id", mydivid);
      mydiv.setAttribute("class", "PopupResizeBorderFrame");
    }
    rv = this._htmlbf.parentNode.appendChild(mydiv);
  }
  else
    rv = mydiv;

  return rv;
} // CreateSizerFrame()



/**************************************************************
 * Matching
 */

obj_PopupResize.prototype.MatchSizerFrame = function ()
{
  if (null != this._htmlsz && null != this._htmlbf)
  {
    this._htmlsz.style.top  = this._htmlbf.offsetTop + this._htmlbf.offsetHeight - this._htmlsz.offsetHeight + "px";
    this._htmlsz.style.left = this._htmlbf.offsetLeft + this._htmlbf.offsetWidth - this._htmlsz.offsetWidth + "px";
  }
} // MatchSizerFrame()


obj_PopupResize.prototype.MatchBorderFrame = function ()
{
  if (null != this._htmlborder && null != this._htmlbf)
  {
    this._htmlborder.style.top    = this._htmlbf.offsetTop    + "px";
    this._htmlborder.style.left   = this._htmlbf.offsetLeft   + "px";
    this._htmlborder.style.height = this._htmlbf.offsetHeight + "px";
    this._htmlborder.style.width  = this._htmlbf.offsetWidth  + "px";
  }
} // MatchSizerFrame()


obj_PopupResize.prototype.MatchBaseFrame = function ()
{
  if (null != this._htmlsz && null != this._htmlbf)
  {
    this._htmlbf.style.width  = this._htmlsz.offsetLeft + this._htmlsz.offsetWidth  + "px";
    this._htmlbf.style.height = this._htmlsz.offsetTop  + this._htmlsz.offsetHeight + "px";

    alert(  "W = " + this._htmlbf.style.width + " (" + this._htmlbf.offsetWidth + ")\n"
          + "H = " + this._htmlbf.style.height + " (" + this._htmlbf.offsetHeight + ")");
  }
} // MatchBaseFrame()


obj_PopupResize.prototype.MatchSizeHdlFrame = function ()
{
  if (null != this._htmlszhdl && null != document.body)
  {
    this._htmlszhdl.style.width  = document.body.offsetWidth -1 + "px";
    this._htmlszhdl.style.height = document.body.offsetHeight - 1 + "px";
  }
} // MatchSizeHdlFrame()





/**************************************************************
 * Event handling
 */


/**********************
 * Mouseover
 */

obj_PopupResize.prototype.EventHandleOverSizerFrame = function ( in_event )
{
  var This, ev, el;

  ev = (null == in_event) ? window.event : in_event;
  el = (null != ev) ? ((document.all) ? ev.srcElement
                                      : ev.target)
                    : null;
  This = (null != el) ? el.objPopupResize : null;

  if (null != This && null != This.IsValid && This.IsValid())
  {
    el.className = "PopupResizeFrameOver";
    This.MatchSizerFrame();
  } // if (This.IsValid)
} // EventHandleOverSizerFrame()


/**********************
 * Mouseout
 */

obj_PopupResize.prototype.EventHandleOutSizerFrame = function ( in_event )
{
  var This, ev, el, w, h;

  ev = (null == in_event) ? window.event : in_event;
  el = (null != ev) ? ((document.all) ? ev.srcElement
                                      : ev.target)
                    : null;
  This = (null != el) ? el.objPopupResize : null;

  if (null != This && null != This.IsValid && This.IsValid() && false == This._boInResize)
  {
    w = el.offsetWidth;
    h = el.offsetHeight;
    el.className = "PopupResizeFrame";
    el.style.left = el.offsetLeft + (w - el.offsetWidth)  + "px";
    el.style.top  = el.offsetTop  + (h - el.offsetHeight) + "px";
  } // if (This.IsValid)
} // EventHandleOutSizerFrame()


/**********************
 * Mousedown
 */

obj_PopupResize.prototype.EventHandleDownSizerFrame = function ( in_event )
{
  var This, ev, el;

  ev = (null == in_event) ? window.event : in_event;
  el = (null != ev) ? ((document.all) ? ev.srcElement
                                      : ev.target)
                    : null;
  This = (null != el) ? el.objPopupResize : null;

  if (null != This && null != This.IsValid && This.IsValid())
  {
    This.MatchSizerFrame();
    This._htmlborder.className = "PopupResizeBorderFrameOver";
    This.MatchBorderFrame();
    This._htmlszhdl.className = "PopupResizeHdlFrameOver";
    This.MatchSizeHdlFrame();
    if (false == This._boInResize)
    {
      (null != document.all)
        ? This._htmlszhdl.attachEvent("onmousemove", This.EventHandleMoveSizerFrame)
        : This._htmlszhdl.addEventListener("mousemove", This.EventHandleMoveSizerFrame, true);
    }

    This._mousex = ev.clientX;
    This._mousey = ev.clientY;
    This._thisx  = This._htmlsz.offsetLeft;
    This._thisy  = This._htmlsz.offsetTop;
    This._thisw  = This._htmlborder.offsetWidth;
    This._thish  = This._htmlborder.offsetHeight;

    This._boInResize = true;

  } // if (This.IsValid)
} // EventHandleDownSizerFrame()


/**********************
 * Mouseup
 */

obj_PopupResize.prototype.EventHandleUpSizerFrame = function ( in_event )
{
  var This, ev, el,
      x, y, dx, dy,
      sz, bd, szx, szy, bdw, bdh;

  ev = (null == in_event) ? window.event : in_event;
  el = (null != ev) ? ((document.all) ? ev.srcElement
                                      : ev.target)
                    : null;
  This = (null != el) ? el.objPopupResize : null;

  if (null != This && null != This.IsValid && This.IsValid())
  {
    (null != document.all)
      ? This._htmlszhdl.detachEvent("onmousemove", This.EventHandleMoveSizerFrame)
      : This._htmlszhdl.removeEventListener("mousemove", This.EventHandleMoveSizerFrame, true);
    This._boInResize = false;

    sz = This._htmlsz;
    bd = This._htmlborder;

    dx = ev.clientX - This._mousex;
    dy = ev.clientY - This._mousey;

    sz.style.left   = This._thisx + dx + "px";
    sz.style.top    = This._thisy + dy + "px";
    bd.style.width  = This._thisw + dx + "px";
    bd.style.height = This._thish + dy + "px";

    This._htmlbf.style.width  = bd.offsetWidth - 2 + "px";
    This._htmlbf.style.height = bd.offsetHeight - 2 + "px";

    This._htmlborder.className = "PopupResizeBorderFrame";
    This._htmlszhdl.className = "PopupResizeHdlFrame";

    This.DetermineBFDimensions();

    This._mousex = 0;
    This._mousey = 0;

    if (null != This._callbackfn)
    {
      This._callbackfn(This);
    }
  } // if (This.IsValid)
} // EventHandleUpSizerFrame()


/**********************
 * Mousemove
 */

obj_PopupResize.prototype.EventHandleMoveSizerFrame = function ( in_event )
{
  var This, ev, el,
      x, y, dx, dy,
      sz, bd, szx, szy, bdw, bdh;

  ev = (null == in_event) ? window.event : in_event;
  el = (null != ev) ? ((document.all) ? ev.srcElement
                                      : ev.target)
                    : null;
  This = (null != el) ? el.objPopupResize : null;

  if (null != This && null != This.IsValid && This.IsValid())
  {
    sz = This._htmlsz;
    bd = This._htmlborder;

    dx = ev.clientX - This._mousex;
    dy = ev.clientY - This._mousey;

    sz.style.left   = This._thisx + dx + "px";
    sz.style.top    = This._thisy + dy + "px";
    bd.style.width  = This._thisw + dx + "px";
    bd.style.height = This._thish + dy + "px";

  } // if (This.IsValid)
} // EventHandleMoveSizerFrame()


/**********************
 * Moving the IFrame
 */

obj_PopupResize.prototype.EventHandleMovePopup = function ( in_event, in_doit )
{
  var This, ev, t;

  if (true == in_doit)
  {
    if ("undefined" != this.IsValid && this.IsValid())
    {
      this.MatchSizerFrame();
      this._popupmovetimer = null;
    }
  }
  else
  {
    ev = (null != in_event) ? in_event : window.event;
    if (null != ev)
    {
      This = (null != ev.target) ? ev.target : ev.srcElement;
      This = (null != This) ? This.objPopupResize : null;
      if (null != This)
      {
        t = This._popupmovetimer;

        if (null != t)
        {
          clearTimeout(t);
        }

        gPopupResizeLastObj = This;
        This._popupmovetimer = setTimeout("gPopupResizeLastObj.EventHandleMovePopup(null, true)", 100);
      }
    }
  }
}
