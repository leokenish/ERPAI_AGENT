﻿SE80 수동 반영 대상 — CSS 21개

이 ZIP은 앞서 제공한 KBS_WebGUI_Modern_v1의 CSS 21개만 따로 묶은 것입니다.
새로운 코드 변경은 없습니다. 21개 CSS와 이 안내문 1개로 구성됩니다.
CSS에는 원본 코드와 추가 디자인 규칙이 모두 포함되어 있습니다. 변경분만 있는 파일이 아닙니다.

실제 교체 대상
서비스: WEBGUI
테마: SL
파일/긴 이름: STYLE/<파일명>.CSS
일부 객체의 내부 MIME 키는 파일/긴 이름과 다릅니다. 아래에서 두 이름을 모두 확인하세요.
이 매핑은 원본 .sap.xml의 SERVICE / THEME / MIMENAME / LONGNAME 값을 확인한 결과입니다.
SE80 트리에서 어느 이름이 표시되는지, 실제 메뉴와 게시 대상은 현재 시스템에서 확인해야 합니다.
파일명을 내부 키의 축약된 이름으로 변경하는 작업은 아닙니다.

왜 이전 패키지에는 42개 변경 파일이 있었나
CSS 21개: 화면 표현을 바꾸는 실제 콘텐츠.
CSS.sap.xml 21개: 추출본의 BYTE_LENGTH(바이트 길이)를 맞춘 메타데이터.
SE80에서 기존 MIME의 CSS 콘텐츠를 수동으로 바꾸는 작업에는 XML 21개를 따로 입력하지 않습니다.
JavaScript, HTMLBusiness 템플릿, 이미지, 폰트 파일, SYSTEM 파일은 이번 수동 교체 대상이 아닙니다.

반영 방법
1. 실제 화면이 WEBGUI/SL CSS를 사용하는지 Network의 전체 URL과 응답으로 확인합니다.
   운영 게시본이 첨부 추출본과 다른 경우 그대로 덮어쓰지 말고 먼저 차이를 확인합니다.
2. 기존 CSS 콘텐츠를 백업합니다. 먼저 개발/검증계에서 작업합니다.
3. SE80의 대응하는 기존 MIME 콘텐츠를 같은 이름의 수정 CSS 전체 내용으로 교체합니다.
   현재 환경의 파일 업로드 기능이 있다면 파일 전체를 교체할 수 있습니다.
   코드 편집 방식이어도 한 줄씩 찾아 바꾸는 대신 해당 CSS 전체 내용을 교체하면 됩니다.
   새 MIME 객체를 만들거나 파일명을 바꾸는 작업이 아닙니다.
4. 같은 작업을 아래 21개에 수행합니다. 실제 환경의 저장·게시 절차를 따릅니다.
   게시 대상, 전송, 캐시 절차는 현재 시스템에서 확인해야 합니다.
5. 실제 HTTP 응답에 KBS_WEBGUI_MODERN_V1_BEGIN 표시가 있는지 확인하고 업무 화면을 검증합니다.

이 ZIP 자체는 SAP 자동 가져오기용이 아닙니다. 파일별 콘텐츠 교체용입니다.
원복용 파일은 앞서 제공한 전체 패키지의 rollback/WEBGUI_Modern_v1_rollback.zip에 있습니다.

파일별 반영 목록 (체크칸은 수동 기록용, 공통 SERVICE=WEBGUI / THEME=SL)
[ ] 01. 파일/긴 이름: STYLE/GUI_PAGE.CSS
         내부 MIME 키: STYLE/GUI_PAGE.CSS
         변경 영역: 화면 바탕과 기본 텍스트 대비

[ ] 02. 파일/긴 이름: STYLE/GUI_FONT.CSS
         내부 MIME 키: STYLE/GUI_FONT.CSS
         변경 영역: 한국어 시스템 글꼴 대체 순서; 등폭 글꼴/본문 12px 유지

[ ] 03. 파일/긴 이름: STYLE/GUI_CUA.CSS
         내부 MIME 키: STYLE/GUI_CUA.CSS
         변경 영역: 상단 제목, 메뉴/명령 영역, 툴바 버튼

[ ] 04. 파일/긴 이름: STYLE/GUI_INPUT.CSS
         내부 MIME 키: STYLE/GUI_INPUT.CSS
         변경 영역: 입력, 읽기 전용, 강조, 포커스 상태

[ ] 05. 파일/긴 이름: STYLE/GUI_BUTTON.CSS
         내부 MIME 키: STYLE/GUI_BUTTON.CSS
         변경 영역: 버튼 상태와 키보드 포커스

[ ] 06. 파일/긴 이름: STYLE/GUI_GROUPBOX.CSS
         내부 MIME 키: STYLE/GUI_GR3D108149
         변경 영역: 그룹 영역과 모서리 장식

[ ] 07. 파일/긴 이름: STYLE/GUI_TABLECONTROL.CSS
         내부 MIME 키: STYLE/GUI_TA2E032895
         변경 영역: Table Control 표의 헤더, 선택, 편집 상태

[ ] 08. 파일/긴 이름: STYLE/GUI_DROPDOWN.CSS
         내부 MIME 키: STYLE/GUI_DRF494FF00
         변경 영역: 드롭다운 목록과 선택 상태

[ ] 09. 파일/긴 이름: STYLE/GUI_TS.CSS
         내부 MIME 키: STYLE/GUI_TS.CSS
         변경 영역: 탭과 연결부 장식

[ ] 10. 파일/긴 이름: STYLE/GUI_POPUP.CSS
         내부 MIME 키: STYLE/GUI_POPUP.CSS
         변경 영역: 팝업 제목, 테두리, 배경

[ ] 11. 파일/긴 이름: STYLE/MENU.CSS
         내부 MIME 키: STYLE/MENU.CSS
         변경 영역: 메뉴 및 별도 메뉴 프레임

[ ] 12. 파일/긴 이름: STYLE/GUI_GRIDVIEW.CSS
         내부 MIME 키: STYLE/GUI_GRF3E567E0
         변경 영역: ALV 그리드 상태

[ ] 13. 파일/긴 이름: STYLE/COLUMNTREE.CSS
         내부 MIME 키: STYLE/COLUMNTREE.CSS
         변경 영역: 트리 헤더와 선택 상태

[ ] 14. 파일/긴 이름: STYLE/GUI_STATUSBAR.CSS
         내부 MIME 키: STYLE/GUI_STF6497F11
         변경 영역: 상태 표시줄과 메시지 영역

[ ] 15. 파일/긴 이름: STYLE/GUI_BAR.CSS
         내부 MIME 키: STYLE/GUI_BAR.CSS
         변경 영역: 제목/버튼바

[ ] 16. 파일/긴 이름: STYLE/GUI_TOOLBAR.CSS
         내부 MIME 키: STYLE/GUI_TO1BA93056
         변경 영역: 아이콘 툴바

[ ] 17. 파일/긴 이름: STYLE/GUI_TOOLBARCTRL.CSS
         내부 MIME 키: STYLE/GUI_TOAFB98BB0
         변경 영역: ALV 등 내부 툴바

[ ] 18. 파일/긴 이름: STYLE/GUI_SCROLL.CSS
         내부 MIME 키: STYLE/GUI_SCROLL.CSS
         변경 영역: 스크롤 트랙과 슬라이더

[ ] 19. 파일/긴 이름: STYLE/SEARCHHELPCTRL.CSS
         내부 MIME 키: STYLE/SEARCH9076F23C
         변경 영역: 값 도움말 결과 목록

[ ] 20. 파일/긴 이름: STYLE/EDIT.CSS
         내부 MIME 키: STYLE/EDIT.CSS
         변경 영역: 텍스트 편집 영역

[ ] 21. 파일/긴 이름: STYLE/DYNPROLIST.CSS
         내부 MIME 키: STYLE/DYNPROLIST.CSS
         변경 영역: 고전 목록 화면

검증 상태
기존 수정본의 정적 검사 및 로컬 적용/원복 검사는 통과했습니다.
실제 SAP와 Windows Chrome/Edge에서 업무 기능이 동작하는지는 미검증입니다.
CSS 교체는 21회이며, 저장·게시 및 업무 검증은 별도 작업입니다.
