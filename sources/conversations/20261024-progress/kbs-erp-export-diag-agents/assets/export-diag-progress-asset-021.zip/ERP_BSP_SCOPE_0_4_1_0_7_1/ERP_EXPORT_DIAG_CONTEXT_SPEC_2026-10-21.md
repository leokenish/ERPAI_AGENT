# ERP Export·DIAG 프로젝트 업무맥락 및 개발 명세서

문서 버전: 1.7  
정리 기준일: 2026-10-22, 한국시간  
코드 기준: **Export 0.4.1 / DIAG 0.7.1 / SAP ECC 6.0 · SAP_BASIS 700 Unicode**  
문서 목적: 대화의 요구사항·결정·수정 이력·남은 문제를 보존하고, 다음 대화에서 적은 맥락으로 개발을 재개한다.

## 1. 재개할 때 먼저 읽을 요약

1. 사용자는 개인 계정에서 진행하던 ERP 소스 추출·검증 프로젝트를 Business 계정으로 이관했다.
2. 기본 흐름은 **개발 패키지 또는 BSP 한 앱 Export → 로컬 파일 수정 → ZIP 업로드 → DIAG 3자 비교 → 선택 웹자산 서버 반영**이다.
3. 장기적으로 소스 반영 범위를 확대하려 하지만, 현재 ABAP·DDIC는 진단 전용이다.
4. 기존 SMIM·W3MI MIME 저장에 **기존 BSP 페이지의 Layout 저장과 해당 WAPP 페이지 활성화**를 추가했다.
5. BSP Page Attributes·Event Handler·Type Definitions·애플리케이션 정의는 업로드로 변경하지 않는다. 보존 여부는 점검한다.
6. 같은 애플리케이션의 **다른 HTM에 미활성 변경이 있다는 이유만으로 차단하지 않는다.** 선택한 페이지와 공통 정의의 점검 경고는 별도로 처리한다.
7. CTS는 선택 화면의 `웹자산 CTS 작업(요청 하위)`에 **본인 소유의 수정 가능한 개발 작업 번호**를 입력한다. 현재 구현은 상위 요청 번호를 직접 받지 않는다.
8. 최신 수정본은 **Z_PACKAGE_EXPORT_0_4_1.abap / Z_PACKAGE_DIAG_0_7_1.abap**이다. BSP 단독 ZIP은 앱 폴더 하나 아래 pages/MIMEs/catalog/baseline으로 구성한다. 이전 0.4.0/0.7.0의 packages 경로 문제를 수정했다.
9. 사용자는 DIAG 0.6.11에서 **ACTIVATED_VERIFIED / REUSED_VERIFIED / VERIFIED** 결과 후 SE80에서도 정상 반영을 확인했다. 이 사례는 기존 미활성 Layout 재사용 후 활성화 경로다. Export 0.4.0의 BSP 실제 추출은 사용자 ZIP으로 확인했다. 새 0.4.1/0.7.1의 SAP 실행은 아직 미확인이다.
10. 이후 사용자가 제공한 **ZHR5.zip에서 원인을 확정했다. 해당 .htm은 일반 HTML이 아니라 SAP SO2 XML이다.** 0.6.7의 독립 선언행 가정은 이 파일에 맞지 않았다. 0.6.8은 XML의 기존 최상위 static 본문만 추출·대조하고, 현재 SAP의 서버 구문을 보존하여 편집용 P_CONTENT를 만든다.

**바로 다음 작업:** 두 REPORT를 교체·문법 검사·활성화한 뒤 Export에서 BSP 애플리케이션 하나를 추출한다. DIAG의 같은 모드/같은 앱으로 변경 없는 ZIP을 먼저 비교하고 Layout 또는 MIME 한 건으로 반영한다. 최신 폴더 계약·한계·검증은 18절, 최초 BSP 확장은 17절, 사용자 성공 근거는 11.8절을 읽는다.

## 2. 문서의 근거와 범위

이 문서는 이 대화에서 확인되는 사용자 요청·오류 보고, 이전 작업의 연속성 기록, 현재 보관된 0.5.0~0.6.11 소스·README·검증 결과를 대조해 작성했다. 전체 대화의 축약 명세이며, 모든 메시지를 그대로 옮긴 원문 기록은 아니다.

- 초기 계정 이관 자료와 초기 개선 제언의 세부 원문을 모두 다시 확보한 것은 아니다. 확인되지 않은 초기 제안을 이미 합의된 요구사항으로 만들지 않는다.
- 공유 링크의 로그인·인증 완료 과정은 현재 근거만으로 세부 복원하지 않는다. 사용자는 이후 “공유링크까지 확보됐다”고 말했고, 실제 참조용 WEBGUI ABAP 파일이 작업 자료에 남아 있다.
- 현재 코드의 구현, 사용자가 실제 SAP에서 관찰한 결과, 로컬 시험으로 확인한 사항을 구분한다.
- 다른 대화의 WEBGUI 결재화면 개편 버전이나 메인화면 디자인 작업은 이 DIAG 프로그램의 버전·결함 이력에 섞지 않는다.

## 3. 프로젝트 목적과 업무 환경

### 3.1 출발점

개인 계정에서 ERP Export와 DIAG를 어느 정도 개발한 뒤 Business 계정에서 이어서 작업하기로 했다. 사용자는 전체 업무맥락 정리와 후속 작업의 연속성을 요청했고, 기존 두 프로그램의 개선 의견도 검토 대상으로 요청했다.

그 후 별도 WEBGUI 전면개편 프로젝트에서 사용한 웹자산 비교·저장·활성화 경험을 DIAG에 적용하는 방향으로 범위가 확장됐다.

### 3.2 사용자가 원하는 사용 방식

1. 개발 패키지 또는 BSP 애플리케이션 하나를 Export한다.
2. 추출된 패키지 안의 특정 HTML·HTM·JS·CSS·MIME 파일을 로컬에서 수정한다.
3. 원본 구조를 유지한 ZIP을 DIAG에 업로드한다.
4. 추출 당시 원본, 수정 ZIP, 현재 SAP 내용을 비교한다.
5. 웹자산 모드에서 선택한 기존 파일만 서버에 반영한다.
6. BSP는 해당 페이지를 활성화하고, 저장·활성화 결과를 구분해 확인한다.

### 3.3 대상 환경

| 항목 | 기준 |
|---|---|
| 시스템 | SAP ERP ECC 6.0 |
| ABAP 호환 기준 | SAP_BASIS 700, Unicode |
| DIAG REPORT | `z_package_diag` |
| 기존 진단 기준 | DIAG 0.4.5 |
| 기존 MIME 반영 기준 | DIAG 0.5.0 |
| 최신 수정본 | Export 0.4.1 / DIAG 0.7.1 |
| 최초 Export 개발 기준 | 0.3.18, 이후 0.4.0 BSP 모드, 현재 0.4.1 |
| 실행 방식 | SAP GUI에서 대화형 실행 |
| 서버 접속 | 이 작업 환경에서 실제 SAP 서버에 접속해 실행한 것은 아님 |
| 배포 형식 | 전체 단일 `.abap` REPORT와 설명·변경 내역·검증 자료 ZIP |

0.6.x BSP 반영 오류 수정 당시에는 Export를 변경하지 않았다. 이후 0.4.0에서 BSP 단독 모드를 추가했고, 현재 0.4.1에서 단일 앱 폴더 구조로 수정했다.

## 4. WEBGUI 참고 자료와 적용한 방향

사용자가 제공한 공유 링크:

[WEBGUI 전면개편 프로젝트 공유 대화](https://chatgpt.com/share/e/6ad5f566-e818-83ec-9e8a-bf172acad247)

확보된 참조 소스:

`/workspace/scratch/ff86f61403eb/bsp-work/input/Z_ITS_WEBASSET_APPLY.abap`

파일 헤더에서 확인한 참조 프로그램은 `Z_ITS_WEBASSET_APPLY`, 버전 1.0.9이며 기존 ITS `IAMU/IATU` 콘텐츠를 대상으로 한다.

DIAG에 적용한 것은 선택·재비교·백업·저장·재검증 흐름과 상단 도구모음 방식이다. 객체별 저장 방식까지 동일하게 취급하지 않는다.

| 객체 | 현재 DIAG에서 반영 성공의 의미 |
|---|---|
| SMIM·W3MI | 기존 MIME 콘텐츠 저장 후 바이트·매핑·CTS 검증 |
| BSP WAPP | 기존 페이지 Layout 저장 후 해당 페이지 활성화, 활성 내용·다른 탭·CTS 검증 |
| ITS IAMU/IATU | 현재 DIAG 반영 범위 밖. 참조 프로그램의 publish 흐름을 그대로 제공하는 것이 아님 |

버튼 이름이 `선택 저장/활성화`여도 MIME에 BSP 활성화를 수행하는 것은 아니다. 실제 웹 화면 실행과 브라우저·서버 캐시 검증은 별도이다.

## 5. 대화 흐름과 요구사항 변화

| 순서 | 사용자 요청·보고 | 처리 결과 또는 현재 해석 |
|---|---|---|
| 1 | 개인 계정 ERP 소스 추출·검증 작업을 Business 계정으로 이관 | 업무맥락과 자료를 이어서 관리하는 프로젝트로 진행 |
| 2 | 기존 Export·DIAG 개선 의견 요청 | 검토 대상으로 두었으며, 이후 웹자산 반영 요청으로 초점 이동. 초기 제언 세부 원문은 이 문서에서 임의 복원하지 않음 |
| 3 | WEBGUI 공유 링크처럼 비교 후 저장·활성화하고 싶음. 우선 구현 없이 검토 요청 | ABAP·DDIC 반영보다 웹자산부터 확대하는 방향 설정 |
| 4 | 공유 링크 접근 실패와 로그인·별도 인증코드 입력 가능 여부 문의 | 이후 사용자가 링크 확보를 전제로 검토 재요청. 인증 완료 세부 과정은 현재 근거로 확정하지 않음 |
| 5 | 수정한 Export 패키지를 DIAG에 올려 웹자산 서버 반영하도록 구현 요청 | 기존 SMIM·W3MI 반영을 지원하는 0.5.0 기반 확보 |
| 6 | HTM을 수정해 목록에는 나오는데 저장/활성화 버튼을 찾지 못함 | 실제 수정 대상이 MIME이 아닌 BSP 페이지임을 확인 |
| 7 | 시스템의 웹 작업 대부분이 BSP이며 Layout HTML부터 반영하고 싶음 | BSP Layout 저장·기존 페이지 활성화로 확장 승인 |
| 8 | 기존 SMIM·W3MI에 BSP 지원 추가 요청 | 0.6.0 BSP 확장본 작성 |
| 9 | 521줄 `SO2_VERSION is unknown` | 0.6.1 타입 호환성 수정 |
| 10 | `BSP Properties의 키·언어·페이지 유형 검증 실패` | 0.6.2 유형 판정 및 필드별 진단 보완 |
| 11 | `BSP 행 길이/형 변환 손실: 줄을 나누고 다시 업로드하십시오.` | 0.6.3 고정 길이 문자형 패딩 오탐 수정 |
| 12 | 작업 완료 시 수정 ABAP 다운로드를 반드시 달라고 요청 | 이후 전체 REPORT와 ZIP을 실제 파일로 전달하는 방식 유지 |
| 13 | `Could not generate the data object; the type __DYNAMICALLY_CREATED_TYPE__ is generic` | 0.6.4 범용 RTTI 생성·객체 키 바인딩 수정 |
| 14 | 같은 BSP 애플리케이션의 미활성 정의/페이지 때문에 차단 | 초기 안내에서는 SE80 미활성 객체 확인을 설명 |
| 15 | SE80에서는 Active로 보이며 다른 HTM 편집 때문에 전체 차단하는 것은 부당하다고 지적 | 0.6.5에서 다른 페이지 미활성 여부에 따른 전역 차단 제거 |
| 16 | `운송 대상 파일: 내 수정 가능한 Workbench 작업 번호를 선택 화면에 입력하십시오.` | 코드상 `p_task` 공란인 사전점검 오류. 하위 작업 번호 입력 위치·조건 안내. 이 건만으로 코드 변경하지 않음 |
| 17 | CTS 입력 후 `FAILED_REVIEW`, 저장된 미활성/활성 Layout이 업로드와 다르다는 오류 | 0.6.5 화면에서 활성화 `NOT_RUN` 확인. 0.6.6 검증 기준·오류 기록 수정 |
| 18 | 전체 대화 정리와 Markdown 명세 요청 | 문서 1.0 작성. 당시 0.6.6 전달·재시험 대기 상태를 기록 |
| 19 | 0.6.6에서 저장 전 원본/API Layout 불일치: 258/257행, 1행 2열 ?/% | 저장·활성화 미실행 확인. XML 선언행이 추가된 표현을 가능 원인으로 분석 |
| 20 | 위 오류에 대한 후속 수정 | 0.6.7: 직접 대응 우선, 독립 선언행 제외 후 원본 본문 전체 대조. 문서 1.1 작성 |
| 21 | 0.6.7에서 같은 차이와 ‘선두 XML 선언행 확인 불가’ | 실제 Layout 원문 필요성을 확인하고 수정 ZIP 요청 |
| 22 | ZHR5.zip 첨부 | 대상 .htm이 SO2 XML임을 확인. 주석 2줄·빈 줄 수정은 마지막 static 1개 내부에 있음 |
| 23 | 첨부 ZIP에 대한 후속 수정 | 0.6.8 SO2 static 대응 구현, 신규 119건·기존 회귀 통과. 문서 1.2로 원인 정정. 실제 SAP 재시험 대기 |
| 24 | 0.6.8 저장 후 I 버전 조회와 WAPP 점검 결과 불일치 | I 버전 내용 검증 이후 경고 프로토콜 항목을 필수로 요구한 오탐 확인. 활성화 NOT_RUN |
| 25 | 위 저장 후 실패 수정 | 0.6.9: I 직접 검증을 저장 증거로 사용, 경고 없음에 따른 차단 제거, 확인된 저장 상태 보존. 문서 1.3 갱신 |
| 26 | 0.6.9에서 ACTIVATION_REVIEW와 CX_SY_DYN_CALL_ILLEGAL_TYPE | 화면에 SAVED_INACTIVE 확인. 활성화 호출 또는 결과 조회 중 타입 예외이며 정확한 인수 미확정 |
| 27 | 위 타입 오류 후속 수정 | 0.6.10: P_CHECKLIST의 구체 참조 변수, 저장 전 형식 점검, 호출부 직접 CATCH·원인 연쇄·위치 기록. 문서 1.4 갱신 |
| 28 | 0.6.10 WAPP·WAPD 중복 경고로 BLOCKED | JSON 두 조회 모두 같은 EU829/VAR1=WAPP. 저장·활성화 NOT_RUN, A=C 확인 |
| 29 | 경고 오분류와 기존 I 재개 보완 | 0.6.11: 객체별 분류·전체 키 대조·조건부 활성화 재개. 문서 1.5 갱신 |

## 6. Export 패키지와 3자 비교 명세

### 6.1 입력 형식

현재 `im_manifest_compat` 코드가 허용하는 값:

| 필드 | 값 |
|---|---|
| `FORMAT` | `DEVHUB-EXPORT` |
| `VERSION` | `0.2` |
| `TOOL_VERSION` | `0.3.18` 또는 `0.3.28` |

코드 주석은 0.3.18을 기준으로 설명하며 0.3.28 태그도 유지한다. 이는 **현재 reader의 허용 목록**이며, 두 Export 버전의 모든 실행 결과를 이 대화에서 실서버 검증했다는 뜻은 아니다. 다른 버전을 통과시키기 위해 manifest 버전 값을 수동으로 바꾸지 않는다.

주요 구조:

| 위치·파일 | 역할 |
|---|---|
| `manifest.xml` | 파일 경로, 객체 정보, 원본 길이·체크섬·비교 모드 등 |
| `packages/...` | 사용자가 수정할 작업 파일 B |
| `.devhub/baseline/...` | 추출 당시 원본 A |
| `catalog/web-assets.xml` | 웹자산과 SAP 객체의 대응 정보 |
| 자산별 메타데이터 | MIME 식별자·언어·경로·매개변수 등 |
| BSP `page-paths.xml` | 내부 페이지 키와 원래 파일명·추출 경로 대응 |
| BSP `Properties.xml` | 페이지 키·언어·속성·유형 |

콘텐츠만 수정한다. baseline, manifest, 매핑 XML, 언어·객체 식별자, 폴더·파일명을 차단 회피 목적으로 바꾸지 않는다. 원본 CRC와 길이 검사는 원본 사본의 일관성 점검이며 암호학적 서명 검증은 아니다.

### 6.2 A/B/C 정의

| 기호 | 의미 |
|---|---|
| A | Export 당시 원본, ZIP에 포함된 baseline |
| B | 사용자가 수정한 업로드 ZIP 콘텐츠 |
| C | DIAG 실행 시 읽은 현재 SAP 콘텐츠 |

기존 A→B, A→C, C→B 비교를 유지한다. 반영 결과는 별도 `WA_*` 필드에 기록한다. 저장 후 기존 비교 열의 ‘수정’이 남아 있어도 이상이 아니다. 새 서버 상태를 기준으로 비교하려면 다시 실행한다.

### 6.3 저장 후보 판정

| 조건 | 기본 판정 |
|---|---|
| A=C, B만 변경 | `READY` 후보. 나머지 매핑·권한·API·미활성 조건까지 통과해야 함 |
| B=C | `ALREADY_EQUAL`, 저장 불필요 |
| A=B, C만 변경 | `UPLOAD_UNCHANGED`, 업로드로 서버 변경을 되돌리지 않음 |
| A·B·C가 서로 다른 변경 상태 | `CONFLICT`, 재추출·병합 필요 |
| 원본·업로드·현재 내용 중 필요한 읽기 실패 | 저장 차단 |
| 신규 파일·삭제·미확정 매핑 | 현재 반영 기능으로 처리하지 않음 |

## 7. 기능 범위와 화면 명세

### 7.1 현재 반영 범위

| 자산 | 진단 | 저장 | 활성화·제약 |
|---|---|---|---|
| SMIM 기존 MIME | 가능 | 가능 | 별도 BSP 활성화 없음. LOIO·URL·실제 언어·패키지 보존 |
| W3MI 기존 MIME | 가능 | 가능 | 콘텐츠·filesize 갱신, 기타 기존 매개변수 보존 |
| BSP 기존 페이지 Layout | 가능 | 가능 | 해당 WAPP 페이지 활성화. 공백/V/X 유형 대상 |
| BSP Page Attributes | 조회·비교/보존 점검 | 업로드 반영 제외 | Layout과 동반 변경되면 차단 가능 |
| BSP Event Handler·Type Definitions | 조회·비교/보존 점검 | 업로드 반영 제외 | Layout과 동반 변경되면 차단 가능 |
| BSP 애플리케이션 속성·공통 정의 | 조회·보존/경고 점검 | 업로드 반영 제외 | 공통 WAPD 경고 별도 처리 |
| ABAP 프로그램·함수·Include | 기존 진단 유지 | 제외 | 자동 반영 없음 |
| DDIC·메타데이터 XML | 기존 진단 유지 | 제외 | XML을 DDIC 변경으로 실행하지 않음 |
| 신규·삭제·이름/경로/언어/유형 변경 | 진단 결과로 표시 가능 | 제외 | 기존 파일 교체 범위 |
| ITS IAMU/IATU 저장·publish | 현재 DIAG 반영 범위 밖 | 제외 | 참조 WEBGUI 도구와 구분 |

표의 ‘가능’은 코드 구현 범위이다. 모든 자산 유형의 사용자 SAP 성공 시험이 완료됐다는 뜻은 아니다.

### 7.2 선택 화면

- `진단 대상`: 개발클래스(하위 포함).
- `추출본 파일`: 비교할 Export ZIP.
- `추가선택(결과유형)`: **전체 / ABAP 소스 / XML / 웹자산(HTML·JS·CSS·MIME)**.
- `신규/누락/수정만 조회` 체크박스.
- `웹자산 CTS 작업(요청 하위)` 입력란: 위 체크박스 아래.

초기 요청의 핵심인 ABAP와 웹자산 분리를 구현하면서 기존 전체·XML 모드는 유지했다.

### 7.3 결과 화면과 버튼

웹자산 결과 목록의 별도 상단 도구모음:

- `선택 저장/활성화`
- `반영 로그 저장`
- `JSON 다운로드`

상세 비교를 확인한 후 목록으로 돌아와 대상 행을 선택하고 반영한다. 상세 비교 화면에서 직접 저장하는 구조는 아니다. 전체·ABAP·XML 결과 모드에서는 저장 기능을 제공하지 않는다.

선택은 행 ID 기준으로 처리한다. 정렬 후에도 같은 객체를 대상으로 한다. 필터로 숨겨진 선택 행, 저장 불가 행 혼합 선택은 사전점검에서 막는다. 한 번에 최대 100개이며 이미 반영을 시도한 행은 같은 실행 화면에서 재시도하지 않고 재진단한다.

주요 결과 정보: 반영등·반영 상태·설명, 저장 결과, 활성화 결과, 대상 미활성 점검, BSP 애플리케이션·페이지 키·유형, 서버 경로, CTS 작업, 반영 후 크기와 확인 시각.

## 8. BSP 반영 상세 명세

### 8.1 페이지 식별과 허용 유형

- 내부 `APPLNAME/PAGEKEY`와 원래 표시 파일명을 구분한다.
- `page-paths.xml`, 자산 카탈로그, `Properties.xml`, manifest를 교차 확인한다.
- 실제 SAP 내부 언어 키를 사용한다. 샘플의 `3`을 임의로 `KO`로 바꾸지 않는다.
- 파일명 대소문자를 근거로 내부 키를 새로 만들지 않는다.

| `PAGETYPE` | 의미 | Layout 반영 |
|---|---|---|
| 공백 | Flow Logic | 지원 |
| `V` | View | 지원 |
| `X` | Fragment | 지원 |
| Controller 및 기타 | 별도 유형 | 이번 범위에서 제외 |

공백은 유효한 페이지 유형이다. 다만 Properties 자체가 없거나 키가 빈 데이터를 정상 페이지로 허용하지 않는다.

### 8.2 Layout과 다른 탭 보존

- `SET_PAGE`로 Layout만 설정한다.
- `SET_ATTRS`, `SET_PARAMETERS`, `SET_EVENT_HANDLERS`, `SET_TYPE_SOURCE`로 업로드 값을 쓰지 않는다.
- 같은 페이지의 Page Attributes, Event Handler, Type Definitions 및 애플리케이션 속성을 전후 비교한다.
- SAP 관리용 버전·수정일시·생성 정보 일부만 보존 비교에서 제외한다.
- 기존 `<% ... %>`, `<%= ... %>`, `<%@ ... %>` 등의 서버 측 구문은 내용과 순서를 유지한다.
- `RUNAT` 구문은 현재 보수적 지원 범위에서 제외한다.
- 이 문자열 보존 검사는 HTML/JS/CSS의 실행 안전성이나 업무 기능 정상 동작을 증명하는 검사는 아니다.

### 8.3 문자·행 변환

- UTF-8 확인과 바이트 왕복 검증을 사용한다.
- 입력 단계의 BOM, CRLF/LF, 마지막 개행 1개 처리 정책은 기존 코드를 유지한다.
- 단독 CR은 차단한다. 내부 빈 행과 의미 있는 공백을 임의로 제거하지 않는다.
- 고정 길이 C형은 대입 전에 실제 문자 용량을 확인한다. 잘림을 허용하지 않는다.
- 고정 필드가 추가한 패딩과 입력 범위의 문자를 구분한다.
- 한 행이 실제 용량을 초과하면 행 번호·입력 길이·용량을 보여 준다. 자동 줄바꿈으로 HTML/JS 의미를 바꾸지 않는다.
- 여러 필드 구조·비문자 행 등 해석할 수 없는 형식은 차단한다.

### 8.4 미활성 점검 범위

0.6.5부터 애플리케이션 전체의 `GET_ALL_PAGES(I)` 목록을 선택 페이지 차단 근거로 사용하지 않는다.

| 상태 | 현재 처리 |
|---|---|
| 다른 HTM에 미활성 변경 존재 | 그것만으로 선택 페이지를 차단하지 않음 |
| 선택 WAPP에 기존 미활성/점검 경고 | I·작성자·전체 키·다른 탭 검증 일치 시 `READY_ACTIVATE`, 불일치 시 차단 |
| 공통 WAPD에 미활성/점검 경고 | `APP_REVIEW`, 별도 차단 |
| 두 경고 모두 | `BOTH_REVIEW` |
| 조회 실패 | `CHECK_FAILED` |
| 해당 점검에서 경고 없음 | `NONE` |

`RS_INACTIVE_OBJECTS_WARNING`를 정확한 WAPP 키와 WAPD 키에 각각 호출하고 반환 프로토콜을 요청한다. 메시지가 있다는 이유만으로 그 메시지의 실제 의미를 모두 ‘미활성 확정’이라고 해석하지 않는다. `wa_inactive_detail`에 객체·키·원문 프로토콜을 남긴다.

**0.6.9 저장 후 판정:** 경고 프로토콜에 항목이 없다는 사실은 I 버전 부재의 증거가 아니다. 별도 세션의 LOAD(I)·GET_VERSION=I·native Layout 전체 일치·다른 탭 보존을 확인하면 저장을 검증한 것으로 기록한다. `SAVED_INACTIVE_STATE`에 WAPP/WAPD 프로토콜 유무, 반영 로그 `SAVED_INACTIVE_PROTOCOL`에 원문을 남긴다. 공통 WAPD 경고는 이후 활성화를 계속 차단한다. 0.6.9 자체에는 기존 I 재개 기능이 없었다. 0.6.11의 조건부 재개는 아래 별도 규칙으로 추가했다.

**0.6.11 분류:** EU829의 VAR1/VAR2와 조회 대상 객체를 구분한다. WAPD 조회에 나온 WAPP 메시지는 `RELATED_WAPP_NOT_WAPD`로 보관한다. 선택 WAPP/공통 WAPD 전체 키를 DWINACTIV에서 각각 읽어 별도 확인하며, 전체 앱을 조회하거나 테이블을 변경하지 않는다. 잘린 VAR2는 검토 신호일 뿐 쓰기 허용 근거가 아니다. 미해석 메시지는 보류한다. JSON 원문에 전체 키의 작업 목록과 시스템 메시지·분류를 추가한다.

**0.6.11 활성화 재개:** 전체 WAPP 키의 작업 기록이 현재 사용자 소유이고 삭제 표시가 없어야 한다. 별도 세션 I 버전·native Layout=B·다른 탭/속성 일치를 확인하면 `READY_ACTIVATE / RESUME_VERIFIED` 후보가 된다. 실행 시 기존 CTS 작업에 정확한 WAPP이 이미 등록됐는지 확인하고, 잠금·내용·소유자를 다시 검사한다. `SET_PAGE/SAVE`와 CTS 삽입을 생략하고 한 WAPP만 활성화한다. I가 다르면 덮어쓰지 않는다. 재사용 성공은 저장 상태 `REUSED_VERIFIED`로 구분한다. 원래 실패 실행의 식별자까지 증명하는 기능은 아니며 현재 상태에 근거해 재개한다.

사용자가 보여 준 SE80 애플리케이션의 `Active` 표시는 선택한 앱 화면의 상태이며 모든 하위 페이지의 편집 상태가 없다는 증거로 사용하지 않는다. 확인 메뉴는 왼쪽 트리의 해당 애플리케이션을 우클릭한 뒤 `활성화`이다. 목록 확인과 실제 활성화 실행은 구분한다.

표준 애플리케이션 잠금은 계속 사용한다. 다른 개발자가 앱을 편집하며 잠금을 보유한 경우에는 잠금 획득이 거부될 수 있다. 이는 다른 HTM의 미활성 변경이 존재한다는 이유로 차단하는 것과 별개다.

실제 공통 정의 변경을 허용하거나 다른 모든 페이지의 전후 보존을 독립적으로 증명하는 기능은 완료 범위로 기록하지 않는다.

### 8.5 저장·활성화 절차

1. 원본·업로드·현재 상태와 객체·언어·페이지 매핑을 확인한다.
2. 원본 Layout과 현재 `P_CONTENT`의 전체 대응을 `BASELINE_CHECK`한다. 직접 대응을 우선하고 SO2 XML은 static 좌표·본문을 검증해 변환한다(8.8절). 독립 선언행 대응은 별도 형식으로 유지한다.
3. 선택 전체의 API·권한·CTS 사전점검을 통과한다.
4. 표준 잠금 후 현재 내용을 다시 확인한다.
5. 원복 ZIP과 실행 로그를 저장하고 재읽어 확인한다.
6. 파일별 최신 내용과 다른 탭 상태를 확인하고 저장 의도를 기록한다.
7. `RS_CORR_INSERT`로 해당 `LIMU WAPP`을 CTS 작업에 등록하고 확인한다.
8. 활성 A 버전을 읽은 핸들에서 `SET_PAGE`로 Layout을 설정한다.
9. 즉시 `GET_PAGE`하여 `SET_PAGE_READBACK`을 확인한 뒤 `SAVE`한다.
10. COMMIT 후 별도 내부 세션에서 I 버전임을 확인하고 `SAVED_INACTIVE_CHECK`·다른 탭 보존을 검증한다. 통과 즉시 `SAVED_INACTIVE`를 기록한다. WAPP 경고 프로토콜의 존재를 필수 조건으로 삼지 않으며, 공통 WAPD 경고는 활성화를 차단한다.
11. `RS_WORKING_OBJECTS_ACTIVATE`에 해당 WAPP 한 건을 전달한다. 애플리케이션 전체를 활성화하지 않는다.
12. 활성화 메시지와 반환 객체 범위를 확인하고 COMMIT한다.
13. 별도 내부 세션 A 버전에서 `ACTIVE_CHECK`, 다른 탭·미활성 상태·CTS를 확인한다.
14. 결과와 로그를 저장하고 획득한 잠금을 해제한다. 첫 실패 뒤 나머지 파일은 진행하지 않는다.

0.6.11의 `READY_ACTIVATE` 경로에서는 7~10의 새 저장 대신 기존 CTS 등록·I 내용·작성자를 재검증하고 `REUSED_INACTIVE`를 기록한다. 새 CTS 삽입·SET_PAGE·SAVE는 호출하지 않는다. 이후 11~14의 활성화와 사후 검증은 동일하다.

별도 조회 세션은 같은 REPORT의 읽기 전용 분기를 `SUBMIT ... AND RETURN`으로 호출한다. 쓰기 핸들의 캐시만 보고 저장·활성화 성공을 판정하지 않기 위한 구조다.

### 8.6 0.6.6 검증 기준

**기준:** `SET_PAGE`에 전달한 `O2PAGELINE_TABLE`과 `GET_PAGE`가 돌려준 같은 타입의 `P_CONTENT`를 직접 비교한다.

| 비교 결과 | 판단 |
|---|---|
| 행 테이블 정확히 일치 | 해당 Layout 내용 검증 통과. 다른 보호 조건은 별도로 통과해야 함 |
| 행 테이블 불일치 | 실패. 행 수·최초 차이 행/열·문자 기록 |
| 행은 같지만 원시 Layout 바이트가 다름 | 원시 비교 `DIFFERENT`를 기록. 표현 차이만으로 행 검증을 실패시키지 않음 |
| 원시 바이트는 같지만 행이 다름 | 실패 |
| 원시 Layout 문자 해석 실패 | `UNREADABLE`과 오류를 증거로 기록. 행 테이블 검증 결과와 구분 |

문자열 행의 후행 공백은 비교 대상이다. 고정 길이 필드는 동일한 폭의 실제 값끼리 비교한다. `CONDENSE`나 일괄 trim으로 통과시키지 않는다.

새로운 `wa_verify_detail`에는 `BASELINE_CHECK`, `SET_PAGE_READBACK`, `SAVED_INACTIVE_CHECK`, `ACTIVE_CHECK`, `OBSERVED_AFTER_ERROR` 단계의 근거가 남는다. 차이 문자는 `<SPACE>`, `<TAB>`, `<LF>`, `<EOL>`로 구분해 보여 준다.

### 8.7 0.6.7 Export/API 표현 대응

0.6.6 사용자 오류는 원본 258행/API 257행, 첫 행 둘째 문자 `?/%`였다. 당시에는 원문이 없어 독립 XML 선언행 차이로 가정했다. **이후 ZHR5.zip에서 SO2 XML 전체 구조가 확인되어, 해당 사용자 사례에 대한 이 가정은 정정했다.** 아래 규칙은 실제로 독립 선언행만 다른 별도 형식에 한해 유지한다.

| 단계 | 허용 조건·처리 |
|---|---|
| 직접 대응 | 원본 전체를 변환한 행이 현재 `P_CONTENT`와 같으면 `mode=DIRECT`. 실제 Layout의 XML 선언은 보존 |
| 선언 후보 | 직접 대응 실패 시에만 첫 줄의 독립 XML 1.0 선언 확인. 인코딩 생략/UTF-8, 선택적인 standalone=yes/no 지원 |
| 원본 증명 | 선언행 1개를 제외한 나머지 원본의 모든 행이 현재 `P_CONTENT`와 정확히 일치해야 함 |
| 업로드 확인 | 업로드에도 같은 선언행이 그대로 있어야 함. 변경·삭제 시 차단 |
| 저장 입력 | 두 조건 통과 시 `mode=XML_DECLARATION`으로 본문만 기존 변환·서버 구문 보존 검사에 전달 |
| 미확정 | `mode=UNRESOLVED`, 직접 비교 및 후보 비교의 차이를 기록하고 차단 |

- 선언행의 탭·공백과 작은따옴표도 지원하되, 원본/수정본 선언행의 실제 내용은 같아야 한다.
- 다른 처리 지시문, XML-stylesheet, UTF-16 선언, 선행 빈 줄, 선언과 HTML이 같은 줄에 있는 형태는 이 변환으로 허용하지 않는다.
- 본문의 빈 행·공백을 임의로 지우거나 행 수만 맞춰 통과시키지 않는다.
- ZIP·baseline·원시 A/B/C는 변경하지 않는다. 기존 충돌·백업·다른 탭 보존 검사는 유지한다.
- XML 선언 분리는 서버의 실제 Layout에 넣을 행을 결정하는 과정이다. Export 재추출이나 헤더 수동 삭제를 요구하지 않는다.

### 8.8 0.6.8 SO2 XML Layout 대응

확인한 실제 원본 첫 부분:

```xml
<?xml version="1.0" encoding="utf-8"?><so2:page o="0" x="1" y="1" language="javascript">
```

실제 파일에는 줄바꿈 없이 `so2:static`이 이어진다. `.htm` 확장자만으로 편집용 HTML이라고 판단하면 안 된다. 이 파일에는 `xmlns:so2` 선언도 없다.

| 단계 | 처리 기준 |
|---|---|
| 파싱 | 임시 wrapper에 so2 namespace와 `xml:space="preserve"`를 제공. ZIP·서버 원시는 변경하지 않음 |
| 변경 범위 | 원본/수정본의 구조·모든 속성·include·서버 script가 같아야 함. 기존 최상위 static의 문자/CDATA 본문만 변경 허용 |
| 위치 검증 | 원본 static의 x/y 행·열 좌표를 현재 SAP P_CONTENT와 대조. 겹침·역순·범위 오류·본문 차이 차단 |
| 서버 구문 보존 | static 이외 구간은 현재 SAP 편집용 Layout에서 복사. 서버 지시문을 추측하거나 XML 태그를 일괄 제거하지 않음 |
| 전체 원본 증명 | 복원한 원본을 동일 SAP 행 타입으로 변환하여 현재 P_CONTENT 전체와 정확히 비교 |
| 저장 입력 | 변경 static 본문으로 편집용 행 생성. 기존 서버 토큰·UTF-8·행 용량 검사 적용 |
| 결과 확인 | `SET_PAGE_READBACK` → I 저장 확인 → 단일 WAPP 활성화 → A 확인 유지 |
| 로그 | `BASELINE_CHECK:mode=SO2_XML`, 전체 행 대응 결과, 변경 static 구간 수 |

- XML 문자 참조는 파서로 한 번 해석한다. CDATA 안의 HTML 엔티티 문자열은 보존한다.
- 고정 C형 패딩은 native 필드 특성에 따라 다루고, static에 명시된 공백과 STRING 후행 공백은 유지한다. 최종 원본 native 행 전체가 같은지 확인한다.
- XML 메타데이터의 o/x/y를 로컬 편집기에 맞춰 갱신하지 않는다. 수정본에도 원본 좌표를 유지하고, 원본 좌표로 현재 SAP의 교체 범위를 찾는다.
- 중첩 static·XML 노드 추가/삭제·서버 script/include 변경은 이번 범위에서 제외한다.
- 외부 DTD/ENTITY는 차단하며 CDATA 안의 HTML DOCTYPE 문자는 일반 본문으로 유지한다.
- 원본 바이트를 읽는 Export 및 DIAG snapshot reader는 바꾸지 않았다. 이번 변경은 저장 전 예상 행 생성 단계에 한정한다.

## 9. CTS·백업·실패 처리

### 9.1 CTS 입력 조건

현재 코드의 조건:

- 입력 작업: `E070-TRFUNCTION = S`, `TRSTATUS = D`.
- 작업 소유자: 현재 `SY-UNAME`.
- 상위 요청: `TRFUNCTION = K`, `TRSTATUS = D`.
- `$TMP`는 작업 번호 없이 처리한다.
- 다른 로컬 패키지·수리 작업·타 사용자 작업 등을 자동으로 허용하는 기능은 아니다.

SE09/SE10에서 적절한 Workbench 요청을 펼쳐 **본인 하위 개발 작업** 번호를 확인한다. 현재 버전은 저장 시 표준 CTS 선택 팝업을 띄우지 않는다. 이 입력을 위해 요청·작업을 릴리스할 필요가 없다.

`PREFLIGHT_FAILED`와 저장/활성화 `NOT_RUN`이었던 CTS 공란 사례는 저장 전 중단이었다. 반면 저장 후 `FAILED_REVIEW`는 같은 의미가 아니다.

### 9.2 백업과 원복

- 백업 ZIP: 선택 파일과 매핑·필요 동반 파일을 포함한다.
- 자동 실행 로그: 백업 ZIP 경로에 `.run.xml`을 붙인 파일.
- 수동 로그: `반영 로그 저장`.
- 전체 결과: `JSON 다운로드`.
- 백업 ZIP은 같은 DIAG에서 다시 진단할 수 있는 부분 패키지다.
- 원복 ZIP의 B는 저장 직전 서버 내용, A는 정방향으로 넣으려던 내용이다.
- 정상 활성화 후 서버가 정방향 결과 그대로이면 원복 후보가 될 수 있다. 이후 다른 변경이 생기면 충돌을 검토한다.
- BSP에 기존 미활성 변경이 남아 있으면 원복도 차단될 수 있다. 자동 삭제·자동 강제 덮어쓰기는 하지 않는다.

여러 파일을 하나의 원자적 트랜잭션으로 반영하지 않는다. 앞선 성공 파일은 뒤 파일 실패 후에도 남을 수 있다. API 내부 또는 명시적 COMMIT이 있으므로 `ROLLBACK WORK`를 원복 성공의 증거로 사용하지 않는다.

### 9.3 상태 읽기

| 상태 | 의미 |
|---|---|
| `READY` | 저장 후보 |
| `READY_ACTIVATE` | 기존 I=업로드 검증을 통과한 활성화 재개 후보 |
| `RESUME_VERIFIED` | 미활성 점검 열: 전체 키·작성자·I 내용·다른 탭 검증 일치 |
| `ALREADY_EQUAL` | 현재 SAP와 같아 저장 불필요 |
| `UPLOAD_UNCHANGED` | 업로드가 원본 그대로이므로 서버 변경을 되돌리지 않음 |
| `CONFLICT` | 원본 이후 서버와 업로드가 모두 달라 재검토 필요 |
| `BLOCKED` | 매핑·지원 범위·점검 조건 불충족 |
| `PREFLIGHT_FAILED` | 실제 반영 사전점검 실패 |
| `SAVED_VERIFIED` | MIME 저장 후 검증 성공 |
| `SAVED_INACTIVE` | BSP I 버전 저장 확인 |
| `REUSED_INACTIVE` | 기존 I를 재검증하여 사용, 이번 저장은 생략 |
| `REUSED_VERIFIED` | 저장 상태 열: 기존 I 재사용 후 활성화·사후 검증 성공 |
| `SAVED_NOT_ACTIVATED` | I 저장 또는 재사용 확인 후 활성화 호출 전에 중단. 0.6.9는 I 내용 검증 후 WAPD 경고로 중단된 경우도 이 상태로 보존 |
| `ACTIVATION_REVIEW` | 활성화 시도 또는 이후 검증에 오류 |
| `ACTIVATED_VERIFIED` | BSP 저장 또는 기존 I 재사용·페이지 활성화 및 후속 검증 성공 |
| `FAILED_REVIEW` | 저장/조회/검증 등 실패. 실제 서버 상태 확인 필요 |
| `LOG_FAILED_REVIEW` | 로그 기록 실패. 후속 파일 중단 |
| `NOT_RUN` | 해당 단계 미실행. 다른 단계까지 미실행이라는 뜻은 아님 |

## 10. 버전별 수정 이력

| 버전 | 계기 | 핵심 변경 | 남은 한계 |
|---|---|---|---|
| 0.4.5 | 기존 패키지 진단 기반 | 3자 비교·ABAP 문법/활성 소스 증거 등 기존 진단 | 이번 문서는 초기 전체 개발 이력을 복원한 문서가 아님 |
| 0.5.0 | Export 웹자산을 서버에 반영 | 기존 SMIM·W3MI 선택 저장, CTS·잠금·백업·재조회 | BSP는 당시 진단 전용 |
| 0.6.0 | BSP가 주 사용 대상임을 확인 | 기존 BSP Layout 저장과 단일 페이지 활성화 추가 | 대상 SAP에서 타입·메타데이터·변환 문제가 후속 발견 |
| 0.6.1 | `SO2_VERSION is unknown` | 버전 타입을 로컬 C1로 통일, ABAP type-pool 명시, 일부 정적 별칭 의존 제거 | 대상 SAP 전체 DDIC/클래스 컴파일 보증 아님 |
| 0.6.2 | BSP Properties 검증 실패 | 실제 유형 공백/V/X로 수정, 키·언어·유형 오류 상세화, 유형 결과 열 추가 | 당시 사용자 Properties 원문으로 모든 불일치 원인을 확정한 것은 아님 |
| 0.6.3 | 짧은 HTML도 행 길이/형 변환 손실로 차단 | C형 패딩 오탐 수정, 대입 전 길이 확인, 입력 문자·빈 행 보존 | 실제 SAP 저장 후 표현 차이까지 검증한 수정은 아님 |
| 0.6.4 | 범용 동적 타입 생성 오류 | 객체 키 API의 입력을 구체 타입으로 바인딩, 범용 테이블의 구체 행 타입 생성 처리 | 실제 대상 SAP RTTI·커널 실행은 미확인 |
| 0.6.5 | 다른 HTM 미활성 때문에 전체 차단 | 선택 WAPP/공통 WAPD만 점검, 원문 프로토콜 보관 | WAPD 경고는 별도 차단 유지. 실제 메시지 의미는 로그로 확인 필요 |
| 0.6.6 | 저장된 I Layout 불일치와 활성본 불일치 메시지 | 동일 P_CONTENT 행 비교, 저장 전후 단계 분리, 최초 차이 기록, 활성화 미실행 시 중복 오류 제거 | 사용자 재시험에서 선두 원본/API 표현 차이로 저장 전 차단 |
| 0.6.7 | 저장 전 258/257행, 1행 2열 ?/% 차이 | 직접 대응 우선, 독립 XML 선언행 분리 후 전체 원본 대응 증명 | 사용자 재시험 실패. 이후 첨부에서 실제 SO2 XML 구조 확인 |
| 0.6.8 | 실제 ZHR5.zip의 SO2 XML 확인 | static 본문·원본 좌표를 native P_CONTENT와 대조하고 서버 구문을 보존하여 저장 입력 생성 | 사용자 실행에서 I 버전 내용 검증 뒤 WAPP 경고 유무 오탐으로 중단. 활성화 미실행 |
| 0.6.9 | I 버전 직접 검증 성공인데 WAPP 경고 없음으로 실패 | 잘못된 경고 항목 필수 조건 제거, SAVED_INACTIVE 즉시 기록, 프로토콜 원문 보존 | 실제 실행은 저장 검증 통과 후 타입 예외로 ACTIVATION_REVIEW |
| 0.6.10 | 활성화 단계 CX_SY_DYN_CALL_ILLEGAL_TYPE | 구체 P_CHECKLIST 수신 참조, 사전 타입 점검, 호출부 예외 원인·위치 기록 | 로컬 관련 검증 통과. 실제 실패 인수 확정 및 SAP 재시험 대기 |
| 0.6.11 | 같은 WAPP 경고를 WAPD로도 분류, 기존 I 때문에 재실행 차단 | 실제 객체/전체 키 분류, 조건부 활성화 재개, 저장 생략·기존 CTS 재검증 | 로컬 관련 검증 통과. 현재 I·작업 기록·실제 활성화는 SAP 재시험 필요 |

### 10.1 0.6.1~0.6.4 재발 방지 세부 기준

- `SO2_VERSION` 대신 `ty_bsp_version TYPE c LENGTH 1`을 사용한다. A/I 의미는 유지한다.
- `SEU_OBJKEY` 같은 선택적 별칭 대신 실제 CTS 필드 타입을 참조한다.
- 체크리스트 메시지 테이블은 대상 API 메타데이터를 확인한다. 읽을 수 없는 메시지를 버리고 성공 처리하지 않는다.
- BSP 객체 키는 SAP `GET_CONCATENATED_KEY_FROM_ID`를 이용한다. 파일명으로 수동 연결하지 않는다.
- 범용 ANY 입력 타입을 그대로 `CREATE DATA ... TYPE HANDLE`하지 않고 구체 키 변수의 참조를 전달한다.
- 표준/인덱스/범용 테이블의 생성 실패는 구체 행 타입으로 제한적으로 처리한다. 정렬/해시 키를 임의로 바꾸지 않는다.
- `web_lines`는 다른 소스 추출에도 사용되므로 BSP 오류를 피하기 위해 전체 동작을 바꾸지 않는다.

## 11. 현재 시험 사례와 마지막 실패의 정확한 상태

### 11.1 사용자가 시험 중인 객체

| 항목 | 확인된 값 |
|---|---|
| 개발 패키지 | `ZHR5` |
| BSP 애플리케이션 | `Z52_FLEX_TIME` |
| 내부 페이지 키 | `FLEX_WORK_PERFORMANCE_VIEW.HTM` |
| 원래 표시 파일명 | `FLEX_WORK_PERFORMANCE_VIEW.htm` |
| 언어 | SAP 내부 키 `3` |
| 페이지 유형 | Flow Logic, 공백 |
| 수정 규모 | 처음에는 HTML 약 2줄 수정으로 시험 |

보고된 패키지 내부 경로:

`packages/ZHR5/BSP Application/WAPA/Z52_FLEX_TIME/pages/FLEX_WORK_PERFORMANCE_VIEW/Layout/FLEX_WORK_PERFORMANCE_VIEW.htm`

### 11.2 직전 0.6.5 실패 이력

0.6.5에서 CTS 번호 입력 후 저장/활성화를 눌렀을 때:

> FAILED_REVIEW — 저장된 미활성 Layout이 업로드와 다릅니다. 활성 Layout이 업로드와 다릅니다.

화면에서 확인한 값:

- 저장 결과: `FAILED_REVIEW`.
- 활성화 결과: `NOT_RUN`.
- 대상 미활성 점검: `NONE`.

해석:

1. CTS 공란 단계는 넘어갔고 저장 후 I 버전 비교 단계에서 중단됐다.
2. 첫 오류 때문에 활성화 호출은 실행하지 않았다.
3. 기존 코드는 이때도 활성본과 업로드를 비교하여 두 번째 오류를 덧붙였다.
4. `NONE`은 화면에 남아 있는 반영 전 점검 값이다. 실패 후 I 버전이 없다는 보장은 아니다.
5. SAVE/COMMIT이 선행했을 수 있으므로 미활성본이 남을 수 있다.
6. 실제 사용자 I 버전의 `P_CONTENT/P_XML_SOURCE` 원문은 확보하지 못했다. 패딩·반환 표현 차이를 가능한 원인으로 보완했으나 확정 진단으로 기록하지 않는다.

### 11.3 0.6.6 사용자 SAP 결과

```text
저장 전 원본/API Layout 표현 불일치:
P_CONTENT 행 수 기대=258/조회=257;
최초 차이 행=1/열=2;
행 문자수 기대=255/조회=255;
차이 문자 기대=[?]/조회=[%]
```

- 반영 상태 `BLOCKED`, 저장 `NOT_RUN`, 활성화 `NOT_RUN`, 대상 미활성 점검 `NONE`.
- DIAG 0.6.6 진단 화면까지 실행됐으며 원본 표현 대응 사전점검에서 중단됐다.
- **이번 시도에서는 저장·활성화를 실행하지 않았다.** 이전 0.6.5가 남겼을 수 있는 I 버전까지 없다는 뜻은 아니다.
- 255/255는 비교한 고정 길이 필드의 문자수다. 이 숫자만으로 데이터 잘림이라고 판정하지 않는다.
- 합성 fixture에서 선두 XML 선언 + 257행 본문으로 같은 오류 형태를 재현했다. 사용자 실제 Layout과 P_CONTENT 원문은 확보하지 못했다.

### 11.4 최신 0.6.7 결과와 실제 첨부 확인

사용자 오류:

```text
원본/API Layout 표현 불일치: P_CONTENT 행 수 기대=258/조회=257;
최초 차이 행=1/열=2; 행 문자수 기대=255/조회=255;
차이 문자 기대=[?]/조회=[%]; 선두 XML 선언행 확인 불가.
```

화면에서 DIAG 0.6.7, `BLOCKED`, 저장·활성화 `NOT_RUN`, 미활성 점검 `NONE`을 확인했다. 이번 시도에서 쓰기는 실행되지 않았다.

이후 받은 파일: [ZHR5.zip](sandbox:/workspace/scratch/ff86f61403eb/upload/ZHR5.zip), 51,192,027바이트. 해당 페이지 A는 8,380바이트, B는 8,483바이트다.

| 확인 항목 | 결과 |
|---|---|
| 실제 형식 | XML 선언과 같은 줄에서 시작하는 SAP `so2:page` 구조 |
| 주요 요소 | page, static, include, script |
| static 개수 | 3개, 그중 마지막 1개만 변경 |
| 사용자 수정 | 브라우저 script 안 주석 두 줄 추가, 빈 줄 삭제/추가 |
| 서버 구문/속성 | include 경로·서버 script·XML 속성·좌표 동일 |
| 실제 P_CONTENT 원문 | 미확보. 화면에서 257행만 확인 |

원본 SHA-256: `b41e7dcc8da07e939399f47c84409da7a76ef99317f533e80b13efda61012db7`  
수정본 SHA-256: `3042e184284afe8790ceccf7537a9ed13f0d37824a88682038b68d7bd90ecdf9`

### 11.5 0.6.8 SAP 실행 결과와 0.6.9 수정

사용자 메시지와 실행 화면:

```text
FAILED_REVIEW
선택 BSP 페이지의 I 버전 조회와 WAPP 미활성 점검 결과가 일치하지 않습니다.
활성화는 실행하지 않았습니다.
```

화면은 DIAG 0.6.8이며 저장 FAILED_REVIEW, 활성화 NOT_RUN, 미활성 점검 NONE이다.
해당 문구가 생성되는 `wa_bsp_saved_check`의 순서로 확인한 사실:

1. SAVE와 COMMIT이 선행했다.
2. 별도 내부 세션의 I 버전 LOAD 및 GET_VERSION=I 확인이 통과했다.
3. native P_CONTENT 일치와 다른 탭/활성 애플리케이션 속성 보존 검사가 통과했다.
4. 그다음 WAPP 경고 프로토콜에 항목이 없다는 이유로 실패 처리했다.

즉 이 실패는 앞선 SO2 표현 불일치와 다른 단계이며, 활성화 성공의 근거는 아니다.
I 버전 직접 검증 결과와 경고 목록 유무를 같은 존재 증거로 강제 연결한 코드 오류다.
0.6.9는 항목 부재만으로 실패하는 조건을 제거하고 직접 검증을 유지한다.
I 검증 직후 SAVED_INACTIVE를 기록하므로 후속 WAPD 경고가 있으면
SAVED_NOT_ACTIVATED / 저장 SAVED_INACTIVE / 활성화 NOT_RUN으로 구분한다.
선택 WAPP 한 건 활성화 직전 재검증, 권한·CTS·잠금·백업은 유지한다.

| 항목 | 상태 |
|---|---|
| 0.6.8 사용자 SAP 실행 | 저장 후 I 내용 검증을 통과한 다음 경고 프로토콜 오탐으로 중단 |
| 0.6.9 코드·ABAP·ZIP·명세서 수정 | 완료 |
| 로컬 파서·회귀 검증 | 완료 |
| 0.6.9 SAP 실행 | 저장 후 I 검증 통과, 활성화/결과 조회 단계 타입 예외. 다음 절 참조 |
| 실제 BSP 화면 정상 동작 | 결과 미수신 |
| 백업으로 실서버 원복 시험 | 완료 근거 없음 |

이전 실행의 미활성 Layout이 남아 있을 수 있다. 새 진단에서 READY인 경우 재시험한다.
PAGE_REVIEW가 생기면 해당 페이지의 기존 I와 원문 경고를 확인해야 하며, 이번 변경으로
기존 I 자동 삭제/강제 재개나 애플리케이션 전체 활성화를 추가한 것은 아니다.

### 11.6 0.6.9 타입 예외와 0.6.10 조치

```text
ACTIVATION_REVIEW
An exception with the type CX_SY_DYN_CALL_ILLEGAL_TYPE occurred, but was neither
handled locally, nor declared in a RAISING clau...
```

사용자 화면에서 DIAG 0.6.9, 저장 SAVED_INACTIVE, 활성화 FAILED_REVIEW, 미활성 점검 NONE을 확인했다.
저장 직후 I 검증은 통과했다. 이후 활성화 함수 또는 체크리스트 처리 단계에서 발생한 예외다.
기존 외부 CATCH가 기록한 문구만으로 문제 인수나 SAP 내부 실행 여부를 확정할 수 없다.
현재 I가 남아 있다고 단정하거나 활성화가 전혀 실행되지 않았다고 안내하지 않는다.

확인한 코드상의 원인 후보는 `P_CHECKLIST`를 범용 `REF TO object`에 직접 받던 부분이다.
abapGit의 동일 활성화 함수 호출은 `REF TO CL_WB_CHECKLIST`를 사용한다.
0.6.10 변경은 다음과 같다.

- 활성 함수 인터페이스에서 P_CHECKLIST 타입을 점검하고 구체 클래스 참조 변수를 생성한다.
- `CREATE DATA ... TYPE REF TO (class_name)`으로 만든 변수의 실제 타입을 ANY 필드 심볼로 유지하여 함수에 전달한다.
- 클래스의 정적 TYPE 선언이나 체크리스트 객체의 선행 생성은 추가하지 않는다.
- 사전 API 점검과 활성화 직전에 같은 참조 생성·형식 확인을 수행한다.
- 범용 객체 참조는 함수 반환 뒤 GET_ERROR_MESSAGES 호출용으로만 사용한다.
- 활성화 FORM 안에서 예외를 처리하고 단계·예외 원문·클래스·프로그램·인클루드·줄 번호와 PREVIOUS 원인을 보존한다.
- JSON/로그의 ACTIVATION_CALL과 ACTIVATION_EXCEPTION으로 호출 시도·함수 반환·결과 조회 실패를 구분한다.
- UI_DECOUPLED는 조회한 이름으로 분기한다. 로그 기록에 따른 SY-SUBRC 변경 영향을 받지 않는다.
- 예외 발생 후 활성화를 자동으로 재호출하지 않는다. A 버전 재조회와 최초 오류 보존은 유지한다.

구체 수신 타입 변경은 합리적인 호환성 수정이지만 사용자 SAP 오류의 정확한 원인을 입증한 것은 아니다.
이후 0.6.10에서 진단 실행 결과가 확보됐으나 사전 차단으로 활성화에 진입하지 않았다. 따라서 활성화 타입 수정의 효과와 실제 웹 화면 결과는 여전히 미확인이다.

### 11.7 0.6.10 중복 경고와 0.6.11 조치

근거: `ZHR5_diag_20261021_202240.json`, `DIAG_WEBAPPLY_RUN.xml`, 사용자 화면.

- 대상 행 259: BLOCKED, 저장 NOT_RUN, 활성화 NOT_RUN, 미활성 BOTH_REVIEW.
- A 8,380 / B 8,483 / C 8,380바이트, A=C. `wa_verify_detail`은 비어 있다.
- WAPP 조회와 WAPD 조회 모두 같은 SPROT_U 한 건: SEVERITY=E, LANGU=3, AG=EU, MSGNR=829, VAR1=WAPP.
- VAR2는 `Z52_FLEX_TIME                 FLEX_WORK_PERFORMANC`로 50자에서 잘린 키다. WAPD를 직접 지목한 메시지는 없다.
- 실행 XML은 REPORT_VERSION=0.6.10, CTS_TASK=KSDK9A9MS0. 백업·대상·결과·이벤트가 비어 있다. 이번 실행은 반영 단계에 들어가지 않았다.
- 따라서 WAPD 조회의 WAPP 메시지를 공통 정의 경고로 표시한 것은 코드상 오분류다. 실제 공통 WAPD의 존재/부재와 현재 I=B 여부는 이 자료만으로 확정하지 않는다.

0.6.11은 메시지 대상과 전체 키 작업 목록을 대조하고 SAP의 해석된 메시지도 남긴다. 기존 I의 전체 키·작성자·삭제 여부·native 내용·다른 탭이 검증되면 READY_ACTIVATE가 된다. 입력 CTS의 기존 WAPP 등록을 확인하고 저장 없이 선택 페이지 활성화를 재개한다. 다른 I 내용이나 실제 WAPD 변경·미해석 오류를 통과시키지 않는다. 0.6.10의 활성화 타입 수정은 유지한다.

### 11.8 DIAG 0.6.11 사용자 성공과 SE80 확인

사용자 화면에서 대상 `Z52_FLEX_TIME / FLEX_WORK_PERFORMANCE_VIEW.HTM`의
`ACTIVATED_VERIFIED`, 저장 `REUSED_VERIFIED`, 활성화 `VERIFIED`, 미활성 `RESUME_VERIFIED`를 확인했다.
기존 I의 내용·작성자·범위와 CTS를 검증한 후 저장을 생략하고 해당 페이지를 활성화한 사례다.
사용자는 이어서 “실제 se80에서도 제대로 반영됐어”라고 확인했다.

이 증거로 해당 사례의 활성화와 SE80 반영 성공을 기록한다. 일반적인 새 저장 경로 전부,
브라우저 업무 기능 전체, 이후 0.7.0 BSP 단독 모드까지 검증된 것으로 확대하지 않는다.
이후 요청은 오류 재수정이 아니라 개발 패키지/BSP 앱 단독 추출·진단 범위 확장이다.

## 12. DIAG 0.6.11 배포 당시 로컬 검증 이력

아래는 0.6.11 배포 당시 기록이다. 후속 사용자 SAP 성공은 11.8절, 최신 0.4.0/0.7.0 검증은 17절을 따른다.

0.6.11은 변경된 경고 분류·기존 I 재개·읽기/재검증·트랜잭션과 전체 파서/구조 조건을 직접 실행했다. 나머지 결과는 이력으로 유지했다. `validation/run-scope.json`이 실행 범위의 기준이다.

| 검증군 | 결과 | 실행 기준 |
|---|---|---|
| 전체 REPORT 파서 | abaplint 2.120.82, v700, 15,350문장, unknown 0, issues 0 | 0.6.11 직접 실행 |
| 프로토콜·작성자·I 재개 | 실제 0.6.10 메시지 fixture, 38사례 통과 | 0.6.11 직접 실행 |
| 미활성·읽기·I 재검증 | 36사례 통과 | 0.6.11 직접 실행 |
| BSP 비교·가드·문자·메시지·Properties·트랜잭션 | 114사례, 트랜잭션 27 중 재개 8 포함 | 0.6.11 직접 실행 |
| 소스 구조 조건 | 65개 통과 | 0.6.11 직접 실행 |
| 활성화 참조·예외 처리 | 이전 21사례 통과 결과 | 0.6.10, 이번 재실행 안 함 |
| MIME·분류·기존 트랜잭션 | 이전 통과 결과 | 0.6.9, 이번 재실행 안 함 |
| 행 변환 / RTTI / native 재조회 | 39 / 15 / 59사례 이전 통과 | 0.6.9, 이번 재실행 안 함 |
| DIRECT·독립 선언행 / SO2 | 77 / 119사례 이전 통과 | 0.6.9, 이번 재실행 안 함 |

신규 원문 fixture는 실제 사용자 JSON의 WAPP/WAPD 프로토콜을 보존한다. DWINACTIV 전체 키 기록·현재 I 내용·SAP 메시지 사전은 아직 실서버 자료가 없어 시험 대역이다. 전체 키 누락/충돌·다른 사용자·삭제 표시·다른 탭·I 내용 변경·실제 WAPD 변경·CTS 누락·활성화 실패·사후 검증 실패 조건을 실행했다. 재개 경로의 저장/CTS 삽입 호출은 0회다.

실제 REPORT의 FORM을 추출하여 로컬 ABAP transpiler/runtime으로 실행했다. SAP 저장소·API·CTS·잠금·GUI·UTF-8 코덱 등 외부 동작에는 시험 대역을 사용했다. 일부 동적 호출에는 로컬 변환기 호환 연결이 있다.

0.6.8에서 추가한 SO2 시험은 실제 첨부 XML A/B를 사용한다. Python XML 파서가 만든 DOM을 시험 대역으로 제공하고 실제 ABAP FORM의 구조·속성 대조와 좌표 대응을 실행했다. SAP native P_CONTENT는 원본 좌표에 맞춘 서버 구문 prefix를 사용하는 합성 자료이며, 이 조건에서 257행 → 259행 변환을 확인했다. 실제 코드는 prefix를 추측하지 않고 SAP에서 복사한다. 기존 77건의 SO2 비대상 분기는 stub이며 SO2 분기는 신규 119건으로 검증했다.

따라서 다음을 의미하지 않는다:

- 실제 SAP SE38 컴파일 성공.
- SAP API 시그니처·행 타입·버전 조회·언어 처리의 완전한 검증.
- 실제 COMMIT/잠금 유지·단일 WAPP 활성화의 성공.
- 사용자 오류 원문의 실서버 재현.
- HTML·JS·CSS 실행 및 업무 기능 검증.

필요 시 배포 ZIP을 푼 루트에서 실행:

```bash
npm ci --prefix validation
python3 validation/run-all.py
```

`validation/*.prog.abap`는 시험용이다. SAP에 설치할 파일은 루트의 전체 REPORT 한 개다. ZIP에는 `node_modules`와 생성 JS를 포함하지 않는다.

## 13. 최신 산출물과 코드 탐색 지도

### 13.1 최신 산출물

| 파일 | 용도 |
|---|---|
| [Z_PACKAGE_EXPORT_0_4_0.abap](sandbox:/workspace/scratch/ff86f61403eb/ERP_BSP_SCOPE_0_4_0_0_7_0/Z_PACKAGE_EXPORT_0_4_0.abap) | 전체 Export REPORT |
| [Z_PACKAGE_DIAG_0_7_0.abap](sandbox:/workspace/scratch/ff86f61403eb/ERP_BSP_SCOPE_0_4_0_0_7_0/Z_PACKAGE_DIAG_0_7_0.abap) | 전체 DIAG REPORT |
| [ERP_BSP_SCOPE_0_4_0_0_7_0.zip](sandbox:/workspace/scratch/ff86f61403eb/ERP_BSP_SCOPE_0_4_0_0_7_0.zip) | 두 소스·설명·명세·변경점·검증·직전 기준 소스 |
| [README_BSP_SCOPE_ko.txt](sandbox:/workspace/scratch/ff86f61403eb/ERP_BSP_SCOPE_0_4_0_0_7_0/README_BSP_SCOPE_ko.txt) | 설치·사용·호환성 |
| [VALIDATION_ko.txt](sandbox:/workspace/scratch/ff86f61403eb/ERP_BSP_SCOPE_0_4_0_0_7_0/VALIDATION_ko.txt) | 실제 실행한 로컬 시험 범위와 한계 |

Export SHA-256: `538ee5d6de43e83fd496f3f99a5760c3b49c08dbaaf98db26d67cb2071bbd4c7` / 213,640바이트.

DIAG SHA-256: `4f7d1a1df678b1c1ba9d647408db54d54c21e2c561371fd0232536a7c36782a9` / 604,208바이트.

`validation/run-scope.json`에 이번 실행과 이력 검증을 구분했다. `previous/`에는 직전 Export 0.3.18과 DIAG 0.6.11이 들어 있다.
`CHANGES_EXPORT_0_3_18_to_0_4_0.diff`, `CHANGES_DIAG_0_6_11_to_0_7_0.diff`로 수정 범위를 확인한다.
과거 0.6.11 전체 배포 ZIP은 이전 이력 자료로 보존되며 최신 설치 기준은 위 두 REPORT다.

### 13.2 필요한 부분만 읽기 위한 FORM 지도

| 관심 영역 | 주요 FORM |
|---|---|
| ZIP 형식·호환 | `im_manifest_compat`, `im_read_manifest` |
| 웹자산 준비·선택 실행 | `wa_prepare`, `wa_apply`, `wa_bsp_prepare` |
| 권한·CTS 입력 확인 | `wa_authority` |
| 페이지 유형·Properties | `wa_bsp_page_kind`, `wa_bsp_properties_check` |
| UTF-8·행 변환 | `wa_bsp_normalize`, `wa_bsp_content`, `wa_bsp_line_assign` |
| Export/API 표현 분기 | `wa_bsp_xml_declaration`, `wa_bsp_export_content` |
| SO2 XML·변경 범위 | `wa_bsp_so2_parse`, `wa_bsp_so2_dom`, `wa_bsp_so2_pair`, `wa_bsp_so2_attrs`, `wa_bsp_so2_text` |
| SO2 좌표·native 변환 | `wa_bsp_so2_row`, `wa_bsp_so2_gap`, `wa_bsp_so2_span`, `wa_bsp_so2_content` |
| 대상 SAP 메타데이터·키 | `wa_method_contract`, `wa_method_table`, `wa_bsp_object_key` |
| 별도 세션 조회 | `wa_bsp_probe`, `wa_bsp_fetch_version` |
| 미활성 상태 | `wa_bsp_object_state`, `wa_bsp_protocol`, `wa_bsp_pending_probe`, `wa_bsp_pending_note` |
| 기존 I 재개 | `wa_bsp_resume_check`, `wa_bsp_resume_owner`, `wa_bsp_resume_owner_check` |
| 저장 내용 비교 | `wa_bsp_row_text`, `wa_bsp_compare_lines`, `wa_bsp_check_layout` |
| 검증 상세 기록 | `wa_bsp_verify_record`, `im_json_row` |
| 다른 탭 보존 | `wa_bsp_guard`, `wa_bsp_clear_generated` |
| 잠금·CTS | `wa_bsp_lock`, `wa_bsp_cts`, `wa_bsp_cts_verify` |
| 저장·I 검증·활성화 | `wa_bsp_save`, `wa_bsp_saved_check`, `wa_bsp_activate` |
| 활성화 수신 타입·예외 원인 | `wa_bsp_checklist_ref`, `wa_bsp_exception`, `wa_bsp_api_check` |
| 전체 흐름·실패 후 관찰 | `wa_bsp_one`, `wa_bsp_observed` |
| 백업 | `wa_backup_build`, `wa_backup_payload` |

0.6.11은 0.6.10 대비 FORM 4개 추가, 7개 변경, 265개 버전 문자열 외 동일이며 전체 276개다. 경고 분류·재개 제어와 확인 문구를 변경했다. SO2·행 변환·활성화 호출부·잠금·CTS 구현·MIME·Export는 유지했다.

## 14. 다음 작업 순서와 필요한 근거

### 14.1 우선순위 1: BSP 단독 모드 실서버 확인

1. Export 0.4.1 / DIAG 0.7.1 전체 소스로 기존 REPORT를 교체·문법 검사·활성화한다.
2. Export의 BSP 애플리케이션 모드에서 ZWEB_COMMON 하나를 추출한다.
3. baseline을 보존한 변경 없는 ZIP을 DIAG의 같은 모드/앱 이름으로 비교한다.
4. 작은 Layout 또는 MIME 변경 한 건을 업로드하고 기존 저장/활성화 절차를 확인한다.
5. 오류면 새 버전·줄 번호 또는 JSON/실행 로그를 확인한다. 같은 앱의 다른 페이지는 별도 범위이며 원복 ZIP도 같은 BSP 모드로 연다.

### 14.2 실패 유형별 최소 자료

| 실패 유형 | 우선 확보할 자료 |
|---|---|
| 문법 오류 | 버전, 프로그램명, 오류 전문, 줄 번호와 주변 코드 |
| `BASELINE_CHECK` | JSON `wa_verify_detail`, 필요 시 실제 SAP P_CONTENT 행·형식. 이번 ZHR5.zip A/B는 이미 확보했으므로 재요청하지 않음 |
| `SET_PAGE_READBACK` | 기대/조회 행 수·최초 차이, 대상 API 시그니처·행 타입 필요 여부 판단 |
| `SAVED_INACTIVE_CHECK`·`SAVED_INACTIVE_STATE` | JSON과 `.run.xml`, I 버전, 다른 탭 보존, WAPP/WAPD 원문 프로토콜. 실제 내용 차이와 경고 유무를 구분 |
| `ACTIVE_CHECK` | 활성화 반환 메시지·객체 목록, A 버전 내용, CTS 등록 결과 |
| `ACTIVATION_EXCEPTION` | JSON wa_verify_detail과 .run.xml의 발생 단계·원인 연쇄·소스 위치. API_SIGNATURE이면 실제 인터페이스 선언 |
| `PAGE_REVIEW`·`APP_REVIEW`·재개 보류 | `wa_inactive_detail`의 원문·분류·정확한 작업 목록, `wa_verify_detail`의 재개 이유, 현재 I 내용/작성자 |
| CTS·권한·잠금 | 전체 오류, 입력이 요청인지 하위 작업인지, 소유자·수정 가능 상태 |

가능하면 화면 한 장만 반복 전달하는 대신 **JSON 다운로드 + 반영 로그**를 기본 근거로 사용한다. 필요할 때만 관련 Layout과 매핑 파일로 범위를 넓힌다.

### 14.3 실서버 성공으로 확인해야 할 항목

- 시험용 BSP 한 페이지의 Layout 변경이 저장되고 해당 페이지가 활성화된다.
- 활성 `P_CONTENT`가 기대 행과 일치하고 다른 탭·공통 속성이 보존된다.
- 지정 CTS 작업에 해당 `LIMU WAPP`이 등록된다.
- 다른 HTM의 미활성 변경이 있다는 이유만으로 차단하지 않는다.
- 실제 웹 화면에서 변경 내용과 기존 기능을 확인한다.
- 백업을 이용한 원복을 별도 시험한다.

### 14.4 이후 검토할 개선 후보 — 아직 구현 확정 아님

- 저장 시 CTS 작업 선택 UI 또는 요청에서 본인 하위 작업을 찾는 기능.
- 0.6.11 현재 상태 검증 방식에 더해, 이전 실행 식별자와 I 작성 시점을 연계하는 추적 기능.
- 실제 SAP 반환 자료를 포함한 최소 재현 fixture와 호환성 기록.
- 공통 WAPD 경고의 메시지별 정확한 의미와 허용 가능 범위 검토.
- 신규 객체·ITS publish·ABAP·DDIC 반영은 별도 범위·검증 설계 후 결정.

이 후보들은 이 문서 작성으로 구현하거나 승인한 사항이 아니다.

## 15. 후속 작업 원칙과 맥락 사용량 절감

- 처음에는 1절, 11.8절, 18절과 14절을 읽고 필요한 FORM과 결과 파일만 연다.
- 최신 문제를 근거로 필요한 부분부터 확인한다. 전체 0.6.x 테스트·이력을 매번 다시 읽거나 같은 검증을 이유 없이 반복하지 않는다.
- 사용자가 제공한 새 실행 결과가 이 문서보다 최신이면 해당 결과를 우선한다.
- 실제 미확인 원인을 확정적으로 표현하지 않는다. 로컬 재현과 사용자 SAP 재현을 구분한다.
- 불필요한 전역 차단은 좁히되, 실제 충돌·다른 작업 덮어쓰기·데이터 잘림을 숨기는 우회는 넣지 않는다.
- 변경 시 SAP_BASIS 700 호환성을 유지한다. 선택적 DDIC 타입이나 범용 RTTI 생성에 대한 이전 실패를 반복하지 않는다.
- 수정 완료 시 설명만 전달하지 말고 **전체 ABAP 다운로드**와 필요한 변경·검증 자료를 제공한다.
- 사용자 SAP에 직접 반영했다거나 정상 활성화됐다고 추정하지 않는다.
- 이번 문서는 향후 불필요한 재설명을 줄이기 위한 기준점이다. 이후에는 변경 사항·실행 증거·미결 항목만 갱신하면 된다.

### 다음 대화에 붙여 넣을 재개 지침

```text
ERP_EXPORT_DIAG_CONTEXT_SPEC_2026-10-21.md v1.7을 기준으로 이어가세요.
최신 소스는 Export 0.4.1 / DIAG 0.7.1입니다. SAP ECC 6.0 / BASIS 700 Unicode.
1·11.8·18절과 해당 FORM부터 읽고, 기존 전체 이력을 반복 탐색하지 마세요.

사용자가 Export 0.4.0으로 추출한 ZWEB_COMMON_export.zip에서 폴더 문제를 확인했습니다.
ZBUDGET/ZHR1/ZMOBILE에는 다른 소스가 아니라 MIME 소유권 메타데이터와 README만 있었습니다.
0.4.1 BSP ZIP은 ZWEB_COMMON/ 폴더 하나, 내부 pages/, MIMEs/, catalog/, .devhub/baseline/입니다.
manifest 0.4 + PATH_LAYOUT=BSP_APP_ROOT; 경로는 앱 폴더의 manifest 기준 상대 경로입니다.
MIME 메타데이터는 catalog/mime-metadata.xml 하나로 합치며 실제 DEVCLASS/LOIO/URL을 보존합니다.
DIAG는 검증된 헤더에서 경로 모드를 선택해 SAP 스냅샷·반영·원복 ZIP의 매핑을 맞춥니다.
기존 0.4.0 BSP/패키지 및 0.3.18/0.3.28 패키지 ZIP도 읽습니다. 폴더/manifest 수동 이동 금지.

저장 범위: 기존 MIME/BSP Layout, 단일 WAPP 활성화. 다른 BSP 탭·ABAP·DDIC 저장 제외.
사용자는 DIAG 0.6.11에서 I 재사용 후 활성화와 SE80 반영을 확인했습니다.
이번 버전의 로컬 267사례, 소스 조건 75개, 두 REPORT v700 파서 오류 0입니다.
첨부 ZIP의 Layout 75/MIME 659 및 다른 소유 패키지 MIME 5개와 모든 원본 사본 보존을
오프라인 변환 fixture로 확인했습니다. 새 ABAP의 실제 SAP 실행은 아직 미확인입니다.
실행 요약은 validation/run-layout.json. 수정 후 전체 .abap 다운로드를 반드시 제공하세요.
```


## 16. 기존 작업에서 사용한 참고 자료

아래 링크는 기존 작업과 후속 수정의 참고 근거 위치이다. abapGit의 P_CONTENT 사용은 참고할 수 있으나, Export에 XML 선언행이 항상 추가된다는 근거로 해석하지 않는다.

- [사용자 WEBGUI 공유 대화](https://chatgpt.com/share/e/6ad5f566-e818-83ec-9e8a-bf172acad247)
- [abapGit WAPA 구현](https://github.com/abapGit/abapGit/blob/main/src/objects/zcl_abapgit_object_wapa.clas.abap)
- [abapGit 객체 활성화 구현](https://github.com/abapGit/abapGit/blob/main/src/objects/core/zcl_abapgit_objects_activation.clas.abap)
- [SAP CREATE DATA REF TO 문법](https://help.sap.com/docs/abap-cloud/abap-keywords/create-data-ref-to?version=latest)
- [SAP CALL FUNCTION 매개변수 규칙](https://help.sap.com/doc/abapdocu_731_index_htm/7.31/en-US/abapcall_function_parameter.htm)
- [SAP DWINACTIV 참고 문서](https://help.sap.com/docs/SUPPORT_CONTENT/abapfaq/3353524262.html?locale=ja-JP)
- [SAP NetWeaver 7.00 BSP 활성화 문서](https://help.sap.com/docs/SAP_NETWEAVER_700/12aa7f056c531014aa5bca7aee037e55/4c4908f1919c4d4de10000000a15822b.html)

공개 구현과 문서는 API 사용 방향의 참고 자료이며 사용자 SAP 시스템의 동일 동작을 보증하지 않는다.

## 17. BSP 단독 추출·진단 확장 — Export 0.4.0 / DIAG 0.7.0

### 17.1 승인된 요구사항과 구현

사용자는 개발 패키지 단위 외에 ZWEB_COMMON, ZWEB_WF 같은 BSP 애플리케이션 하나를 추출하고,
해당 ZIP을 DIAG에서 웹자산으로 진단해 기존 저장/활성화를 사용하도록 요청·승인했다.
두 프로그램을 수정하며 개발 패키지 모드는 유지하기로 했다.

| 구분 | 구현 |
|---|---|
| 선택 화면 | `P_PKGM` 개발 패키지 / `P_BSPM` BSP 애플리케이션, `P_BSP` 정확한 앱 이름 |
| 필수값 | 모드별 실행 시 검사. 라디오 전환은 미입력 ZIP/패키지 때문에 막지 않음 |
| Export BSP 목록 | 정확한 R3TR WAPA 한 건과 MIME API의 해당 앱 하위 URL에 대응하는 R3TR SMIM |
| 실제 소유권 | 각 SMIM의 TADIR 패키지 유지. 앱과 달라도 해당 MIME만 포함 |
| 제외 | 패키지 전체 조회, 다른 앱, FUGR/DDIC/PROG/클래스 본문, 외부 공용 MIME 자동 포함 |
| 원본 | 기존 `packages/...` 경로와 `.devhub/baseline` 보존, RAW 바이트·CRC/길이 계약 유지 |
| ZIP 이름 | `<앱>_export.zip`, 이름공간 특수문자는 기존 safe_leaf 규칙 |
| manifest | DEVHUB-EXPORT 0.3, Export 0.4.0; SCOPE_KIND=PACKAGE/BSP, BSP_APPLICATION/BSP_PACKAGE |
| DIAG 범위 | 헤더·앱·파일 경로·현재 객체의 실제 식별자를 확인한 후 비교·반영 |
| 표시 | BSP 모드에서 P_MIME 강제, 다른 결과유형 선택 비활성. 전체 결과 JSON은 유지 |
| 비교 | BSP 다른 탭도 읽고 비교·보존 점검. 패키지 ABAP 컴파일 파이프라인은 생략 |
| 반영 | 0.6.11의 기존 Layout/MIME 절차 유지; 조회/쓰기 직전 BSP 범위 재검증 추가 |
| fresh 조회 | 내부 SUBMIT에 선택 모드와 앱 이름 전달 |
| 백업/로그 | 원본 범위 헤더 보존. JSON에 범위/앱, 실행 XML에 추출 헤더 기록 |

MIME 루트가 없으면 페이지 전용 앱으로 처리한다. MIME 트리/LOIO 조회 자체가 실패하면
범위를 확정할 수 없으므로 중단한다. 소유 TADIR이 없는 파일은 본문을 추측해 읽지 않고
외부 참조 및 경고로 남긴다. MIME 트리에 포함되지 않는 독립 W3MI는 앱 소속을 추정하지 않으며
필요하면 기존 개발 패키지 모드를 사용한다. 앱 간 외부 참조는 자동 의존성 번들이 아니다.

### 17.2 호환성과 기존 오류 예방

- 새 Export의 패키지 모드도 manifest 0.3을 사용하므로 DIAG 0.7.0과 함께 배포한다.
- 이전 manifest 0.2 / Export 0.3.18·0.3.28은 개발 패키지 모드에서 계속 읽는다.
- 다른 모드/앱의 ZIP 또는 범위 밖 manifest 파일은 거부한다. ZIP 파일명으로 객체를 매핑하지 않는다.
- 원래 Export에 남아 있던 `SO2_VERSION`을 로컬 C(1) 타입으로 바꿨다.
- XML Layout이 없는 경우의 텍스트 대체 경로도 SPACE/V/X 페이지 유형으로 DIAG와 맞췄다.
- 다른 탭, ABAP, DDIC 저장·신규/삭제/이름 변경·전역 앱 활성화 기능은 추가하지 않았다.
- 백업 ZIP도 같은 BSP 모드/같은 앱에서 연다. MIME만 선택한 부분 백업에는 Layout 파일이 없어도 된다.

### 17.3 확인 결과와 다음 확인

두 전체 REPORT의 SAP 700 로컬 파서 오류 0. 범위·모드·호환·manifest·쓰기 경계 63,
Export 입력 4, MIME 탐색 10, 기존 BSP 114, MIME 트랜잭션 9, 분류/바이너리 18로
총 218사례가 통과했다. 소스 통합 조건 53개를 별도로 확인했다.
SAP SQL·MIME API·권한·CTS·잠금·저장·활성화·GUI는 시험 대역이다.
이 결과는 새 버전의 실제 SAP 문법 검사와 추출/반영 성공을 뜻하지 않는다.

관련 FORM: 양쪽 `scope_mode`, `scope_selection`, `scope_screen`, `scope_discover_bsp`,
`scope_add_object`, `scope_url_check`; DIAG `im_manifest_compat`, `im_scope_manifest`,
`im_scope_file`, `im_scope_current`, `wa_scope_check`.
이전 성공한 저장/활성화 핵심 FORM은 유지했으며 diff와 `validation/*-form-diff.json`으로 확인할 수 있다.


## 18. BSP 단일 앱 폴더 수정 — Export 0.4.1 / DIAG 0.7.1 (2026-10-22)

### 18.1 사용자 요청과 실물 근거

사용자는 ZWEB_COMMON만 추출했는데 packages 안에 ZBUDGET/ZHR1/ZMOBILE이 보인다며
선택 앱 폴더 하나만 추출하고 DIAG도 함께 고쳐 달라고 요청했다.
첨부 `ZWEB_COMMON_export.zip`은 Export 0.4.0, SCOPE_KIND=BSP, 앱 ZWEB_COMMON,
앱 실제 소유 패키지 ZWEB, ZIP 항목 1,982개, manifest payload 985개다.
ZBUDGET/ZHR1/ZMOBILE에는 소유권별 MIME metadata.xml과 README만 있었으며,
다른 패키지의 ABAP/DDIC/함수그룹을 수집한 것은 아니었다.

해당 3개 패키지가 소유한 MIME 5개는 모두 선택 앱의 URL 하위에 있었다.
ZMOBILE의 erpweb-2.0.0.js/min.js, ZBUDGET의 marjoram-1.0.0.css/min.css,
ZHR1의 images/icon_urgent.gif이다. 파일을 누락시키는 대신 물리적인 폴더 구성을 바꿨다.

### 18.2 새 출력 계약

- ZIP 이름은 `ZWEB_COMMON_export.zip`, 최상위는 `ZWEB_COMMON/` 하나다.
- 앱 안에는 `pages/`, `MIMEs/`, `catalog/`, `.devhub/baseline/`, `logs/`, manifest/README/Git 설정을 둔다.
- BSP 모드에서는 `packages/`와 소유 패키지별 README를 만들지 않는다.
- `catalog/mime-metadata.xml` 한 파일에 모든 소속 MIME 메타데이터를 기록한다.
  각 행의 DEVCLASS/LOIO/URL은 실제 값 그대로다. 통합 카탈로그의 manifest 소유 객체 필드는 공란이다.
- manifest의 PACKAGES는 실제 소유 패키지 목록이다. 출력 폴더 또는 수집할 패키지 범위로 해석하지 않는다.
- manifest 및 웹 카탈로그의 경로는 manifest가 있는 앱 폴더를 기준으로 한 상대 경로다.
- `.devhub/baseline/`은 각 상대 payload 경로를 그대로 미러링한다. 기존 바이트·CRC/길이 계약은 동일하다.
- 앱 폴더째 압축하거나 앱 내부의 전체 내용을 압축한 ZIP 모두 DIAG의 기존 manifest-prefix 탐색으로 읽는다.
- 개발 패키지 모드의 출력 경로는 기존대로 유지한다.

| schema / Export | 모드 | 경로 처리 |
|---|---|---|
| 0.2 / 0.3.18·0.3.28 | PACKAGE | 기존 packages 경로 |
| 0.3 / 0.4.0 | PACKAGE 또는 BSP | 기존 packages 경로 |
| 0.3 / 0.4.1 | PACKAGE | 기존 packages 경로 |
| 0.4 / 0.4.1 + PATH_LAYOUT=BSP_APP_ROOT | BSP | pages/MIMEs/catalog 상대 경로, 앱 폴더 하나 |

### 18.3 DIAG 변경과 반영 보존

`im_manifest_compat`가 올바른 버전·모드·앱·PATH_LAYOUT을 확인한 뒤 `gv_bsp_flat`을 설정한다.
화면의 BSP 선택만으로 플래그를 켜지 않으므로 구버전 BSP ZIP도 기존 경로로 현재 SAP를 읽는다.
`im_reset`에서 플래그를 초기화한다.

공통 `scope_bsp_root`와 `mime_metadata_path`로 Export·DIAG 스냅샷의 상대 경로를 맞춘다.
`im_payload_path`는 manifest 루트 확인 및 원본 목록 밖 추가 파일 확인에 같이 사용한다.
flat BSP의 WAPA는 pages 아래, SMIM은 MIMEs 아래이며 실제 앱/소유 객체 검증을 유지한다.
새 binary MIME도 목록에 표시하지만 manifest 밖 신규 객체 쓰기는 계속 차단한다.
`scope_zip_path`는 Export ZIP과 원복 ZIP에만 바깥 앱 폴더를 붙인다.
논리 경로·체크섬 대상에는 바깥 폴더 이름을 넣지 않는다.

`wa_bsp_prepare`, `wa_prepare`, `wa_scope_check`, `wa_bsp_save`, `wa_bsp_activate`,
`wa_bsp_one`, `wa_bsp_resume_check`, `wa_bsp_guard`, `wa_bsp_so2_content`,
`wa_lock`, `wa_cts`, `wa_one`, `im_triplet` 등 기존 매핑·반영·보존 핵심은 이전 소스와 동일하다.
`wa_backup_build`는 원래 파일/기준 사본 구성과 헤더를 유지하고 ZIP 엔트리 경로만 앱 폴더로 감싼다.

### 18.4 검증과 남은 확인

- SAP 7.00 로컬 파서: 전체 Export/DIAG 오류 0.
- 실행 가능한 ABAP FORM 시험: 범위·호환·탐색 112, 새 레이아웃·ZIP 색인·통합 메타데이터·원복 11,
  기존 BSP 114, MIME 트랜잭션 9, 결과 분류/바이너리 21 = 267사례 통과.
- 소스 통합 조건 75개 통과. 새/이전 코드 FORM 비교 자료를 포함했다.
- 첨부 ZIP 오프라인 변환 검증: Layout 75, MIME 콘텐츠 659 및 기타 payload 980개의
  본문/원본 사본 바이트를 모두 보존했다. 통합 대상 메타데이터 4개 → 1개,
  manifest 985 → 982개, ZIP 항목 1,982 → 1,972개다.
- MIME 메타데이터 660행, 웹자산 카탈로그 735행의 실제 식별자를 유지했다.
  소유 패키지가 다른 MIME 5개도 그대로 남는다.
- 경로 변환 fixture는 오프라인 시험물이며 새 ABAP가 SAP에서 만든 실제 추출본이 아니다.
  사용자 원본 ZIP을 변경하지 않았고 시험 ZIP은 배포 자료에 포함하지 않았다.
- SAP API·XML·ZIP·권한·CTS·GUI는 시험 대역이다. 0.4.1/0.7.1의 SAP 컴파일·실행은 사용자 확인이 필요하다.

다음 확인: 두 REPORT 교체 → 새 BSP 추출 → 앱 폴더 하나인지 확인 → 무수정 ZIP 비교 →
작은 Layout 또는 MIME 한 건 저장/활성화. manifest나 기존 ZIP 폴더를 수동으로 바꾸지 않는다.
검증 스크립트는 validation/run-current.py, 실제 ZIP 점검은 validation/real-zip-check.py다.
