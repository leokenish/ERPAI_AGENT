ERP BSP 단독 폴더 추출·진단 수정본
Export 0.4.1 / DIAG 0.7.1 — 2026-10-22
대상: SAP ECC 6.0 / SAP_BASIS 700 Unicode / SAP GUI

1. 이번 문제와 수정
사용자 ZWEB_COMMON_export.zip의 ZBUDGET/ZHR1/ZMOBILE 폴더에는
다른 업무 소스가 아니라 MIME 소유 패키지별 metadata.xml과 README만 있었다.
선택 앱 MIME 파일 중 5개의 실제 소유 패키지가 앱 소유 패키지 ZWEB과 달랐다.
이 5개도 ZWEB_COMMON URL 하위의 자산이므로 빼지 않는다.

BSP 모드에서는 압축을 풀면 ZWEB_COMMON 폴더 하나만 나오도록 수정했다.
packages/ 폴더와 소유 패키지별 README는 만들지 않는다.
MIME 메타데이터는 catalog/mime-metadata.xml 한 파일로 합친다.
DEVCLASS/LOIO/URL/언어 등 실제 소유권은 각 메타데이터 행에 보존한다.
manifest PACKAGES에 ZBUDGET 등의 이름이 남는 것은 권한·CTS·객체 매핑용이다.
해당 패키지 전체를 추출한다는 의미가 아니다.

2. 설치 파일
- Z_PACKAGE_EXPORT_0_4_1.abap: 기존 REPORT Z_PACKAGE_EXPORT 전체 소스로 교체.
- Z_PACKAGE_DIAG_0_7_1.abap: 기존 REPORT Z_PACKAGE_DIAG 전체 소스로 교체.
- 두 프로그램을 SAP에서 문법 검사하고 활성화한다. REPORT 이름은 그대로다.
- previous/와 validation/의 ABAP는 설치 대상이 아니다.

3. 새 BSP ZIP 구조
ZWEB_COMMON/manifest.xml
ZWEB_COMMON/pages/<페이지>/Layout/<파일>.htm
ZWEB_COMMON/pages/<페이지>/Properties.xml
ZWEB_COMMON/pages/<페이지>/Page Attributes.xml
ZWEB_COMMON/pages/<페이지>/Event Handler/...
ZWEB_COMMON/pages/<페이지>/Type Definitions.abap
ZWEB_COMMON/pages/page-paths.xml 및 페이지 목록
ZWEB_COMMON/MIMEs/<원래 MIME 하위 폴더>/<파일>
ZWEB_COMMON/catalog/mime-metadata.xml
ZWEB_COMMON/catalog/web-assets.xml, objects.xml, references.xml
ZWEB_COMMON/.devhub/baseline/pages/...
ZWEB_COMMON/.devhub/baseline/MIMEs/...
ZWEB_COMMON/.devhub/baseline/catalog/...
ZWEB_COMMON/logs/..., README.md, .gitattributes, .gitignore

manifest와 카탈로그 내부 경로는 ZWEB_COMMON/manifest.xml 기준 상대 경로다.
예: pages/... 또는 MIMEs/.... 앱 이름을 다시 앞에 붙이지 않는다.
이름공간의 / 등은 기존 ~HH 규칙으로 안전하게 폴더/ZIP 이름에 표현한다.

4. 사용 순서
① 두 REPORT를 교체한 뒤 Export의 BSP 애플리케이션 모드에서
   ZWEB_COMMON을 다시 추출한다. ZIP 파일명은 ZWEB_COMMON_export.zip이다.
② ZIP을 풀고 ZWEB_COMMON/pages/.../Layout 또는 ZWEB_COMMON/MIMEs의 기존 파일만 수정한다.
③ manifest.xml, catalog/ 및 .devhub/baseline을 그대로 포함해 ZIP으로 다시 압축한다.
   앱 폴더 자체를 압축하거나 앱 폴더 안의 전체 내용을 압축하는 두 방식 모두 DIAG가 인식한다.
④ DIAG의 BSP 애플리케이션 모드에서 같은 앱 이름과 ZIP을 선택한다.
   결과유형은 웹자산으로 고정된다.
⑤ 운송 대상이면 본인의 수정 가능한 Workbench 하위 작업 번호를 입력한다.
⑥ 비교 결과에서 반영할 행을 선택하고 기존 저장/활성화 기능을 사용한다.
   백업·실행 로그를 저장하고, 결과와 SE80·웹 화면을 확인한다.

먼저 변경 없는 새 ZIP으로 비교한 뒤 작은 Layout 또는 MIME 한 건으로 확인한다.
구버전 ZIP의 폴더를 수동으로 옮기거나 manifest 버전을 직접 고치지 않는다.

5. DIAG 수정과 호환성
- 새 pages/MIMEs 경로, 통합 MIME 메타데이터를 서버 비교 경로와 동일하게 맞췄다.
- 원본 manifest에 없는 새 파일도 표시하지만 자동 생성/저장은 하지 않는다.
- 새 형식의 원복 ZIP도 앱 폴더 하나와 같은 범위 정보를 유지한다.
- Export 0.4.0의 기존 BSP ZIP도 DIAG 0.7.1에서 그대로 읽는다.
  이 경우 비교용 SAP 스냅샷과 원복 ZIP은 기존 packages 경로를 유지한다.
- 기존 패키지 모드 및 SMIM/W3MI 지원은 유지한다.

입력 계약:
* manifest 0.2 / Export 0.3.18·0.3.28: 기존 패키지 모드.
* manifest 0.3 / Export 0.4.0: 패키지 또는 기존 BSP 경로.
* manifest 0.3 / Export 0.4.1: 패키지 모드, 기존 경로.
* manifest 0.4 / Export 0.4.1: BSP 모드, PATH_LAYOUT=BSP_APP_ROOT.
새 BSP ZIP은 DIAG 0.7.1이 필요하다. 이전 DIAG/별도 DEVHUB_CHECK를 새 형식 지원으로 간주하지 않는다.

6. 저장/활성화 범위
기존 SMIM/W3MI MIME 교체 및 기존 BSP Layout 저장·단일 WAPP 활성화 범위다.
BSP 모드에서는 선택 앱 소속 SMIM과 기존 Layout을 처리한다.
Page Attributes, Event Handler, Type Definitions, 공통 정의, ABAP/DDIC는 업로드로 저장하지 않는다.
원본 A/수정 B/현재 SAP C 비교, 실제 소유 패키지 권한, CTS, 잠금,
최신 원본 재조회, 백업, 저장 후 검증 및 다른 탭 보존 로직을 유지했다.
앱 전체 활성화, 객체 신규/삭제/이름 변경, 외부 앱 자동 추출은 추가하지 않았다.

7. 확인 결과와 한계
- 두 전체 REPORT: 로컬 SAP 7.00 파서 오류 0.
- 실제 ABAP FORM을 변환 실행한 범위/경로/원복/기존 저장 흐름 등 267사례 통과.
- 소스 통합 조건 75개 통과. SAP API·XML·ZIP·권한·CTS·GUI 등 외부 동작은 시험 대역이다.
- 첨부 ZIP 1,982개 항목에 대한 오프라인 경로 변환 검증:
  Layout 75개, MIME 콘텐츠 659개 및 나머지 원본/기준 사본을 유지했다.
  MIME 메타데이터 4개를 1개로 모아 manifest payload는 985개에서 982개가 된다.
  실제 MIME 소유권 660행과 웹 카탈로그 735행의 식별자를 보존했다.
- 위 변환 ZIP은 시험 fixture이며 SAP에서 새 ABAP로 생성한 파일이 아니다. 배포 ZIP에는 넣지 않았다.
- Export 0.4.1 / DIAG 0.7.1의 실제 SAP 문법 검사·화면·추출·저장/활성화는 아직 실행하지 못했다.
- 앞서 사용자가 확인한 DIAG 0.6.11의 SE80 반영 성공을 새 버전의 실행 완료로 확대 해석하지 않는다.

검증 재실행: validation 폴더에서 npm ci 후 상위 폴더 기준 python3 validation/run-current.py.
실제 ZIP 검증은 real-zip-check.py에 원본 ZIP과 임시 fixture 출력 경로를 인자로 준다.
오류가 있으면 버전·오류 전문·줄 번호 또는 DIAG JSON/반영 로그로 해당 단계부터 확인한다.
