const fs=require('fs'), path=require('path');
const {Transpiler}=require('@abaplint/transpiler'), {ABAP}=require('@abaplint/runtime');
const src=fs.readFileSync(path.resolve(__dirname,'../Z_PACKAGE_DIAG_0_7_1.abap'),'utf8');
const form=n=>{const m=src.match(new RegExp('^FORM '+n+'[\\s\\S]*?^ENDFORM\\.','m')); if(!m)throw Error(n);return m[0]};
const results=[];
async function run(name,code,cases){
 code=code.split(/('(?:''|[^'])*'|`(?:``|[^`])*`|\|(?:\\.|[^|])*\|)/g)
   .map((part,i)=>i%2?part:part.replace(/(?<![<>=])=(?!=|>)/g,' = ')).join('');
 fs.writeFileSync(path.join(__dirname,name+'.prog.abap'),code);
 const out=await new Transpiler({addCommonJS:false,unknownTypes:'compileError'}).runRaw([{filename:name+'.prog.abap',contents:code}]);
 global.abap=new ABAP();
 let commits=0, rollbacks=0;
 // SAP transaction boundaries are external effects; the control flow is production ABAP.
 let js=out.objects.find(o=>o.object.type==='PROG').chunk.getCode();
 js=js.replaceAll('abap.statements.assert(abap.compare.initial(err));',
   'if (!abap.compare.initial(err)) throw new Error(err.get()); abap.statements.assert(abap.compare.initial(err));');
 js=js.replace(/await abap.statements.commit\([^;]*;/g,'commits();').replace(/await abap.statements.rollback\([^;]*;/g,'rollbacks();');
 fs.writeFileSync(path.join(__dirname,name+'.js'),js);
 await new (Object.getPrototypeOf(async function(){}).constructor)('abap','commits','rollbacks',js)(global.abap,()=>commits++,()=>rollbacks++);
 results.push({name,cases,assertions:(code.match(/\bASSERT\b/g)||[]).length,result:'PASS',commits,rollbacks});
}
const quote=s=>"'"+s.replaceAll("'","''")+"'";
(async()=>{
 const cases=[
 ['X','X','X','old','new','old','X','BLOCKED'],
 ['X','X','X','old','new','new','','ALREADY_EQUAL'],
 ['X','X','X','old','old','server','','UPLOAD_UNCHANGED'],
 ['X','X','X','old','new','server','','CONFLICT'],
 ['','X','X','old','new','old','','BLOCKED'],
 ['X','','X','old','new','old','','BLOCKED'],
 ['X','X','','old','new','old','','BLOCKED'],
 ['X','X','X','forward','original','forward','X','BLOCKED'],
 ['X','X','X','forward','original','original','','ALREADY_EQUAL'],
 ['X','X','X','forward','original','later','','CONFLICT']];
 let code=`REPORT zbspgate. DATA: a TYPE string, b TYPE string, c TYPE string,
 ready TYPE c, state TYPE c LENGTH 24, note TYPE c LENGTH 255.\n`;
 for(const [ao,bo,co,a,b,c,r,s] of cases)code+=`a=${quote(a)}. b=${quote(b)}. c=${quote(c)}.
 PERFORM wa_bsp_gate USING '${ao}' '${bo}' '${co}' a b c CHANGING ready state note.
 ASSERT ready = '${r}'. ASSERT state = '${s}'.\n`;
 await run('zbspgate',code+form('wa_bsp_gate'),cases.length);

 // Stub only the already-existing SAP UTF-8 codec. All normalization,
 // token preservation, line conversion and equality FORMs are production.
 code=`REPORT zbsptext.
 TYPES ty_lines TYPE STANDARD TABLE OF string.
 TYPES o2pageline_table TYPE STANDARD TABLE OF string.
 CLASS cl_abap_char_utilities DEFINITION.
 PUBLIC SECTION. CLASS-DATA: newline TYPE c, cr_lf TYPE c LENGTH 2.
 CLASS-METHODS class_constructor.
 ENDCLASS.
 CLASS cl_abap_char_utilities IMPLEMENTATION.
 METHOD class_constructor. newline = |\\n|. cr_lf = |\\r\\n|. ENDMETHOD. ENDCLASS.
 TYPES: BEGIN OF fixture, raw TYPE xstring, text TYPE string, END OF fixture.
 DATA: fixtures TYPE STANDARD TABLE OF fixture, fixture_no TYPE i,
 a TYPE xstring, b TYPE xstring, txt TYPE string, txt2 TYPE string, err TYPE string,
 eq TYPE c, tokens TYPE ty_lines, content TYPE o2pageline_table, gv_lf TYPE string.
 gv_lf = cl_abap_char_utilities=>newline.
`;
 const texts=[
 ['<html>old</html>','<html>새 화면</html>',true],
 ['<%@page language="abap"%><b>old</b>','<%@page language="abap"%><b>new</b>',true],
 ['<%= name %><b>old</b>','<%= name %><b>new</b>',true],
 ['<%= name %>','<%= other %>',false],
 ['<%@page language="abap"%>','<%@page language="javascript"%>',false],
 ['<b>old</b>','<% write secret. %><b>new</b>',false],
 ['<%= name %><b>old</b>','<b>new</b>',false],
 ['<%= a %><%= b %>','<%= b %><%= a %>',false],
 ['<%-- preserve %> comment --%><b>old</b>','<%-- preserve %> comment --%><b>new</b>',true],
 ['<b>old</b>','<% unterminated',false],
 ['<b>old</b>','<%-- unterminated %>',false],
 ['<script runat="server">old</script>','<script runat="server">new</script>',false],
 ['<script>let x=1;</script>','<script>let x=2;</script>',true],
 ['<html>old</html>','',false],
 ['<b>old</b>','<b>'+('x'.repeat(900))+'</b>',true]
 ];
 for(const [a,b,ok] of texts)code+=`txt=${quote(a)}. PERFORM utf8 USING txt CHANGING a.
 txt=${quote(b)}. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS ${ok?'':'NOT '}INITIAL.\n`;
 // CRLF, BOM behavior belongs to existing codec; here CRLF/LF and the one-terminal-LF policy.
 for(const [a,b,equal] of [['a\\r\\nb\\r\\n','a\\nb\\n',true],['a\\n','a',true],['a\\n\\n','a\\n',false],['a ','a',false]]){
 code+=`txt=|${a}|. PERFORM utf8 USING txt CHANGING a.
 txt=|${b}|. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_equal USING a b CHANGING eq err. ASSERT err IS INITIAL. ASSERT eq = '${equal?'X':''}'.\n`;
 }
 code+=`txt=|a\\rb|. PERFORM utf8 USING txt CHANGING a.
 PERFORM wa_bsp_normalize USING a CHANGING txt2 err. ASSERT err IS NOT INITIAL.
 a='DEAD'. PERFORM wa_bsp_normalize USING a CHANGING txt2 err. ASSERT err IS NOT INITIAL.
 FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
 DATA: f TYPE fixture, key TYPE x LENGTH 4.
 ADD 1 TO fixture_no. key=fixture_no. raw=key. f-raw=raw. f-text=text. APPEND f TO fixtures.
 ENDFORM.
 FORM im_decode USING raw TYPE xstring CHANGING text TYPE string error TYPE string.
 DATA f TYPE fixture. CLEAR: text,error.
 READ TABLE fixtures INTO f WITH KEY raw=raw.
 IF sy-subrc <> 0. error='codec rejected'. ELSE. text=f-text. ENDIF.
 ENDFORM.
 `+['wa_bsp_normalize','wa_bsp_equal','wa_bsp_tokens','wa_bsp_line_error','wa_bsp_line_assign','wa_bsp_content','web_lines'].map(form).join('\n');
 await run('zbsptext',code,texts.length+6);

 code=`REPORT zbspcontext.
 TYPES: BEGIN OF ty_file, object TYPE c LENGTH 4, component TYPE string, check_mode TYPE c LENGTH 12, END OF ty_file.
 TYPES: BEGIN OF ty_asset, kind TYPE c LENGTH 24, END OF ty_asset.
 TYPES: BEGIN OF ty_key, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 30, END OF ty_key.
 TYPES: BEGIN OF wa_target, selected TYPE c, eligible TYPE c, locked TYPE c,
 file TYPE ty_file, asset TYPE ty_asset, bsp_key TYPE ty_key,
 bsp_objkey TYPE c LENGTH 80, bsp_expected TYPE STANDARD TABLE OF string WITH DEFAULT KEY,
 bsp_guard TYPE xstring, END OF wa_target.
 TYPES: BEGIN OF ty_app, name TYPE c LENGTH 30, END OF ty_app.
 DATA: p_mime TYPE c, im_screen_mode TYPE c, wa_busy TYPE c, wa_backup TYPE string,
 wa_journal_owned TYPE c, wa_bsp_apps TYPE STANDARD TABLE OF ty_app,
 app TYPE ty_app, t TYPE wa_target, err TYPE string.
`;
 const guards=['',"p_mime = space.","im_screen_mode = 'D'.","wa_busy = space.","t-selected = space.",
 "t-eligible = space.","t-locked = space.","CLEAR wa_backup.","CLEAR wa_journal_owned.",
 "t-file-object = 'PROG'.","t-file-component = 'BSP_EVENT_SOURCE'.","t-file-check_mode = 'LF_UTF8'.",
 "t-asset-kind = 'BSP_CONTROLLER'.","CLEAR t-bsp_key.","CLEAR t-bsp_objkey.",
 "REFRESH t-bsp_expected.","CLEAR t-bsp_guard.","REFRESH wa_bsp_apps."];
 for(const change of guards)code+=`PERFORM setup. ${change}
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS ${change?'NOT ':''}INITIAL.\n`;
 code+=`FORM setup.
 CLEAR: t, err. REFRESH wa_bsp_apps. p_mime = 'X'. im_screen_mode = 'M'. wa_busy = 'X'.
 wa_backup = 'verified.zip'. wa_journal_owned = 'X'. t-selected = 'X'. t-eligible = 'X'. t-locked = 'X'.
 t-file-object = 'WAPA'. t-file-component = 'BSP_LAYOUT'. t-file-check_mode = 'RAW'.
 t-asset-kind = 'BSP_PAGE'. t-bsp_key-applname = 'ZTEST'. t-bsp_key-pagekey = 'TEST.HTM'.
 t-bsp_objkey = 'SAP_FORMATTED_KEY'. APPEND 'content' TO t-bsp_expected. t-bsp_guard = '99'.
 app-name = 'ZTEST'. APPEND app TO wa_bsp_apps. ENDFORM.
 `+(form('wa_bsp_context')+`\n FORM wa_scope_check USING t TYPE wa_target CHANGING err TYPE string. CLEAR err. ENDFORM.\n`);
 await run('zbspcontext',code,guards.length);

 code=`REPORT zbsptransaction.
 TYPES: BEGIN OF ty_file, path TYPE string, devclass TYPE c LENGTH 30, END OF ty_file.
 TYPES: BEGIN OF ty_asset, language TYPE c, END OF ty_asset.
 TYPES: BEGIN OF wa_target, id TYPE i, file TYPE ty_file, asset TYPE ty_asset,
 before TYPE xstring, wanted TYPE xstring, eligible TYPE c, task TYPE c LENGTH 20,
 bsp_guard TYPE xstring, bsp_key TYPE c LENGTH 30, bsp_phase TYPE c LENGTH 24,
 bsp_save TYPE c LENGTH 24, bsp_activate TYPE c LENGTH 24, bsp_resume TYPE c, END OF wa_target.
 TYPES: BEGIN OF wa_bsp_snapshot, layout TYPE xstring, guard TYPE xstring,
 inactive TYPE STANDARD TABLE OF string WITH DEFAULT KEY, app_inactive TYPE c, END OF wa_bsp_snapshot.
 CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
 CLASS cx_root IMPLEMENTATION. METHOD get_text. text='exception'. ENDMETHOD. ENDCLASS.
 DATA: p_task TYPE c LENGTH 20, wa_touched TYPE c, wa_log_error TYPE string, t TYPE wa_target, err TYPE string,
 scenario TYPE string, active TYPE xstring, pending TYPE xstring, guard TYPE xstring,
 cts_calls TYPE i, save_calls TYPE i, activate_calls TYPE i, flush_calls TYPE i,
 last_state TYPE string, last_light TYPE string, observed TYPE i, reads TYPE i,
 phase_save TYPE string, phase_activate TYPE string.
`;
 const tx=[
 ['success',1,1,1,'ACTIVATED_VERIFIED',false,'VERIFIED','VERIFIED'],
 ['resume_success',0,0,1,'ACTIVATED_VERIFIED',false,'REUSED_VERIFIED','VERIFIED'],
 ['resume_cts',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['resume_changed',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['resume_saved_check',0,0,0,'SAVED_NOT_ACTIVATED',true,'REUSED_INACTIVE','NOT_RUN'],
 ['resume_common',0,0,0,'SAVED_NOT_ACTIVATED',true,'REUSED_INACTIVE','NOT_RUN'],
 ['resume_activation',0,0,1,'ACTIVATION_REVIEW',true,'REUSED_INACTIVE','FAILED_REVIEW'],
 ['resume_post_read',0,0,1,'ACTIVATION_REVIEW',true,'REUSED_INACTIVE','FAILED_REVIEW'],
 ['resume_cts_lost',0,0,1,'ACTIVATION_REVIEW',true,'REUSED_INACTIVE','FAILED_REVIEW'],
 ['context',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['stale',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['inactive',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['log_before',0,0,0,'FAILED_REVIEW',true,'NOT_RUN','NOT_RUN'],
 ['cts',1,0,0,'FAILED_REVIEW',true,'FAILED_REVIEW','NOT_RUN'],
 ['save',1,1,0,'FAILED_REVIEW',true,'FAILED_REVIEW','NOT_RUN'],
 ['saved_check',1,1,0,'FAILED_REVIEW',true,'FAILED_REVIEW','NOT_RUN'],
 ['common_definition',1,1,0,'SAVED_NOT_ACTIVATED',true,'SAVED_INACTIVE','NOT_RUN'],
 ['activation_guard',1,1,0,'SAVED_NOT_ACTIVATED',true,'SAVED_INACTIVE','NOT_RUN'],
 ['log_between',1,1,0,'SAVED_NOT_ACTIVATED',true,'SAVED_INACTIVE','NOT_RUN'],
 ['activate',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['activate_partial',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['mismatch',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['other_tab',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['inactive_after',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['post_read',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['cts_lost',1,1,1,'ACTIVATION_REVIEW',true,'SAVED_INACTIVE','FAILED_REVIEW'],
 ['log_after',1,1,1,'LOG_FAILED_REVIEW',true,'VERIFIED','VERIFIED']
 ];
 for(const [name,cts,save,act,state,error,ss,aa] of tx)code+=`PERFORM setup USING '${name}'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls=${cts}. ASSERT save_calls=${save}. ASSERT activate_calls=${act}.
 ASSERT last_state='${state}'. ASSERT err IS ${error?'NOT ':''}INITIAL.
 ASSERT phase_save='${ss}'. ASSERT phase_activate='${aa}'.
 ASSERT t-eligible='${cts||name.startsWith('resume_')?'':'X'}'.
 ${(cts||name.startsWith('resume_'))&&!act?`ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.`:''}\n`;
 code+=`
 FORM setup USING name TYPE c.
 CLEAR: t,err,wa_touched,wa_log_error,pending,cts_calls,save_calls,activate_calls,
 flush_calls,last_state,last_light,observed,reads,phase_save,phase_activate.
 t-id=1. t-file-path='page.htm'. t-before='41'. t-wanted='42'. t-bsp_guard='99'.
 t-bsp_save='NOT_RUN'. t-bsp_activate='NOT_RUN'. t-eligible='X'.
 active=t-before. guard=t-bsp_guard. scenario=name.
 t-file-devclass='ZTEST'. p_task='OWN_TASK'.
 IF scenario CP 'resume_*'. t-bsp_resume='X'. pending=t-wanted. ENDIF.
 IF scenario='stale'. active='43'. ENDIF.
 ENDFORM.
 FORM wa_bsp_context USING target TYPE wa_target CHANGING error TYPE string.
 CLEAR error. IF scenario='context'. error='context rejected'. ENDIF. ENDFORM.
 FORM wa_bsp_read USING after TYPE c CHANGING target TYPE wa_target raw TYPE xstring error TYPE string.
 CLEAR error. raw=active. IF scenario='inactive'. error='existing inactive'. ENDIF. ENDFORM.
 FORM wa_bsp_cts CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. ADD 1 TO cts_calls. IF scenario='cts'. error='CTS failed'. ENDIF. ENDFORM.
 FORM wa_bsp_save CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. ADD 1 TO save_calls. target-bsp_save='SAVE_RETURNED'. pending=target-wanted.
 IF scenario='save'. error='save failed after possible internal commit'. ENDIF. ENDFORM.
 FORM wa_bsp_saved_check CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. IF scenario='saved_check' OR scenario='resume_saved_check'. error='inactive differs'. RETURN. ENDIF.
 target-bsp_save='SAVED_INACTIVE'.
 IF target-bsp_resume='X'. target-bsp_save='REUSED_INACTIVE'. ENDIF.
 IF scenario='common_definition' OR scenario='resume_common'. error='shared WAPD warning'. ENDIF. ENDFORM.
 FORM wa_bsp_activate CHANGING target TYPE wa_target error TYPE string.
 CLEAR error.
 IF scenario='activation_guard'. error='activation recheck rejected'. RETURN. ENDIF.
 ADD 1 TO activate_calls. target-bsp_activate='ACTIVATE_ATTEMPT'.
 IF scenario='activate' OR scenario='resume_activation'. error='syntax error'. RETURN. ENDIF.
 active=pending. CLEAR pending.
 IF scenario='activate_partial'. error='activation error after commit'. RETURN. ENDIF.
 IF scenario='mismatch'. active='43'. ENDIF.
 IF scenario='other_tab'. guard='98'. ENDIF.
 IF scenario='inactive_after'. pending='42'. ENDIF.
 target-bsp_activate='ACTIVATE_RETURNED'. ENDFORM.
 FORM wa_bsp_fetch USING key TYPE c lang TYPE c CHANGING snap TYPE wa_bsp_snapshot error TYPE string.
 CLEAR: snap,error. ADD 1 TO reads. snap-layout=active. snap-guard=guard.
 IF pending IS NOT INITIAL. APPEND 'page.htm' TO snap-inactive. ENDIF.
 IF scenario='post_read' OR scenario='resume_post_read'. error='fresh read failed'. ENDIF. ENDFORM.
 FORM wa_bsp_guard USING snap TYPE wa_bsp_snapshot CHANGING raw TYPE xstring.
 raw=snap-guard. ENDFORM.
 FORM wa_bsp_equal USING a TYPE xstring b TYPE xstring CHANGING eq TYPE c error TYPE string.
 CLEAR: eq,error. IF a=b. eq='X'. ENDIF. ENDFORM.
 FORM wa_bsp_check_layout USING target TYPE wa_target snap TYPE wa_bsp_snapshot phase TYPE csequence
 CHANGING eq TYPE c error TYPE string.
 ASSERT target-bsp_activate <> 'NOT_RUN'.
 PERFORM wa_bsp_equal USING snap-layout target-wanted CHANGING eq error.
 IF eq <> 'X'. error='ACTIVE_CHECK Layout mismatch'. ENDIF. ENDFORM.
 FORM wa_bsp_cts_verify USING target TYPE wa_target CHANGING error TYPE string.
 CLEAR error.
 IF target-bsp_resume='X'. ASSERT target-task=p_task. ENDIF.
 IF scenario='cts_lost' OR scenario='resume_cts' OR ( scenario='resume_cts_lost' AND activate_calls > 0 ). error='CTS missing'. ENDIF. ENDFORM.
 FORM wa_bsp_resume_check USING target TYPE wa_target CHANGING detail TYPE string error TYPE string.
 ASSERT target-bsp_resume='X'. CLEAR error. detail='verified I same as upload'.
 IF scenario='resume_changed'. error='I changed'. ENDIF. ENDFORM.
 FORM wa_bsp_verify_record USING target TYPE wa_target phase TYPE csequence state TYPE csequence detail TYPE string.
 ASSERT phase='REUSE_INACTIVE'. ASSERT state='VERIFIED'. ASSERT save_calls=0. ASSERT cts_calls=0.
 ENDFORM.
 FORM wa_bsp_observed USING target TYPE wa_target snap TYPE wa_bsp_snapshot.
 ADD 1 TO observed. ENDFORM.
 FORM wa_bsp_pending_note USING key TYPE c snap TYPE wa_bsp_snapshot
 CHANGING state TYPE c note TYPE string.
 state='NONE'. CLEAR note.
 IF snap-inactive IS NOT INITIAL OR snap-app_inactive='X'.
 state='PAGE_REVIEW'. note='selected page pending'. ENDIF. ENDFORM.
 FORM wa_bsp_status USING target TYPE wa_target.
 phase_save=target-bsp_save. phase_activate=target-bsp_activate. ENDFORM.
 FORM wa_flush CHANGING error TYPE string.
 CLEAR error. ADD 1 TO flush_calls.
 IF ( scenario='log_before' AND flush_calls=1 ) OR
    ( scenario='log_between' AND flush_calls=2 ) OR
    ( scenario='log_after' AND flush_calls=3 ). error='disk error'. ENDIF. ENDFORM.
 FORM wa_set_result USING id TYPE i state TYPE csequence note TYPE string light TYPE csequence size TYPE i task TYPE c.
 last_state=state. last_light=light. ENDFORM.
 FORM wa_event_add USING id TYPE i path TYPE string phase TYPE csequence state TYPE csequence detail TYPE string.
 ENDFORM.
 `+form('wa_bsp_one');
 await run('zbsptransaction',code,tx.length);
 code=`REPORT zbspmessage.
 TYPES: BEGIN OF ty_id, msgid TYPE c LENGTH 20, msgno TYPE n LENGTH 3, END OF ty_id.
 TYPES: BEGIN OF ty_message, mtype TYPE c, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY,
 object_text TYPE string, message TYPE ty_id, END OF ty_message.
 TYPES: BEGIN OF ty_short, mtype TYPE c, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY, END OF ty_short.
 TYPES: BEGIN OF ty_missing_type, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY, END OF ty_missing_type.
 TYPES: BEGIN OF ty_missing_text, mtype TYPE c, END OF ty_missing_text.
 DATA: msg TYPE ty_message, short TYPE ty_short, no_type TYPE ty_missing_type,
 no_text TYPE ty_missing_text, severity TYPE c, text TYPE string, err TYPE string.
 START-OF-SELECTION.
 msg-mtype = 'E'. msg-object_text = 'PAGE'. APPEND 'Syntax error' TO msg-mtext.
 APPEND 'line 5' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'E'. ASSERT text = 'PAGE Syntax error line 5'.
 CLEAR msg. msg-mtype = 'W'. APPEND 'Warning' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'W'. ASSERT text = 'Warning'.
 CLEAR msg. msg-mtype = 'E'. msg-message-msgid = 'BSP'. msg-message-msgno = '012'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'E'. ASSERT text = 'BSP 012'.
 CLEAR msg. msg-mtype = 'A'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'A'. ASSERT text IS NOT INITIAL.
 short-mtype = 'S'. APPEND 'Done' TO short-mtext.
 PERFORM wa_bsp_message USING short CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'S'. ASSERT text = 'Done'.
 PERFORM wa_bsp_message USING no_type CHANGING severity text err.
 ASSERT err IS NOT INITIAL. ASSERT severity IS INITIAL.
 no_text-mtype = 'E'.
 PERFORM wa_bsp_message USING no_text CHANGING severity text err.
 ASSERT err IS NOT INITIAL.
 CLEAR msg. msg-mtype = '?'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS NOT INITIAL. ASSERT severity IS INITIAL.
 CLEAR msg. msg-mtype = 'X'. APPEND 'Abort' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity = 'X'. ASSERT text = 'Abort'.
 `+form('wa_bsp_message');
 await run('zbspmessage',code,9);
 const pageTypes=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/bsp-page-types.json'),'utf8')).pages;
 const kinds=['','V','X','H','F','C','M','1','?','x'];
 code=`REPORT zbspkind. DATA: kind TYPE c, ok TYPE c, text TYPE string. START-OF-SELECTION.\n`;
 for(const kind of kinds){code+=`kind = ${quote(kind)}. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok = ${quote(['','V','X'].includes(kind)?'X':'')}. ASSERT text IS NOT INITIAL.\n`;}
 code+=form('wa_bsp_page_kind'); await run('zbspkind',code,kinds.length);
 code=`REPORT zbspprops.
 TYPES: BEGIN OF o2pagkey, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 70, END OF o2pagkey.
 TYPES: BEGIN OF o2pagattr, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 70, pagetype TYPE c, END OF o2pagattr.
 DATA: key TYPE o2pagkey, wanted TYPE o2pagkey, attrs TYPE o2pagattr,
 lang TYPE sy-langu, wanted_lang TYPE sy-langu, err TYPE string.
 START-OF-SELECTION.
 `;
 let propertyCases=0;
 const checkProps=(setup,errorField)=>{propertyCases++;code+=`PERFORM setup. ${setup}
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ${errorField?`ASSERT err CS ${quote(errorField)}. ASSERT err IS NOT INITIAL.`:'ASSERT err IS INITIAL.'}\n`;};
 // Page-type values come from an independently serialized BSP example, not the old allowlist.
 for(const page of pageTypes)checkProps(`attrs-pagetype = ${quote(page.pagetype)}.`,null);
 checkProps("key-applname = 'OTHER_APP'.",'PAGE_KEY/APPLNAME');
 checkProps("key-pagekey = 'OTHER.HTM'.",'PAGE_KEY/PAGEKEY');
 checkProps("lang = 'E'.",'REQUESTED_LANGUAGE');
 checkProps("attrs-applname = 'OTHER_APP'.",'PROPERTIES/APPLNAME');
 checkProps("attrs-pagekey = 'OTHER.HTM'.",'PROPERTIES/PAGEKEY');
 checkProps('CLEAR attrs.','PROPERTIES/APPLNAME');
 checkProps('CLEAR key.','PAGE_KEY/APPLNAME');
 checkProps('CLEAR lang.','REQUESTED_LANGUAGE');
 checkProps('CLEAR wanted.','검증 대상');
 checkProps('CLEAR wanted_lang.','검증 대상');
 for(const kind of ['H','F','C','M','?'])checkProps(`attrs-pagetype = ${quote(kind)}.`,'PAGETYPE');
 checkProps("key-pagekey = 'flex_work_performance_view.htm'.",'PAGE_KEY/PAGEKEY');
 code+=`FORM setup.
 CLEAR: key, wanted, attrs, err.
 wanted-applname = 'Z52_FLEX_TIME'. wanted-pagekey = 'FLEX_WORK_PERFORMANCE_VIEW.HTM'.
 key = wanted. attrs-applname = wanted-applname. attrs-pagekey = wanted-pagekey.
 lang = '3'. wanted_lang = '3'.
 ENDFORM.\n`+form('wa_bsp_page_kind')+'\n'+form('wa_bsp_property_error')+'\n'+form('wa_bsp_properties_check');
 await run('zbspprops',code,propertyCases);
 console.log(JSON.stringify({tests:results,limits:'SAP repository, CTS, locking, activation, GUI and codec calls are test doubles; target SAP validation still required'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
