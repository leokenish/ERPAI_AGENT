const fs=require('fs');
const a=require('@abaplint/core');
const source=process.argv[2];
const reg=new a.Registry(new a.Config(JSON.stringify({
 global:{files:'/**/*.abap'}, syntax:{version:'v700',errorNamespace:'^(Z|Y|LCL_|TY_|LIF_)'},
 rules:{parser_error:true,check_syntax:true}
})));
reg.addFile(new a.MemoryFile('z_package_diag.prog.abap',fs.readFileSync(source,'utf8')));
reg.parse();
let parsed=0,unknown=[];
for(const obj of reg.getObjects()) for(const file of obj.getABAPFiles()) for(const st of file.getStatements()) {
 parsed++; if(st.get().constructor.name === 'Unknown') unknown.push({row:st.getStart().getRow(),text:st.concatTokens()});
}
const issues=reg.findIssues().map(i=>({rule:i.getKey(),row:i.getStart().getRow(),message:i.getMessage()}));
const report={source,abaplint:require('@abaplint/core/package.json').version,version:'v700',statements:parsed,unknown,issues};
console.log(JSON.stringify(report,null,2));
process.exitCode=unknown.length?1:0;
