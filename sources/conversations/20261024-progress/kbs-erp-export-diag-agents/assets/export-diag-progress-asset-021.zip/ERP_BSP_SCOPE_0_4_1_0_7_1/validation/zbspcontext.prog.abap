REPORT zbspcontext.
 TYPES: BEGIN OF ty_file, object TYPE c LENGTH 4, component TYPE string, check_mode TYPE c LENGTH 12, END OF ty_file.
 TYPES: BEGIN OF ty_asset, kind TYPE c LENGTH 24, END OF ty_asset.
 TYPES: BEGIN OF ty_key, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 30, END OF ty_key.
 TYPES: BEGIN OF wa_target, selected TYPE c, eligible TYPE c, locked TYPE c,
 file TYPE ty_file, asset TYPE ty_asset, bsp_key TYPE ty_key,
 bsp_objkey TYPE c LENGTH 80, bsp_expected TYPE STANDARD TABLE OF string WITH DEFAULT KEY,
 bsp_guard TYPE xstring, END OF wa_target.
 TYPES: BEGIN OF ty_app, name TYPE c LENGTH 30, END OF ty_app.
 DATA: p_mime TYPE c, im_screen_mode TYPE c, wa_busy TYPE c, wa_backup TYPE string,
 wa_journal_owned TYPE c, wa_bsp_apps TYPE STANDARD TABLE OF ty_app,
 app TYPE ty_app, t TYPE wa_target, err TYPE string.
PERFORM setup. 
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS INITIAL.
PERFORM setup. p_mime  =  space.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. im_screen_mode  =  'D'.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. wa_busy  =  space.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-selected  =  space.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-eligible  =  space.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-locked  =  space.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR wa_backup.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR wa_journal_owned.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-file-object  =  'PROG'.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-file-component  =  'BSP_EVENT_SOURCE'.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-file-check_mode  =  'LF_UTF8'.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. t-asset-kind  =  'BSP_CONTROLLER'.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR t-bsp_key.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR t-bsp_objkey.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. REFRESH t-bsp_expected.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR t-bsp_guard.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
PERFORM setup. REFRESH wa_bsp_apps.
 PERFORM wa_bsp_context USING t CHANGING err. ASSERT err IS NOT INITIAL.
FORM setup.
 CLEAR: t, err. REFRESH wa_bsp_apps. p_mime  =  'X'. im_screen_mode  =  'M'. wa_busy  =  'X'.
 wa_backup  =  'verified.zip'. wa_journal_owned  =  'X'. t-selected  =  'X'. t-eligible  =  'X'. t-locked  =  'X'.
 t-file-object  =  'WAPA'. t-file-component  =  'BSP_LAYOUT'. t-file-check_mode  =  'RAW'.
 t-asset-kind  =  'BSP_PAGE'. t-bsp_key-applname  =  'ZTEST'. t-bsp_key-pagekey  =  'TEST.HTM'.
 t-bsp_objkey  =  'SAP_FORMATTED_KEY'. APPEND 'content' TO t-bsp_expected. t-bsp_guard  =  '99'.
 app-name  =  'ZTEST'. APPEND app TO wa_bsp_apps. ENDFORM.
 FORM wa_bsp_context USING ps_target TYPE wa_target CHANGING cv_error TYPE string.
  CLEAR cv_error.
  PERFORM wa_scope_check USING ps_target CHANGING cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  IF p_mime <> 'X' OR im_screen_mode <> 'M' OR wa_busy <> 'X' OR
     ps_target-selected <> 'X' OR ps_target-eligible <> 'X' OR ps_target-locked <> 'X' OR
     wa_backup IS INITIAL OR wa_journal_owned <> 'X' OR
     ps_target-file-object <> 'WAPA' OR ps_target-file-component <> 'BSP_LAYOUT' OR
     ps_target-file-check_mode <> 'RAW' OR ps_target-asset-kind <> 'BSP_PAGE' OR
     ps_target-bsp_key IS INITIAL OR ps_target-bsp_objkey IS INITIAL OR
     ps_target-bsp_expected IS INITIAL OR ps_target-bsp_guard IS INITIAL.
    cv_error  =  'BSP_WRITE_CONTEXT_REJECTED'. RETURN.
  ENDIF.
  READ TABLE wa_bsp_apps WITH KEY name  =  ps_target-bsp_key-applname TRANSPORTING NO FIELDS.
  IF sy-subrc <> 0. cv_error  =  'BSP_WRITE_LOCK_HANDLE_MISSING'. ENDIF.
ENDFORM.
 FORM wa_scope_check USING t TYPE wa_target CHANGING err TYPE string. CLEAR err. ENDFORM.
