// Execute production ABAP scope rules and discovery with SAP I/O doubles.
const fs=require('fs'),path=require('path');
const {Transpiler}=require('@abaplint/transpiler'),{ABAP}=require('@abaplint/runtime');
const source=fs.readFileSync(path.resolve(__dirname,'../Z_PACKAGE_DIAG_0_7_1.abap'),'utf8');
const exp=fs.readFileSync(path.resolve(__dirname,'../Z_PACKAGE_EXPORT_0_4_1.abap'),'utf8');
const form=(n,s=source)=>s.match(new RegExp('^FORM '+n+'\\b[\\s\\S]*?^ENDFORM\\.','m'))[0];
const q=s=>"'"+s.replaceAll("'","''")+"'";
const results=[];
async function run(name,code,cases){
 fs.writeFileSync(path.join(__dirname,name+'.prog.abap'),code);
 const out=await new Transpiler({addCommonJS:false,unknownTypes:'compileError'}).runRaw([{filename:name+'.prog.abap',contents:code}]);
 const js=out.objects.find(o=>o.object.type==='PROG').chunk.getCode();
 fs.writeFileSync(path.join(__dirname,name+'.js'),js);
 global.abap=new ABAP();
 await new (Object.getPrototypeOf(async function(){}).constructor)('abap',js)(global.abap);
 results.push({name,cases,assertions:(code.match(/\bASSERT\b/g)||[]).length,result:'PASS'});
 console.log(name,'PASS',cases);
}
const common=`
TYPES: o2applname TYPE c LENGTH 30, boole_d TYPE c, string_table TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, pgmid TYPE c LENGTH 4, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF tdevc, devclass TYPE c LENGTH 30, END OF tdevc.
TYPES: BEGIN OF ty_object, pgmid TYPE tadir-pgmid, object TYPE tadir-object, obj_name TYPE tadir-obj_name,
devclass TYPE tadir-devclass, status TYPE c LENGTH 20, reason TYPE string, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
TYPES ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
DATA: p_bspm TYPE c, p_pkgm TYPE c, p_sub TYPE c, p_bsp TYPE o2applname, p_pack TYPE tadir-devclass, p_file TYPE c LENGTH 255,
p_mb TYPE i, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
gv_scope_kind TYPE c LENGTH 12, gv_scope_package TYPE tadir-devclass, gv_bsp_flat TYPE c,
gv_fatal TYPE string, gv_archive_name TYPE string, gv_stage TYPE c LENGTH 30, gv_count TYPE i,
gt_packages TYPE ty_packages, gt_seen_pkg TYPE SORTED TABLE OF ty_package WITH UNIQUE KEY devclass,
gt_objects TYPE STANDARD TABLE OF ty_object WITH DEFAULT KEY, gs_object TYPE ty_object,
err TYPE string, url TYPE string, ok TYPE c, n TYPE i, obj TYPE ty_object, pkg TYPE ty_package.
`;
const codec=`
FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
* External SAP codec double; only escaped ASCII slash used in these fixtures.
 ASSERT text = '/'. raw = '2F'.
ENDFORM.
`;
const rules=['scope_url','scope_url_check','bsp_app_from_url','bsp_mime_relative','segment','safe_leaf'].map(n=>form(n)).join('\n')+codec;
const fileType=source.match(/TYPES: BEGIN OF ty_file,[\s\S]*?END OF ty_file\./)[0];
const headerType=`TYPES: BEGIN OF ty_header, format TYPE c LENGTH 30, version TYPE c LENGTH 10,
tool_version TYPE c LENGTH 10, scope_kind TYPE c LENGTH 12, bsp_application TYPE o2applname,
bsp_package TYPE tadir-devclass, path_layout TYPE c LENGTH 20, END OF ty_header.`;
(async()=>{
 let cases=0;
 let code='REPORT zscope_rules.\n'+common+fileType+headerType+`
TYPES: BEGIN OF ty_asset, original_path TYPE string, END OF ty_asset.
TYPES: BEGIN OF o2pagkey, applname TYPE o2applname, pagekey TYPE c LENGTH 70, END OF o2pagkey.
TYPES: BEGIN OF wa_target, file TYPE ty_file, asset TYPE ty_asset, bsp_key TYPE o2pagkey, END OF wa_target.
DATA: im_header TYPE ty_header, im_packages TYPE ty_packages, f TYPE ty_file, target TYPE wa_target,
im_manifest TYPE STANDARD TABLE OF ty_file, metadata_error TYPE string, metadata_calls TYPE i.
START-OF-SELECTION.
`;
 const test=(label,s)=>{cases++;code+=`* CASE ${cases} ${label}\nPERFORM setup.\n${s}\n`;};
 test('BSP mode overrides stale result variant',`p_all = 'X'. p_src = 'X'. p_xml = 'X'. p_pkgm = 'X'. p_sub = 'X'. p_mb = 1.
PERFORM scope_mode. ASSERT p_mime = 'X'. ASSERT p_all IS INITIAL. ASSERT p_src IS INITIAL.
ASSERT p_xml IS INITIAL. ASSERT p_pkgm IS INITIAL. ASSERT p_sub IS INITIAL. ASSERT p_mb = 512. ASSERT gv_scope_kind = 'BSP'.`);
 test('package mode keeps result choice and descendants',`CLEAR p_bspm. p_src = 'X'. PERFORM scope_mode.
ASSERT p_pkgm = 'X'. ASSERT p_sub = 'X'. ASSERT p_src = 'X'. ASSERT gv_scope_kind = 'PACKAGE'.`);
 test('app name required',`CLEAR p_bsp. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('package required',`CLEAR: p_bspm, p_pack. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('ZIP required only on execution validation',`CLEAR p_file. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.`);
 for(const [app,valid] of [['ZWEB_COMMON',true],['ZWEB_WF',true],['/KBS/ZWEB',true],['ZWEB*',false],['ZWEB_COMMON/EVIL',false],['/SAP/ZWEB_COMMON',false],['',false],['ZWEB COMMON',false]]){
 test('canonical app '+app,`p_bsp = ${q(app)}. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS ${valid?'':'NOT '}INITIAL.`);
 }
 for(const [u,valid] of [['/SAP/BC/BSP/SAP/ZWEB_COMMON/css/main.css',true],['/sap/bc/bsp/sap/zweb_common/js/a.js',true],['/SAP/BC/BSP/SAP/ZWEB_COMMON2/a.js',false],['/SAP/BC/BSP/SAP/ZWEB_WF/a.js',false],['/SAP/PUBLIC/a.js',false],['/SAP/BC/BSP/SAP/ZWEB_COMMON/../other.js',false],['/SAP/BC/BSP/SAP/ZWEB_COMMON/css//a.css',false],['/SAP/BC/BSP/SAP/ZWEB_COMMON',true]]){
 test('URL boundary '+u,`url = ${q(u)}. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS ${valid?'':'NOT '}INITIAL.`);
 }
 const headers=[
 ['legacy 0318 package',false,'0.2','0.3.18','','','',true],
 ['legacy 0328 package',false,'0.2','0.3.28','','','',true],
 ['legacy BSP forbidden',true,'0.2','0.3.18','','','',false],
 ['legacy scope injection',false,'0.2','0.3.18','BSP','ZWEB_COMMON','ZWEB',false],
 ['new package',false,'0.3','0.4.0','PACKAGE','','',true],
 ['new BSP',true,'0.3','0.4.0','BSP','ZWEB_COMMON','ZWEB',true],
 ['other BSP',true,'0.3','0.4.0','BSP','ZWEB_WF','ZWEB',false],
 ['BSP in package mode',false,'0.3','0.4.0','BSP','ZWEB_COMMON','ZWEB',false],
 ['package in BSP mode',true,'0.3','0.4.0','PACKAGE','','',false],
 ['missing owner',true,'0.3','0.4.0','BSP','ZWEB_COMMON','',false],
 ['unknown version',true,'0.3','9.9.9','BSP','ZWEB_COMMON','ZWEB',false],
 ['wrong schema',true,'0.2','0.4.0','BSP','ZWEB_COMMON','ZWEB',false],
 ['wrong mode',false,'0.3','0.4.0','ALL','','',false]
 ];
 for(const [label,bsp,version,tool,kind,app,pkg,valid] of headers)test(label,`
 p_bspm = '${bsp?'X':''}'. im_header-version = '${version}'. im_header-tool_version = '${tool}'.
 im_header-scope_kind = '${kind}'. im_header-bsp_application = '${app}'. im_header-bsp_package = '${pkg}'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS ${valid?'':'NOT '}INITIAL.`);
 const files=[
 ['own Layout','WAPA','ZWEB_COMMON','ZWEB','BSP_LAYOUT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Layout/index.htm',true],
 ['own event read only','WAPA','ZWEB_COMMON','ZWEB','BSP_EVENT_SOURCE','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Event Handler/ONINPUTPROCESSING.abap',true],
 ['foreign app same package','WAPA','ZWEB_WF','ZWEB','BSP_LAYOUT','packages/ZWEB/BSP Application/WAPA/ZWEB_WF/pages/a/Layout/a.htm',false],
 ['lying WAPA path','WAPA','ZWEB_COMMON','ZWEB','BSP_LAYOUT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON2/pages/a/Layout/a.htm',false],
 ['cross package owned MIME','SMIM','LOIO1','ZMEDIA','MIME_CONTENT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/js/app.js',true],
 ['external MIME path','SMIM','LOIO1','ZMEDIA','MIME_CONTENT','packages/ZWEB/MIME/text/javascript/app.js',false],
 ['unlisted owner','SMIM','LOIO1','OTHER','MIME_CONTENT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/app.js',false],
 ['package DDIC forbidden','TABL','ZTABLE','ZWEB','DDIC_TABLE','packages/ZWEB/Dictionary Object/ZTABLE.xml',false],
 ['package FUGR forbidden','FUGR','ZGROUP','ZWEB','FUNCTION_API_SOURCE','packages/ZWEB/Function Module/F.abap',false],
 ['unbound W3MI forbidden','W3MI','LOGO','ZWEB','W3MI_CONTENT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/logo.png',false],
 ['metadata cross package','','','ZMEDIA','MIME_METADATA','packages/ZMEDIA/MIME/metadata.xml',true],
 ['catalog','','','','WEB_CATALOG','catalog/web-assets.xml',true]
 ];
 for(const [label,obj,name,pkg,comp,pth,valid] of files)test(label,`
 CLEAR f. f-object = '${obj}'. f-obj_name = '${name}'. f-devclass = '${pkg}'.
 f-component = '${comp}'. f-path = '${pth}'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS ${valid?'':'NOT '}INITIAL.`);

 const flatHeaders=[
 ['flat BSP accepted',true,'0.4','0.4.1','BSP','ZWEB_COMMON','ZWEB','BSP_APP_ROOT',true],
 ['package 041 accepted',false,'0.3','0.4.1','PACKAGE','','','',true],
 ['flat owner missing',true,'0.4','0.4.1','BSP','ZWEB_COMMON','','BSP_APP_ROOT',false],
 ['flat wrong app',true,'0.4','0.4.1','BSP','ZWEB_WF','ZWEB','BSP_APP_ROOT',false],
 ['flat package mode forbidden',false,'0.4','0.4.1','BSP','ZWEB_COMMON','ZWEB','BSP_APP_ROOT',false],
 ['new BSP without marker forbidden',true,'0.4','0.4.1','BSP','ZWEB_COMMON','ZWEB','',false],
 ['new BSP with legacy schema forbidden',true,'0.3','0.4.1','BSP','ZWEB_COMMON','ZWEB','',false],
 ['legacy marker injection forbidden',true,'0.3','0.4.0','BSP','ZWEB_COMMON','ZWEB','BSP_APP_ROOT',false],
 ['old package marker injection forbidden',false,'0.2','0.3.18','','','','BSP_APP_ROOT',false]
 ];
 for(const [label,bsp,version,tool,kind,app,pkg,layout,valid] of flatHeaders)test(label,`
 gv_bsp_flat = 'X'. p_bspm = '${bsp?'X':''}'. im_header-version = '${version}'. im_header-tool_version = '${tool}'.
 im_header-scope_kind = '${kind}'. im_header-bsp_application = '${app}'. im_header-bsp_package = '${pkg}'.
 im_header-path_layout = '${layout}'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS ${valid?'':'NOT '}INITIAL. ASSERT gv_bsp_flat = '${valid&&layout?'X':''}'.`);
 const flatFiles=[
 ['flat Layout','WAPA','ZWEB_COMMON','ZWEB','BSP_LAYOUT','pages/index/Layout/index.htm',true],
 ['flat event read only','WAPA','ZWEB_COMMON','ZWEB','BSP_EVENT_SOURCE','pages/index/Event Handler/on.abap',true],
 ['flat WAPA cannot use MIME root','WAPA','ZWEB_COMMON','ZWEB','BSP_LAYOUT','MIMEs/index.htm',false],
 ['flat WAPA foreign app','WAPA','ZWEB_WF','ZWEB','BSP_LAYOUT','pages/index/Layout/index.htm',false],
 ['flat owner retained','SMIM','LOIO1','ZMEDIA','MIME_CONTENT','MIMEs/app.js',true],
 ['flat unlisted owner','SMIM','LOIO1','OTHER','MIME_CONTENT','MIMEs/app.js',false],
 ['flat metadata','','','','MIME_METADATA','catalog/mime-metadata.xml',true],
 ['flat metadata cannot claim one owner','','','ZMEDIA','MIME_METADATA','catalog/mime-metadata.xml',false],
 ['legacy metadata rejected in flat mode','','','ZMEDIA','MIME_METADATA','packages/ZMEDIA/MIME/metadata.xml',false],
 ['legacy MIME rejected in flat mode','SMIM','LOIO1','ZMEDIA','MIME_CONTENT','packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/app.js',false]
 ];
 for(const [label,obj,name,pkg,comp,pth,valid] of flatFiles)test(label,`
 gv_bsp_flat = 'X'. CLEAR f. f-object = '${obj}'. f-obj_name = '${name}'. f-devclass = '${pkg}'.
 f-component = '${comp}'. f-path = '${pth}'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS ${valid?'':'NOT '}INITIAL.`);
 for(const [pth,flat,valid] of [
 ['pages/index/Layout/index.htm',true,true],['MIMEs/extra.woff2',true,true],
 ['catalog/mime-metadata.xml',true,true],['catalog/web-assets.xml',true,true],
 ['packages/ZHR1/MIME/a.js',true,false],['.devhub/baseline/MIMEs/a.js',true,false],
 ['ZWEB_COMMON/pages/a.htm',true,false],['README.md',true,false],
 ['MIMEs/a.js',false,false],['packages/ZWEB/a.js',false,true]
 ])test('logical payload root '+pth,`gv_bsp_flat = '${flat?'X':''}'. url = '${pth}'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = '${valid?'X':''}'.`);
 test('flat archive wrapper and baseline',`gv_bsp_flat = 'X'. url = 'pages/index/Layout/index.htm'.
 PERFORM scope_zip_path USING url CHANGING err. ASSERT err = 'ZWEB_COMMON/pages/index/Layout/index.htm'.
 url = '.devhub/baseline/MIMEs/app.js'. PERFORM scope_zip_path USING url CHANGING err.
 ASSERT err = 'ZWEB_COMMON/.devhub/baseline/MIMEs/app.js'.
 PERFORM scope_zip_path USING 'manifest.xml' CHANGING err. ASSERT err = 'ZWEB_COMMON/manifest.xml'.`);
 test('package archive has no wrapper',`url = 'manifest.xml'. PERFORM scope_zip_path USING url CHANGING err. ASSERT err = url.`);
 test('namespaced app wrapper escaped',`gv_bsp_flat = 'X'. p_bsp = '/KBS/ZWEB'.
 PERFORM scope_zip_path USING 'manifest.xml' CHANGING err. ASSERT err = '~2FKBS~2FZWEB/manifest.xml'.`);
 test('flat Layout write mapping',`gv_bsp_flat = 'X'. f-path = 'pages/index/Layout/index.htm'. PERFORM add_current.
 target-file = f. target-bsp_key-applname = p_bsp. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.`);
 test('flat event remains nonwritable',`gv_bsp_flat = 'X'. f-path = 'pages/index/Event Handler/on.abap'.
 f-component = 'BSP_EVENT_SOURCE'. PERFORM add_current. target-file = f. target-bsp_key-applname = p_bsp.
 PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('flat MIME owner and URL retained',`PERFORM mime_target. gv_bsp_flat = 'X'. f-path = 'MIMEs/a.js'. target-file = f.
 PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.
 target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_WF/a.js'. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('missing current identity never writable',`PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.`);
 test('current exact object accepted',`PERFORM add_current. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok = 'X'.`);
 test('foreign object with own path rejected',`PERFORM add_current. f-obj_name = 'OTHER'. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.`);
 test('owner changed rejected',`PERFORM add_current. f-devclass = 'ZMEDIA'. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.`);
 test('write Layout accepted',`PERFORM add_current. target-file = f. target-bsp_key-applname = p_bsp.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.`);
 test('write event forbidden',`PERFORM add_current. f-component = 'BSP_EVENT_SOURCE'. target-file = f. target-bsp_key-applname = p_bsp.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('write native key must match',`PERFORM add_current. target-file = f. target-bsp_key-applname = 'ZWEB_WF'.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('owned MIME write boundary',`PERFORM mime_target. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.`);
 test('foreign URL write forbidden even same object fields',`PERFORM mime_target. target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_WF/a.js'.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('scoped manifest with Layout and unchanged catalog',`APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL. ASSERT metadata_calls = 1.`);
 test('catalog required in manifest',`APPEND f TO im_manifest.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL. ASSERT metadata_calls = 0.`);
 test('MIME-only selected rollback does not require page payload',`PERFORM mime_target. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL.`);
 test('foreign manifest rejected before snapshot',`f-obj_name = 'ZWEB_WF'. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL. ASSERT metadata_calls = 0.`);
 test('changed baseline catalog stops scope validation',`APPEND f TO im_manifest. PERFORM add_catalog. metadata_error = 'catalog differs'.
PERFORM im_scope_manifest CHANGING err. ASSERT err = metadata_error.`);
 test('missing primary owner rejected',`DELETE im_packages WHERE devclass = 'ZWEB'. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('unbound W3MI rejected in manifest',`f-object = 'W3MI'. f-component = 'W3MI_CONTENT'. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL.`);
 test('legacy package scope bypasses BSP-only manifest rule',`CLEAR p_bspm. REFRESH im_manifest.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL. ASSERT metadata_calls = 0.`);
 code+=`
FORM setup.
 CLEAR: gv_bsp_flat, err, url, ok, f, target, im_header, p_pack, p_all, p_src, p_xml, p_mime, metadata_error, metadata_calls.
 REFRESH: im_packages, gt_objects, im_manifest. p_bspm = 'X'. p_bsp = 'ZWEB_COMMON'. p_file = 'input.zip'.
 im_header-format = 'DEVHUB-EXPORT'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = p_bsp. im_header-bsp_package = 'ZWEB'.
 pkg-devclass = 'ZWEB'. APPEND pkg TO im_packages. pkg-devclass = 'ZMEDIA'. APPEND pkg TO im_packages.
 f-object = 'WAPA'. f-obj_name = p_bsp. f-devclass = 'ZWEB'. f-component = 'BSP_LAYOUT'. f-check_mode = 'RAW'.
 f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Layout/index.htm'.
ENDFORM.
FORM add_current.
 CLEAR obj. obj-pgmid = 'R3TR'. obj-object = f-object. obj-obj_name = f-obj_name. obj-devclass = f-devclass.
 APPEND obj TO gt_objects.
ENDFORM.
FORM mime_target.
 f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'. f-component = 'MIME_CONTENT'.
 f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/a.js'.
 PERFORM add_current. target-file = f. target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_COMMON/a.js'.
ENDFORM.
FORM add_catalog.
 DATA cat TYPE ty_file. cat-component = 'WEB_CATALOG'. cat-path = 'catalog/web-assets.xml'. APPEND cat TO im_manifest.
ENDFORM.
FORM wa_metadata USING p TYPE string CHANGING raw TYPE xstring error TYPE string.
 ASSERT p = 'catalog/web-assets.xml'. ADD 1 TO metadata_calls. error = metadata_error. CLEAR raw.
ENDFORM.
`+rules+['scope_mode','scope_selection','im_manifest_compat','im_scope_file','im_scope_manifest','im_scope_current','mime_metadata_path','wa_scope_check','scope_bsp_root','scope_zip_path','im_payload_path'].map(n=>form(n)).join('\n');
 await run('zscope_rules',code,cases);

 // Independently execute the Export variant normalization and required scope.
 cases=0;code='REPORT zscope_export.\n'+common+`
RANGES s_pack FOR p_pack.
START-OF-SELECTION.
p_bspm = 'X'. p_bsp = 'zweb_common'. PERFORM scope_mode.
ASSERT gv_bsp_flat = 'X'. ASSERT p_bsp = 'ZWEB_COMMON'. ASSERT p_sub IS INITIAL. ASSERT gv_scope_kind = 'BSP'.
PERFORM scope_selection CHANGING err. ASSERT err IS INITIAL.
CLEAR p_bspm. PERFORM scope_mode. ASSERT gv_bsp_flat IS INITIAL. ASSERT p_sub = 'X'.
PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.
s_pack-sign = 'I'. s_pack-option = 'EQ'. s_pack-low = 'ZWEB'. APPEND s_pack.
PERFORM scope_selection CHANGING err. ASSERT err IS INITIAL.
`+rules+form('scope_mode',exp)+form('scope_selection',exp);
 await run('zscope_export',code,4);

 // Discovery SQL and MIME APIs below are explicit SAP doubles. No serializer
 // or scope decision is substituted. Selection uses real object names/packages.
 let discovery=form('scope_discover_bsp');
 discovery=discovery.replace(/SELECT SINGLE pgmid object obj_name devclass FROM tadir\s+INTO CORRESPONDING FIELDS OF ls_app\s+WHERE pgmid = 'R3TR' AND object = 'WAPA' AND obj_name = p_bsp\./,
 `PERFORM mock_tadir USING 'WAPA' p_bsp CHANGING ls_app.`);
 discovery=discovery.replace(/SELECT SINGLE pgmid object obj_name devclass FROM tadir\s+INTO CORRESPONDING FIELDS OF ls_child\s+WHERE pgmid = 'R3TR' AND object = 'SMIM' AND obj_name = lv_id\./,
 `PERFORM mock_tadir USING 'SMIM' lv_id CHANGING ls_child.`);
 if(discovery.includes('SELECT SINGLE'))throw Error('unmocked SQL');
 code='REPORT zscope_discovery.\n'+common+`
TYPES: BEGIN OF skwf_io, objid TYPE c LENGTH 32, class TYPE c LENGTH 10, END OF skwf_io.
TYPES: BEGIN OF ty_web_ref, object TYPE tadir-object, obj_name TYPE tadir-obj_name, component TYPE string,
target_object TYPE tadir-object, target_name TYPE tadir-obj_name, scope TYPE c LENGTH 24, evidence TYPE c LENGTH 24, END OF ty_web_ref.
DATA: gt_web_refs TYPE STANDARD TABLE OF ty_web_ref, db TYPE STANDARD TABLE OF ty_object,
inventory TYPE string_table, root_url TYPE string, auth TYPE c, missing_root TYPE c, bad_root TYPE c,
api_calls TYPE i, list_calls TYPE i, queries TYPE i, warnings TYPE i.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'exception'. ENDMETHOD. ENDCLASS.
INTERFACE if_mr_api.
METHODS get_io_for_url IMPORTING i_url TYPE string EXPORTING e_loio TYPE skwf_io e_is_folder TYPE boole_d EXCEPTIONS not_found failed.
METHODS file_list IMPORTING i_url TYPE string i_recursive_call TYPE c i_check_authority TYPE c EXPORTING e_files TYPE string_table EXCEPTIONS failed.
ENDINTERFACE.
CLASS cl_mime_repository_api DEFINITION. PUBLIC SECTION.
INTERFACES if_mr_api. CLASS-METHODS get_api RETURNING VALUE(api) TYPE REF TO if_mr_api.
ENDCLASS.
CLASS cl_mime_repository_api IMPLEMENTATION.
METHOD get_api. CREATE OBJECT api TYPE cl_mime_repository_api. ENDMETHOD.
METHOD if_mr_api~get_io_for_url.
 ADD 1 TO api_calls. CLEAR: e_loio, e_is_folder.
 IF i_url = root_url.
   IF missing_root = 'X'. RAISE not_found. ENDIF.
   IF bad_root = 'X'. RAISE failed. ENDIF.
   e_is_folder = 'X'. e_loio-objid = 'ROOT'.
 ELSEIF i_url CS '/missing.js'. e_loio-objid = 'UNOWNED'.
 ELSEIF i_url CS '/image.png'. e_loio-objid = 'LOIO2'.
 ELSE. e_loio-objid = 'LOIO1'.
 ENDIF.
ENDMETHOD.
METHOD if_mr_api~file_list.
 ASSERT i_url = root_url. ASSERT i_recursive_call = 'X'. ASSERT i_check_authority = 'X'.
 ADD 1 TO list_calls. e_files = inventory.
ENDMETHOD.
ENDCLASS.
START-OF-SELECTION.
`;
 cases=0;
 const discTest=(label,s)=>{cases++;code+=`* CASE ${cases} ${label}\nPERFORM setup.\n${s}\n`;};
 discTest('only chosen WAPA plus own MIME; cross package retained',`PERFORM scope_discover_bsp.
ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.
DESCRIBE TABLE gt_packages LINES n. ASSERT n = 2. ASSERT gv_archive_name = 'ZWEB_COMMON_export.zip'.
ASSERT gv_scope_package = 'ZWEB'. LOOP AT gt_objects INTO obj.
ASSERT obj-object = 'WAPA' OR obj-object = 'SMIM'.
IF obj-object = 'WAPA'. ASSERT obj-obj_name = 'ZWEB_COMMON'. ENDIF. ENDLOOP.
READ TABLE gt_objects WITH KEY object = 'SMIM' obj_name = 'LOIO1' devclass = 'ZMEDIA' TRANSPORTING NO FIELDS.
ASSERT sy-subrc = 0. ASSERT list_calls = 1.`);
 discTest('no MIME folder still exports Layout app',`missing_root = 'X'. PERFORM scope_discover_bsp.
ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 1. ASSERT list_calls = 0.`);
 discTest('MIME root failure stops instead of empty success',`bad_root = 'X'. PERFORM scope_discover_bsp.
ASSERT gv_fatal IS NOT INITIAL.`);
 discTest('auth denied before MIME lookup',`CLEAR auth. PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.
ASSERT api_calls = 0. ASSERT gt_objects IS INITIAL.`);
 discTest('missing WAPA before MIME lookup',`DELETE db WHERE object = 'WAPA' AND obj_name = 'ZWEB_COMMON'.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL. ASSERT api_calls = 0.`);
 discTest('outside app URL cannot expand scope',`APPEND '/SAP/BC/BSP/SAP/ZWEB_WF/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.
READ TABLE gt_objects WITH KEY object = 'WAPA' obj_name = 'ZWEB_WF' TRANSPORTING NO FIELDS. ASSERT sy-subrc <> 0.`);
 discTest('prefix app cannot expand scope',`APPEND '/SAP/BC/BSP/SAP/ZWEB_COMMON2/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.`);
 discTest('duplicate paths and LOIO are exported once',`APPEND 'js/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.`);
 discTest('unregistered MIME is recorded not guessed',`APPEND 'missing.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.
DESCRIBE TABLE gt_web_refs LINES n. ASSERT n = 1. ASSERT warnings = 1.`);
 discTest('namespace app preserves canonical name and safe filename',`p_bsp = '/KBS/ZWEB'. root_url = '/SAP/BC/BSP/KBS/ZWEB'.
obj-pgmid = 'R3TR'. obj-object = 'WAPA'. obj-obj_name = p_bsp. obj-devclass = 'ZWEB'. APPEND obj TO db.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. ASSERT gv_archive_name = '~2FKBS~2FZWEB_export.zip'.`);
 code+=`
FORM setup.
 CLEAR: gv_fatal, gv_scope_package, gv_archive_name, gv_count, api_calls, list_calls, queries, warnings, missing_root, bad_root.
 REFRESH: gt_objects, gt_packages, gt_seen_pkg, gt_web_refs, db, inventory.
 p_bspm = 'X'. p_bsp = 'ZWEB_COMMON'. auth = 'X'. root_url = '/SAP/BC/BSP/SAP/ZWEB_COMMON'.
 obj-pgmid = 'R3TR'. obj-object = 'WAPA'. obj-obj_name = p_bsp. obj-devclass = 'ZWEB'. APPEND obj TO db.
 obj-obj_name = 'ZWEB_WF'. APPEND obj TO db.
 obj-object = 'FUGR'. obj-obj_name = 'FUNCTIONS'. APPEND obj TO db.
 obj-object = 'TABL'. obj-obj_name = 'ZTAB'. APPEND obj TO db.
 obj-object = 'W3MI'. obj-obj_name = 'LOGO'. APPEND obj TO db.
 obj-object = 'SMIM'. obj-obj_name = 'LOIO1'. obj-devclass = 'ZMEDIA'. APPEND obj TO db.
 obj-obj_name = 'LOIO2'. obj-devclass = 'ZWEB'. APPEND obj TO db.
 obj-obj_name = 'EXTERNAL'. APPEND obj TO db.
 APPEND 'js/main.js' TO inventory. APPEND 'image.png' TO inventory.
ENDFORM.
FORM mock_tadir USING kind TYPE c name TYPE c CHANGING row TYPE ty_object.
 ADD 1 TO queries. CLEAR row.
 ASSERT kind = 'WAPA' OR kind = 'SMIM'.
 READ TABLE db INTO row WITH KEY pgmid = 'R3TR' object = kind obj_name = name.
ENDFORM.
FORM check_auth USING kind TYPE c name TYPE c package TYPE c CHANGING allowed TYPE c.
 allowed = auth.
ENDFORM.
FORM log USING stage TYPE c state TYPE c message TYPE csequence.
 ADD 1 TO warnings.
ENDFORM.
`+rules+form('scope_add_object')+discovery;
 await run('zscope_discovery',code,cases);
 fs.writeFileSync(path.join(__dirname,'scope-result.json'),JSON.stringify({results,total_cases:results.reduce((n,r)=>n+r.cases,0),scope:'Production ABAP rules/discovery; SAP SQL, authorization and MIME I/O are doubles. No live SAP execution.'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
