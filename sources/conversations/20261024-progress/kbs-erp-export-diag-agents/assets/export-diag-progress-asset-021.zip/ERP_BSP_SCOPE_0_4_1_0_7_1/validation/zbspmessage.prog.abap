REPORT zbspmessage.
 TYPES: BEGIN OF ty_id, msgid TYPE c LENGTH 20, msgno TYPE n LENGTH 3, END OF ty_id.
 TYPES: BEGIN OF ty_message, mtype TYPE c, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY,
 object_text TYPE string, message TYPE ty_id, END OF ty_message.
 TYPES: BEGIN OF ty_short, mtype TYPE c, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY, END OF ty_short.
 TYPES: BEGIN OF ty_missing_type, mtext TYPE STANDARD TABLE OF string WITH DEFAULT KEY, END OF ty_missing_type.
 TYPES: BEGIN OF ty_missing_text, mtype TYPE c, END OF ty_missing_text.
 DATA: msg TYPE ty_message, short TYPE ty_short, no_type TYPE ty_missing_type,
 no_text TYPE ty_missing_text, severity TYPE c, text TYPE string, err TYPE string.
 START-OF-SELECTION.
 msg-mtype  =  'E'. msg-object_text  =  'PAGE'. APPEND 'Syntax error' TO msg-mtext.
 APPEND 'line 5' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'E'. ASSERT text  =  'PAGE Syntax error line 5'.
 CLEAR msg. msg-mtype  =  'W'. APPEND 'Warning' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'W'. ASSERT text  =  'Warning'.
 CLEAR msg. msg-mtype  =  'E'. msg-message-msgid  =  'BSP'. msg-message-msgno  =  '012'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'E'. ASSERT text  =  'BSP 012'.
 CLEAR msg. msg-mtype  =  'A'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'A'. ASSERT text IS NOT INITIAL.
 short-mtype  =  'S'. APPEND 'Done' TO short-mtext.
 PERFORM wa_bsp_message USING short CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'S'. ASSERT text  =  'Done'.
 PERFORM wa_bsp_message USING no_type CHANGING severity text err.
 ASSERT err IS NOT INITIAL. ASSERT severity IS INITIAL.
 no_text-mtype  =  'E'.
 PERFORM wa_bsp_message USING no_text CHANGING severity text err.
 ASSERT err IS NOT INITIAL.
 CLEAR msg. msg-mtype  =  '?'.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS NOT INITIAL. ASSERT severity IS INITIAL.
 CLEAR msg. msg-mtype  =  'X'. APPEND 'Abort' TO msg-mtext.
 PERFORM wa_bsp_message USING msg CHANGING severity text err.
 ASSERT err IS INITIAL. ASSERT severity  =  'X'. ASSERT text  =  'Abort'.
 FORM wa_bsp_message USING ps_message TYPE ANY
                   CHANGING cv_severity TYPE c cv_text TYPE string cv_error TYPE string.
  DATA: lv_line TYPE string, lv_head TYPE string, lv_id TYPE string, lv_number TYPE string.
  FIELD-SYMBOLS: <lv_value> TYPE ANY, <lt_text> TYPE ANY TABLE,
                 <lv_line> TYPE ANY, <ls_id> TYPE ANY.
  CLEAR: cv_severity, cv_text, cv_error.
  ASSIGN COMPONENT 'MTYPE' OF STRUCTURE ps_message TO <lv_value>.
  IF sy-subrc <> 0.
    cv_error  =  'BSP activation message has no severity field'. RETURN.
  ENDIF.
  lv_head  =  <lv_value>.
  IF lv_head <> 'S' AND lv_head <> 'I' AND lv_head <> 'W' AND
     lv_head <> 'E' AND lv_head <> 'A' AND lv_head <> 'X'.
    cv_error  =  'BSP activation message has an unknown severity'. RETURN.
  ENDIF.
  cv_severity  =  lv_head.
  ASSIGN COMPONENT 'MTEXT' OF STRUCTURE ps_message TO <lt_text>.
  IF sy-subrc <> 0.
    cv_error  =  'BSP activation message text table unavailable'. RETURN.
  ENDIF.
  LOOP AT <lt_text> ASSIGNING <lv_line>.
    lv_line  =  <lv_line>.
    IF cv_text IS INITIAL. cv_text  =  lv_line.
    ELSE. CONCATENATE cv_text lv_line INTO cv_text SEPARATED BY space.
    ENDIF.
  ENDLOOP.
  IF cv_text IS INITIAL.
    ASSIGN COMPONENT 'MESSAGE' OF STRUCTURE ps_message TO <ls_id>.
    IF sy-subrc  =  0.
      ASSIGN COMPONENT 'MSGID' OF STRUCTURE <ls_id> TO <lv_value>.
      IF sy-subrc  =  0. lv_id  =  <lv_value>. ENDIF.
      ASSIGN COMPONENT 'MSGNO' OF STRUCTURE <ls_id> TO <lv_value>.
      IF sy-subrc  =  0. lv_number  =  <lv_value>. ENDIF.
      CONCATENATE lv_id lv_number INTO cv_text SEPARATED BY space.
      CONDENSE cv_text.
    ENDIF.
    IF cv_text IS INITIAL. cv_text  =  'BSP activation message without text'. ENDIF.
  ENDIF.
  ASSIGN COMPONENT 'OBJECT_TEXT' OF STRUCTURE ps_message TO <lv_value>.
  IF sy-subrc  =  0 AND <lv_value> IS NOT INITIAL.
    lv_head  =  <lv_value>.
    CONCATENATE lv_head cv_text INTO cv_text SEPARATED BY space.
  ENDIF.
ENDFORM.