REPORT ztxn.
TYPES sysubrc TYPE i.
TYPES: BEGIN OF ty_file, path TYPE string, object TYPE c LENGTH 4, END OF ty_file.
TYPES: BEGIN OF wa_target, id TYPE i, file TYPE ty_file, before TYPE xstring,
 wanted TYPE xstring, eligible TYPE c, task TYPE c LENGTH 20, END OF wa_target.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'exception'. ENDMETHOD. ENDCLASS.
DATA: wa_touched TYPE c, wa_log_error TYPE string, target TYPE wa_target,
 error TYPE string, scenario TYPE c LENGTH 20, server TYPE xstring,
 cts_calls TYPE i, put_calls TYPE i, flush_calls TYPE i,
 last_state TYPE string, last_light TYPE string.
PERFORM setup USING 'success'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'SAVED_VERIFIED'. ASSERT last_light = '@08@'.
ASSERT target-eligible = ''.
ASSERT error IS INITIAL.
PERFORM setup USING 'stale'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 0. ASSERT put_calls = 0.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = 'X'.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'log_before'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 0. ASSERT put_calls = 0.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = 'X'.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'cts_fail'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 0.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'put_fail'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'mismatch'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'read_fail'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'log_after'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'LOG_FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
PERFORM setup USING 'cts_lost'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = 1. ASSERT put_calls = 1.
ASSERT last_state = 'FAILED_REVIEW'. ASSERT last_light = '@0A@'.
ASSERT target-eligible = ''.
ASSERT error IS NOT INITIAL.
WRITE 'transaction: 9 cases passed'.

FORM wa_bsp_one CHANGING t TYPE wa_target err TYPE string.
 ASSERT 1 = 0.
ENDFORM.

FORM setup USING name TYPE c.
 CLEAR: target, error, wa_touched, wa_log_error, cts_calls, put_calls, flush_calls, last_state, last_light.
 target-id = 1. target-file-path = 'asset.js'. target-before = '4100'. target-wanted = '420000'.
 target-eligible = 'X'. server = target-before. scenario = name.
 IF scenario = 'stale'. server = '43'. ENDIF.
ENDFORM.
FORM wa_read USING after TYPE c CHANGING t TYPE wa_target raw TYPE xstring err TYPE string.
 CLEAR err. raw = server.
 IF after = 'X' AND scenario = 'read_fail'. err = 'read failed'. CLEAR raw. ENDIF.
ENDFORM.
FORM wa_flush CHANGING err TYPE string.
 CLEAR err. ADD 1 TO flush_calls.
 IF scenario = 'log_before' AND flush_calls = 1. err = 'disk full'. ENDIF.
 IF scenario = 'log_after' AND flush_calls = 2. err = 'disk full'. ENDIF.
ENDFORM.
FORM wa_cts CHANGING t TYPE wa_target err TYPE string.
 CLEAR err. ADD 1 TO cts_calls.
 IF scenario = 'cts_fail'. err = 'CTS rejected'. ENDIF.
ENDFORM.
FORM wa_put USING t TYPE wa_target CHANGING err TYPE string.
 CLEAR err. ADD 1 TO put_calls. server = t-wanted.
 IF scenario = 'put_fail'. err = 'API error after internal save'. ENDIF.
 IF scenario = 'mismatch'. server = 'DEAD'. ENDIF.
ENDFORM.
FORM wa_cts_verify USING t TYPE wa_target CHANGING err TYPE string.
 CLEAR err. IF scenario = 'cts_lost'. err = 'CTS entry missing after commit'. ENDIF.
ENDFORM.
FORM wa_set_result USING id TYPE i state TYPE csequence note TYPE string light TYPE csequence size TYPE i task TYPE c.
 last_state = state. last_light = light.
ENDFORM.
FORM wa_event_add USING id TYPE i path TYPE string phase TYPE csequence state TYPE csequence detail TYPE string.
ENDFORM.
FORM wa_one CHANGING cs_target TYPE wa_target cv_error TYPE string.
  DATA: lv_raw TYPE xstring, lv_check_error TYPE string, lv_detail TYPE string,
        lv_after TYPE i, lv_attempt TYPE c, lv_rc TYPE sysubrc,
        lo_error TYPE REF TO cx_root.
  CLEAR cv_error.
  IF cs_target-file-object = 'WAPA'.
    PERFORM wa_bsp_one CHANGING cs_target cv_error. RETURN.
  ENDIF.
  TRY.
      PERFORM wa_read USING space CHANGING cs_target lv_raw cv_error.
      IF cv_error IS INITIAL AND lv_raw <> cs_target-before.
        cv_error = '저장 직전 SAP 내용이 진단 시점과 다릅니다. 덮어쓰지 않았습니다.'.
      ENDIF.
      IF cv_error IS INITIAL.
        lv_detail = 'CTS 등록 및 저장 호출 직전. 중단된 경우 실제 SAP 재진단이 필요합니다.'.
        PERFORM wa_set_result USING cs_target-id 'WRITE_INTENT' lv_detail '@09@' 0 cs_target-task.
        PERFORM wa_event_add USING cs_target-id cs_target-file-path 'BEFORE_WRITE' 'WRITE_INTENT' lv_detail.
        PERFORM wa_flush CHANGING cv_error.
      ENDIF.
      IF cv_error IS INITIAL.
        lv_attempt = 'X'. wa_touched = 'X'.
        CLEAR: sy-msgid, sy-msgno, sy-msgv1, sy-msgv2, sy-msgv3, sy-msgv4.
        PERFORM wa_cts CHANGING cs_target cv_error.
      ENDIF.
      IF cv_error IS INITIAL. PERFORM wa_put USING cs_target CHANGING cv_error. ENDIF.
      IF cv_error IS INITIAL.
        COMMIT WORK AND WAIT.
        lv_rc = sy-subrc.
        IF lv_rc <> 0. cv_error = 'COMMIT update failure: 실제 저장 상태를 재진단하십시오.'. ENDIF.
      ELSEIF lv_attempt = 'X'.
        ROLLBACK WORK.
      ENDIF.
    CATCH cx_root INTO lo_error.
      cv_error = lo_error->get_text( ).
      IF lv_attempt = 'X'. ROLLBACK WORK. ENDIF.
  ENDTRY.
  IF lv_attempt = 'X'.
* An API may commit internally. ROLLBACK is never reported as a successful
* restoration. Re-read even after errors and retain the manual restore ZIP.
    CLEAR cs_target-eligible.
    PERFORM wa_read USING 'X' CHANGING cs_target lv_raw lv_check_error.
    IF lv_check_error IS INITIAL.
      lv_after = xstrlen( lv_raw ).
      IF lv_raw <> cs_target-wanted AND cv_error IS INITIAL.
        cv_error = '저장 후 전체 바이트가 업로드 파일과 다릅니다.'.
      ENDIF.
      IF cv_error IS NOT INITIAL.
        IF lv_raw = cs_target-before. lv_detail = '현재 조회 바이트는 저장 전과 동일.'.
        ELSEIF lv_raw = cs_target-wanted. lv_detail = '현재 조회 바이트는 업로드와 동일하나 이전 API 오류가 있어 성공 판정 보류.'.
        ELSE. lv_detail = '현재 SAP는 저장 전/업로드 모두와 다릅니다. 백업 기준으로 확인 필요.'. ENDIF.
        CONCATENATE cv_error lv_detail INTO cv_error SEPARATED BY space.
      ENDIF.
    ELSE.
      CONCATENATE cv_error '반영 후 조회 실패:' lv_check_error INTO cv_error SEPARATED BY space.
    ENDIF.
    IF cv_error IS INITIAL. PERFORM wa_cts_verify USING cs_target CHANGING cv_error. ENDIF.
  ENDIF.
  IF cv_error IS INITIAL AND lv_attempt = 'X'.
    lv_detail = 'MIME 저장·재조회 바이트 일치. 별도 활성화 없음. HTTP/캐시/화면 실행은 미검증.'.
    PERFORM wa_set_result USING cs_target-id 'SAVED_VERIFIED' lv_detail '@08@' lv_after cs_target-task.
    PERFORM wa_event_add USING cs_target-id cs_target-file-path 'READ_BACK' 'SAVED_VERIFIED' lv_detail.
  ELSE.
    PERFORM wa_set_result USING cs_target-id 'FAILED_REVIEW' cv_error '@0A@' lv_after cs_target-task.
    PERFORM wa_event_add USING cs_target-id cs_target-file-path 'APPLY' 'FAILED_REVIEW' cv_error.
  ENDIF.
  PERFORM wa_flush CHANGING lv_check_error.
  IF lv_check_error IS NOT INITIAL.
    wa_log_error = lv_check_error.
    CONCATENATE cv_error '실행 로그 저장 실패:' lv_check_error INTO cv_error SEPARATED BY space.
    PERFORM wa_set_result USING cs_target-id 'LOG_FAILED_REVIEW' cv_error '@0A@' lv_after cs_target-task.
  ENDIF.
ENDFORM.