REPORT zbspgate. DATA: a TYPE string, b TYPE string, c TYPE string,
 ready TYPE c, state TYPE c LENGTH 24, note TYPE c LENGTH 255.
a = 'old'. b = 'new'. c = 'old'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  'X'. ASSERT state  =  'BLOCKED'.
a = 'old'. b = 'new'. c = 'new'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'ALREADY_EQUAL'.
a = 'old'. b = 'old'. c = 'server'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'UPLOAD_UNCHANGED'.
a = 'old'. b = 'new'. c = 'server'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'CONFLICT'.
a = 'old'. b = 'new'. c = 'old'.
 PERFORM wa_bsp_gate USING '' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'BLOCKED'.
a = 'old'. b = 'new'. c = 'old'.
 PERFORM wa_bsp_gate USING 'X' '' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'BLOCKED'.
a = 'old'. b = 'new'. c = 'old'.
 PERFORM wa_bsp_gate USING 'X' 'X' '' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'BLOCKED'.
a = 'forward'. b = 'original'. c = 'forward'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  'X'. ASSERT state  =  'BLOCKED'.
a = 'forward'. b = 'original'. c = 'original'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'ALREADY_EQUAL'.
a = 'forward'. b = 'original'. c = 'later'.
 PERFORM wa_bsp_gate USING 'X' 'X' 'X' a b c CHANGING ready state note.
 ASSERT ready  =  ''. ASSERT state  =  'CONFLICT'.
FORM wa_bsp_gate USING pv_ao TYPE c pv_bo TYPE c pv_co TYPE c
                      pv_a TYPE string pv_b TYPE string pv_c TYPE string
                CHANGING cv_ready TYPE c cv_state TYPE c cv_note TYPE c.
  CLEAR cv_ready. cv_state  =  'BLOCKED'.
  IF pv_ao <> 'X' OR pv_bo <> 'X' OR pv_co <> 'X'.
    cv_note  =  '원본·수정본·SAP 활성 Layout을 모두 읽어야 합니다.'.
  ELSEIF pv_b  =  pv_c.
    cv_state  =  'ALREADY_EQUAL'. cv_note  =  'SAP 활성 Layout과 동일: 저장 불필요.'.
  ELSEIF pv_a  =  pv_b.
    cv_state  =  'UPLOAD_UNCHANGED'. cv_note  =  '업로드 Layout은 원본과 동일: SAP 변경을 되돌리지 않습니다.'.
  ELSEIF pv_a <> pv_c.
    cv_state  =  'CONFLICT'. cv_note  =  'Export 이후 SAP Layout도 변경되었습니다. 재추출 후 병합하십시오.'.
  ELSE.
* Remaining metadata/API/inactive/companion guards must still pass.
    cv_ready  =  'X'. cv_note  =  'BSP 저장 후보의 매핑과 미활성 상태를 점검합니다.'.
  ENDIF.
ENDFORM.