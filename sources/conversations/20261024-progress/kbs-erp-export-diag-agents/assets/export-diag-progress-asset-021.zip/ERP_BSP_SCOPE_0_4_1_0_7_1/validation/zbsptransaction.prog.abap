REPORT zbsptransaction.
 TYPES: BEGIN OF ty_file, path TYPE string, devclass TYPE c LENGTH 30, END OF ty_file.
 TYPES: BEGIN OF ty_asset, language TYPE c, END OF ty_asset.
 TYPES: BEGIN OF wa_target, id TYPE i, file TYPE ty_file, asset TYPE ty_asset,
 before TYPE xstring, wanted TYPE xstring, eligible TYPE c, task TYPE c LENGTH 20,
 bsp_guard TYPE xstring, bsp_key TYPE c LENGTH 30, bsp_phase TYPE c LENGTH 24,
 bsp_save TYPE c LENGTH 24, bsp_activate TYPE c LENGTH 24, bsp_resume TYPE c, END OF wa_target.
 TYPES: BEGIN OF wa_bsp_snapshot, layout TYPE xstring, guard TYPE xstring,
 inactive TYPE STANDARD TABLE OF string WITH DEFAULT KEY, app_inactive TYPE c, END OF wa_bsp_snapshot.
 CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
 CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'exception'. ENDMETHOD. ENDCLASS.
 DATA: p_task TYPE c LENGTH 20, wa_touched TYPE c, wa_log_error TYPE string, t TYPE wa_target, err TYPE string,
 scenario TYPE string, active TYPE xstring, pending TYPE xstring, guard TYPE xstring,
 cts_calls TYPE i, save_calls TYPE i, activate_calls TYPE i, flush_calls TYPE i,
 last_state TYPE string, last_light TYPE string, observed TYPE i, reads TYPE i,
 phase_save TYPE string, phase_activate TYPE string.
PERFORM setup USING 'success'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATED_VERIFIED'. ASSERT err IS INITIAL.
 ASSERT phase_save = 'VERIFIED'. ASSERT phase_activate = 'VERIFIED'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'resume_success'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATED_VERIFIED'. ASSERT err IS INITIAL.
 ASSERT phase_save = 'REUSED_VERIFIED'. ASSERT phase_activate = 'VERIFIED'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'resume_cts'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'resume_changed'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'resume_saved_check'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'SAVED_NOT_ACTIVATED'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'REUSED_INACTIVE'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'resume_common'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'SAVED_NOT_ACTIVATED'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'REUSED_INACTIVE'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'resume_activation'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'REUSED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'resume_post_read'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'REUSED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'resume_cts_lost'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'REUSED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'context'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = 'X'.
 
PERFORM setup USING 'stale'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = 'X'.
 
PERFORM setup USING 'inactive'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = 'X'.
 
PERFORM setup USING 'log_before'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 0. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'NOT_RUN'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = 'X'.
 
PERFORM setup USING 'cts'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 0. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'FAILED_REVIEW'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'save'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'FAILED_REVIEW'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'saved_check'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 0.
 ASSERT last_state = 'FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'FAILED_REVIEW'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'common_definition'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 0.
 ASSERT last_state = 'SAVED_NOT_ACTIVATED'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'activation_guard'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 0.
 ASSERT last_state = 'SAVED_NOT_ACTIVATED'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'log_between'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 0.
 ASSERT last_state = 'SAVED_NOT_ACTIVATED'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'NOT_RUN'.
 ASSERT t-eligible = ''.
 ASSERT err CS '활성화는 실행하지 않았습니다.'. ASSERT err NS 'ACTIVE_CHECK'.
PERFORM setup USING 'activate'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'activate_partial'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'mismatch'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'other_tab'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'inactive_after'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'post_read'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'cts_lost'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'ACTIVATION_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'SAVED_INACTIVE'. ASSERT phase_activate = 'FAILED_REVIEW'.
 ASSERT t-eligible = ''.
 
PERFORM setup USING 'log_after'.
 PERFORM wa_bsp_one CHANGING t err.
 ASSERT cts_calls = 1. ASSERT save_calls = 1. ASSERT activate_calls = 1.
 ASSERT last_state = 'LOG_FAILED_REVIEW'. ASSERT err IS NOT INITIAL.
 ASSERT phase_save = 'VERIFIED'. ASSERT phase_activate = 'VERIFIED'.
 ASSERT t-eligible = ''.
 

 FORM setup USING name TYPE c.
 CLEAR: t,err,wa_touched,wa_log_error,pending,cts_calls,save_calls,activate_calls,
 flush_calls,last_state,last_light,observed,reads,phase_save,phase_activate.
 t-id = 1. t-file-path = 'page.htm'. t-before = '41'. t-wanted = '42'. t-bsp_guard = '99'.
 t-bsp_save = 'NOT_RUN'. t-bsp_activate = 'NOT_RUN'. t-eligible = 'X'.
 active = t-before. guard = t-bsp_guard. scenario = name.
 t-file-devclass = 'ZTEST'. p_task = 'OWN_TASK'.
 IF scenario CP 'resume_*'. t-bsp_resume = 'X'. pending = t-wanted. ENDIF.
 IF scenario = 'stale'. active = '43'. ENDIF.
 ENDFORM.
 FORM wa_bsp_context USING target TYPE wa_target CHANGING error TYPE string.
 CLEAR error. IF scenario = 'context'. error = 'context rejected'. ENDIF. ENDFORM.
 FORM wa_bsp_read USING after TYPE c CHANGING target TYPE wa_target raw TYPE xstring error TYPE string.
 CLEAR error. raw = active. IF scenario = 'inactive'. error = 'existing inactive'. ENDIF. ENDFORM.
 FORM wa_bsp_cts CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. ADD 1 TO cts_calls. IF scenario = 'cts'. error = 'CTS failed'. ENDIF. ENDFORM.
 FORM wa_bsp_save CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. ADD 1 TO save_calls. target-bsp_save = 'SAVE_RETURNED'. pending = target-wanted.
 IF scenario = 'save'. error = 'save failed after possible internal commit'. ENDIF. ENDFORM.
 FORM wa_bsp_saved_check CHANGING target TYPE wa_target error TYPE string.
 CLEAR error. IF scenario = 'saved_check' OR scenario = 'resume_saved_check'. error = 'inactive differs'. RETURN. ENDIF.
 target-bsp_save = 'SAVED_INACTIVE'.
 IF target-bsp_resume = 'X'. target-bsp_save = 'REUSED_INACTIVE'. ENDIF.
 IF scenario = 'common_definition' OR scenario = 'resume_common'. error = 'shared WAPD warning'. ENDIF. ENDFORM.
 FORM wa_bsp_activate CHANGING target TYPE wa_target error TYPE string.
 CLEAR error.
 IF scenario = 'activation_guard'. error = 'activation recheck rejected'. RETURN. ENDIF.
 ADD 1 TO activate_calls. target-bsp_activate = 'ACTIVATE_ATTEMPT'.
 IF scenario = 'activate' OR scenario = 'resume_activation'. error = 'syntax error'. RETURN. ENDIF.
 active = pending. CLEAR pending.
 IF scenario = 'activate_partial'. error = 'activation error after commit'. RETURN. ENDIF.
 IF scenario = 'mismatch'. active = '43'. ENDIF.
 IF scenario = 'other_tab'. guard = '98'. ENDIF.
 IF scenario = 'inactive_after'. pending = '42'. ENDIF.
 target-bsp_activate = 'ACTIVATE_RETURNED'. ENDFORM.
 FORM wa_bsp_fetch USING key TYPE c lang TYPE c CHANGING snap TYPE wa_bsp_snapshot error TYPE string.
 CLEAR: snap,error. ADD 1 TO reads. snap-layout = active. snap-guard = guard.
 IF pending IS NOT INITIAL. APPEND 'page.htm' TO snap-inactive. ENDIF.
 IF scenario = 'post_read' OR scenario = 'resume_post_read'. error = 'fresh read failed'. ENDIF. ENDFORM.
 FORM wa_bsp_guard USING snap TYPE wa_bsp_snapshot CHANGING raw TYPE xstring.
 raw = snap-guard. ENDFORM.
 FORM wa_bsp_equal USING a TYPE xstring b TYPE xstring CHANGING eq TYPE c error TYPE string.
 CLEAR: eq,error. IF a = b. eq = 'X'. ENDIF. ENDFORM.
 FORM wa_bsp_check_layout USING target TYPE wa_target snap TYPE wa_bsp_snapshot phase TYPE csequence
 CHANGING eq TYPE c error TYPE string.
 ASSERT target-bsp_activate <> 'NOT_RUN'.
 PERFORM wa_bsp_equal USING snap-layout target-wanted CHANGING eq error.
 IF eq <> 'X'. error = 'ACTIVE_CHECK Layout mismatch'. ENDIF. ENDFORM.
 FORM wa_bsp_cts_verify USING target TYPE wa_target CHANGING error TYPE string.
 CLEAR error.
 IF target-bsp_resume = 'X'. ASSERT target-task = p_task. ENDIF.
 IF scenario = 'cts_lost' OR scenario = 'resume_cts' OR ( scenario = 'resume_cts_lost' AND activate_calls > 0 ). error = 'CTS missing'. ENDIF. ENDFORM.
 FORM wa_bsp_resume_check USING target TYPE wa_target CHANGING detail TYPE string error TYPE string.
 ASSERT target-bsp_resume = 'X'. CLEAR error. detail = 'verified I same as upload'.
 IF scenario = 'resume_changed'. error = 'I changed'. ENDIF. ENDFORM.
 FORM wa_bsp_verify_record USING target TYPE wa_target phase TYPE csequence state TYPE csequence detail TYPE string.
 ASSERT phase = 'REUSE_INACTIVE'. ASSERT state = 'VERIFIED'. ASSERT save_calls = 0. ASSERT cts_calls = 0.
 ENDFORM.
 FORM wa_bsp_observed USING target TYPE wa_target snap TYPE wa_bsp_snapshot.
 ADD 1 TO observed. ENDFORM.
 FORM wa_bsp_pending_note USING key TYPE c snap TYPE wa_bsp_snapshot
 CHANGING state TYPE c note TYPE string.
 state = 'NONE'. CLEAR note.
 IF snap-inactive IS NOT INITIAL OR snap-app_inactive = 'X'.
 state = 'PAGE_REVIEW'. note = 'selected page pending'. ENDIF. ENDFORM.
 FORM wa_bsp_status USING target TYPE wa_target.
 phase_save = target-bsp_save. phase_activate = target-bsp_activate. ENDFORM.
 FORM wa_flush CHANGING error TYPE string.
 CLEAR error. ADD 1 TO flush_calls.
 IF ( scenario = 'log_before' AND flush_calls = 1 ) OR
    ( scenario = 'log_between' AND flush_calls = 2 ) OR
    ( scenario = 'log_after' AND flush_calls = 3 ). error = 'disk error'. ENDIF. ENDFORM.
 FORM wa_set_result USING id TYPE i state TYPE csequence note TYPE string light TYPE csequence size TYPE i task TYPE c.
 last_state = state. last_light = light. ENDFORM.
 FORM wa_event_add USING id TYPE i path TYPE string phase TYPE csequence state TYPE csequence detail TYPE string.
 ENDFORM.
 FORM wa_bsp_one CHANGING cs_target TYPE wa_target cv_error TYPE string.
  DATA: lv_raw TYPE xstring, lv_error TYPE string, lv_detail TYPE string,
        lv_attempt TYPE c, lv_equal TYPE c, lv_after TYPE i, lv_state TYPE c LENGTH 24,
        ls_now TYPE wa_bsp_snapshot, lo_error TYPE REF TO cx_root,
        lv_pending TYPE c LENGTH 16.
  CLEAR cv_error.
  TRY.
      PERFORM wa_bsp_context USING cs_target CHANGING cv_error.
      IF cv_error IS INITIAL. PERFORM wa_bsp_read USING space CHANGING cs_target lv_raw cv_error. ENDIF.
      IF cv_error IS INITIAL AND lv_raw <> cs_target-before.
        cv_error  =  '저장 직전 BSP 활성 소스가 진단 시점과 다릅니다.'.
      ENDIF.
      IF cv_error IS INITIAL.
        cs_target-bsp_phase  =  'BEFORE_SAVE'.
        lv_detail  =  'BSP Layout 저장 전: 백업 완료, 다른 탭 보존, 단일 페이지 활성화 예정.'.
        IF cs_target-bsp_resume  =  'X'.
          cs_target-bsp_phase  =  'BEFORE_RESUME'.
          lv_detail  =  'BSP 활성화 재개 전: 기존 I=업로드 검증, SET_PAGE/SAVE 생략, 기존 CTS 등록 확인 예정.'.
        ENDIF.
        PERFORM wa_set_result USING cs_target-id 'WRITE_INTENT' lv_detail '@09@' 0 cs_target-task.
        PERFORM wa_event_add USING cs_target-id cs_target-file-path cs_target-bsp_phase 'WRITE_INTENT' lv_detail.
        PERFORM wa_flush CHANGING cv_error.
      ENDIF.
      IF cv_error IS INITIAL.
        lv_attempt  =  'X'. wa_touched  =  'X'.
        IF cs_target-bsp_resume  =  'X'.
* Existing inactive content must already belong to the supplied task. Do not
* insert/move it into a different CTS task merely to make resume possible.
          IF cs_target-file-devclass <> '$TMP'. cs_target-task  =  p_task. ENDIF.
          PERFORM wa_bsp_cts_verify USING cs_target CHANGING cv_error.
          IF cv_error IS INITIAL.
            PERFORM wa_bsp_resume_check USING cs_target CHANGING lv_detail cv_error.
          ENDIF.
          IF cv_error IS INITIAL.
            cs_target-bsp_save  =  'REUSED_INACTIVE'.
            PERFORM wa_bsp_verify_record USING cs_target 'REUSE_INACTIVE' 'VERIFIED' lv_detail.
          ENDIF.
        ELSE.
          PERFORM wa_bsp_cts CHANGING cs_target cv_error.
          IF cv_error IS INITIAL. PERFORM wa_bsp_save CHANGING cs_target cv_error. ENDIF.
          IF cv_error IS INITIAL.
            COMMIT WORK AND WAIT.
            IF sy-subrc <> 0. cv_error  =  'BSP SAVE commit failed'. ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
      IF cv_error IS INITIAL. PERFORM wa_bsp_saved_check CHANGING cs_target cv_error. ENDIF.
      IF cv_error IS INITIAL.
        cs_target-bsp_phase  =  'BEFORE_ACTIVATE'.
        PERFORM wa_bsp_status USING cs_target.
        lv_detail  =  '미활성 Layout 저장·재조회 확인. 다른 탭 동일. 해당 WAPP 한 페이지 활성화 직전.'.
        IF cs_target-bsp_resume  =  'X'.
          lv_detail  =  '기존 미활성 Layout 재사용·CTS·다른 탭 검증 완료. 저장 생략. 해당 WAPP 한 페이지 활성화 직전.'.
        ENDIF.
        PERFORM wa_set_result USING cs_target-id cs_target-bsp_save lv_detail '@09@' 0 cs_target-task.
        PERFORM wa_event_add USING cs_target-id cs_target-file-path 'BEFORE_ACTIVATE' cs_target-bsp_save lv_detail.
        PERFORM wa_flush CHANGING cv_error.
      ENDIF.
      IF cv_error IS INITIAL. PERFORM wa_bsp_activate CHANGING cs_target cv_error. ENDIF.
      IF cv_error IS INITIAL.
        COMMIT WORK AND WAIT.
        IF sy-subrc <> 0. cv_error  =  'BSP activation commit failed'. ENDIF.
      ENDIF.
      IF cv_error IS NOT INITIAL AND lv_attempt  =  'X'. ROLLBACK WORK. ENDIF.
    CATCH cx_root INTO lo_error.
      cv_error  =  lo_error->get_text( ).
      IF lv_attempt  =  'X'. ROLLBACK WORK. ENDIF.
  ENDTRY.
* Do not mask an earlier error with a later equal read. SAVE/activation can
* commit internally; report observed state and retain the recovery package.
  IF lv_attempt  =  'X'.
    CLEAR cs_target-eligible.
    TRY.
        PERFORM wa_bsp_fetch USING cs_target-bsp_key cs_target-asset-language CHANGING ls_now lv_error.
        IF lv_error IS INITIAL.
          lv_after  =  xstrlen( ls_now-layout ).
          PERFORM wa_bsp_guard USING ls_now CHANGING lv_raw.
          IF lv_raw <> cs_target-bsp_guard. lv_error  =  '반영 후 다른 BSP 탭/애플리케이션 속성 불일치'. ENDIF.
          IF lv_error IS INITIAL AND cs_target-bsp_activate <> 'NOT_RUN'.
            PERFORM wa_bsp_check_layout USING cs_target ls_now 'ACTIVE_CHECK'
              CHANGING lv_equal lv_error.
          ENDIF.
* If activation was skipped, the unchanged active page is expected, not a second failure.
          IF lv_error IS INITIAL AND cs_target-bsp_activate <> 'NOT_RUN'.
            PERFORM wa_bsp_pending_note USING cs_target-bsp_key ls_now CHANGING lv_pending lv_error.
          ENDIF.
          IF cv_error IS NOT INITIAL OR lv_error IS NOT INITIAL.
            PERFORM wa_bsp_observed USING cs_target ls_now.
          ENDIF.
        ENDIF.
        IF lv_error IS NOT INITIAL.
          CONCATENATE cv_error lv_error INTO cv_error SEPARATED BY space.
        ENDIF.
        IF cv_error IS INITIAL. PERFORM wa_bsp_cts_verify USING cs_target CHANGING cv_error. ENDIF.
      CATCH cx_root INTO lo_error.
        lv_error  =  lo_error->get_text( ).
        CONCATENATE cv_error 'BSP 재조회 실패:' lv_error INTO cv_error SEPARATED BY space.
    ENDTRY.
  ENDIF.
  IF cv_error IS INITIAL AND lv_attempt  =  'X'.
    cs_target-bsp_save  =  'VERIFIED'. cs_target-bsp_activate  =  'VERIFIED'.
    lv_state  =  'ACTIVATED_VERIFIED'.
    lv_detail  =  'BSP Layout 저장·페이지 활성화·활성 소스/다른 탭 보존 검증 완료. 실제 화면 실행은 별도 확인.'.
    IF cs_target-bsp_resume  =  'X'.
      cs_target-bsp_save  =  'REUSED_VERIFIED'.
      lv_detail  =  '기존 미활성 Layout 재사용·해당 페이지 활성화·활성 소스/다른 탭 보존 검증 완료. 이번 실행의 저장은 생략.'.
    ENDIF.
    PERFORM wa_set_result USING cs_target-id lv_state lv_detail '@08@' lv_after cs_target-task.
  ELSE.
    lv_state  =  'FAILED_REVIEW'.
    IF lv_attempt  =  'X' AND cs_target-bsp_activate  =  'NOT_RUN'.
      CONCATENATE cv_error '활성화는 실행하지 않았습니다.' INTO cv_error SEPARATED BY space.
    ENDIF.
    IF cs_target-bsp_save  =  'SAVED_INACTIVE' OR cs_target-bsp_save  =  'REUSED_INACTIVE'.
      IF cs_target-bsp_activate  =  'NOT_RUN'. lv_state  =  'SAVED_NOT_ACTIVATED'.
      ELSE. lv_state  =  'ACTIVATION_REVIEW'. cs_target-bsp_activate  =  'FAILED_REVIEW'.
      ENDIF.
    ELSEIF lv_attempt  =  'X' AND cs_target-bsp_resume IS INITIAL. cs_target-bsp_save  =  'FAILED_REVIEW'.
    ENDIF.
    lv_detail  =  cv_error.
    PERFORM wa_set_result USING cs_target-id lv_state lv_detail '@0A@' lv_after cs_target-task.
  ENDIF.
  PERFORM wa_bsp_status USING cs_target.
  PERFORM wa_event_add USING cs_target-id cs_target-file-path 'BSP_RESULT' lv_state lv_detail.
  PERFORM wa_flush CHANGING lv_error.
  IF lv_error IS NOT INITIAL.
    wa_log_error  =  lv_error.
    CONCATENATE cv_error '실행 로그 저장 실패:' lv_error INTO cv_error SEPARATED BY space.
    PERFORM wa_set_result USING cs_target-id 'LOG_FAILED_REVIEW' cv_error '@0A@' lv_after cs_target-task.
  ENDIF.
ENDFORM.