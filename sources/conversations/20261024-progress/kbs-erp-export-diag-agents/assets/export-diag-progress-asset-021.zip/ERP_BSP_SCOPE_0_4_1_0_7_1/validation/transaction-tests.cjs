const fs=require('fs'),path=require('path');
const {Transpiler}=require('@abaplint/transpiler');
const {ABAP}=require('@abaplint/runtime');
const source=fs.readFileSync((process.argv[2] || path.resolve(__dirname,'../Z_PACKAGE_DIAG_0_7_1.abap')),'utf8');
const one=source.match(/^FORM wa_one[\s\S]*?^ENDFORM\./m)[0];
// Production orchestration, only external SAP/frontend calls are test doubles.
const declarations=`REPORT ztxn.
TYPES sysubrc TYPE i.
TYPES: BEGIN OF ty_file, path TYPE string, object TYPE c LENGTH 4, END OF ty_file.
TYPES: BEGIN OF wa_target, id TYPE i, file TYPE ty_file, before TYPE xstring,
 wanted TYPE xstring, eligible TYPE c, task TYPE c LENGTH 20, END OF wa_target.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'exception'. ENDMETHOD. ENDCLASS.
DATA: wa_touched TYPE c, wa_log_error TYPE string, target TYPE wa_target,
 error TYPE string, scenario TYPE c LENGTH 20, server TYPE xstring,
 cts_calls TYPE i, put_calls TYPE i, flush_calls TYPE i,
 last_state TYPE string, last_light TYPE string.
`;
const stubs=`
FORM wa_bsp_one CHANGING t TYPE wa_target err TYPE string.
 ASSERT 1 = 0.
ENDFORM.

FORM setup USING name TYPE c.
 CLEAR: target, error, wa_touched, wa_log_error, cts_calls, put_calls, flush_calls, last_state, last_light.
 target-id = 1. target-file-path = 'asset.js'. target-before = '4100'. target-wanted = '420000'.
 target-eligible = 'X'. server = target-before. scenario = name.
 IF scenario = 'stale'. server = '43'. ENDIF.
ENDFORM.
FORM wa_read USING after TYPE c CHANGING t TYPE wa_target raw TYPE xstring err TYPE string.
 CLEAR err. raw = server.
 IF after = 'X' AND scenario = 'read_fail'. err = 'read failed'. CLEAR raw. ENDIF.
ENDFORM.
FORM wa_flush CHANGING err TYPE string.
 CLEAR err. ADD 1 TO flush_calls.
 IF scenario = 'log_before' AND flush_calls = 1. err = 'disk full'. ENDIF.
 IF scenario = 'log_after' AND flush_calls = 2. err = 'disk full'. ENDIF.
ENDFORM.
FORM wa_cts CHANGING t TYPE wa_target err TYPE string.
 CLEAR err. ADD 1 TO cts_calls.
 IF scenario = 'cts_fail'. err = 'CTS rejected'. ENDIF.
ENDFORM.
FORM wa_put USING t TYPE wa_target CHANGING err TYPE string.
 CLEAR err. ADD 1 TO put_calls. server = t-wanted.
 IF scenario = 'put_fail'. err = 'API error after internal save'. ENDIF.
 IF scenario = 'mismatch'. server = 'DEAD'. ENDIF.
ENDFORM.
FORM wa_cts_verify USING t TYPE wa_target CHANGING err TYPE string.
 CLEAR err. IF scenario = 'cts_lost'. err = 'CTS entry missing after commit'. ENDIF.
ENDFORM.
FORM wa_set_result USING id TYPE i state TYPE csequence note TYPE string light TYPE csequence size TYPE i task TYPE c.
 last_state = state. last_light = light.
ENDFORM.
FORM wa_event_add USING id TYPE i path TYPE string phase TYPE csequence state TYPE csequence detail TYPE string.
ENDFORM.
`;
const cases=[
 {name:'success',cts:1,put:1,state:'SAVED_VERIFIED',light:'@08@',err:false,eligible:''},
 {name:'stale',cts:0,put:0,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:'X'},
 {name:'log_before',cts:0,put:0,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:'X'},
 {name:'cts_fail',cts:1,put:0,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
 {name:'put_fail',cts:1,put:1,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
 {name:'mismatch',cts:1,put:1,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
 {name:'read_fail',cts:1,put:1,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
 {name:'log_after',cts:1,put:1,state:'LOG_FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
 {name:'cts_lost',cts:1,put:1,state:'FAILED_REVIEW',light:'@0A@',err:true,eligible:''},
];
(async()=>{
let code=declarations;
for(const c of cases) code+=`PERFORM setup USING '${c.name}'.
PERFORM wa_one CHANGING target error.
ASSERT cts_calls = ${c.cts}. ASSERT put_calls = ${c.put}.
ASSERT last_state = '${c.state}'. ASSERT last_light = '${c.light}'.
ASSERT target-eligible = '${c.eligible}'.
ASSERT error IS ${c.err?'NOT ':''}INITIAL.
`;
code+=`WRITE 'transaction: ${cases.length} cases passed'.\n`+stubs+one;
fs.writeFileSync(path.join(__dirname,'transaction-test.prog.abap'),code);
const out=await new Transpiler({addCommonJS:false,unknownTypes:'compileError'}).runRaw([{filename:'ztxn.prog.abap',contents:code}]);
global.abap=new ABAP();
let commits=0,rollbacks=0;
global.abap.context.databaseConnections['DEFAULT']={commit:async()=>{commits++},rollback:async()=>{rollbacks++}};
let js=out.objects.map(o=>o.chunk.getCode()).join('\n');
fs.writeFileSync(path.join(__dirname,'transaction-test.js'),js);
await new (Object.getPrototypeOf(async function(){}).constructor)('abap',js)(global.abap);
if(commits!==5||rollbacks!==2)throw Error(`commit/rollback ${commits}/${rollbacks}`);
console.log(JSON.stringify({test:'production wa_one FORM with fault-injected SAP/frontend doubles',cases:cases.length,assertions:cases.length*6+2,commits,rollbacks,result:'PASS',scope:'control flow only, no SAP API execution'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
