const fs=require('fs'),path=require('path');
const {Transpiler}=require('@abaplint/transpiler');
const {ABAP}=require('@abaplint/runtime');
const source=fs.readFileSync((process.argv[2] || path.resolve(__dirname,'../Z_PACKAGE_DIAG_0_7_1.abap')),'utf8');
function form(n){return source.match(new RegExp('^FORM '+n+'[\\s\\S]*?^ENDFORM\\.','m'))[0];}
let code=`REPORT zcontent.
TYPES: BEGIN OF im_result, path TYPE c LENGTH 255, component TYPE c LENGTH 80,
 pair_ab TYPE c LENGTH 12, pair_ac TYPE c LENGTH 12, pair_cb TYPE c LENGTH 12, END OF im_result.
DATA: p_diff TYPE c, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
 row TYPE im_result, match TYPE c, raw TYPE xstring, ok TYPE c,
 bytes TYPE STANDARD TABLE OF x255, byte TYPE x255.
`;
// Define the test fixture row type without replacing the production binary reader.
code=code.replace('DATA: p_diff','TYPES x255 TYPE x LENGTH 255.\nDATA: p_diff');
const cases=[
 ['web','p/x.js','MIME_CONTENT','X'],
 ['abap','p/x.js','MIME_CONTENT',''],
 ['abap','p/x.abap','SOURCE','X'],
 ['web','p/x.abap','SOURCE',''],
 ['web','p/page.htm','BSP_LAYOUT','X'],
 ['xml','p/xml.xml','MIME_CONTENT',''],
 ['web','p/xml.xml','MIME_CONTENT','X'],
 ['xml','p/metadata.xml','MIME_METADATA','X'],
 ['web','p/metadata.xml','MIME_METADATA',''],
 ['web','p/new.js','','X'],
 ['web','packages/Z/mime/new.png','','X'],
 ['web','MIMEs/font.woff2','','X'],
 ['web','catalog/mime-metadata.xml','MIME_METADATA',''],
 ['web','pages/index/Layout/index.htm','BSP_LAYOUT','X'],
 ['all','p/a.xml','DDIC_DEFINITION','X'],
];
for(const [mode,file,component,result] of cases){
code+=`CLEAR: p_all, p_src, p_xml, p_mime, row.
${{web:'p_mime',abap:'p_src',xml:'p_xml',all:'p_all'}[mode]} = 'X'.
row-path = '${file}'. row-component = '${component}'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = '${result}'.\n`;
}
code+=`p_diff = 'X'. p_all = 'X'. CLEAR row.
row-pair_ab = '변경없음'. row-pair_ac = '수정'. row-pair_cb = '수정'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
row-pair_ac = '변경없음'. row-pair_cb = '변경없음'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match IS INITIAL.
REFRESH bytes. byte = '410000'. APPEND byte TO bytes.
PERFORM web_binary USING bytes 3 CHANGING raw ok. ASSERT ok = 'X'. ASSERT raw = '410000'.
PERFORM web_binary USING bytes 256 CHANGING raw ok. ASSERT ok IS INITIAL.
APPEND byte TO bytes.
PERFORM web_binary USING bytes 3 CHANGING raw ok. ASSERT ok IS INITIAL.
REFRESH bytes.
PERFORM web_binary USING bytes 0 CHANGING raw ok. ASSERT ok = 'X'. ASSERT raw IS INITIAL.
WRITE 'filter/binary: 21 cases passed'.
`+form('wa_is_web')+form('im_filter_match')+form('web_binary');
(async()=>{
fs.writeFileSync(path.join(__dirname,'content-filter-test.prog.abap'),code);
const out=await new Transpiler({addCommonJS:false,unknownTypes:'compileError'}).runRaw([{filename:'zcontent.prog.abap',contents:code}]);
global.abap=new ABAP();const js=out.objects[0].chunk.getCode();
fs.writeFileSync(path.join(__dirname,'content-filter-test.js'),js);
await new (Object.getPrototypeOf(async function(){}).constructor)('abap',js)(global.abap);
console.log(JSON.stringify({test:'production web classification, display filter and binary reader',cases:21,assertions:23,result:'PASS'},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
