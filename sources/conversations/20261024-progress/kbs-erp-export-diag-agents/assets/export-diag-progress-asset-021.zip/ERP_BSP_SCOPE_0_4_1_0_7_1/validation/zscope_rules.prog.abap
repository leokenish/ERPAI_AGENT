REPORT zscope_rules.

TYPES: o2applname TYPE c LENGTH 30, boole_d TYPE c, string_table TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, pgmid TYPE c LENGTH 4, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF tdevc, devclass TYPE c LENGTH 30, END OF tdevc.
TYPES: BEGIN OF ty_object, pgmid TYPE tadir-pgmid, object TYPE tadir-object, obj_name TYPE tadir-obj_name,
devclass TYPE tadir-devclass, status TYPE c LENGTH 20, reason TYPE string, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
TYPES ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
DATA: p_bspm TYPE c, p_pkgm TYPE c, p_sub TYPE c, p_bsp TYPE o2applname, p_pack TYPE tadir-devclass, p_file TYPE c LENGTH 255,
p_mb TYPE i, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
gv_scope_kind TYPE c LENGTH 12, gv_scope_package TYPE tadir-devclass, gv_bsp_flat TYPE c,
gv_fatal TYPE string, gv_archive_name TYPE string, gv_stage TYPE c LENGTH 30, gv_count TYPE i,
gt_packages TYPE ty_packages, gt_seen_pkg TYPE SORTED TABLE OF ty_package WITH UNIQUE KEY devclass,
gt_objects TYPE STANDARD TABLE OF ty_object WITH DEFAULT KEY, gs_object TYPE ty_object,
err TYPE string, url TYPE string, ok TYPE c, n TYPE i, obj TYPE ty_object, pkg TYPE ty_package.
TYPES: BEGIN OF ty_file,
         path TYPE string,
         baseline TYPE string,
         devclass TYPE tadir-devclass,
         object TYPE tadir-object,
         obj_name TYPE tadir-obj_name,
         component TYPE string,
         language TYPE sy-langu,
         active_state TYPE c LENGTH 1,
         byte_length TYPE i,
         checksum_algorithm TYPE c LENGTH 20,
         checksum TYPE i,
         capability TYPE c LENGTH 20,
         check_mode TYPE c LENGTH 12,
       END OF ty_file.TYPES: BEGIN OF ty_header, format TYPE c LENGTH 30, version TYPE c LENGTH 10,
tool_version TYPE c LENGTH 10, scope_kind TYPE c LENGTH 12, bsp_application TYPE o2applname,
bsp_package TYPE tadir-devclass, path_layout TYPE c LENGTH 20, END OF ty_header.
TYPES: BEGIN OF ty_asset, original_path TYPE string, END OF ty_asset.
TYPES: BEGIN OF o2pagkey, applname TYPE o2applname, pagekey TYPE c LENGTH 70, END OF o2pagkey.
TYPES: BEGIN OF wa_target, file TYPE ty_file, asset TYPE ty_asset, bsp_key TYPE o2pagkey, END OF wa_target.
DATA: im_header TYPE ty_header, im_packages TYPE ty_packages, f TYPE ty_file, target TYPE wa_target,
im_manifest TYPE STANDARD TABLE OF ty_file, metadata_error TYPE string, metadata_calls TYPE i.
START-OF-SELECTION.
* CASE 1 BSP mode overrides stale result variant
PERFORM setup.
p_all = 'X'. p_src = 'X'. p_xml = 'X'. p_pkgm = 'X'. p_sub = 'X'. p_mb = 1.
PERFORM scope_mode. ASSERT p_mime = 'X'. ASSERT p_all IS INITIAL. ASSERT p_src IS INITIAL.
ASSERT p_xml IS INITIAL. ASSERT p_pkgm IS INITIAL. ASSERT p_sub IS INITIAL. ASSERT p_mb = 512. ASSERT gv_scope_kind = 'BSP'.
* CASE 2 package mode keeps result choice and descendants
PERFORM setup.
CLEAR p_bspm. p_src = 'X'. PERFORM scope_mode.
ASSERT p_pkgm = 'X'. ASSERT p_sub = 'X'. ASSERT p_src = 'X'. ASSERT gv_scope_kind = 'PACKAGE'.
* CASE 3 app name required
PERFORM setup.
CLEAR p_bsp. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 4 package required
PERFORM setup.
CLEAR: p_bspm, p_pack. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 5 ZIP required only on execution validation
PERFORM setup.
CLEAR p_file. PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 6 canonical app ZWEB_COMMON
PERFORM setup.
p_bsp = 'ZWEB_COMMON'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS INITIAL.
* CASE 7 canonical app ZWEB_WF
PERFORM setup.
p_bsp = 'ZWEB_WF'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS INITIAL.
* CASE 8 canonical app /KBS/ZWEB
PERFORM setup.
p_bsp = '/KBS/ZWEB'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS INITIAL.
* CASE 9 canonical app ZWEB*
PERFORM setup.
p_bsp = 'ZWEB*'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS NOT INITIAL.
* CASE 10 canonical app ZWEB_COMMON/EVIL
PERFORM setup.
p_bsp = 'ZWEB_COMMON/EVIL'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS NOT INITIAL.
* CASE 11 canonical app /SAP/ZWEB_COMMON
PERFORM setup.
p_bsp = '/SAP/ZWEB_COMMON'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS NOT INITIAL.
* CASE 12 canonical app 
PERFORM setup.
p_bsp = ''. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS NOT INITIAL.
* CASE 13 canonical app ZWEB COMMON
PERFORM setup.
p_bsp = 'ZWEB COMMON'. PERFORM scope_url USING p_bsp CHANGING url err. ASSERT err IS NOT INITIAL.
* CASE 14 URL boundary /SAP/BC/BSP/SAP/ZWEB_COMMON/css/main.css
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_COMMON/css/main.css'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS INITIAL.
* CASE 15 URL boundary /sap/bc/bsp/sap/zweb_common/js/a.js
PERFORM setup.
url = '/sap/bc/bsp/sap/zweb_common/js/a.js'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS INITIAL.
* CASE 16 URL boundary /SAP/BC/BSP/SAP/ZWEB_COMMON2/a.js
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_COMMON2/a.js'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 17 URL boundary /SAP/BC/BSP/SAP/ZWEB_WF/a.js
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_WF/a.js'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 18 URL boundary /SAP/PUBLIC/a.js
PERFORM setup.
url = '/SAP/PUBLIC/a.js'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 19 URL boundary /SAP/BC/BSP/SAP/ZWEB_COMMON/../other.js
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_COMMON/../other.js'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 20 URL boundary /SAP/BC/BSP/SAP/ZWEB_COMMON/css//a.css
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_COMMON/css//a.css'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 21 URL boundary /SAP/BC/BSP/SAP/ZWEB_COMMON
PERFORM setup.
url = '/SAP/BC/BSP/SAP/ZWEB_COMMON'. PERFORM scope_url_check USING url CHANGING err. ASSERT err IS INITIAL.
* CASE 22 legacy 0318 package
PERFORM setup.

 p_bspm = ''. im_header-version = '0.2'. im_header-tool_version = '0.3.18'.
 im_header-scope_kind = ''. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS INITIAL.
* CASE 23 legacy 0328 package
PERFORM setup.

 p_bspm = ''. im_header-version = '0.2'. im_header-tool_version = '0.3.28'.
 im_header-scope_kind = ''. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS INITIAL.
* CASE 24 legacy BSP forbidden
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.2'. im_header-tool_version = '0.3.18'.
 im_header-scope_kind = ''. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 25 legacy scope injection
PERFORM setup.

 p_bspm = ''. im_header-version = '0.2'. im_header-tool_version = '0.3.18'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 26 new package
PERFORM setup.

 p_bspm = ''. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'PACKAGE'. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS INITIAL.
* CASE 27 new BSP
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS INITIAL.
* CASE 28 other BSP
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_WF'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 29 BSP in package mode
PERFORM setup.

 p_bspm = ''. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 30 package in BSP mode
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'PACKAGE'. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 31 missing owner
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 32 unknown version
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '9.9.9'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 33 wrong schema
PERFORM setup.

 p_bspm = 'X'. im_header-version = '0.2'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 34 wrong mode
PERFORM setup.

 p_bspm = ''. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'ALL'. im_header-bsp_application = ''. im_header-bsp_package = ''.
 PERFORM im_manifest_compat USING im_header CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 35 own Layout
PERFORM setup.

 CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Layout/index.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 36 own event read only
PERFORM setup.

 CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_EVENT_SOURCE'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Event Handler/ONINPUTPROCESSING.abap'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 37 foreign app same package
PERFORM setup.

 CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_WF'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_WF/pages/a/Layout/a.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 38 lying WAPA path
PERFORM setup.

 CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON2/pages/a/Layout/a.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 39 cross package owned MIME
PERFORM setup.

 CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_CONTENT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/js/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 40 external MIME path
PERFORM setup.

 CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_CONTENT'. f-path = 'packages/ZWEB/MIME/text/javascript/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 41 unlisted owner
PERFORM setup.

 CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'OTHER'.
 f-component = 'MIME_CONTENT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 42 package DDIC forbidden
PERFORM setup.

 CLEAR f. f-object = 'TABL'. f-obj_name = 'ZTABLE'. f-devclass = 'ZWEB'.
 f-component = 'DDIC_TABLE'. f-path = 'packages/ZWEB/Dictionary Object/ZTABLE.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 43 package FUGR forbidden
PERFORM setup.

 CLEAR f. f-object = 'FUGR'. f-obj_name = 'ZGROUP'. f-devclass = 'ZWEB'.
 f-component = 'FUNCTION_API_SOURCE'. f-path = 'packages/ZWEB/Function Module/F.abap'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 44 unbound W3MI forbidden
PERFORM setup.

 CLEAR f. f-object = 'W3MI'. f-obj_name = 'LOGO'. f-devclass = 'ZWEB'.
 f-component = 'W3MI_CONTENT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/logo.png'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 45 metadata cross package
PERFORM setup.

 CLEAR f. f-object = ''. f-obj_name = ''. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_METADATA'. f-path = 'packages/ZMEDIA/MIME/metadata.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 46 catalog
PERFORM setup.

 CLEAR f. f-object = ''. f-obj_name = ''. f-devclass = ''.
 f-component = 'WEB_CATALOG'. f-path = 'catalog/web-assets.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 47 flat BSP accepted
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.4'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS INITIAL. ASSERT gv_bsp_flat = 'X'.
* CASE 48 package 041 accepted
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = ''. im_header-version = '0.3'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'PACKAGE'. im_header-bsp_application = ''. im_header-bsp_package = ''.
 im_header-path_layout = ''. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 49 flat owner missing
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.4'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = ''.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 50 flat wrong app
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.4'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_WF'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 51 flat package mode forbidden
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = ''. im_header-version = '0.4'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 52 new BSP without marker forbidden
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.4'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = ''. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 53 new BSP with legacy schema forbidden
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.1'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = ''. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 54 legacy marker injection forbidden
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = 'X'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = 'ZWEB_COMMON'. im_header-bsp_package = 'ZWEB'.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 55 old package marker injection forbidden
PERFORM setup.

 gv_bsp_flat = 'X'. p_bspm = ''. im_header-version = '0.2'. im_header-tool_version = '0.3.18'.
 im_header-scope_kind = ''. im_header-bsp_application = ''. im_header-bsp_package = ''.
 im_header-path_layout = 'BSP_APP_ROOT'. PERFORM im_manifest_compat USING im_header CHANGING err.
 ASSERT err IS NOT INITIAL. ASSERT gv_bsp_flat = ''.
* CASE 56 flat Layout
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'pages/index/Layout/index.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 57 flat event read only
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_EVENT_SOURCE'. f-path = 'pages/index/Event Handler/on.abap'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 58 flat WAPA cannot use MIME root
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_COMMON'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'MIMEs/index.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 59 flat WAPA foreign app
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'WAPA'. f-obj_name = 'ZWEB_WF'. f-devclass = 'ZWEB'.
 f-component = 'BSP_LAYOUT'. f-path = 'pages/index/Layout/index.htm'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 60 flat owner retained
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_CONTENT'. f-path = 'MIMEs/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 61 flat unlisted owner
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'OTHER'.
 f-component = 'MIME_CONTENT'. f-path = 'MIMEs/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 62 flat metadata
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = ''. f-obj_name = ''. f-devclass = ''.
 f-component = 'MIME_METADATA'. f-path = 'catalog/mime-metadata.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS INITIAL.
* CASE 63 flat metadata cannot claim one owner
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = ''. f-obj_name = ''. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_METADATA'. f-path = 'catalog/mime-metadata.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 64 legacy metadata rejected in flat mode
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = ''. f-obj_name = ''. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_METADATA'. f-path = 'packages/ZMEDIA/MIME/metadata.xml'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 65 legacy MIME rejected in flat mode
PERFORM setup.

 gv_bsp_flat = 'X'. CLEAR f. f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'.
 f-component = 'MIME_CONTENT'. f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/app.js'. f-check_mode = 'RAW'.
 PERFORM im_scope_file USING f CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 66 logical payload root pages/index/Layout/index.htm
PERFORM setup.
gv_bsp_flat = 'X'. url = 'pages/index/Layout/index.htm'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = 'X'.
* CASE 67 logical payload root MIMEs/extra.woff2
PERFORM setup.
gv_bsp_flat = 'X'. url = 'MIMEs/extra.woff2'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = 'X'.
* CASE 68 logical payload root catalog/mime-metadata.xml
PERFORM setup.
gv_bsp_flat = 'X'. url = 'catalog/mime-metadata.xml'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = 'X'.
* CASE 69 logical payload root catalog/web-assets.xml
PERFORM setup.
gv_bsp_flat = 'X'. url = 'catalog/web-assets.xml'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = 'X'.
* CASE 70 logical payload root packages/ZHR1/MIME/a.js
PERFORM setup.
gv_bsp_flat = 'X'. url = 'packages/ZHR1/MIME/a.js'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = ''.
* CASE 71 logical payload root .devhub/baseline/MIMEs/a.js
PERFORM setup.
gv_bsp_flat = 'X'. url = '.devhub/baseline/MIMEs/a.js'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = ''.
* CASE 72 logical payload root ZWEB_COMMON/pages/a.htm
PERFORM setup.
gv_bsp_flat = 'X'. url = 'ZWEB_COMMON/pages/a.htm'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = ''.
* CASE 73 logical payload root README.md
PERFORM setup.
gv_bsp_flat = 'X'. url = 'README.md'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = ''.
* CASE 74 logical payload root MIMEs/a.js
PERFORM setup.
gv_bsp_flat = ''. url = 'MIMEs/a.js'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = ''.
* CASE 75 logical payload root packages/ZWEB/a.js
PERFORM setup.
gv_bsp_flat = ''. url = 'packages/ZWEB/a.js'.
 PERFORM im_payload_path USING url CHANGING ok. ASSERT ok = 'X'.
* CASE 76 flat archive wrapper and baseline
PERFORM setup.
gv_bsp_flat = 'X'. url = 'pages/index/Layout/index.htm'.
 PERFORM scope_zip_path USING url CHANGING err. ASSERT err = 'ZWEB_COMMON/pages/index/Layout/index.htm'.
 url = '.devhub/baseline/MIMEs/app.js'. PERFORM scope_zip_path USING url CHANGING err.
 ASSERT err = 'ZWEB_COMMON/.devhub/baseline/MIMEs/app.js'.
 PERFORM scope_zip_path USING 'manifest.xml' CHANGING err. ASSERT err = 'ZWEB_COMMON/manifest.xml'.
* CASE 77 package archive has no wrapper
PERFORM setup.
url = 'manifest.xml'. PERFORM scope_zip_path USING url CHANGING err. ASSERT err = url.
* CASE 78 namespaced app wrapper escaped
PERFORM setup.
gv_bsp_flat = 'X'. p_bsp = '/KBS/ZWEB'.
 PERFORM scope_zip_path USING 'manifest.xml' CHANGING err. ASSERT err = '~2FKBS~2FZWEB/manifest.xml'.
* CASE 79 flat Layout write mapping
PERFORM setup.
gv_bsp_flat = 'X'. f-path = 'pages/index/Layout/index.htm'. PERFORM add_current.
 target-file = f. target-bsp_key-applname = p_bsp. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.
* CASE 80 flat event remains nonwritable
PERFORM setup.
gv_bsp_flat = 'X'. f-path = 'pages/index/Event Handler/on.abap'.
 f-component = 'BSP_EVENT_SOURCE'. PERFORM add_current. target-file = f. target-bsp_key-applname = p_bsp.
 PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 81 flat MIME owner and URL retained
PERFORM setup.
PERFORM mime_target. gv_bsp_flat = 'X'. f-path = 'MIMEs/a.js'. target-file = f.
 PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.
 target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_WF/a.js'. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 82 missing current identity never writable
PERFORM setup.
PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.
* CASE 83 current exact object accepted
PERFORM setup.
PERFORM add_current. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok = 'X'.
* CASE 84 foreign object with own path rejected
PERFORM setup.
PERFORM add_current. f-obj_name = 'OTHER'. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.
* CASE 85 owner changed rejected
PERFORM setup.
PERFORM add_current. f-devclass = 'ZMEDIA'. PERFORM im_scope_current USING f CHANGING ok. ASSERT ok IS INITIAL.
* CASE 86 write Layout accepted
PERFORM setup.
PERFORM add_current. target-file = f. target-bsp_key-applname = p_bsp.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.
* CASE 87 write event forbidden
PERFORM setup.
PERFORM add_current. f-component = 'BSP_EVENT_SOURCE'. target-file = f. target-bsp_key-applname = p_bsp.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 88 write native key must match
PERFORM setup.
PERFORM add_current. target-file = f. target-bsp_key-applname = 'ZWEB_WF'.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 89 owned MIME write boundary
PERFORM setup.
PERFORM mime_target. PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS INITIAL.
* CASE 90 foreign URL write forbidden even same object fields
PERFORM setup.
PERFORM mime_target. target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_WF/a.js'.
PERFORM wa_scope_check USING target CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 91 scoped manifest with Layout and unchanged catalog
PERFORM setup.
APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL. ASSERT metadata_calls = 1.
* CASE 92 catalog required in manifest
PERFORM setup.
APPEND f TO im_manifest.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL. ASSERT metadata_calls = 0.
* CASE 93 MIME-only selected rollback does not require page payload
PERFORM setup.
PERFORM mime_target. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL.
* CASE 94 foreign manifest rejected before snapshot
PERFORM setup.
f-obj_name = 'ZWEB_WF'. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL. ASSERT metadata_calls = 0.
* CASE 95 changed baseline catalog stops scope validation
PERFORM setup.
APPEND f TO im_manifest. PERFORM add_catalog. metadata_error = 'catalog differs'.
PERFORM im_scope_manifest CHANGING err. ASSERT err = metadata_error.
* CASE 96 missing primary owner rejected
PERFORM setup.
DELETE im_packages WHERE devclass = 'ZWEB'. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 97 unbound W3MI rejected in manifest
PERFORM setup.
f-object = 'W3MI'. f-component = 'W3MI_CONTENT'. APPEND f TO im_manifest. PERFORM add_catalog.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS NOT INITIAL.
* CASE 98 legacy package scope bypasses BSP-only manifest rule
PERFORM setup.
CLEAR p_bspm. REFRESH im_manifest.
PERFORM im_scope_manifest CHANGING err. ASSERT err IS INITIAL. ASSERT metadata_calls = 0.

FORM setup.
 CLEAR: gv_bsp_flat, err, url, ok, f, target, im_header, p_pack, p_all, p_src, p_xml, p_mime, metadata_error, metadata_calls.
 REFRESH: im_packages, gt_objects, im_manifest. p_bspm = 'X'. p_bsp = 'ZWEB_COMMON'. p_file = 'input.zip'.
 im_header-format = 'DEVHUB-EXPORT'. im_header-version = '0.3'. im_header-tool_version = '0.4.0'.
 im_header-scope_kind = 'BSP'. im_header-bsp_application = p_bsp. im_header-bsp_package = 'ZWEB'.
 pkg-devclass = 'ZWEB'. APPEND pkg TO im_packages. pkg-devclass = 'ZMEDIA'. APPEND pkg TO im_packages.
 f-object = 'WAPA'. f-obj_name = p_bsp. f-devclass = 'ZWEB'. f-component = 'BSP_LAYOUT'. f-check_mode = 'RAW'.
 f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/pages/index/Layout/index.htm'.
ENDFORM.
FORM add_current.
 CLEAR obj. obj-pgmid = 'R3TR'. obj-object = f-object. obj-obj_name = f-obj_name. obj-devclass = f-devclass.
 APPEND obj TO gt_objects.
ENDFORM.
FORM mime_target.
 f-object = 'SMIM'. f-obj_name = 'LOIO1'. f-devclass = 'ZMEDIA'. f-component = 'MIME_CONTENT'.
 f-path = 'packages/ZWEB/BSP Application/WAPA/ZWEB_COMMON/MIMEs/a.js'.
 PERFORM add_current. target-file = f. target-asset-original_path = '/SAP/BC/BSP/SAP/ZWEB_COMMON/a.js'.
ENDFORM.
FORM add_catalog.
 DATA cat TYPE ty_file. cat-component = 'WEB_CATALOG'. cat-path = 'catalog/web-assets.xml'. APPEND cat TO im_manifest.
ENDFORM.
FORM wa_metadata USING p TYPE string CHANGING raw TYPE xstring error TYPE string.
 ASSERT p = 'catalog/web-assets.xml'. ADD 1 TO metadata_calls. error = metadata_error. CLEAR raw.
ENDFORM.
FORM scope_url USING pv_app TYPE o2applname
               CHANGING cv_url TYPE string cv_error TYPE string.
  DATA: lv_tail TYPE string, lv_app TYPE string,
        lv_bsp TYPE c, lv_valid TYPE c.
  CLEAR: cv_url, cv_error.
  IF pv_app IS INITIAL.
    cv_error = 'BSP 애플리케이션 이름을 입력하십시오. 예: ZWEB_COMMON'. RETURN.
  ENDIF.
  IF pv_app(1) = '/'.
    lv_tail = pv_app+1.
    CONCATENATE '/SAP/BC/BSP/' lv_tail INTO cv_url.
  ELSE.
    CONCATENATE '/SAP/BC/BSP/SAP/' pv_app INTO cv_url.
  ENDIF.
  PERFORM bsp_app_from_url USING cv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> pv_app.
    cv_error = 'BSP 이름 형식 오류: 정확한 애플리케이션 이름 하나를 입력하십시오.'.
  ENDIF.
ENDFORM.
FORM scope_url_check USING pv_url TYPE string CHANGING cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lv_relative TYPE string.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  PERFORM bsp_app_from_url USING pv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> p_bsp.
    cv_error = '선택한 BSP 애플리케이션 밖의 MIME 경로입니다.'. RETURN.
  ENDIF.
  PERFORM bsp_mime_relative USING pv_url p_bsp CHANGING lv_relative cv_error.
ENDFORM.
FORM bsp_app_from_url USING pv_url TYPE string
                     CHANGING cv_app TYPE string cv_bsp TYPE c
                              cv_valid TYPE c.
  DATA: lv_url TYPE string, lv_tail TYPE string,
        lt_parts TYPE ty_lines, lv_namespace TYPE string,
        lv_name TYPE string, lv_api_name TYPE o2applname.
  CLEAR: cv_app, cv_bsp, cv_valid.
  lv_url = pv_url.
  TRANSLATE lv_url TO UPPER CASE.
  IF lv_url NP '/SAP/BC/BSP/*'.
* A noncanonical BSP path must not silently pass the scope check.
    IF lv_url CP '*/SAP/BC/BSP/*'. cv_bsp = 'X'. ENDIF.
    RETURN.
  ENDIF.
  cv_bsp = 'X'.
  lv_tail = lv_url+12.
  SPLIT lv_tail AT '/' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_namespace INDEX 1.
  READ TABLE lt_parts INTO lv_name INDEX 2.
  IF lv_namespace IS INITIAL OR lv_name IS INITIAL.
    RETURN.
  ENDIF.
* Resolve canonical, unescaped names only. Never guess encoded aliases.
  IF lv_namespace CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_' OR
     lv_name CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'.
    RETURN.
  ENDIF.
  IF lv_namespace = 'SAP'.
    cv_app = lv_name.
  ELSE.
    CONCATENATE '/' lv_namespace '/' lv_name INTO cv_app.
  ENDIF.
  lv_api_name = cv_app.
  IF lv_api_name <> cv_app.
    CLEAR cv_app. RETURN.
  ENDIF.
  cv_valid = 'X'.
ENDFORM.
FORM bsp_mime_relative USING pv_url TYPE string pv_app TYPE csequence
                      CHANGING cv_relative TYPE string
                               cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lt_parts TYPE ty_lines, lv_part TYPE string,
        lv_safe TYPE string, lv_index TYPE i, lv_count TYPE i.
  CLEAR: cv_relative, cv_error.
  PERFORM bsp_app_from_url USING pv_url
    CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid IS INITIAL OR lv_app <> pv_app.
    cv_error = 'MIME URL is outside the expected BSP application'. RETURN.
  ENDIF.
  SPLIT pv_url AT '/' INTO TABLE lt_parts.
  DESCRIBE TABLE lt_parts LINES lv_count.
* /SAP/BC/BSP/<namespace>/<app>/... : preserve every relative segment.
  LOOP AT lt_parts INTO lv_part FROM 7.
    lv_index = sy-tabix.
    IF lv_part IS INITIAL AND lv_index = lv_count. CONTINUE. ENDIF.
    IF lv_part IS INITIAL OR lv_part = '.' OR lv_part = '..'.
      cv_error = 'Empty or dot segment in BSP MIME URL'. RETURN.
    ENDIF.
    PERFORM safe_leaf USING lv_part CHANGING lv_safe.
    IF cv_relative IS INITIAL.
      cv_relative = lv_safe.
    ELSE.
      CONCATENATE cv_relative '/' lv_safe INTO cv_relative.
    ENDIF.
  ENDLOOP.
ENDFORM.
FORM segment USING pv_name TYPE c CHANGING cv_segment TYPE string.
  DATA lv_name TYPE string.
  lv_name = pv_name.
  PERFORM safe_leaf USING lv_name CHANGING cv_segment.
ENDFORM.
FORM safe_leaf USING pv_name TYPE string CHANGING cv_leaf TYPE string.
  DATA: lt_parts TYPE STANDARD TABLE OF string,
        lv_base TYPE string, lv_char TYPE c LENGTH 1,
        lv_text TYPE string, lv_empty TYPE string,
        lv_data TYPE xstring, lv_byte TYPE x LENGTH 1,
        lv_hex TYPE c LENGTH 2, lv_i TYPE i, lv_j TYPE i,
        lv_n TYPE i, lv_bytes TYPE i, lv_last TYPE i,
        lv_reserved TYPE c LENGTH 1, lv_escape TYPE c LENGTH 1.
* Preserve names, case, Unicode and extensions; no added prefix.
* Escape only Windows-invalid characters, ~ and reserved device names.
* ~ is always escaped, keeping every ~HH mapping reversible.
  CLEAR cv_leaf.
  lv_n = strlen( pv_name ).
  IF lv_n = 0.
    gv_fatal = 'Empty archive name cannot be represented'. RETURN.
  ENDIF.
  SPLIT pv_name AT '.' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_base INDEX 1.
  TRANSLATE lv_base TO UPPER CASE.
  CONDENSE lv_base.
  IF lv_base = 'CON' OR lv_base = 'PRN' OR lv_base = 'AUX' OR
     lv_base = 'NUL' OR lv_base = 'CONIN$' OR lv_base = 'CONOUT$'.
    lv_reserved = 'X'.
  ELSEIF strlen( lv_base ) = 4.
    IF lv_base(3) = 'COM' OR lv_base(3) = 'LPT'.
      IF lv_base+3(1) CA '123456789'. lv_reserved = 'X'. ENDIF.
      lv_text = lv_base+3(1).
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = 'C2B9' OR lv_data = 'C2B2' OR lv_data = 'C2B3'.
        lv_reserved = 'X'.
      ENDIF.
    ENDIF.
  ENDIF.
* Encode the whole terminal run of dots/spaces, not just its final byte.
  lv_last = lv_n.
  WHILE lv_last > 0.
    lv_i = lv_last - 1. lv_char = pv_name+lv_i(1).
    IF lv_char <> '.' AND lv_char <> space. EXIT. ENDIF.
    SUBTRACT 1 FROM lv_last.
  ENDWHILE.
  DO lv_n TIMES.
    lv_i = sy-index - 1. lv_char = pv_name+lv_i(1).
    CLEAR lv_escape.
    IF lv_char CA '<>:"/\|?*~' OR lv_char < space OR
       lv_i >= lv_last OR ( lv_i = 0 AND lv_reserved = 'X' ).
      lv_escape = 'X'.
    ENDIF.
    CONCATENATE lv_char lv_empty INTO lv_text RESPECTING BLANKS.
* DEL is rejected by the offline checker as well.
    IF lv_char BETWEEN ' ' AND '~'.
* Printable ASCII has already been classified above.
    ELSE.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = '7F'. lv_escape = 'X'. ENDIF.
    ENDIF.
    IF lv_escape = 'X'.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      lv_bytes = xstrlen( lv_data ).
      DO lv_bytes TIMES.
        lv_j = sy-index - 1. lv_byte = lv_data+lv_j(1).
        lv_hex = lv_byte.
        CONCATENATE cv_leaf '~' lv_hex INTO cv_leaf.
      ENDDO.
    ELSE.
      CONCATENATE cv_leaf lv_text INTO cv_leaf RESPECTING BLANKS.
    ENDIF.
  ENDDO.
ENDFORM.
FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
* External SAP codec double; only escaped ASCII slash used in these fixtures.
 ASSERT text = '/'. raw = '2F'.
ENDFORM.
FORM scope_mode.
  p_mb = 512.
  IF p_bspm = 'X'.
    CLEAR: p_pkgm, p_sub.
    TRANSLATE p_bsp TO UPPER CASE.
    gv_scope_kind = 'BSP'.
    CLEAR: p_all, p_src, p_xml. p_mime = 'X'.
  ELSE.
    p_pkgm = 'X'. p_sub = 'X'. gv_scope_kind = 'PACKAGE'.
  ENDIF.
ENDFORM.
FORM scope_selection CHANGING cv_error TYPE string.
  DATA lv_url TYPE string.
  CLEAR cv_error.
  IF p_bspm = 'X'.
    PERFORM scope_url USING p_bsp CHANGING lv_url cv_error.
  ELSEIF p_pack IS INITIAL.
    cv_error = '개발 패키지를 입력하십시오.'.
  ENDIF.
  IF cv_error IS INITIAL AND p_file IS INITIAL.
    cv_error = '비교할 추출본 ZIP 파일을 선택하십시오.'.
  ENDIF.
ENDFORM.
FORM im_manifest_compat USING ps_header TYPE ty_header
                        CHANGING cv_error TYPE string.
* The layout is selected from a validated header, never from a filename.
  CLEAR: cv_error, gv_bsp_flat.
  IF ps_header-format <> 'DEVHUB-EXPORT'.
    cv_error = 'MANIFEST_FORMAT_UNSUPPORTED'. RETURN.
  ENDIF.
  IF ps_header-version = '0.2' AND
     ( ps_header-tool_version = '0.3.18' OR ps_header-tool_version = '0.3.28' ).
    IF ps_header-scope_kind IS NOT INITIAL OR ps_header-bsp_application IS NOT INITIAL OR
       ps_header-bsp_package IS NOT INITIAL OR ps_header-path_layout IS NOT INITIAL.
      cv_error = 'LEGACY_SCOPE_INVALID: 기존 ZIP에 BSP 범위를 추가할 수 없습니다.'.
    ELSEIF p_bspm = 'X'.
      cv_error = '이 ZIP은 기존 패키지 추출본입니다. 개발 패키지 모드를 사용하십시오.'.
    ENDIF.
    RETURN.
  ENDIF.
  IF ps_header-version = '0.4' AND ps_header-tool_version = '0.4.1' AND
     ps_header-scope_kind = 'BSP' AND ps_header-path_layout = 'BSP_APP_ROOT'.
* New BSP-only layout. The mode/app identity is checked below.
  ELSEIF ps_header-version = '0.3' AND ps_header-path_layout IS INITIAL AND
         ( ps_header-tool_version = '0.4.0' OR
           ( ps_header-tool_version = '0.4.1' AND ps_header-scope_kind = 'PACKAGE' ) ).
* Original package paths, including the previously exported BSP archives.
  ELSE.
    cv_error = 'EXPORT_VERSION_UNSUPPORTED: 지원 Export=0.3.18/0.3.28/0.4.0/0.4.1; manifest를 직접 바꾸지 마십시오.'.
    RETURN.
  ENDIF.
  IF p_bspm = 'X'.
    IF ps_header-scope_kind <> 'BSP' OR ps_header-bsp_application <> p_bsp OR
       ps_header-bsp_package IS INITIAL.
      cv_error = 'BSP_SCOPE_MISMATCH: 선택한 BSP 이름과 ZIP의 추출 범위가 다릅니다.'.
    ENDIF.
  ELSEIF ps_header-scope_kind <> 'PACKAGE' OR
         ps_header-bsp_application IS NOT INITIAL OR ps_header-bsp_package IS NOT INITIAL.
    cv_error = 'SCOPE_MISMATCH: BSP 추출본은 BSP 애플리케이션 모드에서 업로드하십시오.'.
  ENDIF.
  IF cv_error IS INITIAL AND ps_header-path_layout = 'BSP_APP_ROOT'.
    gv_bsp_flat = 'X'.
  ENDIF.
ENDFORM.
FORM im_scope_file USING ps_file TYPE ty_file CHANGING cv_error TYPE string.
* Path layout may change; real owner and selected app checks remain exact.
  DATA: lv_pkg TYPE string, lv_app TYPE string, lv_root TYPE string,
        lv_mime TYPE string, lv_meta TYPE string, lv_n TYPE i,
        ls_pkg TYPE ty_package.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  IF ps_file-path = 'catalog/web-assets.xml' AND ps_file-component = 'WEB_CATALOG'
     AND ps_file-object IS INITIAL AND ps_file-obj_name IS INITIAL
     AND ps_file-devclass IS INITIAL. RETURN. ENDIF.
  IF gv_bsp_flat = 'X' AND ps_file-path = 'catalog/mime-metadata.xml' AND
     ps_file-component = 'MIME_METADATA' AND ps_file-object IS INITIAL AND
     ps_file-obj_name IS INITIAL AND ps_file-devclass IS INITIAL. RETURN. ENDIF.
  READ TABLE im_packages INTO ls_pkg WITH KEY devclass = ps_file-devclass.
  IF sy-subrc <> 0 OR ps_file-devclass IS INITIAL.
    cv_error = 'BSP_SCOPE_FILE: manifest 소유 패키지 매핑 오류'. RETURN.
  ENDIF.
  PERFORM scope_bsp_root USING im_header-bsp_package im_header-bsp_application
    CHANGING lv_root.
  CONCATENATE lv_root 'MIMEs/' INTO lv_mime.
  IF ps_file-object = 'WAPA' AND ps_file-obj_name = p_bsp AND
     ps_file-devclass = im_header-bsp_package AND ps_file-component CP 'BSP_*'.
    CONCATENATE lv_root 'pages/' INTO lv_root.
    lv_n = strlen( lv_root ).
    IF strlen( ps_file-path ) > lv_n.
      IF ps_file-path(lv_n) = lv_root. RETURN. ENDIF.
    ENDIF.
  ELSEIF ps_file-object = 'SMIM' AND ps_file-obj_name IS NOT INITIAL AND
         ps_file-component = 'MIME_CONTENT' AND ps_file-check_mode = 'RAW'.
    lv_n = strlen( lv_mime ).
    IF strlen( ps_file-path ) > lv_n.
      IF ps_file-path(lv_n) = lv_mime. RETURN. ENDIF.
    ENDIF.
  ELSEIF gv_bsp_flat IS INITIAL AND
         ps_file-component = 'MIME_METADATA' AND ps_file-object IS INITIAL AND
         ps_file-obj_name IS INITIAL.
    PERFORM mime_metadata_path USING ps_file-devclass CHANGING lv_meta.
    IF ps_file-path = lv_meta. RETURN. ENDIF.
  ENDIF.
  cv_error = 'BSP_SCOPE_FILE: 선택 앱 밖의 객체/경로 또는 허용되지 않은 파일 유형'.
ENDFORM.
FORM im_scope_manifest CHANGING cv_error TYPE string.
  DATA: ls_file TYPE ty_file, ls_pkg TYPE ty_package, lv_catalog TYPE c,
        lv_app TYPE c, lv_path TYPE string, lv_raw TYPE xstring.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  READ TABLE im_packages INTO ls_pkg WITH KEY devclass = im_header-bsp_package.
  IF sy-subrc <> 0. cv_error = 'BSP 소유 패키지가 manifest PACKAGES에 없습니다.'. RETURN. ENDIF.
  LOOP AT im_manifest INTO ls_file.
    PERFORM im_scope_file USING ls_file CHANGING cv_error.
    IF cv_error IS NOT INITIAL.
      CONCATENATE cv_error ls_file-path INTO cv_error SEPARATED BY ': '. RETURN.
    ENDIF.
    IF ls_file-path = 'catalog/web-assets.xml'. lv_catalog = 'X'. ENDIF.
    IF ls_file-object = 'WAPA'. lv_app = 'X'. ENDIF.
  ENDLOOP.
* A MIME-only selected rollback may not contain page files. The full
* catalog still supplies identity; no page file is required for restore.
  IF lv_catalog <> 'X'. cv_error = 'BSP 추출본에 웹자산 원본 목록이 없습니다.'. RETURN. ENDIF.
  lv_path = 'catalog/web-assets.xml'.
  PERFORM wa_metadata USING lv_path CHANGING lv_raw cv_error.
ENDFORM.
FORM im_scope_current USING ps_file TYPE ty_file CHANGING cv_in TYPE c.
  DATA lv_error TYPE string.
  CLEAR cv_in.
  PERFORM im_scope_file USING ps_file CHANGING lv_error.
  IF lv_error IS NOT INITIAL. RETURN. ENDIF.
  IF ps_file-component = 'WEB_CATALOG' OR ps_file-component = 'MIME_METADATA'.
    cv_in = 'X'. RETURN.
  ENDIF.
  READ TABLE gt_objects WITH KEY pgmid = 'R3TR' object = ps_file-object
    obj_name = ps_file-obj_name devclass = ps_file-devclass TRANSPORTING NO FIELDS.
  IF sy-subrc = 0. cv_in = 'X'. ENDIF.
ENDFORM.
FORM mime_metadata_path USING pv_package TYPE c
                       CHANGING cv_path TYPE string.
  DATA lv_pkg TYPE string.
  IF gv_bsp_flat = 'X'.
    cv_path = 'catalog/mime-metadata.xml'. RETURN.
  ENDIF.
  PERFORM segment USING pv_package CHANGING lv_pkg.
  CONCATENATE 'packages/' lv_pkg '/MIME/metadata.xml' INTO cv_path.
ENDFORM.
FORM wa_scope_check USING ps_target TYPE wa_target CHANGING cv_error TYPE string.
  DATA lv_in TYPE c.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  PERFORM im_scope_current USING ps_target-file CHANGING lv_in.
  IF lv_in <> 'X'. cv_error = '반영 대상이 선택한 BSP 범위 밖입니다.'. RETURN. ENDIF.
  CASE ps_target-file-object.
    WHEN 'WAPA'.
      IF ps_target-file-obj_name <> p_bsp OR ps_target-file-component <> 'BSP_LAYOUT' OR
         ps_target-bsp_key-applname <> p_bsp.
        cv_error = '선택한 기존 BSP Layout만 반영할 수 있습니다.'.
      ENDIF.
    WHEN 'SMIM'.
      PERFORM scope_url_check USING ps_target-asset-original_path CHANGING cv_error.
    WHEN OTHERS. cv_error = 'BSP 모드의 반영 유형이 아닙니다.'.
  ENDCASE.
ENDFORM.
FORM scope_bsp_root USING pv_package TYPE c pv_app TYPE c
                    CHANGING cv_root TYPE string.
* Logical paths are relative to manifest.xml. Ownership stays in metadata.
  DATA: lv_pkg TYPE string, lv_app TYPE string.
  CLEAR cv_root.
  IF gv_bsp_flat = 'X'. RETURN. ENDIF.
  PERFORM segment USING pv_package CHANGING lv_pkg.
  PERFORM segment USING pv_app CHANGING lv_app.
  CONCATENATE 'packages/' lv_pkg '/BSP Application/WAPA/' lv_app '/'
    INTO cv_root.
ENDFORM.
FORM scope_zip_path USING pv_path TYPE csequence CHANGING cv_path TYPE string.
* Only the ZIP entry has the enclosing app folder; manifest paths do not.
  DATA lv_app TYPE string.
  cv_path = pv_path.
  IF gv_bsp_flat <> 'X'. RETURN. ENDIF.
  PERFORM segment USING p_bsp CHANGING lv_app.
  CONCATENATE lv_app '/' pv_path INTO cv_path.
ENDFORM.
FORM im_payload_path USING pv_path TYPE string CHANGING cv_ok TYPE c.
  CLEAR cv_ok.
  IF pv_path = 'catalog/web-assets.xml'. cv_ok = 'X'. RETURN. ENDIF.
  IF gv_bsp_flat = 'X'.
    IF pv_path CP 'pages/*' OR pv_path CP 'MIMEs/*' OR
       pv_path = 'catalog/mime-metadata.xml'. cv_ok = 'X'. ENDIF.
  ELSEIF pv_path CP 'packages/*'. cv_ok = 'X'.
  ENDIF.
ENDFORM.