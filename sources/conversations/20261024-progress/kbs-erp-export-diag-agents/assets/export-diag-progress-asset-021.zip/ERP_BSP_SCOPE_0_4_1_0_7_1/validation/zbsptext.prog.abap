REPORT zbsptext.
 TYPES ty_lines TYPE STANDARD TABLE OF string.
 TYPES o2pageline_table TYPE STANDARD TABLE OF string.
 CLASS cl_abap_char_utilities DEFINITION.
 PUBLIC SECTION. CLASS-DATA: newline TYPE c, cr_lf TYPE c LENGTH 2.
 CLASS-METHODS class_constructor.
 ENDCLASS.
 CLASS cl_abap_char_utilities IMPLEMENTATION.
 METHOD class_constructor. newline  =  |\n|. cr_lf  =  |\r\n|. ENDMETHOD. ENDCLASS.
 TYPES: BEGIN OF fixture, raw TYPE xstring, text TYPE string, END OF fixture.
 DATA: fixtures TYPE STANDARD TABLE OF fixture, fixture_no TYPE i,
 a TYPE xstring, b TYPE xstring, txt TYPE string, txt2 TYPE string, err TYPE string,
 eq TYPE c, tokens TYPE ty_lines, content TYPE o2pageline_table, gv_lf TYPE string.
 gv_lf  =  cl_abap_char_utilities=>newline.
txt = '<html>old</html>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<html>새 화면</html>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = '<%@page language="abap"%><b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%@page language="abap"%><b>new</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = '<%= name %><b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%= name %><b>new</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = '<%= name %>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%= other %>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<%@page language="abap"%>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%@page language="javascript"%>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<% write secret. %><b>new</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<%= name %><b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<b>new</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<%= a %><%= b %>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%= b %><%= a %>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<%-- preserve %> comment --%><b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%-- preserve %> comment --%><b>new</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = '<b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<% unterminated'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<%-- unterminated %>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<script runat="server">old</script>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<script runat="server">new</script>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<script>let x=1;</script>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<script>let x=2;</script>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = '<html>old</html>'. PERFORM utf8 USING txt CHANGING a.
 txt = ''. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS NOT INITIAL.
txt = '<b>old</b>'. PERFORM utf8 USING txt CHANGING a.
 txt = '<b>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</b>'. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_content USING a b CHANGING content err.
 ASSERT err IS INITIAL.
txt = |a\r\nb\r\n|. PERFORM utf8 USING txt CHANGING a.
 txt = |a\nb\n|. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_equal USING a b CHANGING eq err. ASSERT err IS INITIAL. ASSERT eq  =  'X'.
txt = |a\n|. PERFORM utf8 USING txt CHANGING a.
 txt = |a|. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_equal USING a b CHANGING eq err. ASSERT err IS INITIAL. ASSERT eq  =  'X'.
txt = |a\n\n|. PERFORM utf8 USING txt CHANGING a.
 txt = |a\n|. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_equal USING a b CHANGING eq err. ASSERT err IS INITIAL. ASSERT eq  =  ''.
txt = |a |. PERFORM utf8 USING txt CHANGING a.
 txt = |a|. PERFORM utf8 USING txt CHANGING b.
 PERFORM wa_bsp_equal USING a b CHANGING eq err. ASSERT err IS INITIAL. ASSERT eq  =  ''.
txt = |a\rb|. PERFORM utf8 USING txt CHANGING a.
 PERFORM wa_bsp_normalize USING a CHANGING txt2 err. ASSERT err IS NOT INITIAL.
 a = 'DEAD'. PERFORM wa_bsp_normalize USING a CHANGING txt2 err. ASSERT err IS NOT INITIAL.
 FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
 DATA: f TYPE fixture, key TYPE x LENGTH 4.
 ADD 1 TO fixture_no. key = fixture_no. raw = key. f-raw = raw. f-text = text. APPEND f TO fixtures.
 ENDFORM.
 FORM im_decode USING raw TYPE xstring CHANGING text TYPE string error TYPE string.
 DATA f TYPE fixture. CLEAR: text,error.
 READ TABLE fixtures INTO f WITH KEY raw = raw.
 IF sy-subrc <> 0. error = 'codec rejected'. ELSE. text = f-text. ENDIF.
 ENDFORM.
 FORM wa_bsp_normalize USING pv_raw TYPE xstring
                     CHANGING cv_text TYPE string cv_error TYPE string.
  DATA: lv_cr TYPE c, lv_n TYPE i.
  PERFORM im_decode USING pv_raw CHANGING cv_text cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf IN cv_text
    WITH cl_abap_char_utilities=>newline.
  lv_cr  =  cl_abap_char_utilities=>cr_lf(1).
  IF cv_text CS lv_cr.
    cv_error  =  'BSP Layout contains a lone CR; use UTF-8 with LF or CRLF'. RETURN.
  ENDIF.
* SET_PAGE uses logical lines. Ignore only one terminal newline. Interior
* whitespace, trailing spaces and extra empty lines remain significant.
  lv_n  =  strlen( cv_text ) - 1.
  IF lv_n >= 0.
    IF cv_text+lv_n(1)  =  cl_abap_char_utilities=>newline.
      cv_text  =  cv_text(lv_n).
    ENDIF.
  ENDIF.
ENDFORM.
FORM wa_bsp_equal USING pv_left TYPE xstring pv_right TYPE xstring
                 CHANGING cv_equal TYPE c cv_error TYPE string.
  DATA: lv_left TYPE string, lv_right TYPE string.
  CLEAR cv_equal.
  PERFORM wa_bsp_normalize USING pv_left CHANGING lv_left cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  PERFORM wa_bsp_normalize USING pv_right CHANGING lv_right cv_error.
  IF cv_error IS INITIAL AND lv_left  =  lv_right. cv_equal  =  'X'. ENDIF.
ENDFORM.
FORM wa_bsp_tokens USING pv_text TYPE string
                  CHANGING ct_tokens TYPE ty_lines cv_error TYPE string.
  DATA: lv_rest TYPE string, lv_token TYPE string, lv_upper TYPE string,
        lv_at TYPE i, lv_end TYPE i, lv_len TYPE i.
  REFRESH ct_tokens. CLEAR cv_error. lv_rest  =  pv_text.
  lv_upper  =  pv_text. TRANSLATE lv_upper TO UPPER CASE.
* Conservative initial scope: runat = server script syntax is not parsed by
* this guard. Do not claim this lexical preservation check is a sandbox.
  IF lv_upper CS 'RUNAT'.
    cv_error  =  'BSP RUNAT 구문은 이번 Layout 반영 범위에서 제외합니다.'. RETURN.
  ENDIF.
  WHILE lv_rest IS NOT INITIAL.
    FIND FIRST OCCURRENCE OF '<%' IN lv_rest MATCH OFFSET lv_at.
    IF sy-subrc <> 0. EXIT. ENDIF.
    lv_rest  =  lv_rest+lv_at.
    IF lv_rest CP '<%--*'.
      FIND FIRST OCCURRENCE OF '--%>' IN lv_rest MATCH OFFSET lv_end.
      lv_len  =  lv_end + 4.
    ELSE.
      FIND FIRST OCCURRENCE OF '%>' IN lv_rest MATCH OFFSET lv_end.
      lv_len  =  lv_end + 2.
    ENDIF.
    IF sy-subrc <> 0.
      cv_error  =  '닫히지 않은 BSP 서버 측 구문(<% ... %>)이 있습니다.'. RETURN.
    ENDIF.
    lv_token  =  lv_rest(lv_len). APPEND lv_token TO ct_tokens.
    lv_rest  =  lv_rest+lv_len.
  ENDWHILE.
ENDFORM.
FORM wa_bsp_line_error USING pv_reason TYPE csequence pv_row TYPE i
                                   pv_length TYPE i pv_capacity TYPE i
                             CHANGING cv_error TYPE string.
  DATA: lv_row TYPE c LENGTH 12, lv_length TYPE c LENGTH 12,
        lv_capacity TYPE c LENGTH 12.
  WRITE pv_row TO lv_row NO-GROUPING. CONDENSE lv_row.
  WRITE pv_length TO lv_length NO-GROUPING. CONDENSE lv_length.
  WRITE pv_capacity TO lv_capacity NO-GROUPING. CONDENSE lv_capacity.
  CONCATENATE 'BSP Layout 행' lv_row pv_reason ': 입력' lv_length
    '/ SAP 행 용량' lv_capacity '(문자 단위)' INTO cv_error SEPARATED BY space.
ENDFORM.
FORM wa_bsp_line_assign USING pv_text TYPE string pv_row TYPE i
                       CHANGING cv_cell TYPE ANY cv_round TYPE string cv_error TYPE string.
  DATA: lv_kind TYPE c, lv_length TYPE i, lv_capacity TYPE i,
        lv_padded TYPE string, lv_empty TYPE string.
  CLEAR: cv_round, cv_error.
  lv_length  =  strlen( pv_text ).
  DESCRIBE FIELD cv_cell TYPE lv_kind.
  IF lv_kind <> 'g' AND lv_kind <> 'C'.
    PERFORM wa_bsp_line_error USING '지원하지 않는 행 필드 유형' pv_row lv_length 0
      CHANGING cv_error. RETURN.
  ENDIF.
  IF lv_kind  =  'C'.
    DESCRIBE FIELD cv_cell LENGTH lv_capacity IN CHARACTER MODE.
* Check before assignment: truncation must never be mistaken for padding.
    IF lv_length > lv_capacity.
      PERFORM wa_bsp_line_error USING '실제 길이 초과' pv_row lv_length lv_capacity
        CHANGING cv_error. RETURN.
    ENDIF.
  ENDIF.
  cv_cell  =  pv_text.
  CONCATENATE cv_cell lv_empty INTO lv_padded RESPECTING BLANKS.
  IF lv_kind  =  'C'.
* Preserve exactly the known input extent, including input trailing spaces.
* Only the additional fixed-field padding may be ignored; never trim source.
    IF strlen( lv_padded ) <> lv_capacity.
      PERFORM wa_bsp_line_error USING '행 필드 길이 재확인 실패' pv_row lv_length lv_capacity
        CHANGING cv_error. RETURN.
    ENDIF.
    IF lv_length < lv_capacity AND lv_padded+lv_length CN space.
      PERFORM wa_bsp_line_error USING '원문 뒤에 공백 외 데이터 발생' pv_row lv_length lv_capacity
        CHANGING cv_error. RETURN.
    ENDIF.
    IF lv_length > 0. cv_round  =  lv_padded(lv_length). ENDIF.
  ELSE. cv_round  =  lv_padded.
  ENDIF.
  IF cv_round <> pv_text.
    PERFORM wa_bsp_line_error USING '문자 변환 불일치' pv_row lv_length lv_capacity
      CHANGING cv_error.
  ENDIF.
ENDFORM.
FORM wa_bsp_content USING pv_before TYPE xstring pv_wanted TYPE xstring
                   CHANGING ct_content TYPE o2pageline_table cv_error TYPE string.
  DATA: lv_before TYPE string, lv_wanted TYPE string, lv_again TYPE string,
        lt_before TYPE ty_lines, lt_wanted TYPE ty_lines, lt_lines TYPE ty_lines,
        lt_content TYPE o2pageline_table, lv_line TYPE string, lv_round TYPE string,
        lv_kind TYPE c, lv_row TYPE i, lv_length TYPE i, lv_split TYPE string.
  FIELD-SYMBOLS: <ls_line> TYPE ANY, <lv_cell> TYPE ANY, <lv_second> TYPE ANY.
  REFRESH ct_content.
  PERFORM wa_bsp_normalize USING pv_before CHANGING lv_before cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  PERFORM wa_bsp_normalize USING pv_wanted CHANGING lv_wanted cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  IF lv_wanted IS INITIAL. cv_error  =  '빈 BSP Layout으로 교체하지 않습니다.'. RETURN. ENDIF.
  PERFORM wa_bsp_tokens USING lv_before CHANGING lt_before cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  PERFORM wa_bsp_tokens USING lv_wanted CHANGING lt_wanted cv_error.
  IF cv_error IS NOT INITIAL. RETURN. ENDIF.
  IF lt_before <> lt_wanted.
    cv_error  =  'Layout의 서버 측 구문/지시문 변경: 이번 버전은 기존 구문을 유지해야 합니다.'. RETURN.
  ENDIF.
* SPLIT omits the empty segment after its final delimiter. Add one delimiter
* so a significant final empty source row survives the table conversion.
  CONCATENATE lv_wanted cl_abap_char_utilities=>newline
    INTO lv_split RESPECTING BLANKS.
  SPLIT lv_split AT cl_abap_char_utilities=>newline INTO TABLE lt_lines.
  LOOP AT lt_lines INTO lv_line.
    ADD 1 TO lv_row. lv_length  =  strlen( lv_line ).
    APPEND INITIAL LINE TO lt_content ASSIGNING <ls_line>.
    UNASSIGN: <lv_cell>, <lv_second>.
    DESCRIBE FIELD <ls_line> TYPE lv_kind.
    IF lv_kind  =  'u' OR lv_kind  =  'v'.
      ASSIGN COMPONENT 1 OF STRUCTURE <ls_line> TO <lv_cell>.
      IF sy-subrc <> 0.
        PERFORM wa_bsp_line_error USING '행 필드 없음' lv_row lv_length 0
          CHANGING cv_error. RETURN.
      ENDIF.
      ASSIGN COMPONENT 2 OF STRUCTURE <ls_line> TO <lv_second>.
      IF sy-subrc  =  0.
        PERFORM wa_bsp_line_error USING '여러 필드를 가진 행은 지원하지 않음' lv_row lv_length 0
          CHANGING cv_error. RETURN.
      ENDIF.
    ELSE. ASSIGN <ls_line> TO <lv_cell>.
    ENDIF.
    PERFORM wa_bsp_line_assign USING lv_line lv_row
      CHANGING <lv_cell> lv_round cv_error.
    IF cv_error IS NOT INITIAL. RETURN. ENDIF.
* Rebuild from the verified source extent of each row, not fixed-field width.
* Do not change web_lines: it also exports unrelated ABAP sources.
    IF lv_row  =  1. lv_again  =  lv_round.
    ELSE.
      CONCATENATE lv_again cl_abap_char_utilities=>newline lv_round
        INTO lv_again RESPECTING BLANKS.
    ENDIF.
  ENDLOOP.
  IF lv_again <> lv_wanted.
    cv_error  =  'BSP Layout 행 변환 후 내용/줄바꿈 불일치: 저장하지 않습니다.'. RETURN.
  ENDIF.
* Publish only a fully verified table; failed conversions leave no partial data.
  ct_content  =  lt_content.
ENDFORM.
FORM web_lines USING pt_lines TYPE ANY TABLE
               CHANGING cv_text TYPE string cv_ok TYPE c.
  DATA: lv_kind TYPE c, lv_line TYPE string, lv_empty TYPE string.
  FIELD-SYMBOLS: <ls_line> TYPE ANY, <lv_text> TYPE ANY,
                 <lv_second> TYPE ANY.
  CLEAR: cv_text, cv_ok.
  LOOP AT pt_lines ASSIGNING <ls_line>.
    UNASSIGN <lv_text>.
    DESCRIBE FIELD <ls_line> TYPE lv_kind.
    IF lv_kind  =  'u' OR lv_kind  =  'v'.
      ASSIGN COMPONENT 1 OF STRUCTURE <ls_line> TO <lv_text>.
      IF sy-subrc <> 0. RETURN. ENDIF.
      ASSIGN COMPONENT 2 OF STRUCTURE <ls_line> TO <lv_second>.
      IF sy-subrc  =  0. RETURN. ENDIF.
    ELSE.
      ASSIGN <ls_line> TO <lv_text>.
    ENDIF.
    DESCRIBE FIELD <lv_text> TYPE lv_kind.
    IF lv_kind <> 'C' AND lv_kind <> 'g'. RETURN. ENDIF.
    CONCATENATE <lv_text> lv_empty INTO lv_line RESPECTING BLANKS.
    CONCATENATE cv_text lv_line gv_lf INTO cv_text
      RESPECTING BLANKS.
  ENDLOOP.
  cv_ok  =  'X'.
ENDFORM.