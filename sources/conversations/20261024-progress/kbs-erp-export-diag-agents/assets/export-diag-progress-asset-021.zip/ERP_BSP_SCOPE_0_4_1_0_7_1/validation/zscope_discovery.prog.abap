REPORT zscope_discovery.

TYPES: o2applname TYPE c LENGTH 30, boole_d TYPE c, string_table TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, pgmid TYPE c LENGTH 4, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF tdevc, devclass TYPE c LENGTH 30, END OF tdevc.
TYPES: BEGIN OF ty_object, pgmid TYPE tadir-pgmid, object TYPE tadir-object, obj_name TYPE tadir-obj_name,
devclass TYPE tadir-devclass, status TYPE c LENGTH 20, reason TYPE string, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
TYPES ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
DATA: p_bspm TYPE c, p_pkgm TYPE c, p_sub TYPE c, p_bsp TYPE o2applname, p_pack TYPE tadir-devclass, p_file TYPE c LENGTH 255,
p_mb TYPE i, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
gv_scope_kind TYPE c LENGTH 12, gv_scope_package TYPE tadir-devclass, gv_bsp_flat TYPE c,
gv_fatal TYPE string, gv_archive_name TYPE string, gv_stage TYPE c LENGTH 30, gv_count TYPE i,
gt_packages TYPE ty_packages, gt_seen_pkg TYPE SORTED TABLE OF ty_package WITH UNIQUE KEY devclass,
gt_objects TYPE STANDARD TABLE OF ty_object WITH DEFAULT KEY, gs_object TYPE ty_object,
err TYPE string, url TYPE string, ok TYPE c, n TYPE i, obj TYPE ty_object, pkg TYPE ty_package.

TYPES: BEGIN OF skwf_io, objid TYPE c LENGTH 32, class TYPE c LENGTH 10, END OF skwf_io.
TYPES: BEGIN OF ty_web_ref, object TYPE tadir-object, obj_name TYPE tadir-obj_name, component TYPE string,
target_object TYPE tadir-object, target_name TYPE tadir-obj_name, scope TYPE c LENGTH 24, evidence TYPE c LENGTH 24, END OF ty_web_ref.
DATA: gt_web_refs TYPE STANDARD TABLE OF ty_web_ref, db TYPE STANDARD TABLE OF ty_object,
inventory TYPE string_table, root_url TYPE string, auth TYPE c, missing_root TYPE c, bad_root TYPE c,
api_calls TYPE i, list_calls TYPE i, queries TYPE i, warnings TYPE i.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'exception'. ENDMETHOD. ENDCLASS.
INTERFACE if_mr_api.
METHODS get_io_for_url IMPORTING i_url TYPE string EXPORTING e_loio TYPE skwf_io e_is_folder TYPE boole_d EXCEPTIONS not_found failed.
METHODS file_list IMPORTING i_url TYPE string i_recursive_call TYPE c i_check_authority TYPE c EXPORTING e_files TYPE string_table EXCEPTIONS failed.
ENDINTERFACE.
CLASS cl_mime_repository_api DEFINITION. PUBLIC SECTION.
INTERFACES if_mr_api. CLASS-METHODS get_api RETURNING VALUE(api) TYPE REF TO if_mr_api.
ENDCLASS.
CLASS cl_mime_repository_api IMPLEMENTATION.
METHOD get_api. CREATE OBJECT api TYPE cl_mime_repository_api. ENDMETHOD.
METHOD if_mr_api~get_io_for_url.
 ADD 1 TO api_calls. CLEAR: e_loio, e_is_folder.
 IF i_url = root_url.
   IF missing_root = 'X'. RAISE not_found. ENDIF.
   IF bad_root = 'X'. RAISE failed. ENDIF.
   e_is_folder = 'X'. e_loio-objid = 'ROOT'.
 ELSEIF i_url CS '/missing.js'. e_loio-objid = 'UNOWNED'.
 ELSEIF i_url CS '/image.png'. e_loio-objid = 'LOIO2'.
 ELSE. e_loio-objid = 'LOIO1'.
 ENDIF.
ENDMETHOD.
METHOD if_mr_api~file_list.
 ASSERT i_url = root_url. ASSERT i_recursive_call = 'X'. ASSERT i_check_authority = 'X'.
 ADD 1 TO list_calls. e_files = inventory.
ENDMETHOD.
ENDCLASS.
START-OF-SELECTION.
* CASE 1 only chosen WAPA plus own MIME; cross package retained
PERFORM setup.
PERFORM scope_discover_bsp.
ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.
DESCRIBE TABLE gt_packages LINES n. ASSERT n = 2. ASSERT gv_archive_name = 'ZWEB_COMMON_export.zip'.
ASSERT gv_scope_package = 'ZWEB'. LOOP AT gt_objects INTO obj.
ASSERT obj-object = 'WAPA' OR obj-object = 'SMIM'.
IF obj-object = 'WAPA'. ASSERT obj-obj_name = 'ZWEB_COMMON'. ENDIF. ENDLOOP.
READ TABLE gt_objects WITH KEY object = 'SMIM' obj_name = 'LOIO1' devclass = 'ZMEDIA' TRANSPORTING NO FIELDS.
ASSERT sy-subrc = 0. ASSERT list_calls = 1.
* CASE 2 no MIME folder still exports Layout app
PERFORM setup.
missing_root = 'X'. PERFORM scope_discover_bsp.
ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 1. ASSERT list_calls = 0.
* CASE 3 MIME root failure stops instead of empty success
PERFORM setup.
bad_root = 'X'. PERFORM scope_discover_bsp.
ASSERT gv_fatal IS NOT INITIAL.
* CASE 4 auth denied before MIME lookup
PERFORM setup.
CLEAR auth. PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.
ASSERT api_calls = 0. ASSERT gt_objects IS INITIAL.
* CASE 5 missing WAPA before MIME lookup
PERFORM setup.
DELETE db WHERE object = 'WAPA' AND obj_name = 'ZWEB_COMMON'.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL. ASSERT api_calls = 0.
* CASE 6 outside app URL cannot expand scope
PERFORM setup.
APPEND '/SAP/BC/BSP/SAP/ZWEB_WF/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.
READ TABLE gt_objects WITH KEY object = 'WAPA' obj_name = 'ZWEB_WF' TRANSPORTING NO FIELDS. ASSERT sy-subrc <> 0.
* CASE 7 prefix app cannot expand scope
PERFORM setup.
APPEND '/SAP/BC/BSP/SAP/ZWEB_COMMON2/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS NOT INITIAL.
* CASE 8 duplicate paths and LOIO are exported once
PERFORM setup.
APPEND 'js/main.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.
* CASE 9 unregistered MIME is recorded not guessed
PERFORM setup.
APPEND 'missing.js' TO inventory.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. DESCRIBE TABLE gt_objects LINES n. ASSERT n = 3.
DESCRIBE TABLE gt_web_refs LINES n. ASSERT n = 1. ASSERT warnings = 1.
* CASE 10 namespace app preserves canonical name and safe filename
PERFORM setup.
p_bsp = '/KBS/ZWEB'. root_url = '/SAP/BC/BSP/KBS/ZWEB'.
obj-pgmid = 'R3TR'. obj-object = 'WAPA'. obj-obj_name = p_bsp. obj-devclass = 'ZWEB'. APPEND obj TO db.
PERFORM scope_discover_bsp. ASSERT gv_fatal IS INITIAL. ASSERT gv_archive_name = '~2FKBS~2FZWEB_export.zip'.

FORM setup.
 CLEAR: gv_fatal, gv_scope_package, gv_archive_name, gv_count, api_calls, list_calls, queries, warnings, missing_root, bad_root.
 REFRESH: gt_objects, gt_packages, gt_seen_pkg, gt_web_refs, db, inventory.
 p_bspm = 'X'. p_bsp = 'ZWEB_COMMON'. auth = 'X'. root_url = '/SAP/BC/BSP/SAP/ZWEB_COMMON'.
 obj-pgmid = 'R3TR'. obj-object = 'WAPA'. obj-obj_name = p_bsp. obj-devclass = 'ZWEB'. APPEND obj TO db.
 obj-obj_name = 'ZWEB_WF'. APPEND obj TO db.
 obj-object = 'FUGR'. obj-obj_name = 'FUNCTIONS'. APPEND obj TO db.
 obj-object = 'TABL'. obj-obj_name = 'ZTAB'. APPEND obj TO db.
 obj-object = 'W3MI'. obj-obj_name = 'LOGO'. APPEND obj TO db.
 obj-object = 'SMIM'. obj-obj_name = 'LOIO1'. obj-devclass = 'ZMEDIA'. APPEND obj TO db.
 obj-obj_name = 'LOIO2'. obj-devclass = 'ZWEB'. APPEND obj TO db.
 obj-obj_name = 'EXTERNAL'. APPEND obj TO db.
 APPEND 'js/main.js' TO inventory. APPEND 'image.png' TO inventory.
ENDFORM.
FORM mock_tadir USING kind TYPE c name TYPE c CHANGING row TYPE ty_object.
 ADD 1 TO queries. CLEAR row.
 ASSERT kind = 'WAPA' OR kind = 'SMIM'.
 READ TABLE db INTO row WITH KEY pgmid = 'R3TR' object = kind obj_name = name.
ENDFORM.
FORM check_auth USING kind TYPE c name TYPE c package TYPE c CHANGING allowed TYPE c.
 allowed = auth.
ENDFORM.
FORM log USING stage TYPE c state TYPE c message TYPE csequence.
 ADD 1 TO warnings.
ENDFORM.
FORM scope_url USING pv_app TYPE o2applname
               CHANGING cv_url TYPE string cv_error TYPE string.
  DATA: lv_tail TYPE string, lv_app TYPE string,
        lv_bsp TYPE c, lv_valid TYPE c.
  CLEAR: cv_url, cv_error.
  IF pv_app IS INITIAL.
    cv_error = 'BSP 애플리케이션 이름을 입력하십시오. 예: ZWEB_COMMON'. RETURN.
  ENDIF.
  IF pv_app(1) = '/'.
    lv_tail = pv_app+1.
    CONCATENATE '/SAP/BC/BSP/' lv_tail INTO cv_url.
  ELSE.
    CONCATENATE '/SAP/BC/BSP/SAP/' pv_app INTO cv_url.
  ENDIF.
  PERFORM bsp_app_from_url USING cv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> pv_app.
    cv_error = 'BSP 이름 형식 오류: 정확한 애플리케이션 이름 하나를 입력하십시오.'.
  ENDIF.
ENDFORM.
FORM scope_url_check USING pv_url TYPE string CHANGING cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lv_relative TYPE string.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  PERFORM bsp_app_from_url USING pv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> p_bsp.
    cv_error = '선택한 BSP 애플리케이션 밖의 MIME 경로입니다.'. RETURN.
  ENDIF.
  PERFORM bsp_mime_relative USING pv_url p_bsp CHANGING lv_relative cv_error.
ENDFORM.
FORM bsp_app_from_url USING pv_url TYPE string
                     CHANGING cv_app TYPE string cv_bsp TYPE c
                              cv_valid TYPE c.
  DATA: lv_url TYPE string, lv_tail TYPE string,
        lt_parts TYPE ty_lines, lv_namespace TYPE string,
        lv_name TYPE string, lv_api_name TYPE o2applname.
  CLEAR: cv_app, cv_bsp, cv_valid.
  lv_url = pv_url.
  TRANSLATE lv_url TO UPPER CASE.
  IF lv_url NP '/SAP/BC/BSP/*'.
* A noncanonical BSP path must not silently pass the scope check.
    IF lv_url CP '*/SAP/BC/BSP/*'. cv_bsp = 'X'. ENDIF.
    RETURN.
  ENDIF.
  cv_bsp = 'X'.
  lv_tail = lv_url+12.
  SPLIT lv_tail AT '/' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_namespace INDEX 1.
  READ TABLE lt_parts INTO lv_name INDEX 2.
  IF lv_namespace IS INITIAL OR lv_name IS INITIAL.
    RETURN.
  ENDIF.
* Resolve canonical, unescaped names only. Never guess encoded aliases.
  IF lv_namespace CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_' OR
     lv_name CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'.
    RETURN.
  ENDIF.
  IF lv_namespace = 'SAP'.
    cv_app = lv_name.
  ELSE.
    CONCATENATE '/' lv_namespace '/' lv_name INTO cv_app.
  ENDIF.
  lv_api_name = cv_app.
  IF lv_api_name <> cv_app.
    CLEAR cv_app. RETURN.
  ENDIF.
  cv_valid = 'X'.
ENDFORM.
FORM bsp_mime_relative USING pv_url TYPE string pv_app TYPE csequence
                      CHANGING cv_relative TYPE string
                               cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lt_parts TYPE ty_lines, lv_part TYPE string,
        lv_safe TYPE string, lv_index TYPE i, lv_count TYPE i.
  CLEAR: cv_relative, cv_error.
  PERFORM bsp_app_from_url USING pv_url
    CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid IS INITIAL OR lv_app <> pv_app.
    cv_error = 'MIME URL is outside the expected BSP application'. RETURN.
  ENDIF.
  SPLIT pv_url AT '/' INTO TABLE lt_parts.
  DESCRIBE TABLE lt_parts LINES lv_count.
* /SAP/BC/BSP/<namespace>/<app>/... : preserve every relative segment.
  LOOP AT lt_parts INTO lv_part FROM 7.
    lv_index = sy-tabix.
    IF lv_part IS INITIAL AND lv_index = lv_count. CONTINUE. ENDIF.
    IF lv_part IS INITIAL OR lv_part = '.' OR lv_part = '..'.
      cv_error = 'Empty or dot segment in BSP MIME URL'. RETURN.
    ENDIF.
    PERFORM safe_leaf USING lv_part CHANGING lv_safe.
    IF cv_relative IS INITIAL.
      cv_relative = lv_safe.
    ELSE.
      CONCATENATE cv_relative '/' lv_safe INTO cv_relative.
    ENDIF.
  ENDLOOP.
ENDFORM.
FORM segment USING pv_name TYPE c CHANGING cv_segment TYPE string.
  DATA lv_name TYPE string.
  lv_name = pv_name.
  PERFORM safe_leaf USING lv_name CHANGING cv_segment.
ENDFORM.
FORM safe_leaf USING pv_name TYPE string CHANGING cv_leaf TYPE string.
  DATA: lt_parts TYPE STANDARD TABLE OF string,
        lv_base TYPE string, lv_char TYPE c LENGTH 1,
        lv_text TYPE string, lv_empty TYPE string,
        lv_data TYPE xstring, lv_byte TYPE x LENGTH 1,
        lv_hex TYPE c LENGTH 2, lv_i TYPE i, lv_j TYPE i,
        lv_n TYPE i, lv_bytes TYPE i, lv_last TYPE i,
        lv_reserved TYPE c LENGTH 1, lv_escape TYPE c LENGTH 1.
* Preserve names, case, Unicode and extensions; no added prefix.
* Escape only Windows-invalid characters, ~ and reserved device names.
* ~ is always escaped, keeping every ~HH mapping reversible.
  CLEAR cv_leaf.
  lv_n = strlen( pv_name ).
  IF lv_n = 0.
    gv_fatal = 'Empty archive name cannot be represented'. RETURN.
  ENDIF.
  SPLIT pv_name AT '.' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_base INDEX 1.
  TRANSLATE lv_base TO UPPER CASE.
  CONDENSE lv_base.
  IF lv_base = 'CON' OR lv_base = 'PRN' OR lv_base = 'AUX' OR
     lv_base = 'NUL' OR lv_base = 'CONIN$' OR lv_base = 'CONOUT$'.
    lv_reserved = 'X'.
  ELSEIF strlen( lv_base ) = 4.
    IF lv_base(3) = 'COM' OR lv_base(3) = 'LPT'.
      IF lv_base+3(1) CA '123456789'. lv_reserved = 'X'. ENDIF.
      lv_text = lv_base+3(1).
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = 'C2B9' OR lv_data = 'C2B2' OR lv_data = 'C2B3'.
        lv_reserved = 'X'.
      ENDIF.
    ENDIF.
  ENDIF.
* Encode the whole terminal run of dots/spaces, not just its final byte.
  lv_last = lv_n.
  WHILE lv_last > 0.
    lv_i = lv_last - 1. lv_char = pv_name+lv_i(1).
    IF lv_char <> '.' AND lv_char <> space. EXIT. ENDIF.
    SUBTRACT 1 FROM lv_last.
  ENDWHILE.
  DO lv_n TIMES.
    lv_i = sy-index - 1. lv_char = pv_name+lv_i(1).
    CLEAR lv_escape.
    IF lv_char CA '<>:"/\|?*~' OR lv_char < space OR
       lv_i >= lv_last OR ( lv_i = 0 AND lv_reserved = 'X' ).
      lv_escape = 'X'.
    ENDIF.
    CONCATENATE lv_char lv_empty INTO lv_text RESPECTING BLANKS.
* DEL is rejected by the offline checker as well.
    IF lv_char BETWEEN ' ' AND '~'.
* Printable ASCII has already been classified above.
    ELSE.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = '7F'. lv_escape = 'X'. ENDIF.
    ENDIF.
    IF lv_escape = 'X'.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      lv_bytes = xstrlen( lv_data ).
      DO lv_bytes TIMES.
        lv_j = sy-index - 1. lv_byte = lv_data+lv_j(1).
        lv_hex = lv_byte.
        CONCATENATE cv_leaf '~' lv_hex INTO cv_leaf.
      ENDDO.
    ELSE.
      CONCATENATE cv_leaf lv_text INTO cv_leaf RESPECTING BLANKS.
    ENDIF.
  ENDDO.
ENDFORM.
FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
* External SAP codec double; only escaped ASCII slash used in these fixtures.
 ASSERT text = '/'. raw = '2F'.
ENDFORM.
FORM scope_add_object USING ps_object TYPE ty_object.
  DATA ls_pkg TYPE ty_package.
  READ TABLE gt_objects WITH KEY pgmid = ps_object-pgmid
    object = ps_object-object obj_name = ps_object-obj_name TRANSPORTING NO FIELDS.
  IF sy-subrc = 0. RETURN. ENDIF.
  APPEND ps_object TO gt_objects.
  ls_pkg-devclass = ps_object-devclass.
  INSERT ls_pkg INTO TABLE gt_seen_pkg.
  IF sy-subrc = 0. APPEND ls_pkg TO gt_packages. ENDIF.
ENDFORM.FORM scope_discover_bsp.
* Only one WAPA and its MIME subtree are enumerated. Owner packages are
* metadata/authorization context, never an instruction to scan a package.
  DATA: ls_app TYPE ty_object, ls_child TYPE ty_object,
        lo_mime TYPE REF TO if_mr_api, lt_files TYPE string_table,
        lt_seen TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line,
        lv_base TYPE string, lv_url TYPE string, lv_error TYPE string,
        ls_io TYPE skwf_io, lv_id TYPE tadir-obj_name,
        lv_folder TYPE boole_d, lv_auth TYPE c, ls_ref TYPE ty_web_ref,
        lo_error TYPE REF TO cx_root.
  gv_stage = 'BSP_SCOPE'.
  PERFORM scope_url USING p_bsp CHANGING lv_base gv_fatal.
  IF gv_fatal IS NOT INITIAL. RETURN. ENDIF.
  PERFORM mock_tadir USING 'WAPA' p_bsp CHANGING ls_app.
  IF sy-subrc <> 0 OR ls_app-devclass IS INITIAL.
    gv_fatal = 'BSP 애플리케이션의 TADIR 등록/개발 패키지를 찾을 수 없습니다.'. RETURN.
  ENDIF.
  PERFORM check_auth USING ls_app-object ls_app-obj_name ls_app-devclass CHANGING lv_auth.
  IF lv_auth <> 'X'. gv_fatal = 'BSP 애플리케이션 조회 권한이 없습니다.'. RETURN. ENDIF.
  gv_scope_package = ls_app-devclass.
  PERFORM scope_add_object USING ls_app.
  PERFORM segment USING p_bsp CHANGING gv_archive_name.
  CONCATENATE gv_archive_name '_export.zip' INTO gv_archive_name.
  TRY.
      lo_mime = cl_mime_repository_api=>get_api( ).
      IF lo_mime IS INITIAL. gv_fatal = 'MIME repository API unavailable'. RETURN. ENDIF.
      CALL METHOD lo_mime->get_io_for_url EXPORTING i_url = lv_base
        IMPORTING e_loio = ls_io e_is_folder = lv_folder
        EXCEPTIONS not_found = 1 OTHERS = 2.
      IF sy-subrc = 1.
* An app with Layout only is a valid BSP scope.
        WRITE: / 'BSP MIME 폴더 없음:', p_bsp. RETURN.
      ELSEIF sy-subrc <> 0 OR lv_folder <> 'X'.
        gv_fatal = 'BSP MIME 폴더 조회 실패: 추출 범위를 확정하지 못했습니다.'. RETURN.
      ENDIF.
      CALL METHOD lo_mime->file_list
        EXPORTING i_url = lv_base i_recursive_call = 'X' i_check_authority = 'X'
        IMPORTING e_files = lt_files EXCEPTIONS OTHERS = 1.
      IF sy-subrc <> 0.
        gv_fatal = 'BSP MIME 목록 조회 실패: 추출 범위를 확정하지 못했습니다.'. RETURN.
      ENDIF.
      APPEND lv_base TO lt_files.
      LOOP AT lt_files INTO lv_url.
        IF lv_url IS INITIAL. CONTINUE. ENDIF.
        IF lv_url(1) <> '/'. CONCATENATE lv_base '/' lv_url INTO lv_url. ENDIF.
        INSERT lv_url INTO TABLE lt_seen.
        IF sy-subrc <> 0. CONTINUE. ENDIF.
        PERFORM scope_url_check USING lv_url CHANGING gv_fatal.
        IF gv_fatal IS NOT INITIAL. RETURN. ENDIF.
        CLEAR: ls_io, lv_folder, ls_child, ls_ref.
        CALL METHOD lo_mime->get_io_for_url EXPORTING i_url = lv_url
          IMPORTING e_loio = ls_io e_is_folder = lv_folder EXCEPTIONS OTHERS = 1.
        IF sy-subrc <> 0 OR ls_io-objid IS INITIAL.
          gv_fatal = 'BSP MIME URL/LOIO 조회 실패: 추출 범위를 확정하지 못했습니다.'. RETURN.
        ENDIF.
        lv_id = ls_io-objid.
        PERFORM mock_tadir USING 'SMIM' lv_id CHANGING ls_child.
        IF sy-subrc <> 0 OR ls_child-devclass IS INITIAL.
* Folder nodes need not be transport objects. Unowned file bodies are
* excluded explicitly instead of guessing their package/CTS identity.
          IF lv_folder <> 'X'.
            ls_ref-object = 'WAPA'. ls_ref-obj_name = p_bsp.
            ls_ref-component = lv_url. ls_ref-target_object = 'SMIM'.
            ls_ref-target_name = lv_id. ls_ref-scope = 'OWNER_UNRESOLVED'.
            ls_ref-evidence = 'BSP_MIME_TREE_TADIR'. APPEND ls_ref TO gt_web_refs.
            gs_object = ls_app.
            PERFORM log USING 'BSP_SCOPE' 'WARNING'
              'MIME file has no verified TADIR owner; body excluded; see web references'.
          ENDIF.
          CONTINUE.
        ENDIF.
        PERFORM scope_add_object USING ls_child.
      ENDLOOP.
    CATCH cx_root INTO lo_error.
      gv_fatal = lo_error->get_text( ). RETURN.
  ENDTRY.
  SORT gt_packages BY devclass.
  SORT gt_objects BY devclass pgmid object obj_name.
  DESCRIBE TABLE gt_objects LINES gv_count.
  WRITE: / 'BSP 애플리케이션:', p_bsp, / '선택 앱과 소속 MIME 객체:', gv_count.
ENDFORM.