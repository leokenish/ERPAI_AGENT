"""Run the focused BSP folder layout release checks; SAP calls are test doubles."""
from pathlib import Path
import subprocess, json, sys
v=Path(__file__).resolve().parent
r=v.parent
def run(args):
    p=subprocess.run(args,cwd=r,text=True,capture_output=True)
    if p.returncode:
        print(p.stdout);print(p.stderr,file=sys.stderr);raise SystemExit(p.returncode)
    return p.stdout
for name,tag in [('Z_PACKAGE_EXPORT_0_4_1.abap','export'),('Z_PACKAGE_DIAG_0_7_1.abap','diag')]:
    data=json.loads(run(['node',str(v/'parse.cjs'),str(r/name)]))
    assert not data['unknown'] and not data['issues'],data
    (v/f'parse-{tag}.json').write_text(json.dumps(data,indent=2))
run([sys.executable,str(v/'structure-check.py')])
run(['node',str(v/'scope-tests.cjs')])
run(['node',str(v/'layout-tests.cjs')])
for script,out in [('bsp-tests.cjs','bsp-result.json'),('transaction-tests.cjs','transaction-result.json'),('content-filter-tests.cjs','content-filter-result.json')]:
    text=run(['node',str(v/script)])
    data=json.loads(text[text.index('{'):])
    (v/out).write_text(json.dumps(data,indent=2))
print('PASS: v700 parse, scope rules/discovery, app layout/rollback, BSP/MIME regressions, integration invariants. No live SAP execution.')
