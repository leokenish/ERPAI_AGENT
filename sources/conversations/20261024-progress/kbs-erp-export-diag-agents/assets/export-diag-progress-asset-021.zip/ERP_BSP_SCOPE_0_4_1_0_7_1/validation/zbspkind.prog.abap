REPORT zbspkind. DATA: kind TYPE c, ok TYPE c, text TYPE string. START-OF-SELECTION.
kind  =  ''. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  'X'. ASSERT text IS NOT INITIAL.
kind  =  'V'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  'X'. ASSERT text IS NOT INITIAL.
kind  =  'X'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  'X'. ASSERT text IS NOT INITIAL.
kind  =  'H'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  'F'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  'C'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  'M'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  '1'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  '?'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
kind  =  'x'. PERFORM wa_bsp_page_kind USING kind CHANGING ok text.
 ASSERT ok  =  ''. ASSERT text IS NOT INITIAL.
FORM wa_bsp_page_kind USING pv_type TYPE c
                     CHANGING cv_layout TYPE c cv_text TYPE string.
* SAP BSP PAGETYPE: blank  =  flow-logic page, V  =  view, X  =  fragment.
* H/F were incorrect assumptions. Blank is valid only with verified identity.
  CLEAR: cv_layout, cv_text.
  CASE pv_type.
    WHEN space. cv_layout  =  'X'. cv_text  =  'Flow Logic [SPACE]'.
    WHEN 'V'. cv_layout  =  'X'. cv_text  =  'View [V]'.
    WHEN 'X'. cv_layout  =  'X'. cv_text  =  'Fragment [X]'.
    WHEN OTHERS.
      CONCATENATE '지원하지 않는 유형 [' pv_type ']' INTO cv_text.
  ENDCASE.
ENDFORM.