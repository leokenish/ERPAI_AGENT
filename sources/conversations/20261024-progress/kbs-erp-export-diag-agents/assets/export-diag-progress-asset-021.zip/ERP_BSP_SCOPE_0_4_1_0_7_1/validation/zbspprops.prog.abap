REPORT zbspprops.
 TYPES: BEGIN OF o2pagkey, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 70, END OF o2pagkey.
 TYPES: BEGIN OF o2pagattr, applname TYPE c LENGTH 30, pagekey TYPE c LENGTH 70, pagetype TYPE c, END OF o2pagattr.
 DATA: key TYPE o2pagkey, wanted TYPE o2pagkey, attrs TYPE o2pagattr,
 lang TYPE sy-langu, wanted_lang TYPE sy-langu, err TYPE string.
 START-OF-SELECTION.
 PERFORM setup. attrs-pagetype  =  'X'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err IS INITIAL.
PERFORM setup. attrs-pagetype  =  ''.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err IS INITIAL.
PERFORM setup. attrs-pagetype  =  'V'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err IS INITIAL.
PERFORM setup. key-applname  =  'OTHER_APP'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGE_KEY/APPLNAME'. ASSERT err IS NOT INITIAL.
PERFORM setup. key-pagekey  =  'OTHER.HTM'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGE_KEY/PAGEKEY'. ASSERT err IS NOT INITIAL.
PERFORM setup. lang  =  'E'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'REQUESTED_LANGUAGE'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-applname  =  'OTHER_APP'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PROPERTIES/APPLNAME'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagekey  =  'OTHER.HTM'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PROPERTIES/PAGEKEY'. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR attrs.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PROPERTIES/APPLNAME'. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR key.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGE_KEY/APPLNAME'. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR lang.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'REQUESTED_LANGUAGE'. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR wanted.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS '검증 대상'. ASSERT err IS NOT INITIAL.
PERFORM setup. CLEAR wanted_lang.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS '검증 대상'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagetype  =  'H'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGETYPE'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagetype  =  'F'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGETYPE'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagetype  =  'C'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGETYPE'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagetype  =  'M'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGETYPE'. ASSERT err IS NOT INITIAL.
PERFORM setup. attrs-pagetype  =  '?'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGETYPE'. ASSERT err IS NOT INITIAL.
PERFORM setup. key-pagekey  =  'flex_work_performance_view.htm'.
 PERFORM wa_bsp_properties_check USING key lang attrs wanted wanted_lang CHANGING err.
 ASSERT err CS 'PAGE_KEY/PAGEKEY'. ASSERT err IS NOT INITIAL.
FORM setup.
 CLEAR: key, wanted, attrs, err.
 wanted-applname  =  'Z52_FLEX_TIME'. wanted-pagekey  =  'FLEX_WORK_PERFORMANCE_VIEW.HTM'.
 key  =  wanted. attrs-applname  =  wanted-applname. attrs-pagekey  =  wanted-pagekey.
 lang  =  '3'. wanted_lang  =  '3'.
 ENDFORM.
FORM wa_bsp_page_kind USING pv_type TYPE c
                     CHANGING cv_layout TYPE c cv_text TYPE string.
* SAP BSP PAGETYPE: blank  =  flow-logic page, V  =  view, X  =  fragment.
* H/F were incorrect assumptions. Blank is valid only with verified identity.
  CLEAR: cv_layout, cv_text.
  CASE pv_type.
    WHEN space. cv_layout  =  'X'. cv_text  =  'Flow Logic [SPACE]'.
    WHEN 'V'. cv_layout  =  'X'. cv_text  =  'View [V]'.
    WHEN 'X'. cv_layout  =  'X'. cv_text  =  'Fragment [X]'.
    WHEN OTHERS.
      CONCATENATE '지원하지 않는 유형 [' pv_type ']' INTO cv_text.
  ENDCASE.
ENDFORM.
FORM wa_bsp_property_error USING pv_field TYPE csequence
                                pv_actual TYPE csequence pv_expected TYPE csequence
                          CHANGING cv_error TYPE string.
  DATA: lv_actual TYPE string, lv_expected TYPE string.
  lv_actual  =  pv_actual. lv_expected  =  pv_expected.
  IF lv_actual IS INITIAL. lv_actual  =  '<공백/누락>'. ENDIF.
  IF lv_expected IS INITIAL. lv_expected  =  '<공백>'. ENDIF.
  CONCATENATE 'BSP Properties' pv_field '불일치: 실제=' lv_actual
    '/ 기대=' lv_expected INTO cv_error SEPARATED BY space.
ENDFORM.
FORM wa_bsp_properties_check USING ps_key TYPE o2pagkey pv_lang TYPE sy-langu
                                  ps_attrs TYPE o2pagattr ps_expected TYPE o2pagkey
                                  pv_expected_lang TYPE sy-langu
                            CHANGING cv_error TYPE string.
  DATA: lv_ok TYPE c, lv_text TYPE string.
  CLEAR cv_error.
  IF ps_expected-applname IS INITIAL OR ps_expected-pagekey IS INITIAL OR
     pv_expected_lang IS INITIAL.
    cv_error  =  'BSP Properties 검증 대상의 키/언어가 없습니다.'. RETURN.
  ENDIF.
  IF ps_key-applname <> ps_expected-applname.
    PERFORM wa_bsp_property_error USING 'PAGE_KEY/APPLNAME' ps_key-applname
      ps_expected-applname CHANGING cv_error. RETURN.
  ENDIF.
  IF ps_key-pagekey <> ps_expected-pagekey.
    PERFORM wa_bsp_property_error USING 'PAGE_KEY/PAGEKEY' ps_key-pagekey
      ps_expected-pagekey CHANGING cv_error. RETURN.
  ENDIF.
  IF pv_lang <> pv_expected_lang.
    PERFORM wa_bsp_property_error USING 'REQUESTED_LANGUAGE' pv_lang
      pv_expected_lang CHANGING cv_error. RETURN.
  ENDIF.
* Missing PROPERTIES must not become an allowed blank PAGETYPE.
* The API structure must independently identify the same existing page.
  IF ps_attrs-applname <> ps_expected-applname.
    PERFORM wa_bsp_property_error USING 'PROPERTIES/APPLNAME' ps_attrs-applname
      ps_expected-applname CHANGING cv_error. RETURN.
  ENDIF.
  IF ps_attrs-pagekey <> ps_expected-pagekey.
    PERFORM wa_bsp_property_error USING 'PROPERTIES/PAGEKEY' ps_attrs-pagekey
      ps_expected-pagekey CHANGING cv_error. RETURN.
  ENDIF.
  PERFORM wa_bsp_page_kind USING ps_attrs-pagetype CHANGING lv_ok lv_text.
  IF lv_ok <> 'X'.
    CONCATENATE 'BSP Properties/PAGETYPE:' lv_text
      '; 허용=SPACE(Flow Logic), V(View), X(Fragment)' INTO cv_error SEPARATED BY space.
  ENDIF.
ENDFORM.