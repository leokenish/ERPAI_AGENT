REPORT zscope_export.

TYPES: o2applname TYPE c LENGTH 30, boole_d TYPE c, string_table TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, pgmid TYPE c LENGTH 4, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF tdevc, devclass TYPE c LENGTH 30, END OF tdevc.
TYPES: BEGIN OF ty_object, pgmid TYPE tadir-pgmid, object TYPE tadir-object, obj_name TYPE tadir-obj_name,
devclass TYPE tadir-devclass, status TYPE c LENGTH 20, reason TYPE string, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
TYPES ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
DATA: p_bspm TYPE c, p_pkgm TYPE c, p_sub TYPE c, p_bsp TYPE o2applname, p_pack TYPE tadir-devclass, p_file TYPE c LENGTH 255,
p_mb TYPE i, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
gv_scope_kind TYPE c LENGTH 12, gv_scope_package TYPE tadir-devclass, gv_bsp_flat TYPE c,
gv_fatal TYPE string, gv_archive_name TYPE string, gv_stage TYPE c LENGTH 30, gv_count TYPE i,
gt_packages TYPE ty_packages, gt_seen_pkg TYPE SORTED TABLE OF ty_package WITH UNIQUE KEY devclass,
gt_objects TYPE STANDARD TABLE OF ty_object WITH DEFAULT KEY, gs_object TYPE ty_object,
err TYPE string, url TYPE string, ok TYPE c, n TYPE i, obj TYPE ty_object, pkg TYPE ty_package.

RANGES s_pack FOR p_pack.
START-OF-SELECTION.
p_bspm = 'X'. p_bsp = 'zweb_common'. PERFORM scope_mode.
ASSERT gv_bsp_flat = 'X'. ASSERT p_bsp = 'ZWEB_COMMON'. ASSERT p_sub IS INITIAL. ASSERT gv_scope_kind = 'BSP'.
PERFORM scope_selection CHANGING err. ASSERT err IS INITIAL.
CLEAR p_bspm. PERFORM scope_mode. ASSERT gv_bsp_flat IS INITIAL. ASSERT p_sub = 'X'.
PERFORM scope_selection CHANGING err. ASSERT err IS NOT INITIAL.
s_pack-sign = 'I'. s_pack-option = 'EQ'. s_pack-low = 'ZWEB'. APPEND s_pack.
PERFORM scope_selection CHANGING err. ASSERT err IS INITIAL.
FORM scope_url USING pv_app TYPE o2applname
               CHANGING cv_url TYPE string cv_error TYPE string.
  DATA: lv_tail TYPE string, lv_app TYPE string,
        lv_bsp TYPE c, lv_valid TYPE c.
  CLEAR: cv_url, cv_error.
  IF pv_app IS INITIAL.
    cv_error = 'BSP 애플리케이션 이름을 입력하십시오. 예: ZWEB_COMMON'. RETURN.
  ENDIF.
  IF pv_app(1) = '/'.
    lv_tail = pv_app+1.
    CONCATENATE '/SAP/BC/BSP/' lv_tail INTO cv_url.
  ELSE.
    CONCATENATE '/SAP/BC/BSP/SAP/' pv_app INTO cv_url.
  ENDIF.
  PERFORM bsp_app_from_url USING cv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> pv_app.
    cv_error = 'BSP 이름 형식 오류: 정확한 애플리케이션 이름 하나를 입력하십시오.'.
  ENDIF.
ENDFORM.
FORM scope_url_check USING pv_url TYPE string CHANGING cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lv_relative TYPE string.
  CLEAR cv_error.
  IF p_bspm <> 'X'. RETURN. ENDIF.
  PERFORM bsp_app_from_url USING pv_url CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid <> 'X' OR lv_app <> p_bsp.
    cv_error = '선택한 BSP 애플리케이션 밖의 MIME 경로입니다.'. RETURN.
  ENDIF.
  PERFORM bsp_mime_relative USING pv_url p_bsp CHANGING lv_relative cv_error.
ENDFORM.
FORM bsp_app_from_url USING pv_url TYPE string
                     CHANGING cv_app TYPE string cv_bsp TYPE c
                              cv_valid TYPE c.
  DATA: lv_url TYPE string, lv_tail TYPE string,
        lt_parts TYPE ty_lines, lv_namespace TYPE string,
        lv_name TYPE string, lv_api_name TYPE o2applname.
  CLEAR: cv_app, cv_bsp, cv_valid.
  lv_url = pv_url.
  TRANSLATE lv_url TO UPPER CASE.
  IF lv_url NP '/SAP/BC/BSP/*'.
* A noncanonical BSP path must not silently pass the scope check.
    IF lv_url CP '*/SAP/BC/BSP/*'. cv_bsp = 'X'. ENDIF.
    RETURN.
  ENDIF.
  cv_bsp = 'X'.
  lv_tail = lv_url+12.
  SPLIT lv_tail AT '/' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_namespace INDEX 1.
  READ TABLE lt_parts INTO lv_name INDEX 2.
  IF lv_namespace IS INITIAL OR lv_name IS INITIAL.
    RETURN.
  ENDIF.
* Resolve canonical, unescaped names only. Never guess encoded aliases.
  IF lv_namespace CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_' OR
     lv_name CN 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'.
    RETURN.
  ENDIF.
  IF lv_namespace = 'SAP'.
    cv_app = lv_name.
  ELSE.
    CONCATENATE '/' lv_namespace '/' lv_name INTO cv_app.
  ENDIF.
  lv_api_name = cv_app.
  IF lv_api_name <> cv_app.
    CLEAR cv_app. RETURN.
  ENDIF.
  cv_valid = 'X'.
ENDFORM.
FORM bsp_mime_relative USING pv_url TYPE string pv_app TYPE csequence
                      CHANGING cv_relative TYPE string
                               cv_error TYPE string.
  DATA: lv_app TYPE string, lv_bsp TYPE c, lv_valid TYPE c,
        lt_parts TYPE ty_lines, lv_part TYPE string,
        lv_safe TYPE string, lv_index TYPE i, lv_count TYPE i.
  CLEAR: cv_relative, cv_error.
  PERFORM bsp_app_from_url USING pv_url
    CHANGING lv_app lv_bsp lv_valid.
  IF lv_valid IS INITIAL OR lv_app <> pv_app.
    cv_error = 'MIME URL is outside the expected BSP application'. RETURN.
  ENDIF.
  SPLIT pv_url AT '/' INTO TABLE lt_parts.
  DESCRIBE TABLE lt_parts LINES lv_count.
* /SAP/BC/BSP/<namespace>/<app>/... : preserve every relative segment.
  LOOP AT lt_parts INTO lv_part FROM 7.
    lv_index = sy-tabix.
    IF lv_part IS INITIAL AND lv_index = lv_count. CONTINUE. ENDIF.
    IF lv_part IS INITIAL OR lv_part = '.' OR lv_part = '..'.
      cv_error = 'Empty or dot segment in BSP MIME URL'. RETURN.
    ENDIF.
    PERFORM safe_leaf USING lv_part CHANGING lv_safe.
    IF cv_relative IS INITIAL.
      cv_relative = lv_safe.
    ELSE.
      CONCATENATE cv_relative '/' lv_safe INTO cv_relative.
    ENDIF.
  ENDLOOP.
ENDFORM.
FORM segment USING pv_name TYPE c CHANGING cv_segment TYPE string.
  DATA lv_name TYPE string.
  lv_name = pv_name.
  PERFORM safe_leaf USING lv_name CHANGING cv_segment.
ENDFORM.
FORM safe_leaf USING pv_name TYPE string CHANGING cv_leaf TYPE string.
  DATA: lt_parts TYPE STANDARD TABLE OF string,
        lv_base TYPE string, lv_char TYPE c LENGTH 1,
        lv_text TYPE string, lv_empty TYPE string,
        lv_data TYPE xstring, lv_byte TYPE x LENGTH 1,
        lv_hex TYPE c LENGTH 2, lv_i TYPE i, lv_j TYPE i,
        lv_n TYPE i, lv_bytes TYPE i, lv_last TYPE i,
        lv_reserved TYPE c LENGTH 1, lv_escape TYPE c LENGTH 1.
* Preserve names, case, Unicode and extensions; no added prefix.
* Escape only Windows-invalid characters, ~ and reserved device names.
* ~ is always escaped, keeping every ~HH mapping reversible.
  CLEAR cv_leaf.
  lv_n = strlen( pv_name ).
  IF lv_n = 0.
    gv_fatal = 'Empty archive name cannot be represented'. RETURN.
  ENDIF.
  SPLIT pv_name AT '.' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_base INDEX 1.
  TRANSLATE lv_base TO UPPER CASE.
  CONDENSE lv_base.
  IF lv_base = 'CON' OR lv_base = 'PRN' OR lv_base = 'AUX' OR
     lv_base = 'NUL' OR lv_base = 'CONIN$' OR lv_base = 'CONOUT$'.
    lv_reserved = 'X'.
  ELSEIF strlen( lv_base ) = 4.
    IF lv_base(3) = 'COM' OR lv_base(3) = 'LPT'.
      IF lv_base+3(1) CA '123456789'. lv_reserved = 'X'. ENDIF.
      lv_text = lv_base+3(1).
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = 'C2B9' OR lv_data = 'C2B2' OR lv_data = 'C2B3'.
        lv_reserved = 'X'.
      ENDIF.
    ENDIF.
  ENDIF.
* Encode the whole terminal run of dots/spaces, not just its final byte.
  lv_last = lv_n.
  WHILE lv_last > 0.
    lv_i = lv_last - 1. lv_char = pv_name+lv_i(1).
    IF lv_char <> '.' AND lv_char <> space. EXIT. ENDIF.
    SUBTRACT 1 FROM lv_last.
  ENDWHILE.
  DO lv_n TIMES.
    lv_i = sy-index - 1. lv_char = pv_name+lv_i(1).
    CLEAR lv_escape.
    IF lv_char CA '<>:"/\|?*~' OR lv_char < space OR
       lv_i >= lv_last OR ( lv_i = 0 AND lv_reserved = 'X' ).
      lv_escape = 'X'.
    ENDIF.
    CONCATENATE lv_char lv_empty INTO lv_text RESPECTING BLANKS.
* DEL is rejected by the offline checker as well.
    IF lv_char BETWEEN ' ' AND '~'.
* Printable ASCII has already been classified above.
    ELSE.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = '7F'. lv_escape = 'X'. ENDIF.
    ENDIF.
    IF lv_escape = 'X'.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      lv_bytes = xstrlen( lv_data ).
      DO lv_bytes TIMES.
        lv_j = sy-index - 1. lv_byte = lv_data+lv_j(1).
        lv_hex = lv_byte.
        CONCATENATE cv_leaf '~' lv_hex INTO cv_leaf.
      ENDDO.
    ELSE.
      CONCATENATE cv_leaf lv_text INTO cv_leaf RESPECTING BLANKS.
    ENDIF.
  ENDDO.
ENDFORM.
FORM utf8 USING text TYPE string CHANGING raw TYPE xstring.
* External SAP codec double; only escaped ASCII slash used in these fixtures.
 ASSERT text = '/'. raw = '2F'.
ENDFORM.
FORM scope_mode.
  p_mb = 512. CLEAR gv_bsp_flat.
  IF p_bspm = 'X'.
    CLEAR: p_pkgm, p_sub.
    TRANSLATE p_bsp TO UPPER CASE.
    gv_scope_kind = 'BSP'. gv_bsp_flat = 'X'.
  ELSE.
    p_pkgm = 'X'. p_sub = 'X'. gv_scope_kind = 'PACKAGE'.
  ENDIF.
ENDFORM.FORM scope_selection CHANGING cv_error TYPE string.
  DATA lv_url TYPE string.
  CLEAR cv_error.
  IF p_bspm = 'X'.
    PERFORM scope_url USING p_bsp CHANGING lv_url cv_error.
  ELSEIF s_pack[] IS INITIAL.
    cv_error = '개발 패키지를 하나 이상 입력하십시오.'.
  ENDIF.
ENDFORM.