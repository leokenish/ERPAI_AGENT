REPORT zlayout.
TYPES: o2applname TYPE c LENGTH 30, ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF ty_object, object TYPE tadir-object, obj_name TYPE tadir-obj_name, devclass TYPE tadir-devclass, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
TYPES: BEGIN OF ty_file,
         path TYPE string,
         baseline TYPE string,
         devclass TYPE tadir-devclass,
         object TYPE tadir-object,
         obj_name TYPE tadir-obj_name,
         component TYPE string,
         language TYPE sy-langu,
         active_state TYPE c LENGTH 1,
         byte_length TYPE i,
         checksum_algorithm TYPE c LENGTH 20,
         checksum TYPE i,
         capability TYPE c LENGTH 20,
         check_mode TYPE c LENGTH 12,
       END OF ty_file.
TYPES im_files TYPE STANDARD TABLE OF ty_file WITH DEFAULT KEY.
TYPES im_paths TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line.
TYPES: BEGIN OF ty_header, version TYPE c LENGTH 10, tool_version TYPE c LENGTH 10,
 scope_kind TYPE c LENGTH 12, bsp_application TYPE o2applname, bsp_package TYPE tadir-devclass,
 path_layout TYPE c LENGTH 20, completeness TYPE c LENGTH 20, import_enabled TYPE c, END OF ty_header.
TYPES: BEGIN OF ty_mime_metadata, devclass TYPE tadir-devclass, loio TYPE c LENGTH 32, content_path TYPE string, END OF ty_mime_metadata.
TYPES ty_metadata TYPE STANDARD TABLE OF ty_mime_metadata WITH DEFAULT KEY.
TYPES: BEGIN OF wwwparams, name TYPE c LENGTH 20, value TYPE c LENGTH 255, END OF wwwparams.
TYPES fupararef TYPE c LENGTH 1.
TYPES: BEGIN OF ty_asset, metadata_path TYPE string, END OF ty_asset.
TYPES: BEGIN OF wa_target, selected TYPE c, file TYPE ty_file, asset TYPE ty_asset,
 wanted TYPE xstring, before TYPE xstring, bsp_map TYPE string, bsp_prefix TYPE string,
 params TYPE STANDARD TABLE OF wwwparams WITH DEFAULT KEY, END OF wa_target.
TYPES: BEGIN OF im_entry, path TYPE string, original TYPE string, size TYPE i, END OF im_entry.
TYPES im_entries TYPE SORTED TABLE OF im_entry WITH UNIQUE KEY path.
TYPES: BEGIN OF zip_blob, name TYPE string, content TYPE xstring, END OF zip_blob.
DATA: captured TYPE STANDARD TABLE OF zip_blob, blob TYPE zip_blob,
 gv_bsp_flat TYPE c, p_bsp TYPE o2applname, gv_scope_package TYPE tadir-devclass,
 gv_fatal TYPE string, gv_bytes TYPE i, gv_maxbytes TYPE i,
 gt_paths TYPE im_paths, gt_packages TYPE ty_packages, im_packages TYPE ty_packages,
 gs_object TYPE ty_object, gv_root TYPE string, gv_file_language TYPE c, gv_check_mode TYPE c LENGTH 12, gv_payload_state TYPE c,
 gt_mime_metadata TYPE ty_metadata, metadata TYPE ty_metadata, meta TYPE ty_mime_metadata,
 wa_targets TYPE STANDARD TABLE OF wa_target, target TYPE wa_target,
 im_manifest_index TYPE SORTED TABLE OF ty_file WITH UNIQUE KEY path,
 im_header TYPE ty_header, captured_header TYPE ty_header, captured_files TYPE im_files,
 f TYPE ty_file, saved_files TYPE im_files, flat_calls TYPE i, package_calls TYPE i,
 raw TYPE xstring, error TYPE string, logical TYPE string, entries TYPE im_entries,
 entry TYPE im_entry, pkg TYPE ty_package, n TYPE i.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'mock exception'. ENDMETHOD. ENDCLASS.
CLASS lcl_chars DEFINITION. PUBLIC SECTION. CONSTANTS newline TYPE c VALUE '%'. ENDCLASS.
CLASS lcl_chars IMPLEMENTATION. ENDCLASS.
CLASS cl_abap_zip DEFINITION. PUBLIC SECTION.
 TYPES: BEGIN OF t_file, name TYPE string, size TYPE i, END OF t_file.
 DATA files TYPE STANDARD TABLE OF t_file WITH DEFAULT KEY.
 METHODS add IMPORTING name TYPE string content TYPE xstring.
 METHODS save RETURNING VALUE(zip) TYPE xstring.
 CLASS-METHODS crc32 IMPORTING content TYPE xstring RETURNING VALUE(crc32) TYPE i.
ENDCLASS.
CLASS cl_abap_zip IMPLEMENTATION.
 METHOD add. DATA: f TYPE t_file, b TYPE zip_blob.
 f-name = name. f-size = xstrlen( content ). APPEND f TO files.
 b-name = name. b-content = content. APPEND b TO captured.
 ENDMETHOD.
 METHOD save. zip = '504B'. ENDMETHOD.
 METHOD crc32. crc32 = xstrlen( content ). ENDMETHOD.
ENDCLASS.
DATA go_zip TYPE REF TO cl_abap_zip.
START-OF-SELECTION.
* CASE 1 Export wraps payload and baseline; DIAG removes enclosing folder
PERFORM setup.

 logical = 'MIMEs/js/app.js'. raw = '410042'. PERFORM add_raw USING logical raw.
 logical = '.devhub/baseline/MIMEs/js/app.js'. PERFORM add_raw USING logical raw.
 logical = 'manifest.xml'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS INITIAL.
 READ TABLE captured INTO blob INDEX 1. ASSERT blob-name = 'ZWEB_COMMON/MIMEs/js/app.js'. ASSERT blob-content = raw.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.
 READ TABLE entries INTO entry WITH TABLE KEY path = 'MIMEs/js/app.js'. ASSERT sy-subrc = 0.
 ASSERT entry-original = 'ZWEB_COMMON/MIMEs/js/app.js'.
 READ TABLE entries WITH TABLE KEY path = '.devhub/baseline/MIMEs/js/app.js' TRANSPORTING NO FIELDS. ASSERT sy-subrc = 0.
* CASE 2 package ZIP stays unwrapped
PERFORM setup.
CLEAR gv_bsp_flat. logical = 'packages/ZWEB/a.js'. raw = '00'.
 PERFORM add_raw USING logical raw. logical = 'manifest.xml'. PERFORM add_raw USING logical raw.
 READ TABLE captured INTO blob INDEX 1. ASSERT blob-name = 'packages/ZWEB/a.js'.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.
* CASE 3 flat ZIP contents may also be compressed without enclosing folder
PERFORM setup.
CLEAR gv_bsp_flat.
 logical = 'pages/index/Layout/index.htm'. raw = '00'. PERFORM add_raw USING logical raw.
 logical = 'manifest.xml'. PERFORM add_raw USING logical raw. gv_bsp_flat = 'X'.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.
 READ TABLE entries WITH TABLE KEY path = 'pages/index/Layout/index.htm' TRANSPORTING NO FIELDS. ASSERT sy-subrc = 0.
* CASE 4 case collisions rejected before download
PERFORM setup.
logical = 'MIMEs/app.js'. raw = '00'. PERFORM add_raw USING logical raw.
 logical = 'MIMEs/APP.JS'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS NOT INITIAL.
* CASE 5 archive length includes enclosing app name
PERFORM setup.
DO 215 TIMES. CONCATENATE logical 'a' INTO logical. ENDDO.
 raw = '00'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS NOT INITIAL. ASSERT captured IS INITIAL.
* CASE 6 flat metadata is one catalog and preserves each owner
PERFORM setup.
PERFORM metadata_setup.
 PERFORM finalize_mime. ASSERT gv_fatal IS INITIAL. ASSERT flat_calls = 1. ASSERT package_calls = 0.
 DESCRIBE TABLE saved_files LINES n. ASSERT n = 1. READ TABLE saved_files INTO f INDEX 1.
 ASSERT f-path = 'catalog/mime-metadata.xml'. ASSERT f-devclass IS INITIAL. ASSERT f-object IS INITIAL.
 DESCRIBE TABLE metadata LINES n. ASSERT n = 3. READ TABLE metadata INTO meta INDEX 1. ASSERT meta-devclass = 'ZBUDGET'.
 READ TABLE metadata INTO meta INDEX 2. ASSERT meta-devclass = 'ZMOBILE'.
 READ TABLE metadata INTO meta INDEX 3. ASSERT meta-devclass = 'ZWEB'.
 ASSERT gs_object-devclass = 'SAVED'. ASSERT gv_root = 'saved/'.
* CASE 7 legacy metadata retains per-owner directories
PERFORM setup.
CLEAR gv_bsp_flat. PERFORM metadata_setup.
 PERFORM finalize_mime. ASSERT gv_fatal IS INITIAL. ASSERT flat_calls = 0. ASSERT package_calls = 3.
 READ TABLE saved_files INTO f INDEX 1. ASSERT f-path = 'packages/ZBUDGET/MIME/metadata.xml'. ASSERT f-devclass = 'ZBUDGET'.
* CASE 8 empty metadata does not invent a payload
PERFORM setup.
PERFORM finalize_mime. ASSERT saved_files IS INITIAL. ASSERT flat_calls = 0.
* CASE 9 flat rollback keeps app wrapper and native identity
PERFORM setup.

 gv_bsp_flat = 'X'. PERFORM backup_setup.
 PERFORM wa_backup_build CHANGING raw error. ASSERT error IS INITIAL. ASSERT raw = '504B'.
 ASSERT captured_header-path_layout = im_header-path_layout. ASSERT captured_header-bsp_package = 'ZWEB'.
 ASSERT captured_header-bsp_application = 'ZWEB_COMMON'.
 DESCRIBE TABLE captured_files LINES n. ASSERT n = 3. DESCRIBE TABLE captured LINES n. ASSERT n = 8.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/.devhub/baseline/MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4242'.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4141'.
 READ TABLE captured_files INTO f WITH KEY path = 'MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT f-devclass = 'ZMOBILE'. ASSERT f-byte_length = 2.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/manifest.xml'. ASSERT sy-subrc = 0.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/ROLLBACK_README.txt'. ASSERT sy-subrc = 0.
* CASE 10 legacy rollback remains unwrapped
PERFORM setup.

 gv_bsp_flat = ''. PERFORM backup_setup.
 PERFORM wa_backup_build CHANGING raw error. ASSERT error IS INITIAL. ASSERT raw = '504B'.
 ASSERT captured_header-path_layout = im_header-path_layout. ASSERT captured_header-bsp_package = 'ZWEB'.
 ASSERT captured_header-bsp_application = 'ZWEB_COMMON'.
 DESCRIBE TABLE captured_files LINES n. ASSERT n = 3. DESCRIBE TABLE captured LINES n. ASSERT n = 8.
 READ TABLE captured INTO blob WITH KEY name = '.devhub/baseline/MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4242'.
 READ TABLE captured INTO blob WITH KEY name = 'MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4141'.
 READ TABLE captured_files INTO f WITH KEY path = 'MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT f-devclass = 'ZMOBILE'. ASSERT f-byte_length = 2.
 READ TABLE captured INTO blob WITH KEY name = 'manifest.xml'. ASSERT sy-subrc = 0.
 READ TABLE captured INTO blob WITH KEY name = 'ROLLBACK_README.txt'. ASSERT sy-subrc = 0.
* CASE 11 BSP rollback includes page map and immutable companions
PERFORM setup.
PERFORM backup_setup. REFRESH wa_targets.
 CLEAR target. target-selected = 'X'. target-file-path = 'pages/index/Layout/index.htm'. target-file-object = 'WAPA'.
 target-file-obj_name = p_bsp. target-file-devclass = 'ZWEB'. target-file-component = 'BSP_LAYOUT'.
 target-bsp_prefix = 'pages/index/'. target-bsp_map = 'pages/page-paths.xml'.
 target-asset-metadata_path = 'pages/index/Properties.xml'. target-wanted = '4242'. target-before = '4141'.
 APPEND target TO wa_targets. f = target-file. PERFORM manifest_add.
 f-path = target-asset-metadata_path. f-component = 'BSP_ATTRIBUTES'. PERFORM manifest_add.
 f-path = 'pages/index/Event Handler/on.abap'. f-component = 'BSP_EVENT_SOURCE'. PERFORM manifest_add.
 f-path = target-bsp_map. f-component = 'BSP_PAGE_PATH_MAP'. PERFORM manifest_add.
 PERFORM wa_backup_build CHANGING raw error. ASSERT error IS INITIAL.
 DESCRIBE TABLE captured_files LINES n. ASSERT n = 5.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/pages/index/Event Handler/on.abap'. ASSERT sy-subrc = 0.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/.devhub/baseline/pages/index/Layout/index.htm'. ASSERT sy-subrc = 0. ASSERT blob-content = '4242'.

FORM setup.
 CLEAR: gv_fatal, gv_bytes, flat_calls, package_calls, raw, error, logical, gs_object, gv_root, im_header, target.
 REFRESH: captured, captured_files, metadata, entries, gt_paths, gt_packages, gt_mime_metadata, saved_files, wa_targets, im_manifest_index.
 gv_bsp_flat = 'X'. p_bsp = 'ZWEB_COMMON'. gv_scope_package = 'ZWEB'. gv_maxbytes = 536870912.
 CREATE OBJECT go_zip.
ENDFORM.
FORM metadata_setup.
 gs_object-devclass = 'SAVED'. gv_root = 'saved/'.
 meta-devclass = 'ZMOBILE'. meta-loio = 'MOBILE1'. meta-content_path = 'MIMEs/js/mobile.js'. APPEND meta TO gt_mime_metadata.
 meta-devclass = 'ZWEB'. meta-loio = 'WEB1'. meta-content_path = 'MIMEs/js/web.js'. APPEND meta TO gt_mime_metadata.
 meta-devclass = 'ZBUDGET'. meta-loio = 'BUDGET1'. meta-content_path = 'MIMEs/js/budget.js'. APPEND meta TO gt_mime_metadata.
 pkg-devclass = 'ZBUDGET'. APPEND pkg TO gt_packages. pkg-devclass = 'ZWEB'. APPEND pkg TO gt_packages.
 pkg-devclass = 'ZMOBILE'. APPEND pkg TO gt_packages.
ENDFORM.
FORM backup_setup.
 im_header-version = '0.4'. im_header-tool_version = '0.4.1'. im_header-scope_kind = 'BSP'.
 im_header-bsp_application = p_bsp. im_header-bsp_package = 'ZWEB'.
 IF gv_bsp_flat = 'X'. im_header-path_layout = 'BSP_APP_ROOT'. ENDIF.
 target-selected = 'X'. target-file-path = 'MIMEs/app.js'. target-file-object = 'SMIM'. target-file-devclass = 'ZMOBILE'.
 target-file-obj_name = 'MOBILE1'. target-asset-metadata_path = 'catalog/mime-metadata.xml'.
 target-wanted = '4242'. target-before = '4141'. APPEND target TO wa_targets.
 f = target-file. PERFORM manifest_add. CLEAR f. f-path = 'catalog/mime-metadata.xml'. PERFORM manifest_add.
 f-path = 'catalog/web-assets.xml'. PERFORM manifest_add.
ENDFORM.
FORM manifest_add.
 CONCATENATE '.devhub/baseline/' f-path INTO f-baseline. INSERT f INTO TABLE im_manifest_index.
ENDFORM.
FORM xml_flat USING app TYPE o2applname rows TYPE ty_metadata CHANGING xml TYPE xstring.
 ASSERT app = p_bsp. ADD 1 TO flat_calls. metadata = rows. xml = '3C3E'.
ENDFORM.
FORM xml_package USING owner TYPE c rows TYPE ty_metadata CHANGING xml TYPE xstring.
 DATA row TYPE ty_mime_metadata. LOOP AT rows INTO row. ASSERT row-devclass = owner. ENDLOOP.
 ADD 1 TO package_calls. xml = '3C3E'.
ENDFORM.
FORM xml_manifest USING header TYPE ty_header files TYPE im_files CHANGING xml TYPE xstring.
 captured_header = header. captured_files = files. xml = '3C3E'.
ENDFORM.
FORM add_file USING p TYPE csequence comp TYPE csequence xml TYPE xstring.
 CLEAR f. CONCATENATE gv_root p INTO f-path. f-component = comp. f-devclass = gs_object-devclass. f-object = gs_object-object.
 APPEND f TO saved_files.
ENDFORM.
FORM wa_backup_payload USING p TYPE string CHANGING data TYPE xstring err TYPE string.
 CLEAR err. data = '3C3E'.
ENDFORM.
FORM utf8 USING text TYPE string CHANGING data TYPE xstring. data = '2F'. ENDFORM.
FORM im_progress USING text TYPE csequence a TYPE i b TYPE i detail TYPE csequence. ENDFORM.
FORM im_progress_item USING text TYPE csequence a TYPE i b TYPE i detail TYPE csequence. ENDFORM.
FORM segment USING pv_name TYPE c CHANGING cv_segment TYPE string.
  DATA lv_name TYPE string.
  lv_name = pv_name.
  PERFORM safe_leaf USING lv_name CHANGING cv_segment.
ENDFORM.
FORM safe_leaf USING pv_name TYPE string CHANGING cv_leaf TYPE string.
  DATA: lt_parts TYPE STANDARD TABLE OF string,
        lv_base TYPE string, lv_char TYPE c LENGTH 1,
        lv_text TYPE string, lv_empty TYPE string,
        lv_data TYPE xstring, lv_byte TYPE x LENGTH 1,
        lv_hex TYPE c LENGTH 2, lv_i TYPE i, lv_j TYPE i,
        lv_n TYPE i, lv_bytes TYPE i, lv_last TYPE i,
        lv_reserved TYPE c LENGTH 1, lv_escape TYPE c LENGTH 1.
* Preserve names, case, Unicode and extensions; no added prefix.
* Escape only Windows-invalid characters, ~ and reserved device names.
* ~ is always escaped, keeping every ~HH mapping reversible.
  CLEAR cv_leaf.
  lv_n = strlen( pv_name ).
  IF lv_n = 0.
    gv_fatal = 'Empty archive name cannot be represented'. RETURN.
  ENDIF.
  SPLIT pv_name AT '.' INTO TABLE lt_parts.
  READ TABLE lt_parts INTO lv_base INDEX 1.
  TRANSLATE lv_base TO UPPER CASE.
  CONDENSE lv_base.
  IF lv_base = 'CON' OR lv_base = 'PRN' OR lv_base = 'AUX' OR
     lv_base = 'NUL' OR lv_base = 'CONIN$' OR lv_base = 'CONOUT$'.
    lv_reserved = 'X'.
  ELSEIF strlen( lv_base ) = 4.
    IF lv_base(3) = 'COM' OR lv_base(3) = 'LPT'.
      IF lv_base+3(1) CA '123456789'. lv_reserved = 'X'. ENDIF.
      lv_text = lv_base+3(1).
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = 'C2B9' OR lv_data = 'C2B2' OR lv_data = 'C2B3'.
        lv_reserved = 'X'.
      ENDIF.
    ENDIF.
  ENDIF.
* Encode the whole terminal run of dots/spaces, not just its final byte.
  lv_last = lv_n.
  WHILE lv_last > 0.
    lv_i = lv_last - 1. lv_char = pv_name+lv_i(1).
    IF lv_char <> '.' AND lv_char <> space. EXIT. ENDIF.
    SUBTRACT 1 FROM lv_last.
  ENDWHILE.
  DO lv_n TIMES.
    lv_i = sy-index - 1. lv_char = pv_name+lv_i(1).
    CLEAR lv_escape.
    IF lv_char CA '<>:"/\|?*~' OR lv_char < space OR
       lv_i >= lv_last OR ( lv_i = 0 AND lv_reserved = 'X' ).
      lv_escape = 'X'.
    ENDIF.
    CONCATENATE lv_char lv_empty INTO lv_text RESPECTING BLANKS.
* DEL is rejected by the offline checker as well.
    IF lv_char BETWEEN ' ' AND '~'.
* Printable ASCII has already been classified above.
    ELSE.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      IF lv_data = '7F'. lv_escape = 'X'. ENDIF.
    ENDIF.
    IF lv_escape = 'X'.
      PERFORM utf8 USING lv_text CHANGING lv_data.
      lv_bytes = xstrlen( lv_data ).
      DO lv_bytes TIMES.
        lv_j = sy-index - 1. lv_byte = lv_data+lv_j(1).
        lv_hex = lv_byte.
        CONCATENATE cv_leaf '~' lv_hex INTO cv_leaf.
      ENDDO.
    ELSE.
      CONCATENATE cv_leaf lv_text INTO cv_leaf RESPECTING BLANKS.
    ENDIF.
  ENDDO.
ENDFORM.
FORM scope_zip_path USING pv_path TYPE csequence CHANGING cv_path TYPE string.
* Only the ZIP entry has the enclosing app folder; manifest paths do not.
  DATA lv_app TYPE string.
  cv_path = pv_path.
  IF gv_bsp_flat <> 'X'. RETURN. ENDIF.
  PERFORM segment USING p_bsp CHANGING lv_app.
  CONCATENATE lv_app '/' pv_path INTO cv_path.
ENDFORM.
FORM mime_metadata_path USING pv_package TYPE c
                       CHANGING cv_path TYPE string.
  DATA lv_pkg TYPE string.
  IF gv_bsp_flat = 'X'.
    cv_path = 'catalog/mime-metadata.xml'. RETURN.
  ENDIF.
  PERFORM segment USING pv_package CHANGING lv_pkg.
  CONCATENATE 'packages/' lv_pkg '/MIME/metadata.xml' INTO cv_path.
ENDFORM.
FORM im_index_zip USING po_zip TYPE REF TO cl_abap_zip
                  CHANGING ct_entries TYPE im_entries.
  DATA: ls_zip TYPE cl_abap_zip=>t_file, ls_entry TYPE im_entry,
        lt_raw TYPE im_entries, lt_case TYPE im_paths,
        lv_count TYPE i, lv_total TYPE i, lv_manifests TYPE i, lv_progress TYPE i,
        lv_n TYPE i, lv_start TYPE i, lv_skipped TYPE i,
        lv_name TYPE string, lv_key TYPE string, lv_prefix TYPE string,
        lv_error TYPE string, lv_ignore TYPE c, lv_dir TYPE c,
        lv_actual TYPE c LENGTH 20, lv_limit TYPE c LENGTH 20.
  REFRESH ct_entries.
  DESCRIBE TABLE po_zip->files LINES lv_count.
  PERFORM im_entry_limit USING lv_count 0 lv_name CHANGING gv_fatal.
  IF gv_fatal IS NOT INITIAL. RETURN. ENDIF.
  WRITE: / 'ZIP 전체 항목 수:', lv_count, '(폴더와 baseline 사본 포함)'.
* First resolve the manifest prefix from directory metadata only.
* No GET/decompression is performed here, including for .git pack files.
  PERFORM im_progress USING '압축 항목 검사' 0 lv_count space.
  LOOP AT po_zip->files INTO ls_zip.
    lv_progress = sy-tabix.
    PERFORM im_progress_item USING '압축 항목 검사' lv_progress lv_count ls_zip-name.
    lv_name = ls_zip-name. lv_n = strlen( lv_name ). CLEAR lv_dir.
    IF ls_zip-size < 0.
      PERFORM im_entry_limit USING lv_count ls_zip-size lv_name CHANGING gv_fatal.
      RETURN.
    ENDIF.
    IF lv_n > 0.
      lv_start = lv_n - 1.
      IF lv_name+lv_start(1) = '/'.
        lv_name = lv_name(lv_start). lv_dir = 'X'.
      ENDIF.
    ENDIF.
    PERFORM im_safe_path USING lv_name CHANGING lv_error.
    IF lv_error IS NOT INITIAL.
      CONCATENATE lv_error lv_name INTO gv_fatal SEPARATED BY space. RETURN.
    ENDIF.
    IF lv_dir = 'X'. CONTINUE. ENDIF.
    lv_key = lv_name. TRANSLATE lv_key TO UPPER CASE.
    INSERT lv_key INTO TABLE lt_case.
    IF sy-subrc <> 0.
      gv_fatal = 'Duplicate/case-colliding ZIP entry'. RETURN.
    ENDIF.
    ls_entry-path = lv_name. ls_entry-original = lv_name. ls_entry-size = ls_zip-size.
    INSERT ls_entry INTO TABLE lt_raw.
    IF lv_name = 'manifest.xml' OR lv_name CP '*/manifest.xml'.
* Git-internal files cannot establish an export manifest root.
      IF lv_key CP '.GIT/*' OR lv_key CS '/.GIT/' OR
         lv_key CP '__MACOSX/*'. CONTINUE. ENDIF.
      ADD 1 TO lv_manifests.
      lv_n = strlen( lv_name ) - 12. lv_prefix = lv_name(lv_n).
    ENDIF.
  ENDLOOP.
  IF lv_manifests <> 1.
    gv_fatal = 'ZIP must contain exactly one manifest.xml outside Git metadata'. RETURN.
  ENDIF.
  DESCRIBE TABLE lt_raw LINES lv_count.
  PERFORM im_progress USING '압축 경로 색인' 0 lv_count space.
  LOOP AT lt_raw INTO ls_entry.
    lv_progress = sy-tabix.
    PERFORM im_progress_item USING '압축 경로 색인' lv_progress lv_count ls_entry-path.
    PERFORM im_git_metadata USING ls_entry-path lv_prefix CHANGING lv_ignore.
    IF lv_ignore = 'X'. ADD 1 TO lv_skipped. CONTINUE. ENDIF.
* Limits still apply to every remaining file, including baseline copies.
    PERFORM im_entry_limit USING lv_count ls_entry-size ls_entry-path CHANGING gv_fatal.
    IF gv_fatal IS NOT INITIAL. RETURN. ENDIF.
    lv_total = lv_total + ls_entry-size.
    IF lv_total > gv_maxbytes.
      WRITE lv_total TO lv_actual NO-GROUPING. CONDENSE lv_actual.
      WRITE gv_maxbytes TO lv_limit NO-GROUPING. CONDENSE lv_limit.
      CONCATENATE 'ZIP_TOTAL_LIMIT: Git 제외 압축 해제 누적 용량(bytes)=' lv_actual
        ' / 허용(bytes)=' lv_limit ' / 확인 중인 파일=' ls_entry-path INTO gv_fatal. RETURN.
    ENDIF.
    IF ls_entry-path CP '__MACOSX/*'. CONTINUE. ENDIF.
    lv_n = strlen( lv_prefix ).
    IF lv_n > 0.
      IF strlen( ls_entry-path ) <= lv_n. CONTINUE. ENDIF.
      IF ls_entry-path(lv_n) <> lv_prefix. CONTINUE. ENDIF.
      ls_entry-path = ls_entry-path+lv_n.
    ENDIF.
    IF ls_entry-path = '.DS_Store' OR ls_entry-path CP '*/.DS_Store'. CONTINUE. ENDIF.
    INSERT ls_entry INTO TABLE ct_entries.
  ENDLOOP.
  WRITE: / 'SAP 비교에서 제외한 Git 관리 파일:', lv_skipped,
    / '검사 대상 압축 해제 누적 용량(bytes):', lv_total.
ENDFORM.
FORM im_safe_path USING pv_path TYPE string CHANGING cv_error TYPE string.
  DATA: lt_parts TYPE ty_lines, lv_part TYPE string, lv_n TYPE i, lv_char TYPE c.
  CLEAR cv_error.
  lv_n = strlen( pv_path ).
  IF lv_n = 0 OR lv_n > 512.
    cv_error = 'Empty path or path exceeds 512 characters'. RETURN.
  ENDIF.
  lv_n = lv_n - 1.
  IF pv_path(1) = '/' OR pv_path+lv_n(1) = '/' OR
     pv_path CS '\' OR pv_path CS ':'.
    cv_error = 'Absolute/drive/backslash path is not allowed'. RETURN.
  ENDIF.
  FIND REGEX '[[:cntrl:]]' IN pv_path.
  IF sy-subrc = 0.
    cv_error = 'Control character in ZIP path'. RETURN.
  ENDIF.
  SPLIT pv_path AT '/' INTO TABLE lt_parts.
  LOOP AT lt_parts INTO lv_part.
    IF lv_part IS INITIAL OR lv_part = '.' OR lv_part = '..'.
      cv_error = 'Empty/dot/traversal path segment'. RETURN.
    ENDIF.
    lv_n = strlen( lv_part ) - 1.
    lv_char = lv_part+lv_n(1).
    IF lv_char = space OR lv_char = '.'.
      cv_error = 'Trailing dot/space in path segment'. RETURN.
    ENDIF.
  ENDLOOP.
ENDFORM.
FORM im_git_metadata USING pv_name TYPE string pv_prefix TYPE string
                     CHANGING cv_ignore TYPE c.
* Only workspace root metadata. A .git segment inside a package asset
* is not silently dropped. Prefix is the verified manifest directory.
  DATA: lv_name TYPE string, lv_n TYPE i.
  CLEAR cv_ignore.
  lv_name = pv_name. TRANSLATE lv_name TO UPPER CASE.
  IF lv_name = '.GIT' OR lv_name CP '.GIT/*'.
    cv_ignore = 'X'. RETURN.
  ENDIF.
  lv_n = strlen( pv_prefix ).
  IF lv_n > 0 AND strlen( pv_name ) > lv_n.
    IF pv_name(lv_n) = pv_prefix.
      lv_name = pv_name+lv_n. TRANSLATE lv_name TO UPPER CASE.
      IF lv_name = '.GIT' OR lv_name CP '.GIT/*'. cv_ignore = 'X'. ENDIF.
    ENDIF.
  ENDIF.
ENDFORM.
FORM im_entry_limit USING pv_count TYPE i pv_size TYPE i pv_name TYPE string
                    CHANGING cv_error TYPE string.
  DATA: lv_count TYPE c LENGTH 20, lv_size TYPE c LENGTH 20.
  CLEAR cv_error.
  WRITE pv_count TO lv_count NO-GROUPING. CONDENSE lv_count.
  WRITE pv_size TO lv_size NO-GROUPING. CONDENSE lv_size.
  IF pv_count > 100000.
    CONCATENATE 'ZIP_ENTRY_COUNT_LIMIT: 전체 항목 수=' lv_count
      ' / 허용=100000 (폴더와 baseline 사본 포함)' INTO cv_error.
  ELSEIF pv_size < 0.
    CONCATENATE 'ZIP_INVALID_ENTRY_SIZE: 음수 용량(bytes)=' lv_size
      ' / ZIP 헤더 또는 지원 형식을 확인하십시오. 파일=' pv_name INTO cv_error.
  ELSEIF pv_size > 16777216.
    CONCATENATE 'ZIP_ENTRY_SIZE_LIMIT: 압축 해제 후 개별 파일 용량(bytes)=' lv_size
      ' / 허용=16777216 (16 MiB) / 파일=' pv_name INTO cv_error.
  ENDIF.
ENDFORM.
FORM add_raw USING pv_path TYPE string pv_data TYPE xstring.
  DATA: lv_size TYPE i,
        lv_total TYPE i,
        lv_path_key TYPE string, lv_zip_path TYPE string.
  IF gv_fatal IS NOT INITIAL.
    RETURN.
  ENDIF.
  PERFORM scope_zip_path USING pv_path CHANGING lv_zip_path.
  IF strlen( lv_zip_path ) > 220.
    gv_fatal = 'Archive path exceeds 220 characters; no truncation used'.
    RETURN.
  ENDIF.
* Windows paths are case-insensitive: reject collisions before download.
  lv_path_key = pv_path.
  TRANSLATE lv_path_key TO UPPER CASE.
  INSERT lv_path_key INTO TABLE gt_paths.
  IF sy-subrc <> 0.
    CONCATENATE 'Duplicate/case-colliding archive path:' pv_path INTO gv_fatal
      SEPARATED BY space.
    RETURN.
  ENDIF.
  lv_size = xstrlen( pv_data ).
  IF lv_size > 16777216.
    gv_fatal = 'File exceeds 16 MiB validation-build limit'.
    RETURN.
  ENDIF.
  lv_total = gv_bytes + lv_size.
  IF lv_total > gv_maxbytes.
    gv_fatal = 'Uncompressed ZIP budget exceeded; narrow the selection'.
    RETURN.
  ENDIF.
  CALL METHOD go_zip->add EXPORTING name = lv_zip_path content = pv_data.
  gv_bytes = gv_bytes + lv_size.
ENDFORM.
FORM finalize_mime.
  DATA: lt_meta TYPE STANDARD TABLE OF ty_mime_metadata,
        ls_meta TYPE ty_mime_metadata, ls_pkg TYPE ty_package,
        ls_saved_object TYPE ty_object, lv_saved_root TYPE string,
        lv_xml TYPE xstring, lv_path TYPE string.
  ls_saved_object = gs_object. lv_saved_root = gv_root.
  SORT gt_mime_metadata BY devclass loio.
  IF gv_bsp_flat = 'X'.
* One catalog for the app; each entry retains its actual DEVCLASS/LOIO.
    IF gt_mime_metadata IS NOT INITIAL.
      CLEAR: gs_object, gv_root, gv_file_language, gv_check_mode.
      gv_payload_state = 'U'.
      PERFORM mime_metadata_path USING gv_scope_package CHANGING lv_path.
      PERFORM xml_flat USING p_bsp gt_mime_metadata CHANGING lv_xml.
      PERFORM add_file USING lv_path 'MIME_METADATA' lv_xml.
    ENDIF.
  ELSE.
  LOOP AT gt_packages INTO ls_pkg.
    REFRESH lt_meta.
    LOOP AT gt_mime_metadata INTO ls_meta WHERE devclass = ls_pkg-devclass.
      APPEND ls_meta TO lt_meta.
    ENDLOOP.
    IF lt_meta IS INITIAL. CONTINUE. ENDIF.
    CLEAR: gs_object, gv_root, gv_file_language, gv_check_mode.
    gs_object-devclass = ls_pkg-devclass. gv_payload_state = 'U'.
    PERFORM mime_metadata_path USING ls_pkg-devclass CHANGING lv_path.
    PERFORM xml_package USING ls_pkg-devclass lt_meta CHANGING lv_xml.
    PERFORM add_file USING lv_path 'MIME_METADATA' lv_xml.
    IF gv_fatal IS NOT INITIAL. EXIT. ENDIF.
  ENDLOOP.
  ENDIF.
  gs_object = ls_saved_object. gv_root = lv_saved_root.
  CLEAR: gv_file_language, gv_payload_state, gv_check_mode.
ENDFORM.
FORM wa_backup_build CHANGING cv_raw TYPE xstring cv_error TYPE string.
  DATA: lo_zip TYPE REF TO cl_abap_zip, lt_files TYPE im_files,
        lt_paths TYPE im_paths, lv_path TYPE string, ls_file TYPE ty_file,
        ls_target TYPE wa_target, lv_a TYPE xstring, lv_b TYPE xstring,
        lv_meta TYPE xstring, lv_text TYPE string, ls_header TYPE ty_header,
        lt_params TYPE STANDARD TABLE OF wwwparams, ls_param TYPE wwwparams,
        lt_api TYPE STANDARD TABLE OF fupararef, lv_name TYPE string, lv_size TYPE i, lv_prefix_len TYPE i,
        lo_error TYPE REF TO cx_root, lv_zip_path TYPE string.
  CLEAR: cv_raw, cv_error.
  TRY.
      CREATE OBJECT lo_zip.
      lv_path = 'catalog/web-assets.xml'. INSERT lv_path INTO TABLE lt_paths.
      LOOP AT wa_targets INTO ls_target WHERE selected = 'X'.
        INSERT ls_target-file-path INTO TABLE lt_paths.
        INSERT ls_target-asset-metadata_path INTO TABLE lt_paths.
        IF ls_target-file-object = 'WAPA'.
          INSERT ls_target-bsp_map INTO TABLE lt_paths.
          lv_prefix_len = strlen( ls_target-bsp_prefix ).
          LOOP AT im_manifest_index INTO ls_file.
            IF strlen( ls_file-path ) < lv_prefix_len. CONTINUE. ENDIF.
            IF ls_file-path(lv_prefix_len) = ls_target-bsp_prefix AND
               ls_file-object = 'WAPA' AND ls_file-obj_name = ls_target-file-obj_name.
              lv_path = ls_file-path. INSERT lv_path INTO TABLE lt_paths.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDLOOP.
      LOOP AT lt_paths INTO lv_path.
        CLEAR: lv_a, lv_b, ls_file.
        READ TABLE im_manifest_index INTO ls_file WITH TABLE KEY path = lv_path.
        IF sy-subrc <> 0. cv_error = '백업용 manifest 항목 누락'. RETURN. ENDIF.
        READ TABLE wa_targets INTO ls_target WITH KEY selected = 'X' file-path = lv_path.
        IF sy-subrc = 0.
* Restore package A=forward wanted B=pre-apply current. After a successful
* forward save, A matches SAP; failed/unattempted rows are already equal to B.
          lv_a = ls_target-wanted. lv_b = ls_target-before.
        ELSE.
          PERFORM wa_backup_payload USING lv_path CHANGING lv_a cv_error.
          IF cv_error IS NOT INITIAL. RETURN. ENDIF.
* W3MI's expected filesize must describe the forward content, not the old
* content. All other WWWPARAMS and the original API evidence are preserved.
          READ TABLE wa_targets INTO ls_target
            WITH KEY selected = 'X' asset-metadata_path = lv_path file-object = 'W3MI'.
          IF sy-subrc = 0.
            lt_params = ls_target-params. REFRESH lt_api.
            ASSERT 1 = 2.
            lv_size = xstrlen( ls_target-wanted ).
            LOOP AT lt_params INTO ls_param.
              lv_name = ls_param-name. TRANSLATE lv_name TO LOWER CASE.
              IF lv_name = 'filesize'.
                WRITE lv_size TO ls_param-value LEFT-JUSTIFIED NO-GROUPING.
                CONDENSE ls_param-value. MODIFY lt_params FROM ls_param.
              ENDIF.
            ENDLOOP.
            ASSERT 1 = 2.
          ENDIF.
          lv_b = lv_a.
        ENDIF.
        ls_file-byte_length = xstrlen( lv_a ).
        CALL METHOD cl_abap_zip=>crc32 EXPORTING content = lv_a RECEIVING crc32 = ls_file-checksum.
        APPEND ls_file TO lt_files.
        PERFORM scope_zip_path USING ls_file-baseline CHANGING lv_zip_path.
        CALL METHOD lo_zip->add EXPORTING name = lv_zip_path content = lv_a.
        PERFORM scope_zip_path USING ls_file-path CHANGING lv_zip_path.
        CALL METHOD lo_zip->add EXPORTING name = lv_zip_path content = lv_b.
      ENDLOOP.
      ls_header = im_header. ls_header-completeness = 'PARTIAL'.
      CLEAR ls_header-import_enabled.
      PERFORM xml_manifest USING ls_header lt_files CHANGING lv_meta.
      PERFORM scope_zip_path USING 'manifest.xml' CHANGING lv_zip_path.
        CALL METHOD lo_zip->add EXPORTING name = lv_zip_path content = lv_meta.
      lv_text = 'DIAG 0.7.1 rollback package. Only selected existing MIME/BSP Layout assets are write candidates.'.
      CONCATENATE lv_text 'Upload to DIAG with the same PACKAGE/BSP selection, BSP name and SID/client; choose Web assets.'
        'Content B is the verified pre-apply server data. Baseline A is the forward intended data.'
        'Unchanged or unattempted items require no write. Concurrent later changes remain blocked.'
        'Catalog identity comes from the original Export; this is a partial restore package, not a new Export.'
        'BSP restoration requires page activation. Resolve pending changes of the selected page/shared definition first.'
        INTO lv_text SEPARATED BY lcl_chars=>newline.
      PERFORM utf8 USING lv_text CHANGING lv_meta.
      PERFORM scope_zip_path USING 'ROLLBACK_README.txt' CHANGING lv_zip_path.
        CALL METHOD lo_zip->add EXPORTING name = lv_zip_path content = lv_meta.
      cv_raw = lo_zip->save( ).
      IF xstrlen( cv_raw ) > gv_maxbytes. cv_error = '백업 ZIP이 업로드 제한을 초과합니다. 선택 파일 수를 줄이십시오.'. ENDIF.
    CATCH cx_root INTO lo_error. cv_error = lo_error->get_text( ).
  ENDTRY.
ENDFORM.