from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parent.parent
ex=(root/'Z_PACKAGE_EXPORT_0_4_1.abap').read_text()
di=(root/'Z_PACKAGE_DIAG_0_7_1.abap').read_text()
oldex=(root/'previous/Z_PACKAGE_EXPORT_0_4_0.abap').read_text()
olddi=(root/'previous/Z_PACKAGE_DIAG_0_7_0.abap').read_text()
def forms(s):return dict(re.findall(r'^(FORM (\w+)\b.*?^ENDFORM\.)',s,re.M|re.S)[i][::-1] for i in range(len(re.findall(r'^FORM ',s,re.M))))
ef,df,oe,od=map(forms,[ex,di,oldex,olddi])
checks=[]
def check(name,yes):
    assert yes,name
    checks.append(name)
common=['scope_bsp_root','scope_zip_path','mime_metadata_path','finalize_mime','mime_output_path','scope_url','scope_url_check','scope_screen','scope_add_object','scope_discover_bsp']
for f in common:check(f+' identical in Export/DIAG',ef[f]==df[f])
for label,s,fs in [('Export',ex,ef),('DIAG',di,df)]:
    check(label+' conditional package field',not re.search(r'(?:p_pack|s_pack)[^.]*OBLIGATORY',s))
    check(label+' mode reset in OUTPUT and START',s.count('PERFORM scope_mode.')>=3)
    check(label+' BSP branches before package query',fs['discover'].index('scope_discover_bsp')<fs['discover'].index('SELECT devclass'))
    check(label+' only two bounded TADIR lookups',len(re.findall(r'SELECT SINGLE',fs['scope_discover_bsp']))==2)
    check(label+' MIME authority enabled',"i_check_authority = 'X'" in fs['scope_discover_bsp'])
    check(label+' namespace/URL guard before LOIO',fs['scope_discover_bsp'].index('scope_url_check')<fs['scope_discover_bsp'].index('CLEAR: ls_io'))
    check(label+' serializers barred outside BSP scope',"gs_object-object <> 'WAPA' AND gs_object-object <> 'SMIM'" in fs['export_object'])
    check(label+' snapshot MIME ownership rechecked', 'scope_url_check' in fs['smim_bsp_scope'] and 'scope_url_check' in fs['mime_output_path'])
    check(label+' real owner packages used', 'ls_pkg-devclass = ps_object-devclass' in fs['scope_add_object'])
    check(label+' baseline add logic unchanged',fs['add_file']==(oe if label=='Export' else od)['add_file'])
check('same ty_header serializer/reader schema',re.search(r'TYPES: BEGIN OF ty_header,.*?END OF ty_header\.',ex,re.S).group()==re.search(r'TYPES: BEGIN OF ty_header,.*?END OF ty_header\.',di,re.S).group())
check('Export format explicitly advanced',"gs_header-version = '0.3'" in ef['finalize'])
check('BSP export no stale package selection',"lt_selection = s_pack[]" in ef['finalize'] and 'package_selection = lt_selection' in ef['finalize'])
check('Export original type fallback corrected',"lv_type = space OR lv_type = 'V' OR lv_type = 'X'" in ef['bsp_page'])
check('DIAG web only even saved variants',"CLEAR: p_all, p_src, p_xml. p_mime = 'X'." in df['scope_mode'])
check('DIAG package syntax pipeline skipped in BSP mode',"IF gv_fatal IS INITIAL AND p_bspm <> 'X'.\n        PERFORM im_progress USING 'ABAP 문법 검사 준비'" in di)
check('scope validated before SAP discovery',di.index('PERFORM im_read_manifest.')<di.index('        PERFORM discover.') and 'PERFORM im_scope_manifest' in df['im_read_manifest'])
check('exact current object before apply preparation', 'PERFORM im_scope_current' in df['wa_prepare'])
for f in ['wa_read','wa_put','wa_bsp_context']:check(f+' scope enforced', 'PERFORM wa_scope_check' in df[f])
check('native BSP key matches selected app', 'ps_target-bsp_key-applname <> p_bsp' in df['wa_scope_check'])
check('fresh probe receives scope','WITH p_pkgm = p_pkgm WITH p_bspm = p_bspm WITH p_bsp = p_bsp' in df['wa_bsp_fetch_version'])
check('backup preserves source scope','ls_header = im_header.' in df['wa_backup_build'])
check('JSON and journal contain scope','export_scope_kind' in df['im_json_build'] and 'export_scope = im_header' in df['wa_log_raw'])
for n in ['wa_bsp_save','wa_bsp_activate','wa_bsp_one','wa_bsp_resume_check','wa_bsp_guard','wa_bsp_so2_content','wa_lock','wa_cts','wa_one','wa_bsp_companions','im_triplet']:
    check(n+' successful baseline logic retained',df[n]==od[n])
check('no optional DDIC version/key aliases in either program',not re.search(r'\bTYPE\s+(so2_version|seu_objkey|swbme_error_tab)\b',ex+di,re.I))
check('no broad app activation',not re.search(r'cl_o2_api_application\s*=>\s*activate',di,re.I))

check('new BSP layout marker', "gs_header-version = '0.4'." in ef['finalize'] and "gs_header-path_layout = 'BSP_APP_ROOT'." in ef['finalize'])
check('package README loop excluded for flat BSP', "IF gv_bsp_flat <> 'X'.\n  LOOP AT gt_packages" in ef['finalize'])
check('export ZIP wrapping before length check',ef['add_raw'].index('scope_zip_path')<ef['add_raw'].index('strlen( lv_zip_path )'))
check('DIAG resets prior layout', 'gv_bsp_flat' in df['im_reset'])
check('all rollback ZIP entries wrapped', df['wa_backup_build'].count('PERFORM scope_zip_path')==4 and not re.search(r'lo_zip->add EXPORTING name = (?!lv_zip_path)', df['wa_backup_build']))
check('addition and manifest use same root decision', 'PERFORM im_payload_path' in df['im_compare'] and 'PERFORM im_payload_path' in df['im_read_manifest'])
check('flat WAPA constrained to pages', "CONCATENATE lv_root 'pages/' INTO lv_root." in df['im_scope_file'])
check('legacy snapshot root remains header controlled','gv_bsp_flat' not in df['scope_mode'] and 'gv_bsp_flat' in df['im_manifest_compat'])
for n in ['wa_bsp_prepare','wa_prepare','wa_bsp_companions','wa_scope_check','wa_backup_payload','im_index_zip','wa_metadata','wa_put','wa_read']:
    check(n+' unchanged control logic',df[n]==od[n])
for label,old,new in [('export',oe,ef),('diag',od,df)]:
    def norm(s):return s.replace('0.7.0','0.7.1').replace('0.4.0','0.4.1')
    result={'changed':[n for n in old if n in new and norm(old[n])!=norm(new[n])],
            'added':[n for n in new if n not in old], 'removed':[n for n in old if n not in new]}
    (root/'validation'/f'{label}-form-diff.json').write_text(json.dumps(result,indent=2))
result={'count':len(checks),'checks':checks,'result':'PASS','scope':'source integration invariants; SAP runtime and selection screen rendering not executed'}
(root/'validation/structure-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'count':len(checks),'result':'PASS'}))
