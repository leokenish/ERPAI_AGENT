REPORT zcontent.
TYPES: BEGIN OF im_result, path TYPE c LENGTH 255, component TYPE c LENGTH 80,
 pair_ab TYPE c LENGTH 12, pair_ac TYPE c LENGTH 12, pair_cb TYPE c LENGTH 12, END OF im_result.
TYPES x255 TYPE x LENGTH 255.
DATA: p_diff TYPE c, p_all TYPE c, p_src TYPE c, p_xml TYPE c, p_mime TYPE c,
 row TYPE im_result, match TYPE c, raw TYPE xstring, ok TYPE c,
 bytes TYPE STANDARD TABLE OF x255, byte TYPE x255.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/x.js'. row-component = 'MIME_CONTENT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_src = 'X'.
row-path = 'p/x.js'. row-component = 'MIME_CONTENT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = ''.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_src = 'X'.
row-path = 'p/x.abap'. row-component = 'SOURCE'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/x.abap'. row-component = 'SOURCE'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = ''.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/page.htm'. row-component = 'BSP_LAYOUT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_xml = 'X'.
row-path = 'p/xml.xml'. row-component = 'MIME_CONTENT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = ''.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/xml.xml'. row-component = 'MIME_CONTENT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_xml = 'X'.
row-path = 'p/metadata.xml'. row-component = 'MIME_METADATA'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/metadata.xml'. row-component = 'MIME_METADATA'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = ''.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'p/new.js'. row-component = ''.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'packages/Z/mime/new.png'. row-component = ''.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'MIMEs/font.woff2'. row-component = ''.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'catalog/mime-metadata.xml'. row-component = 'MIME_METADATA'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = ''.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_mime = 'X'.
row-path = 'pages/index/Layout/index.htm'. row-component = 'BSP_LAYOUT'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
CLEAR: p_all, p_src, p_xml, p_mime, row.
p_all = 'X'.
row-path = 'p/a.xml'. row-component = 'DDIC_DEFINITION'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
p_diff = 'X'. p_all = 'X'. CLEAR row.
row-pair_ab = '변경없음'. row-pair_ac = '수정'. row-pair_cb = '수정'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match = 'X'.
row-pair_ac = '변경없음'. row-pair_cb = '변경없음'.
PERFORM im_filter_match USING row CHANGING match. ASSERT match IS INITIAL.
REFRESH bytes. byte = '410000'. APPEND byte TO bytes.
PERFORM web_binary USING bytes 3 CHANGING raw ok. ASSERT ok = 'X'. ASSERT raw = '410000'.
PERFORM web_binary USING bytes 256 CHANGING raw ok. ASSERT ok IS INITIAL.
APPEND byte TO bytes.
PERFORM web_binary USING bytes 3 CHANGING raw ok. ASSERT ok IS INITIAL.
REFRESH bytes.
PERFORM web_binary USING bytes 0 CHANGING raw ok. ASSERT ok = 'X'. ASSERT raw IS INITIAL.
WRITE 'filter/binary: 21 cases passed'.
FORM wa_is_web USING ps_row TYPE im_result CHANGING cv_web TYPE c.
  DATA lv_path TYPE string.
  CLEAR cv_web. lv_path = ps_row-path. TRANSLATE lv_path TO LOWER CASE.
  IF ps_row-component = 'MIME_CONTENT' OR ps_row-component = 'W3MI_CONTENT' OR
     ps_row-component = 'BSP_LAYOUT'. cv_web = 'X'. RETURN. ENDIF.
  IF ps_row-component = 'MIME_METADATA' OR ps_row-component = 'W3MI_METADATA' OR
     ps_row-component = 'WEB_CATALOG' OR lv_path CP '*/metadata.xml'. RETURN. ENDIF.
* Unknown new web files remain visible for diagnosis; mapping/write guards
* still reject them. Extension/path classification is never a write key.
  IF lv_path CP '*.html' OR lv_path CP '*.htm' OR lv_path CP '*.js' OR
     lv_path CP '*.css' OR lv_path CP 'packages/*/mime/*' OR
     lv_path CP '*/mimes/*' OR lv_path CP 'mimes/*'.
    cv_web = 'X'.
  ENDIF.
ENDFORM.FORM im_filter_match USING ps_row TYPE im_result CHANGING cv_match TYPE c.
  DATA: lv_path TYPE string, lv_mime TYPE c.
  CLEAR: cv_match, lv_mime.
* A display predicate only. Unknown/blank pairs are not changes.
* Do not require every pair to change: an edit in only ZIP or only SAP
* can leave another pair unchanged. Preserve those per-pair values.
  IF p_diff = 'X'.
    IF ps_row-pair_ab <> '신규' AND ps_row-pair_ab <> '누락' AND
       ps_row-pair_ab <> '수정' AND ps_row-pair_ac <> '신규' AND
       ps_row-pair_ac <> '누락' AND ps_row-pair_ac <> '수정' AND
       ps_row-pair_cb <> '신규' AND ps_row-pair_cb <> '누락' AND
       ps_row-pair_cb <> '수정'.
      RETURN.
    ENDIF.
  ENDIF.
  IF p_all = 'X'. cv_match = 'X'. RETURN. ENDIF.
  lv_path = ps_row-path. TRANSLATE lv_path TO LOWER CASE.
  PERFORM wa_is_web USING ps_row CHANGING lv_mime.
  IF p_src = 'X'.
    IF lv_path CP '*.abap' AND lv_mime IS INITIAL.
      cv_match = 'X'.
    ENDIF.
  ELSEIF p_xml = 'X'.
    IF lv_path CP '*.xml' AND lv_mime IS INITIAL. cv_match = 'X'. ENDIF.
  ELSEIF p_mime = 'X'.
    cv_match = lv_mime.
  ENDIF.
ENDFORM.FORM web_binary USING pt_rows TYPE ANY TABLE pv_size TYPE i
                CHANGING cv_data TYPE xstring cv_ok TYPE c.
  DATA: lv_kind TYPE c, lv_chunk TYPE xstring, lv_left TYPE i,
        lv_take TYPE i, lv_len TYPE i.
  FIELD-SYMBOLS: <ls_row> TYPE ANY, <lv_value> TYPE ANY,
                 <lv_extra> TYPE ANY.
  CLEAR: cv_data, cv_ok. lv_left = pv_size.
  IF pv_size < 0 OR pv_size > 16777216. RETURN. ENDIF.
  LOOP AT pt_rows ASSIGNING <ls_row>.
    IF lv_left <= 0. RETURN. ENDIF.
    DESCRIBE FIELD <ls_row> TYPE lv_kind.
    IF lv_kind = 'u' OR lv_kind = 'v'.
      ASSIGN COMPONENT 1 OF STRUCTURE <ls_row> TO <lv_value>.
      IF sy-subrc <> 0. RETURN. ENDIF.
      ASSIGN COMPONENT 2 OF STRUCTURE <ls_row> TO <lv_extra>.
      IF sy-subrc = 0. RETURN. ENDIF.
    ELSE.
      ASSIGN <ls_row> TO <lv_value>.
    ENDIF.
    DESCRIBE FIELD <lv_value> TYPE lv_kind.
    IF lv_kind <> 'X' AND lv_kind <> 'y'. RETURN. ENDIF.
    lv_chunk = <lv_value>. lv_len = xstrlen( lv_chunk ).
    lv_take = lv_len.
    IF lv_take > lv_left. lv_take = lv_left. ENDIF.
    CONCATENATE cv_data lv_chunk(lv_take) INTO cv_data IN BYTE MODE.
    SUBTRACT lv_take FROM lv_left.
  ENDLOOP.
  IF lv_left = 0. cv_ok = 'X'. ENDIF.
ENDFORM.