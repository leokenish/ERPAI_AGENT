// Production ABAP path/ZIP-index/finalize/rollback forms. SAP XML, ZIP and
// codecs are I/O doubles; no SAP server or repository writes are executed.
const fs=require('fs'),path=require('path');
const {Transpiler}=require('@abaplint/transpiler'),{ABAP}=require('@abaplint/runtime');
const root=path.resolve(__dirname,'..');
const ex=fs.readFileSync(path.join(root,'Z_PACKAGE_EXPORT_0_4_1.abap'),'utf8');
const di=fs.readFileSync(path.join(root,'Z_PACKAGE_DIAG_0_7_1.abap'),'utf8');
const form=(n,s=di)=>s.match(new RegExp('^FORM '+n+'\\b[\\s\\S]*?^ENDFORM\\.','m'))[0];
let finalize=form('finalize_mime',ex).replace(/CALL TRANSFORMATION id SOURCE application = p_bsp\s+entries = gt_mime_metadata RESULT XML lv_xml\./,
 'PERFORM xml_flat USING p_bsp gt_mime_metadata CHANGING lv_xml.').replace(/CALL TRANSFORMATION id SOURCE development_class = ls_pkg-devclass\s+entries = lt_meta RESULT XML lv_xml\./,
 'PERFORM xml_package USING ls_pkg-devclass lt_meta CHANGING lv_xml.');
let backup=form('wa_backup_build').replaceAll('cl_abap_char_utilities=>newline','lcl_chars=>newline').replace(/CALL TRANSFORMATION id SOURCE XML lv_a RESULT api_metadata = lt_api\./,'ASSERT 1 = 2.').replace(/CALL TRANSFORMATION id SOURCE object_name = ls_target-file-obj_name[\s\S]*?RESULT XML lv_a\./,'ASSERT 1 = 2.').replace(/CALL TRANSFORMATION id SOURCE header = ls_header packages = im_packages files = lt_files[\s\S]*?RESULT XML lv_meta\./,
 'PERFORM xml_manifest USING ls_header lt_files CHANGING lv_meta.');
if(finalize.includes('CALL TRANSFORMATION')||backup.includes('CALL TRANSFORMATION'))throw Error('Unbound SAP XML I/O');
const tyFile=di.match(/TYPES: BEGIN OF ty_file,[\s\S]*?END OF ty_file\./)[0];
let code=`REPORT zlayout.
TYPES: o2applname TYPE c LENGTH 30, ty_lines TYPE STANDARD TABLE OF string WITH DEFAULT KEY.
TYPES: BEGIN OF tadir, object TYPE c LENGTH 4, obj_name TYPE c LENGTH 120, devclass TYPE c LENGTH 30, END OF tadir.
TYPES: BEGIN OF ty_object, object TYPE tadir-object, obj_name TYPE tadir-obj_name, devclass TYPE tadir-devclass, END OF ty_object.
TYPES: BEGIN OF ty_package, devclass TYPE tadir-devclass, END OF ty_package.
TYPES ty_packages TYPE STANDARD TABLE OF ty_package WITH DEFAULT KEY.
${tyFile}
TYPES im_files TYPE STANDARD TABLE OF ty_file WITH DEFAULT KEY.
TYPES im_paths TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line.
TYPES: BEGIN OF ty_header, version TYPE c LENGTH 10, tool_version TYPE c LENGTH 10,
 scope_kind TYPE c LENGTH 12, bsp_application TYPE o2applname, bsp_package TYPE tadir-devclass,
 path_layout TYPE c LENGTH 20, completeness TYPE c LENGTH 20, import_enabled TYPE c, END OF ty_header.
TYPES: BEGIN OF ty_mime_metadata, devclass TYPE tadir-devclass, loio TYPE c LENGTH 32, content_path TYPE string, END OF ty_mime_metadata.
TYPES ty_metadata TYPE STANDARD TABLE OF ty_mime_metadata WITH DEFAULT KEY.
TYPES: BEGIN OF wwwparams, name TYPE c LENGTH 20, value TYPE c LENGTH 255, END OF wwwparams.
TYPES fupararef TYPE c LENGTH 1.
TYPES: BEGIN OF ty_asset, metadata_path TYPE string, END OF ty_asset.
TYPES: BEGIN OF wa_target, selected TYPE c, file TYPE ty_file, asset TYPE ty_asset,
 wanted TYPE xstring, before TYPE xstring, bsp_map TYPE string, bsp_prefix TYPE string,
 params TYPE STANDARD TABLE OF wwwparams WITH DEFAULT KEY, END OF wa_target.
TYPES: BEGIN OF im_entry, path TYPE string, original TYPE string, size TYPE i, END OF im_entry.
TYPES im_entries TYPE SORTED TABLE OF im_entry WITH UNIQUE KEY path.
TYPES: BEGIN OF zip_blob, name TYPE string, content TYPE xstring, END OF zip_blob.
DATA: captured TYPE STANDARD TABLE OF zip_blob, blob TYPE zip_blob,
 gv_bsp_flat TYPE c, p_bsp TYPE o2applname, gv_scope_package TYPE tadir-devclass,
 gv_fatal TYPE string, gv_bytes TYPE i, gv_maxbytes TYPE i,
 gt_paths TYPE im_paths, gt_packages TYPE ty_packages, im_packages TYPE ty_packages,
 gs_object TYPE ty_object, gv_root TYPE string, gv_file_language TYPE c, gv_check_mode TYPE c LENGTH 12, gv_payload_state TYPE c,
 gt_mime_metadata TYPE ty_metadata, metadata TYPE ty_metadata, meta TYPE ty_mime_metadata,
 wa_targets TYPE STANDARD TABLE OF wa_target, target TYPE wa_target,
 im_manifest_index TYPE SORTED TABLE OF ty_file WITH UNIQUE KEY path,
 im_header TYPE ty_header, captured_header TYPE ty_header, captured_files TYPE im_files,
 f TYPE ty_file, saved_files TYPE im_files, flat_calls TYPE i, package_calls TYPE i,
 raw TYPE xstring, error TYPE string, logical TYPE string, entries TYPE im_entries,
 entry TYPE im_entry, pkg TYPE ty_package, n TYPE i.
CLASS cx_root DEFINITION. PUBLIC SECTION. METHODS get_text RETURNING VALUE(text) TYPE string. ENDCLASS.
CLASS cx_root IMPLEMENTATION. METHOD get_text. text = 'mock exception'. ENDMETHOD. ENDCLASS.
CLASS lcl_chars DEFINITION. PUBLIC SECTION. CONSTANTS newline TYPE c VALUE '%'. ENDCLASS.
CLASS lcl_chars IMPLEMENTATION. ENDCLASS.
CLASS cl_abap_zip DEFINITION. PUBLIC SECTION.
 TYPES: BEGIN OF t_file, name TYPE string, size TYPE i, END OF t_file.
 DATA files TYPE STANDARD TABLE OF t_file WITH DEFAULT KEY.
 METHODS add IMPORTING name TYPE string content TYPE xstring.
 METHODS save RETURNING VALUE(zip) TYPE xstring.
 CLASS-METHODS crc32 IMPORTING content TYPE xstring RETURNING VALUE(crc32) TYPE i.
ENDCLASS.
CLASS cl_abap_zip IMPLEMENTATION.
 METHOD add. DATA: f TYPE t_file, b TYPE zip_blob.
 f-name = name. f-size = xstrlen( content ). APPEND f TO files.
 b-name = name. b-content = content. APPEND b TO captured.
 ENDMETHOD.
 METHOD save. zip = '504B'. ENDMETHOD.
 METHOD crc32. crc32 = xstrlen( content ). ENDMETHOD.
ENDCLASS.
DATA go_zip TYPE REF TO cl_abap_zip.
START-OF-SELECTION.
`;
let cases=0;
function test(name,s){cases++;code+=`* CASE ${cases} ${name}\nPERFORM setup.\n${s}\n`;}
test('Export wraps payload and baseline; DIAG removes enclosing folder',`
 logical = 'MIMEs/js/app.js'. raw = '410042'. PERFORM add_raw USING logical raw.
 logical = '.devhub/baseline/MIMEs/js/app.js'. PERFORM add_raw USING logical raw.
 logical = 'manifest.xml'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS INITIAL.
 READ TABLE captured INTO blob INDEX 1. ASSERT blob-name = 'ZWEB_COMMON/MIMEs/js/app.js'. ASSERT blob-content = raw.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.
 READ TABLE entries INTO entry WITH TABLE KEY path = 'MIMEs/js/app.js'. ASSERT sy-subrc = 0.
 ASSERT entry-original = 'ZWEB_COMMON/MIMEs/js/app.js'.
 READ TABLE entries WITH TABLE KEY path = '.devhub/baseline/MIMEs/js/app.js' TRANSPORTING NO FIELDS. ASSERT sy-subrc = 0.`);
test('package ZIP stays unwrapped',`CLEAR gv_bsp_flat. logical = 'packages/ZWEB/a.js'. raw = '00'.
 PERFORM add_raw USING logical raw. logical = 'manifest.xml'. PERFORM add_raw USING logical raw.
 READ TABLE captured INTO blob INDEX 1. ASSERT blob-name = 'packages/ZWEB/a.js'.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.`);
test('flat ZIP contents may also be compressed without enclosing folder',`CLEAR gv_bsp_flat.
 logical = 'pages/index/Layout/index.htm'. raw = '00'. PERFORM add_raw USING logical raw.
 logical = 'manifest.xml'. PERFORM add_raw USING logical raw. gv_bsp_flat = 'X'.
 PERFORM im_index_zip USING go_zip CHANGING entries. ASSERT gv_fatal IS INITIAL.
 READ TABLE entries WITH TABLE KEY path = 'pages/index/Layout/index.htm' TRANSPORTING NO FIELDS. ASSERT sy-subrc = 0.`);
test('case collisions rejected before download',`logical = 'MIMEs/app.js'. raw = '00'. PERFORM add_raw USING logical raw.
 logical = 'MIMEs/APP.JS'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS NOT INITIAL.`);
test('archive length includes enclosing app name',`DO 215 TIMES. CONCATENATE logical 'a' INTO logical. ENDDO.
 raw = '00'. PERFORM add_raw USING logical raw. ASSERT gv_fatal IS NOT INITIAL. ASSERT captured IS INITIAL.`);
test('flat metadata is one catalog and preserves each owner',`PERFORM metadata_setup.
 PERFORM finalize_mime. ASSERT gv_fatal IS INITIAL. ASSERT flat_calls = 1. ASSERT package_calls = 0.
 DESCRIBE TABLE saved_files LINES n. ASSERT n = 1. READ TABLE saved_files INTO f INDEX 1.
 ASSERT f-path = 'catalog/mime-metadata.xml'. ASSERT f-devclass IS INITIAL. ASSERT f-object IS INITIAL.
 DESCRIBE TABLE metadata LINES n. ASSERT n = 3. READ TABLE metadata INTO meta INDEX 1. ASSERT meta-devclass = 'ZBUDGET'.
 READ TABLE metadata INTO meta INDEX 2. ASSERT meta-devclass = 'ZMOBILE'.
 READ TABLE metadata INTO meta INDEX 3. ASSERT meta-devclass = 'ZWEB'.
 ASSERT gs_object-devclass = 'SAVED'. ASSERT gv_root = 'saved/'.`);
test('legacy metadata retains per-owner directories',`CLEAR gv_bsp_flat. PERFORM metadata_setup.
 PERFORM finalize_mime. ASSERT gv_fatal IS INITIAL. ASSERT flat_calls = 0. ASSERT package_calls = 3.
 READ TABLE saved_files INTO f INDEX 1. ASSERT f-path = 'packages/ZBUDGET/MIME/metadata.xml'. ASSERT f-devclass = 'ZBUDGET'.`);
test('empty metadata does not invent a payload',`PERFORM finalize_mime. ASSERT saved_files IS INITIAL. ASSERT flat_calls = 0.`);
for(const [name,flat] of [['flat rollback keeps app wrapper and native identity',true],['legacy rollback remains unwrapped',false]])test(name,`
 gv_bsp_flat = '${flat?'X':''}'. PERFORM backup_setup.
 PERFORM wa_backup_build CHANGING raw error. ASSERT error IS INITIAL. ASSERT raw = '504B'.
 ASSERT captured_header-path_layout = im_header-path_layout. ASSERT captured_header-bsp_package = 'ZWEB'.
 ASSERT captured_header-bsp_application = 'ZWEB_COMMON'.
 DESCRIBE TABLE captured_files LINES n. ASSERT n = 3. DESCRIBE TABLE captured LINES n. ASSERT n = 8.
 READ TABLE captured INTO blob WITH KEY name = '${flat?'ZWEB_COMMON/':''}.devhub/baseline/MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4242'.
 READ TABLE captured INTO blob WITH KEY name = '${flat?'ZWEB_COMMON/':''}MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT blob-content = '4141'.
 READ TABLE captured_files INTO f WITH KEY path = 'MIMEs/app.js'. ASSERT sy-subrc = 0. ASSERT f-devclass = 'ZMOBILE'. ASSERT f-byte_length = 2.
 READ TABLE captured INTO blob WITH KEY name = '${flat?'ZWEB_COMMON/':''}manifest.xml'. ASSERT sy-subrc = 0.
 READ TABLE captured INTO blob WITH KEY name = '${flat?'ZWEB_COMMON/':''}ROLLBACK_README.txt'. ASSERT sy-subrc = 0.`);
test('BSP rollback includes page map and immutable companions',`PERFORM backup_setup. REFRESH wa_targets.
 CLEAR target. target-selected = 'X'. target-file-path = 'pages/index/Layout/index.htm'. target-file-object = 'WAPA'.
 target-file-obj_name = p_bsp. target-file-devclass = 'ZWEB'. target-file-component = 'BSP_LAYOUT'.
 target-bsp_prefix = 'pages/index/'. target-bsp_map = 'pages/page-paths.xml'.
 target-asset-metadata_path = 'pages/index/Properties.xml'. target-wanted = '4242'. target-before = '4141'.
 APPEND target TO wa_targets. f = target-file. PERFORM manifest_add.
 f-path = target-asset-metadata_path. f-component = 'BSP_ATTRIBUTES'. PERFORM manifest_add.
 f-path = 'pages/index/Event Handler/on.abap'. f-component = 'BSP_EVENT_SOURCE'. PERFORM manifest_add.
 f-path = target-bsp_map. f-component = 'BSP_PAGE_PATH_MAP'. PERFORM manifest_add.
 PERFORM wa_backup_build CHANGING raw error. ASSERT error IS INITIAL.
 DESCRIBE TABLE captured_files LINES n. ASSERT n = 5.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/pages/index/Event Handler/on.abap'. ASSERT sy-subrc = 0.
 READ TABLE captured INTO blob WITH KEY name = 'ZWEB_COMMON/.devhub/baseline/pages/index/Layout/index.htm'. ASSERT sy-subrc = 0. ASSERT blob-content = '4242'.`);
code+=`
FORM setup.
 CLEAR: gv_fatal, gv_bytes, flat_calls, package_calls, raw, error, logical, gs_object, gv_root, im_header, target.
 REFRESH: captured, captured_files, metadata, entries, gt_paths, gt_packages, gt_mime_metadata, saved_files, wa_targets, im_manifest_index.
 gv_bsp_flat = 'X'. p_bsp = 'ZWEB_COMMON'. gv_scope_package = 'ZWEB'. gv_maxbytes = 536870912.
 CREATE OBJECT go_zip.
ENDFORM.
FORM metadata_setup.
 gs_object-devclass = 'SAVED'. gv_root = 'saved/'.
 meta-devclass = 'ZMOBILE'. meta-loio = 'MOBILE1'. meta-content_path = 'MIMEs/js/mobile.js'. APPEND meta TO gt_mime_metadata.
 meta-devclass = 'ZWEB'. meta-loio = 'WEB1'. meta-content_path = 'MIMEs/js/web.js'. APPEND meta TO gt_mime_metadata.
 meta-devclass = 'ZBUDGET'. meta-loio = 'BUDGET1'. meta-content_path = 'MIMEs/js/budget.js'. APPEND meta TO gt_mime_metadata.
 pkg-devclass = 'ZBUDGET'. APPEND pkg TO gt_packages. pkg-devclass = 'ZWEB'. APPEND pkg TO gt_packages.
 pkg-devclass = 'ZMOBILE'. APPEND pkg TO gt_packages.
ENDFORM.
FORM backup_setup.
 im_header-version = '0.4'. im_header-tool_version = '0.4.1'. im_header-scope_kind = 'BSP'.
 im_header-bsp_application = p_bsp. im_header-bsp_package = 'ZWEB'.
 IF gv_bsp_flat = 'X'. im_header-path_layout = 'BSP_APP_ROOT'. ENDIF.
 target-selected = 'X'. target-file-path = 'MIMEs/app.js'. target-file-object = 'SMIM'. target-file-devclass = 'ZMOBILE'.
 target-file-obj_name = 'MOBILE1'. target-asset-metadata_path = 'catalog/mime-metadata.xml'.
 target-wanted = '4242'. target-before = '4141'. APPEND target TO wa_targets.
 f = target-file. PERFORM manifest_add. CLEAR f. f-path = 'catalog/mime-metadata.xml'. PERFORM manifest_add.
 f-path = 'catalog/web-assets.xml'. PERFORM manifest_add.
ENDFORM.
FORM manifest_add.
 CONCATENATE '.devhub/baseline/' f-path INTO f-baseline. INSERT f INTO TABLE im_manifest_index.
ENDFORM.
FORM xml_flat USING app TYPE o2applname rows TYPE ty_metadata CHANGING xml TYPE xstring.
 ASSERT app = p_bsp. ADD 1 TO flat_calls. metadata = rows. xml = '3C3E'.
ENDFORM.
FORM xml_package USING owner TYPE c rows TYPE ty_metadata CHANGING xml TYPE xstring.
 DATA row TYPE ty_mime_metadata. LOOP AT rows INTO row. ASSERT row-devclass = owner. ENDLOOP.
 ADD 1 TO package_calls. xml = '3C3E'.
ENDFORM.
FORM xml_manifest USING header TYPE ty_header files TYPE im_files CHANGING xml TYPE xstring.
 captured_header = header. captured_files = files. xml = '3C3E'.
ENDFORM.
FORM add_file USING p TYPE csequence comp TYPE csequence xml TYPE xstring.
 CLEAR f. CONCATENATE gv_root p INTO f-path. f-component = comp. f-devclass = gs_object-devclass. f-object = gs_object-object.
 APPEND f TO saved_files.
ENDFORM.
FORM wa_backup_payload USING p TYPE string CHANGING data TYPE xstring err TYPE string.
 CLEAR err. data = '3C3E'.
ENDFORM.
FORM utf8 USING text TYPE string CHANGING data TYPE xstring. data = '2F'. ENDFORM.
FORM im_progress USING text TYPE csequence a TYPE i b TYPE i detail TYPE csequence. ENDFORM.
FORM im_progress_item USING text TYPE csequence a TYPE i b TYPE i detail TYPE csequence. ENDFORM.
`+['segment','safe_leaf','scope_zip_path','mime_metadata_path','im_index_zip','im_safe_path','im_git_metadata','im_entry_limit'].map(n=>form(n)).join('\n')+'\n'+form('add_raw',ex)+'\n'+finalize+'\n'+backup;
(async()=>{
 fs.writeFileSync(path.join(__dirname,'zlayout.prog.abap'),code);
 const out=await new Transpiler({addCommonJS:false,unknownTypes:'compileError'}).runRaw([{filename:'zlayout.prog.abap',contents:code}]);
 const js=out.objects.find(o=>o.object.type==='PROG').chunk.getCode(); fs.writeFileSync(path.join(__dirname,'zlayout.js'),js);
 global.abap=new ABAP(); await new (Object.getPrototypeOf(async function(){}).constructor)('abap',js)(global.abap);
 const result={cases,assertions:(code.match(/\bASSERT\b/g)||[]).length,result:'PASS',scope:'Production ABAP forms with ZIP/XML/codec I/O doubles; no SAP execution'};
 fs.writeFileSync(path.join(__dirname,'layout-result.json'),JSON.stringify(result,null,2)); console.log(JSON.stringify(result));
})().catch(e=>{console.error(e);process.exit(1)});
