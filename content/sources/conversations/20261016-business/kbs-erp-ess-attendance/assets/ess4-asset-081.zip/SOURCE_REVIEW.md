# SUBMIT-PRG01 source review

## Input provenance

Working baseline:
- `guntae_input_r1_LAYOUT_SUBMIT_ONCE01_FULL.txt`
- `guntae_input_r1_OnInputProcessing_SUBMIT_ONCE01_FULL.txt`

These are the delivered SUBMIT-ONCE01 files the user reported applying. They are not the earlier escaped Markdown uploads.

Original user source uploads remain the provenance of that baseline:
- `붙여넣은 마크다운(4).md` (Layout)
- `붙여넣은 마크다운(2)(1).md` (OnInputProcessing)

No live SAP repository access occurred in this task.

## Exact delta

1. OnInputProcessing:
   - Add local HTTP response/receipt variables.
   - Make receipt GET requests return before action handling.
   - After the original KULJAE/DEL/RETR loop, original result construction, and original cleanup, add a **KULJAE + POST only** 303 response.
   - Store actual result + timestamp in four new non-auto page attributes.
   - No existing token/key/authorization/lock/function/commit/result-check statements are removed.
   - If response preparation fails, report presentation failure alongside the actual outcome; never retry or roll back the business operation from this block.

2. Layout:
   - Match stored receipt to requested ID and the current SAP user; display only on GET.
   - Do not trust message, severity or redirect target supplied by the client.
   - Fold the existing trace by default; no trace deletion.
   - Add a fixed same-page GET link.
   - Keep the SUBMIT-ONCE01 HTMLB click handler and submission guard unchanged.
   - Mark personal/receipt responses no-store.

## Why not navigation->goto_page / exit?

The selected design writes a 303 response and ends the response using `navigation->response_complete()`.
It does not explicitly navigate to a new BSP page object, end the application session, or build an auto-submitted form.
The target is a constant relative same-page URL plus a URL-encoded receipt ID. This retains the current rewritten URL prefix when the browser resolves Location.

Stateful same-page context reuse is a deployment prerequisite already used by the existing page token.
Receipt availability after redirection must be confirmed in SAP; a missing receipt is shown as unknown, not falsely successful.

## Scope intentionally excluded

- Early RETURN branches during token, selection, ownership and state prechecks.
- Non-submission actions (save/edit/delete/recall/approve/resume).
- Durable idempotency across sessions, crash recovery, database transaction redesign.
- Retrospective identification of the first-ever popup's cause.
- Erasing old POST entries already stored in the browser's history.
- Modifying PA2001/PA2006/ZHR2016 or workflow data outside existing application calls.

## Primary documentation checked

SAP interface IF_BSP_PAGE: GET_RESPONSE returns IF_HTTP_RESPONSE.
`https://help.sap.com/docs/SAP_NETWEAVER_700/10a2f2de6c531014b603ffc79090bc6e/4c57bb37c75a6f84e10000000a42189e.html`

SAP interface IF_BSP_NAVIGATION: RESPONSE_COMPLETE suppresses subsequent handlers/layout for an already-generated response; EXIT and explicit navigation have different lifecycle semantics.
`https://help.sap.com/saphelp_snc700_ehp01/helpdata/en/2a/31b98435a111d5992100508b6b8b11/content.htm`

SAP Page Attribute: auto/non-auto values and explicit vs implicit navigation.
`https://help.sap.com/docs/SAP_NETWEAVER_AS_ABAP_752/0884fb55479542b38fb676e8f5b250a1/4c495ab29f9935b8e10000000a42189b-166.html?locale=en-US&state=PRODUCTION&version=7.52.11`

RFC 9110 section 15.4.4: 303 redirects the result of a POST to a retrieval request.
`https://www.rfc-editor.org/rfc/rfc9110.html#section-15.4.4`

Documentation support is not SAP execution evidence.

## Validation interpretation

The Python tests reverse the patch to the exact normalized baseline and model receipt routing/ownership/escaping.
The JavaScript tests execute only the new folding control.
Any local HTTP fixture validates the fixture/client redirect behavior only; it is not the BSP runtime.
No SAP compiler, SAP GUI, production database, live approval or user's browser was driven by these tests.
