'use strict';
/* Local UI unit tests, not the SAP-rendered page or an IE runtime. */
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'guntae_input_r1_LAYOUT_SUBMIT_PRG01_FULL.txt'), 'utf8');
const block = source.match(/function r1PrgToggleTrace\(button\) \{[\s\S]*?return false;\n           \}/)[0];
let lookups = 0, attributes = {}, submits = 0;
let panel = {style: {display: 'none'}};
let button = {innerHTML: '', setAttribute: (name, value) => {attributes[name] = value;}};
const sandbox = {
  document: {getElementById: id => {lookups++; return id === 'r1-submit-trace-panel' ? panel : null;}},
  GoInputProcessing: () => {submits++; throw Error('must not submit');}
};
vm.createContext(sandbox); vm.runInContext(block, sandbox);
assert.strictEqual(sandbox.r1PrgToggleTrace(button), false);
assert.strictEqual(panel.style.display, 'block');
assert.strictEqual(attributes['aria-expanded'], 'true');
assert.strictEqual(sandbox.r1PrgToggleTrace(button), false);
assert.strictEqual(panel.style.display, 'none');
assert.strictEqual(attributes['aria-expanded'], 'false');
panel = null; assert.strictEqual(sandbox.r1PrgToggleTrace(button), false);
assert.strictEqual(submits, 0);
const result = {scope: 'local toggle function only; NOT SAP/IE runtime', assertions: 8, passed: true};
fs.writeFileSync(path.join(__dirname, 'ui_results.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
