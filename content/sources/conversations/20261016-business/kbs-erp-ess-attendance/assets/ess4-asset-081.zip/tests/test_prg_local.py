"""Local source/behavior model tests. These do NOT compile or execute SAP ABAP."""
from pathlib import Path
from dataclasses import dataclass
from urllib.parse import urljoin, quote, urlparse, parse_qs
import hashlib, html, json, re, unittest

ROOT = Path(__file__).resolve().parents[1]
LAYOUT = (ROOT / "guntae_input_r1_LAYOUT_SUBMIT_PRG01_FULL.txt").read_text("utf-8")
INPUT = (ROOT / "guntae_input_r1_OnInputProcessing_SUBMIT_PRG01_FULL.txt").read_text("utf-8")
OLD_INPUT = (ROOT / "source/OnInputProcessing_BEFORE_SUBMIT_PRG01.txt").read_text("utf-8-sig")
OLD_LAYOUT = (ROOT / "source/Layout_BEFORE_SUBMIT_PRG01.txt").read_text("utf-8-sig")
HEAD = (ROOT / "review_blocks/INPUT_DECLARATIONS_AND_GET_GUARD.txt").read_text("utf-8")
TAIL = (ROOT / "review_blocks/INPUT_PRG_RESULT_BLOCK.txt").read_text("utf-8")
LHEAD = (ROOT / "review_blocks/LAYOUT_RECEIPT_HEAD_BLOCK.txt").read_text("utf-8")
LTRACE = (ROOT / "review_blocks/LAYOUT_RESULT_AND_FOLDED_TRACE_BLOCK.txt").read_text("utf-8")
OLD_TRACE = (ROOT / "source/Layout_PREVIOUS_TRACE_BLOCK.txt").read_text("utf-8").rstrip("\n")

@dataclass
class Receipt:
    rid: str
    owner: str
    kind: str
    message: str

def receipt_view(method: str, rid: str, owner: str, receipt: Receipt | None):
    if method != "GET" or not rid:
        return None
    if (len(rid) != 22 or receipt is None or receipt.rid != rid
            or receipt.owner != owner or not receipt.message):
        return ("UNKNOWN", "No matching stored receipt. Check actual request history.")
    return ("SUCCESS" if receipt.kind == "S" else "REVIEW", html.escape(receipt.message))

def finish_model(method, event, done, total, error, rid, owner, actual_result):
    if method != "POST" or event != "KULJAE":
        return None
    receipt = Receipt(rid, owner, "S" if not error and done == total and done > 0 else "E",
                      actual_result)
    if len(rid) != 22:
        return {"redirect": None, "receipt": receipt, "retry_business": False}
    return {
        "redirect": (303, "guntae_input_r1.kbs?r1_prg=" + quote(rid, safe="")),
        "receipt": receipt, "retry_business": False,
        "cache_control": "no-store"
    }

class SourceTests(unittest.TestCase):
    def test_01_every_original_input_line_preserved(self):
        self.assertEqual(INPUT.replace(HEAD, "", 1).replace(TAIL, "", 1), OLD_INPUT)

    def test_02_layout_restoration(self):
        restored = LAYOUT.replace(LHEAD, "", 1)
        restored = re.sub(
            r"           // Start-Add / XA32762 / GNT-R1-U24 / 2026-10-15 / submit-prg01\n"
            r".*?           // End-Add / XA32762 / GNT-R1-U24 / submit-prg01\n",
            "", restored, count=1, flags=re.S)
        restored = restored.replace(LTRACE, OLD_TRACE, 1)
        self.assertEqual(restored, OLD_LAYOUT)

    def test_03_no_new_business_or_database_calls(self):
        new_only = HEAD + TAIL + LHEAD + LTRACE
        active = "\n".join(s for s in new_only.splitlines() if not s.startswith("*"))
        for pattern in [
            r"\bCALL\s+FUNCTION\b", r"\bCOMMIT\s+WORK\b", r"\bROLLBACK\s+WORK\b",
            r"\b(?:UPDATE|DELETE|INSERT|MODIFY|SELECT)\s+(?:zthr|ztgun|zhr|pa20|sww|zwf)",
            r"TO\s+DATABASE", r"\bSUBMIT\s+zrpth", r"=>decide\s*\("]:
            self.assertIsNone(re.search(pattern, active, re.I), pattern)

    def test_04_redirect_after_final_result_and_lock_release(self):
        start = INPUT.index(TAIL)
        self.assertGreater(start, INPUT.rindex("CALL FUNCTION 'DEQUEUE_EZTHR0080'", 0, start))
        self.assertGreater(start, INPUT.rindex("ENDLOOP.", 0, start))
        self.assertGreater(start, INPUT.rindex("VERIFIED_DONE=", 0, start))

    def test_05_303_and_complete_no_auto_submit(self):
        self.assertIn("code = 303 reason = 'See Other'", TAIL)
        self.assertIn("navigation->response_complete( ).\n                        RETURN.", TAIL)
        for text in ["navigation->goto_page", "navigation->exit", "use_auto_submit_form",
                     "window.location", ".submit(", "cl_bsp_server_side_cookie"]:
            self.assertNotIn(text.lower(), TAIL.lower())

    def test_06_csrf_and_db_guard_unchanged(self):
        for clause in [
            "IF gv_v2_token IS INITIAL OR lv_v2_token <> gv_v2_token.",
            "IF ls_r1_db-zsangsin IS NOT INITIAL OR ls_r1_db-zaccept IS NOT INITIAL OR",
            "gv_v2_token, lv_r1_done, lv_r1_error"]:
            self.assertEqual(INPUT.count(clause), OLD_INPUT.count(clause))

    def test_07_diagnostics_folded_and_get_link(self):
        self.assertIn('id="r1-submit-trace-panel" style="display:none;', LAYOUT)
        self.assertIn('type="button" class="v2-button" aria-expanded="false"', LTRACE)
        self.assertIn('href="guntae_input_r1.kbs"', LTRACE)
        self.assertNotIn("<details", LTRACE)

    def test_08_escape_receipt_trace_and_request_method(self):
        for value in ["lv_r1_prg_view_text", "lv_r1_prg_view_title", "lv_r1_prg_view_http"]:
            self.assertIn("cl_http_utility=>escape_html( " + value + " )", LHEAD)
        self.assertIn("cl_http_utility=>escape_html( gv_r1_submit_trace )", LTRACE)
        self.assertIn("cl_http_utility=>escape_html( gv_r1_prg_message )", TAIL)

    def test_09_no_auto_bound_new_attributes_in_markup(self):
        self.assertNotRegex(LAYOUT, r'<input[^>]+name="(?i:gv_r1_prg_)')
        self.assertIn("gv_r1_prg_owner = sy-uname", TAIL)
        self.assertIn("gv_r1_prg_owner = sy-uname", LHEAD)

    def test_10_get_guard_does_not_accept_post_as_view(self):
        self.assertIn("IF lv_r1_prg_http = 'GET' AND lv_r1_prg_query IS NOT INITIAL.", HEAD)
        self.assertIn("IF event->event_id = 'KULJAE' AND lv_r1_prg_http = 'POST'.", TAIL)

    def test_11_original_submit_click_code_unchanged(self):
        # Compare the existing client callback and HTMLB server event stanza.
        pattern = r"var r1SubmitBusy = false;.*?// End-Modify / XA32762 / GNT-R1-U23 / submit-once01"
        self.assertEqual(re.search(pattern, LAYOUT, re.S).group(0),
                         re.search(pattern, OLD_LAYOUT, re.S).group(0))
        button = r'<htmlb:button id\s*=\s*"KULJAE".*?/>'
        self.assertEqual(re.search(button, LAYOUT, re.S).group(0),
                         re.search(button, OLD_LAYOUT, re.S).group(0))

class ModelTests(unittest.TestCase):
    rid = "A"*22
    def done(self, **kw):
        args = dict(method="POST", event="KULJAE", done=1, total=1, error="",
                    rid=self.rid, owner="XA32762", actual_result="1 item submitted")
        args.update(kw)
        return finish_model(**args)

    def test_12_success_redirects_then_get_and_refresh_only_view(self):
        result = self.done()
        self.assertEqual(result["redirect"][0], 303)
        for _ in range(3):
            self.assertEqual(receipt_view("GET", self.rid, "XA32762", result["receipt"]),
                             ("SUCCESS", "1 item submitted"))
        self.assertFalse(result["retry_business"])

    def test_13_partial_batch_is_not_all_success(self):
        r = self.done(done=1, total=3, error="second item failed",
                      actual_result="done=1 stopped=1 unprocessed=1")
        self.assertEqual(r["redirect"][0], 303)
        self.assertEqual(receipt_view("GET", self.rid, "XA32762", r["receipt"])[0], "REVIEW")
        self.assertIn("unprocessed=1", r["receipt"].message)

    def test_14_zero_verified_items_not_success(self):
        self.assertEqual(self.done(done=0)["receipt"].kind, "E")

    def test_15_delete_recall_save_not_redirected(self):
        for event in ["BT_DEL", "BT_RETR", "BT_SAVE", "MODI_SAVE", "CGIUH_SAVE"]:
            self.assertIsNone(self.done(event=event))

    def test_16_get_cannot_finish_business(self):
        self.assertIsNone(self.done(method="GET"))
        self.assertIsNone(receipt_view("POST", self.rid, "XA32762", self.done()["receipt"]))

    def test_17_owner_and_id_mismatch_do_not_expose_success(self):
        receipt = self.done()["receipt"]
        self.assertEqual(receipt_view("GET", self.rid, "OTHER", receipt)[0], "UNKNOWN")
        self.assertEqual(receipt_view("GET", "B"*22, "XA32762", receipt)[0], "UNKNOWN")

    def test_18_expired_or_newer_receipt_is_unknown_not_failure(self):
        self.assertEqual(receipt_view("GET", self.rid, "XA32762", None)[0], "UNKNOWN")
        later = self.done(rid="B"*22)["receipt"]
        self.assertEqual(receipt_view("GET", self.rid, "XA32762", later)[0], "UNKNOWN")

    def test_19_untrusted_text_is_html_escaped(self):
        receipt = self.done(actual_result='<script>alert("X")</script> & next')["receipt"]
        shown = receipt_view("GET", self.rid, "XA32762", receipt)[1]
        self.assertNotIn("<script>", shown)
        self.assertIn("&lt;script&gt;", shown)

    def test_20_relative_location_preserves_encoded_session_and_drops_post_fields(self):
        r = self.done(rid="+" + "A"*20 + "/")
        url = urljoin("https://example.invalid/sap(TESTCTX)/bc/bsp/sap/zhr0008/"
                      "guntae_input_r1.kbs?onInputProcessing=old&v2_token=secret",
                      r["redirect"][1])
        parsed = urlparse(url)
        self.assertEqual(parsed.netloc, "example.invalid")
        self.assertIn("/sap(TESTCTX)/", parsed.path)
        self.assertEqual(parse_qs(parsed.query), {"r1_prg": ["+" + "A"*20 + "/"]})
        self.assertNotIn("secret", url)

    def test_21_bad_receipt_id_does_not_retry_business(self):
        r = self.done(rid="")
        self.assertIsNone(r["redirect"])
        self.assertFalse(r["retry_business"])

    def test_22_no_receipt_on_normal_get(self):
        self.assertIsNone(receipt_view("GET", "", "XA32762", self.done()["receipt"]))

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {
        "scope": "local source restoration and behavior model; NOT SAP execution",
        "tests_run": result.testsRun, "failures": len(result.failures),
        "errors": len(result.errors), "passed": result.wasSuccessful()
    }
    (ROOT / "tests/local_results.json").write_text(json.dumps(summary, indent=2), "utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
