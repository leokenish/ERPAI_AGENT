---
tags: [교대근무, 선택근무, 통상시차시간외, 통합결재, 퇴직자관리자입력검토]
---

# ZHR_52TM_CHECK_APPROVER_N — 미추출 의존

[소스 목차](INDEX.md) · [외부 의존 전체 목록](EXTERNAL_DEPENDENCIES.md)
확인 수준: **참조 구문 확인 / 본체 미추출**. 이 객체의 원본 본문·정의 파일은 현재 추출물에서 확인하지 못했다. 아래는 이 객체를 호출하거나 참조하는 **호출측 원본 파일**이다. 소유 패키지·운영 존재/사용·실행 성공을 추정하지 않는다.

## 참조와 후속 처리 탐색

데이터 조회/저장 행을 이용해 생산자·소비자를 찾을 수 있다. 동일 객체를 읽고 쓴다는 사실은 자동 실행 순서나 외래키를 입증하지 않는다.

| 참조 소스 설명 | 관계 | 근거 파일·위치 |
|---|---|---|
| [LZHR008_3F01](LZHR008_3F01.md) | 직접 호출 | [LZHR008_3F01.abap](../../exports/ZHR5/packages/ZHR5/function-groups/FUGR/ZHR008_3/Include/LZHR008_3F01.abap) L523 |
| [MZH4110F01](MZH4110F01.md) | 직접 호출 | [MZH4110F01.abap](../../exports/ZHR5/packages/ZHR5/programs/PROG/MZH4110F01/source/MZH4110F01.abap) L827 |
| [ZHR_52TM_MOBILE_OVERTIME_APPR](ZHR_52TM_MOBILE_OVERTIME_APPR.md) | 직접 호출 | [ZHR_52TM_MOBILE_OVERTIME_APPR.abap](../../exports/ZHR5/packages/ZHR5/function-groups/FUGR/ZHR008_2/Function%20Module/ZHR_52TM_MOBILE_OVERTIME_APPR/Source%20code/ZHR_52TM_MOBILE_OVERTIME_APPR.abap) L164 |

## 관련 업무
