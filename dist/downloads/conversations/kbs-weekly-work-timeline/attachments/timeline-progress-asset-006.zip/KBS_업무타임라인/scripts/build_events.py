#!/usr/bin/env python3
"""Derive evidence-backed event markers from existing cards; never rewrite cards."""
import argparse,collections,datetime as dt,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def compact(s):return re.sub(r'\s+','',s)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
def day(s):return dt.date.fromisoformat(s)
def rx(p):return re.compile(p,re.I)
SPORTS=[
 ('리우 올림픽',r'리우.{0,14}올림픽'),('평창 동계올림픽',r'평창.{0,14}올림픽'),('도쿄 올림픽',r'도쿄.{0,14}올림픽'),('베이징 동계올림픽',r'베이징.{0,14}올림픽'),('파리 올림픽',r'파리.{0,14}올림픽'),('밀라노 동계올림픽',r'밀라노.{0,20}올림픽'),('강원 동계청소년올림픽',r'(?:강원|강릉).{0,16}청소년올림픽'),
 ('러시아 월드컵',r'러시아.{0,12}월드컵'),('카타르 월드컵',r'카타르.{0,12}월드컵'),('북중미 월드컵',r'북중미.{0,12}월드컵'),('캐나다 여자월드컵',r'캐나다.{0,10}여자월드컵'),('프랑스 여자월드컵',r'프랑스.{0,10}여자월드컵'),('U-20 여자월드컵',r'U[-‐]?20여자월드컵'),('여자월드컵',r'(?:(?:FIFA)?여자월드컵)'),('U-20 월드컵',r'U[-‐]?20월드컵'),
 ('자카르타·팔렘방 아시안게임',r'(?:자카르타|팔렘방).{0,16}아시안게임'),('항저우 아시안게임',r'항저우.{0,12}아시안게임'),('아이치·나고야 아시안게임',r'(?:아이치|나고야).{0,16}아시안게임'),('하얼빈 동계아시안게임',r'하얼빈.{0,14}아시안게임'),('삿포로 동계아시안게임',r'삿포로.{0,14}아시안게임')]
POLICIES=[
 ('수신료 분리징수',r'수신료.{0,8}(?:분리징수|분리고지)|(?:분리징수|분리고지).{0,8}수신료'),('수신료 통합징수',r'수신료.{0,8}(?:통합징수|결합고지|통합고지)|(?:통합징수|결합고지).{0,8}수신료'),
 ('방송 3법',r'방송3법'),('방송 4법',r'방송4법'),('방송법·시행령 개정',r'방송법(?:시행령)?'),('지상파 중간광고',r'중간광고'),('청탁금지법',r'청탁금지법|김영란법'),('근로시간 제도',r'주52시간|근로기준법'),('중대재해처벌법',r'중대재해처벌법|중대재해법'),('개인정보보호법',r'개인정보보호법'),('감염병 방역정책',r'(?:코로나|거리두기).{0,50}(?:해제|전면해제)|(?:해제).{0,25}거리두기')]
NATIONAL=[
 ('메르스 대응',r'메르스'),('코로나19 대응',r'코로나(?:19)?|신종코로나'),('경주 지진 대응',r'경주.{0,12}지진'),('포항 지진 대응',r'포항.{0,12}지진'),('강원 산불 대응',r'(?:강원|강릉|속초|고성).{0,18}산불|산불.{0,18}(?:강원|강릉|속초|고성)'),('울진·삼척 산불 대응',r'(?:울진|삼척).{0,18}산불|산불.{0,18}(?:울진|삼척)'),('영남 산불 대응',r'(?:경북|경남|영남|의성|안동|산청).{0,18}산불|산불.{0,18}(?:경북|경남|영남|의성|안동|산청)'),('집중호우·수해 대응',r'집중호우|수해|폭우'),('이태원 참사 대응',r'이태원.{0,15}(?:참사|사고|압사)'),('제주항공 여객기 사고',r'(?:제주항공|무안공항).{0,20}(?:참사|사고|추락)|(?:여객기|항공기).{0,15}(?:참사|추락)'),('비상계엄 관련 보도',r'비상계엄|12[.·/]?3계엄'),('대통령선거 개표방송',r'(?:제)?(?:19|20|21)대대통령선거|대통령선거개표방송'),('세월호 추모방송',r'(?!)')]
for name in ['차바','링링','미탁','마이삭','하이선','힌남노','카눈']:NATIONAL.append((f'태풍 {name} 대응',rf'(?:태풍.{{0,12}}{name}|{name}.{{0,10}}태풍)'))
COMPILED={kind:[(label,rx(p)) for label,p in rules] for kind,rules in [('sports',SPORTS),('policy',POLICIES),('national',NATIONAL)]}
FAST=rx(r'올림픽|월드컵|아시안게임|방송법|방송[34]법|수신료|중간광고|청탁금지법|김영란법|52시간|근로기준법|중대재해|개인정보보호법|코로나|거리두기|메르스|지진|산불|집중호우|수해|폭우|이태원|제주항공|무안공항|여객기|항공기|계엄|대통령선거|세월호|태풍')
SPORT_EXCLUDE=rx(r'올림픽공원|올림픽경찰서|월드컵경기장|드론월드컵|로보월드컵|양궁월드컵')
RETRO=rx(r'기념|주년|주기|백서|다큐|회고|추모|재판|조사위원|피해보상|소송|훈련')
PREP=rx(r'준비|예정|계획|대비|검토|협의|추진|D[-－]|G[-－]|앞으로|유치|제안|개최지선정|구매|계약|발주|입찰')
def context_excerpt(c,pattern):
 # Keep the matching item and its wrapped/detail lines, never borrow the
 # neighboring bullet's unrelated legislation/event for the stage decision.
 raw=c['raw_text'];chars=[];positions=[]
 for i,ch in enumerate(raw):
  if not ch.isspace():chars.append(ch);positions.append(i)
 flat=''.join(chars);spans=[]
 lines=raw.splitlines();starts=[];pos=0
 for l in lines:starts.append(pos);pos+=len(l)+1
 import bisect
 for m in pattern.finditer(flat):
  lo=bisect.bisect_right(starts,positions[m.start()])-1;hi=bisect.bisect_right(starts,positions[m.end()-1])-1
  indent=len(lines[lo])-len(lines[lo].lstrip());first=lines[lo].lstrip()
  for j in range(hi+1,min(len(lines),hi+16)):
   t=lines[j].strip()
   if not t:hi=j;continue
   level=len(lines[j])-len(lines[j].lstrip())
   bullet=re.match(r'^(?:[○ㅇoO◯▣■◆▶·•・-]|\d+[.)])',t)
   if bullet and level<=indent:break
   hi=j
  spans.extend(range(lo,hi+1))
 return '\n'.join(lines[i] for i in sorted(set(spans)))[:2000]
def opening_date(h):
 ls=[l for l in h['excerpt'].splitlines() if l.strip()]
 for i,line in enumerate(ls):
  if not re.search('개막|개회',line):continue
  text=' '.join(ls[i:i+3]);ds=[]
  for m in re.finditer(r'(?<![0-9])(?:(20[0-9]{2})[./년]\s*)?([0-9]{1,2})[./월]\s*([0-9]{1,2})(?![0-9])',text):
   try:d=dt.date(int(m[1] or h['target_week'][:4]),int(m[2]),int(m[3]))
   except ValueError:continue
   if abs((d-day(h['target_week'])).days)<=28:ds.append(d)
  if ds:return min(ds).isoformat()
 return None
def stage_for(label,fragment):
 # Legal names themselves contain 시행령: do not mistake them for enactment.
 q=fragment.replace('시행령','').replace('시행규칙','')
 if label.startswith('수신료'):
  if rx(r'통과|국무회의의결|공포|의결관련').search(q):return '입법 절차'
  if rx(r'(?:징수|고지|제도).{0,8}(?:시행|재개|전환)|(?:시행|재개).{0,10}(?:징수|고지)').search(q):return '시행 대응'
  if rx(r'입법예고|개정안|법안|시행령개정').search(fragment):return '개정 대응'
  return None
 if rx(r'공포|본회의통과|국무회의의결|법사위통과').search(q):return '입법 절차'
 if rx(r'시행|시행일|전면해제|해제').search(q) and not rx(r'시행을검토|시행검토').search(q):return '시행 대응'
 if rx(r'개정|발의|입법예고|법안|허용|도입').search(q):return '개정 대응'
 return None
def clusters(hits,gap):
 groups=[]
 for h in sorted(hits,key=lambda x:(x['report_week'],x['observation_id'])):
  if not groups or (day(h['report_week'])-day(groups[-1][-1]['report_week'])).days>gap:groups.append([])
  groups[-1].append(h)
 return groups
def make_events(root):
 buckets=collections.defaultdict(list);scanned=0
 for f in sorted((root/'cards').rglob('*.jsonl')):
  for line_no,line in enumerate(f.open(encoding='utf-8'),1):
   c=json.loads(line);scanned+=1;raw=compact(c['raw_text'])
   if not FAST.search(raw):continue
   for kind,rules in COMPILED.items():
    if kind in ('national','policy') and c['org_id'] in ('KBS AMERICA','KBS JAPAN'):continue
    matched_labels=[]
    for label,pat in rules:
     if not pat.search(raw):continue
     if label=='여자월드컵' and any('여자월드컵' in s for s in matched_labels):continue
     fragment=context_excerpt(c,pat);clean=compact(fragment)
     if not clean:continue
     title_clean=compact(c['title_raw'])
     # Specific policy labels take precedence over the generic Broadcasting Act label.
     if label=='방송법·시행령 개정' and rx(r'수신료|방송[34]법|중간광고').search(clean):continue
     stage=None;score=0
     if kind=='sports':
      if not rx(r'개막|개회|중계(?!권)|특별편성|경기|특집다큐').search(clean+title_clean):continue
      if rx(r'월드컵예선전|시청자참여|응원이벤트|개막이후|소요조사').search(clean+title_clean):continue
      pm=pat.search(raw);past=re.search(r'(20[0-9]{2})년?[^0-9]{0,6}$',raw[max(0,pm.start()-12):pm.start()]) if pm else None
      if past and int(c['target_week'][:4])-int(past[1])>2:continue
      if rx(r'친선경기|평가전|대륙간예선|지역예선|[123]차예선|최종예선|최종명단|방송권료|중계권료|중계콘서트|공급계약').search(clean):continue
      if rx(r'주년|주기|기념|D[-－]\d{2,}|G[-－]|유치|특별기회전|전국체육대회').search(clean):continue
      if '장애인' in clean and '장애인' not in label:continue
      score=30*bool(rx(r'특집다큐').search(title_clean))+80*bool(rx(r'개막식|개막전|개막|개회식').search(clean))+28*bool(rx(r'중계(?!권)|경기|특별편성').search(clean))+12*bool(rx(r'생방|생중계').search(clean))
      if PREP.search(clean) or rx(r'기획|제안|소요조사').search(title_clean):score-=35
      if rx(r'폐막|정산|사후|마무리|철거|귀국|해단|시청률|수상|성과|준결승|결승|16강|8강|4강').search(clean):score-=35
      if rx(r'중계방송').search(title_clean) and not PREP.search(title_clean):score+=30
      if c['org_id'] in ('아나운서실','보도국','영상제작국','편성주간','스포츠기획제작부','미디어송출부'):score+=10
     elif kind=='policy':
      if rx(r'외국|이탈리아|독일|영국|법정의무교육|제3자제공절차서|선택근로|강의|상반기개인정보보호교육|직급체계|공문시행|사규|제39조|이후첫실형|선고공판|관리사무소').search(clean+title_clean):continue
      stage=stage_for(label,clean)
      if not stage:continue
      if label.startswith('수신료') and rx(r'아파트|관리사무소|위탁관리업체|홍익종합관리').search(clean+title_clean) and not rx(r'법안|국회|시행령|제도시행|통합징수시행').search(clean):continue
      if rx(r'거부처분|변론기일|소송|징수업무처리규정|시행세칙|일상감사').search(clean):continue
      score={'입법 절차':60,'시행 대응':45,'개정 대응':25}[stage]+15*bool(pat.search(compact(c['title_raw'])))
      if c['org_id'] in ('대외협력국','정책기획국','수신료국','경영정보국','인력관리실','보도국'):score+=10
     else:
      if label!='세월호 추모방송' and RETRO.search(clean+title_clean):continue
      if rx(r'정산|점검|총국장회의|홈페이지|메뉴추가|재난방송대비|재난방송대응시스템|워크숍|교육|연락망|계획수립|소요조사|장비정비|알림지표|법무|변론|손해배상|관련소송|그후|참사[0-9]+(?:일|년)|산불[0-9]+년|피해그후|실적자료|시민행진|진상규명|공작계획').search(clean+title_clean):continue
      if rx(r'계절|장마철|시설물사전점검|정기점검|예방교육|발생대비|대비시설|피해예방|지진대피|모의').search(clean):continue
      if label=='대통령선거 개표방송':
       if not rx(r'개표|선거방송|특집생방송|개표방송').search(clean):continue
       if rx(r'그래픽제작|회선소요|사전조사|회의|계획\(안\)|준비|리허설').search(title_clean):continue
       score=80*bool(rx(r'개표방송|개표상황|특집생방송').search(clean))+25*bool(rx(r'생방|개표방송.{0,5}/').search(clean))-30*bool(PREP.search(clean))
      else:
       if not rx(r'재난|특보|긴급|비상|피해|확산|참사|사고|보도|방송|추모|대응|취재|성금|통합뉴스룸').search(clean):continue
       score=35*bool(rx(r'특보|긴급|특별생방송|재난방송|비상근무|통합뉴스룸').search(clean))+10*bool(rx(r'피해|확산|발생|위기').search(clean))
      if c['org_id'] in ('보도국','영상제작국','보도기획부','보도영상국','디지털뉴스국','재난미디어센터','아나운서실','미디어송출부'):score+=10
     score+=12 if c['section']=='actual' else 0
     h={'org_id':c['org_id'],'work_id':c['work_id'],'observation_id':c['observation_id'],'report_week':c['report_week'],'target_week':c['target_week'],'section':c['section'],'title_raw':c['title_raw'],'excerpt':fragment,'card_file':f.relative_to(root).as_posix(),'line':line_no,'source':c['source'],'score':score,'stage':stage}
     if kind=='sports' and opening_date(h):h['score']+=40
     matched_labels.append(label)
     # Annual policy milestones, not one label every weekly repetition.
     group=label
     if kind=='policy' or label in ('여자월드컵','U-20 여자월드컵','U-20 월드컵','대통령선거 개표방송','세월호 추모방송'):group+='|'+c['target_week'][:4]
     if stage:group+='|'+stage
     buckets[(kind,label,group)].append(h)
 events=[];excluded=[]
 for (kind,label,key),hits in sorted(buckets.items()):
  gap=420 if kind=='sports' else 120 if kind=='policy' else 70
  for cluster in clusters(hits,gap):
   org_count=len({h['org_id'] for h in cluster})
   if kind=='national' and len({h['work_id'] for h in cluster})<2:continue
   if kind=='national' and label in ('코로나19 대응','집중호우·수해 대응') and org_count<3:continue
   if kind=='policy' and org_count<2 and len({h['report_week'] for h in cluster})<2 and max(h['score'] for h in cluster)<70:continue
   if kind=='sports' and max(h['score'] for h in cluster)<40:continue
   if kind=='national' and label not in ('대통령선거 개표방송','세월호 추모방송') and max(h['score'] for h in cluster)<(25 if '지진' in label else 42):continue
   # Anchor sports/elections in the strongest live coverage week, not first procurement.
   if kind=='sports' or label=='대통령선거 개표방송':
    anchor=sorted(cluster,key=lambda h:(-h['score'],h['target_week'],h['observation_id']))[0]
   else:
    strong=[h for h in cluster if h['score']>=(42 if kind=='national' else 50)] or cluster
    earliest=min(h['target_week'] for h in strong)
    near=[h for h in strong if 0<=(day(h['target_week'])-day(earliest)).days<=7]
    anchor=sorted(near,key=lambda h:(-h['score'],h['target_week'],h['observation_id']))[0]
   a=anchor;display=(opening_date(a) if kind=='sports' else None) or a['target_week'];stage=a['stage'] or ('개막·중계' if kind=='sports' and rx(r'개막|개회').search(a['excerpt']) else '중계·방송' if kind=='sports' else '업무 대응');title=label+(f' · {stage}' if kind=='policy' else '')
   # Only reference nearby evidence in the detail panel, keeping unrelated preparatory years out.
   near=[h for h in cluster if abs((day(h['target_week'])-day(display)).days)<=35];near.sort(key=lambda h:(h['observation_id']!=a['observation_id'],-h['score'],h['target_week']))
   refs=[];seen=set()
   for h in near:
    if h['observation_id'] not in seen:refs.append({k:v for k,v in h.items() if k not in ('score','stage')});seen.add(h['observation_id'])
   if not refs:continue
   eid='evt_'+hashlib.sha256((kind+'|'+key+'|'+display).encode()).hexdigest()[:16]
   events.append({'event_id':eid,'title':title,'short_title':label,'category':kind,'category_label':{'sports':'방송·스포츠','policy':'정책·법률','national':'국가 중대사'}[kind],'stage':stage,'display_date':display,'date_basis':'source_opening_date' if kind=='sports' and opening_date(a) else 'source_target_week','date_note':'원문 개막·개회 표현 바로 옆의 날짜를 읽어 배치했습니다. 외부 일정과 대조한 확정값은 아닙니다.' if kind=='sports' and opening_date(a) else '업무카드의 실적·계획 대상 주차에 표시했습니다. 실제 대회 개막일·법률 시행일·사건 발생일의 확정값이 아닙니다.','status':'reported' if a['section']=='actual' else 'planned','source_org':a['org_id'],'org_id':a['org_id'],'work_id':a['work_id'],'observation_id':a['observation_id'],'report_week':a['report_week'],'source':a['source'],'card_file':a['card_file'],'card_line':a['line'],'evidence_count':len(seen),'related_card_count':len({h['observation_id'] for h in cluster}),'organization_count':len({h['org_id'] for h in near}),'evidence':refs[:12],'method':'card_context_rules_v1','review_status':'automatic_with_source_links'})
 events.sort(key=lambda e:(e['display_date'],e['category'],e['title']))
 # A broad unnamed women's World Cup event duplicates a named edition if within 5 weeks.
 events=[e for e in events if not (e['title']=='여자월드컵' and any(o['event_id']!=e['event_id'] and '여자월드컵' in o['title'] and o['title']!='여자월드컵' and abs((day(e['display_date'])-day(o['display_date'])).days)<=35 for o in events))]
 events=[e for e in events if not (e['title']=='영남 산불 대응' and any(o['title']=='울진·삼척 산불 대응' and abs((day(o['display_date'])-day(e['display_date'])).days)<=14 for o in events))]
 dump(root/'timeline/events.json',events)
 summary={'method':'card_context_rules_v1','cards_scanned':scanned,'event_count':len(events),'categories':dict(collections.Counter(e['category_label'] for e in events)),'date_basis':'source_target_week_or_explicit_opening_date','notes':['같은 주제의 반복 카드를 묶고 방송·중계, 정책 개정·시행 대응, 재난·국가 중대사 문맥을 선별했습니다.','개막·개회 표현 바로 옆 날짜가 있으면 원문 날짜를 쓰고, 그 외에는 대상 주차에 표시합니다. 실제 사건 발생일이나 법률 시행일을 외부 자료로 검증한 값은 아닙니다.','올림픽공원·경기장 시설명만 등장한 경우, 일반 점검·예방 훈련, 소송만 등장한 경우는 주요 이벤트에서 제외합니다.','주요 사건의 완전한 목록이나 사람의 전수 의미 검수 결과가 아닙니다. 각 표식에서 근거 원문 카드를 확인할 수 있습니다.']}
 dump(root/'reports/event-extraction.json',summary)
 manifest_path=root/'manifest.json'
 if manifest_path.exists():
  m=read(manifest_path)
  for rel,kind in [('timeline/events.json','company_events'),('reports/event-extraction.json','event_extraction_report')]:
   p=root/rel;f={'path':rel,'kind':kind,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
   if rel.endswith('events.json'):f['records']=len(events)
   m['files']=[x for x in m['files'] if x['path']!=rel]+[f]
  m['ui_version']='2.3.0';m['event_summary']='reports/event-extraction.json';m['event_count']=len(events)
  note='주요 이벤트는 업무카드 문맥에서 자동 선별합니다. 원문 개막·개회 날짜가 있으면 해당 날짜, 그 외에는 카드 대상 주차를 사용하며 실제 발생일·법률 시행일 확정값은 아닙니다.'
  for obj in [m['stats']]:obj['limitations']=[note if x.startswith(('회사 주요 이벤트는','주요 이벤트는')) else x for x in obj['limitations']]
  q=read(root/m['summary']);q['limitations']=[note if x.startswith(('회사 주요 이벤트는','주요 이벤트는')) else x for x in q['limitations']];dump(root/m['summary'],q)
  f=next(f for f in m['files'] if f['path']==m['summary']);p=root/m['summary'];f.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
  dump(manifest_path,m)
 print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True);return events
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('root',type=Path,nargs='?',default=(ROOT/'dist' if (ROOT/'dist').exists() else ROOT));args=a.parse_args();make_events(args.root)
