#!/usr/bin/env python3
"""Embed unchanged OTF bytes in local CSS for offline file:// entrypoints."""
from pathlib import Path
import base64,hashlib,json

ROOT=Path(__file__).resolve().parents[1]
folder=ROOT/'assets/fonts'
weights={400:'SCDream4.otf',500:'SCDream5.otf',600:'SCDream6.otf',700:'SCDream7.otf'}
css=['/* S-Core Dream © S-Core Co., Ltd. See S-Core-Dream-License.png. */',
     '/* Original OTF bytes, Base64 transport only: no conversion or subsetting. */']
files=[]
for weight,name in weights.items():
    data=(folder/name).read_bytes()
    assert data[:4]==b'OTTO',name
    css.append("@font-face{font-family:'S-Core Dream';font-style:normal;font-weight:"+str(weight)+";font-display:swap;src:url('data:font/otf;base64,"+base64.b64encode(data).decode('ascii')+"') format('opentype')}")
    files.append({'file':name,'css_weight':weight,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(folder/'s-core-dream.css').write_text('\n'.join(css)+'\n',encoding='utf-8')
source={'family':'S-Core Dream','author':'S-Core Co., Ltd.','official_page':'https://s-core.co.kr/company/font/',
        'official_distribution_url':'https://s-core.co.kr/wp-content/uploads/2020/03/S-Core_Dream_OTF.zip',
        'download_page':'https://grancosmos.tistory.com/116','retrieved_on':'2026-10-23',
        'retrieval_note':'Official host returned 502/503. Retrieved the redistributed OTF archive with its included license image.',
        'license_file':'S-Core-Dream-License.png','embedding':'Original OTF bytes embedded as Base64 in CSS for offline file access; no font conversion, modification or subsetting.',
        'files':files}
(folder/'FONT-SOURCES.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'fonts':len(files),'css_bytes':(folder/'s-core-dream.css').stat().st_size},indent=2))
