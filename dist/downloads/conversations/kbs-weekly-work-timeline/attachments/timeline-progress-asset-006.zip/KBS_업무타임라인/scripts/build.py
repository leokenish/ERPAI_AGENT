#!/usr/bin/env python3
"""KBS HML -> local JSON files. Python 3.10+, standard library; no database."""
import argparse, collections, datetime as dt, difflib, hashlib, json, re, shutil, tempfile, xml.etree.ElementTree as ET
from pathlib import Path
from parser_base import text, split_blocks, title_for, FIELD, extract_period, norm, uid, RULES
ROOT=Path(__file__).resolve().parents[1]
def dump(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
def jsonl(p,rs):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8',newline='\n') as f:
  for r in rs:f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
def loadlines(p):
 with p.open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def safe_name(s):
 # These source names require no substitutions. Keep a manifest mapping for future names.
 return re.sub(r'[<>:"/\\|?*\x00-\x1f]',lambda m:{'/':'／','\\':'＼',':':'：','*':'＊','?':'？','"':'＂','<':'＜','>':'＞','|':'｜'}.get(m[0],' '),s).rstrip(' .') or '이름 없음'
def tokens(s):return set(re.findall(r'[가-힣A-Za-z0-9]{2,}',s.lower()))-{'추진','계속','관련','작업','진행','준비','실시','업무','운영','대한','지원','예정','주요'}
def numeric_signature(s):return set(re.findall(r'\d+(?:[./~~-]\d+)*',s))
def semantic_score(a,b):
 na,nb=norm(a['title_raw']),norm(b['title_raw'])
 if min(len(na),len(nb))<8 or abs(len(na)-len(nb))>max(len(na),len(nb))*.4:return None
 if numeric_signature(a['title_raw'])!=numeric_signature(b['title_raw']):return None
 ta,tb=tokens(a['title_raw']),tokens(b['title_raw']);common=ta&tb
 if len(common)<2:return None
 title=difflib.SequenceMatcher(None,na,nb,autojunk=False).ratio()
 if title<.70:return None
 da,db=tokens(a['raw_text']),tokens(b['raw_text']);details=len(da&db)/max(1,len(da|db))
 return (title,details,len(common))
def build(source_dir,out):
 out.mkdir(parents=True,exist_ok=True)
 for n in ['cards','works','indexes','timeline','extracted','sources','reports']:
  if (out/n).exists():shutil.rmtree(out/n)
 stats=collections.Counter();sources=[];orgs={};presence=collections.defaultdict(set);headings={};files=[];diagnostics=[];events=[]
 def register(path,kind,count=None):
  p=out/path;files.append({'path':path,'kind':kind,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**({'records':count} if count is not None else {})})
 def save(path,obj,kind,count=None,lines=False):
  (jsonl if lines else dump)(out/path,obj);register(path,kind,count)
 with tempfile.TemporaryDirectory(prefix='kbs-spool-') as tmp:
  spool=Path(tmp);paths=sorted(source_dir.rglob('*.hml'));seen_hash={};seen_weeks={}
  if not paths:raise ValueError('입력 HML 파일이 없습니다.')
  for si,source in enumerate(paths):
   raw=source.read_bytes();h=hashlib.sha256(raw).hexdigest();m=re.search(r'20\d{6}',source.name)
   if not m:raise ValueError('파일명에 시작일 YYYYMMDD가 필요합니다: '+source.name)
   week=dt.datetime.strptime(m[0],'%Y%m%d').date().isoformat();year=int(week[:4]);sid=uid('src',source.name,h)
   if week in seen_weeks:raise ValueError('같은 보고 시작일의 파일이 둘 이상입니다. 원본을 확인하세요: '+week)
   seen_weeks[week]=source.name
   if h in seen_hash:diagnostics.append({'kind':'duplicate_content','files':[seen_hash[h],source.name]})
   seen_hash[h]=source.name;rel=f'sources/{year}/{source.name}';(out/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,out/rel);register(rel,'original_hml')
   root=ET.fromstring(raw)
   if root.tag!='HWPML':raise ValueError('지원하지 않는 문서: '+source.name)
   tables=root.findall('.//TABLE');hq={};current='미분류';heads=[];cells=[];obs_byorg=collections.defaultdict(list)
   for p in root.findall('.//SECTION/P'):
    v=text(p).strip()
    if re.match(r'^【.+】$',v):current=v.strip('【】')
    for t in p.findall('.//TABLE'):hq[id(t)]=current
   for ti,tab in enumerate(tables,1):
    rows=tab.findall('./ROW')
    if not rows:continue
    headers=[text(c).strip() for c in rows[0].findall('./CELL')];heads.append(headers)
    for ri,row in enumerate(rows[1:],2):
     cs=row.findall('./CELL')
     if len(cs)!=3:raise ValueError(f'표 구조 검토 필요: {source.name} {ti}:{ri}')
     name=text(cs[0]).strip();oid=name;folder=safe_name(name)
     org=orgs.setdefault(oid,{'org_id':oid,'name':name,'folder':folder,'headquarters':hq.get(id(tab),'미분류'),'headquarters_by_year':{},'years':[],'report_weeks':[]})
     org['headquarters']=hq.get(id(tab),'미분류');org['headquarters_by_year'][str(year)]=org['headquarters']
     if year not in org['years']:org['years'].append(year)
     if week not in org['report_weeks']:org['report_weeks'].append(week)
     presence[week].add(oid)
     for ci,c in enumerate(cs[1:],2):
      kind='actual' if ci==2 else 'plan';target=(dt.date.fromisoformat(week)+dt.timedelta(days=0 if ci==2 else 7)).isoformat();header=headers[ci-1]
      mm=re.search(r'(\d{1,2})[./](\d{1,2})\s*[-~]',header);d=dt.date.fromisoformat(target);conflict=bool(mm and (int(mm[1]),int(mm[2]))!=(d.month,d.day))
      lines=[text(p) for p in c.findall('./PARALIST/P')];cellid=uid('cell',sid,ti,ri,ci)
      cell={'cell_id':cellid,'source_id':sid,'source_file':rel,'report_week':week,'target_week':target,'org_id':oid,'org_raw':name,'section':kind,'header_raw':header,'header_date_conflict':conflict,'table':ti,'row':ri,'column':ci,'paragraphs':lines};cells.append(cell)
      stats['cell_count']+=1;stats['nonblank_paragraphs']+=sum(bool(s.strip()) for s in lines);stats['header_date_conflicts']+=conflict
      used=set()
      for context,idx in split_blocks(lines,name):
       while idx and not lines[idx[-1]].strip():idx=idx[:-1]
       if not idx:continue
       title=title_for(lines,idx)
       if not title:continue
       rawtext='\n'.join(lines[i] for i in idx);owners=[];used.update(idx)
       for i in idx:
        m=FIELD.match(lines[i])
        if m:owners.append({'role_raw':m[1],'value_raw':m[2].strip(),'paragraph':i+1})
       ob={'observation_id':uid('obs',cellid,idx[0]+1),'org_id':oid,'work_id':None,'report_week':week,'target_week':target,'section':kind,'title_raw':title,'context_raw':context,'raw_text':rawtext,'assignees':owners,'period':extract_period(rawtext,target),'source':{'source_id':sid,'file':rel,'cell_id':cellid,'table':ti,'row':ri,'column':ci,'paragraphs':[i+1 for i in idx]},'extraction':{'method':'paragraph_hierarchy_v2','review_status':'automatic_not_exhaustively_reviewed','flags':(['header_date_conflict'] if conflict else [])+(['long_block'] if len(rawtext)>1400 else [])}}
       obs_byorg[oid].append(ob);stats['card_count']+=1;stats['cards_with_explicit_assignee']+=bool(owners);stats['cards_with_date_mentions']+=bool(ob['period']['raw_mentions']);stats['long_blocks']+=len(rawtext)>1400
      cell['noncard_paragraphs']=[i+1 for i,s in enumerate(lines) if s.strip() and i not in used]
      stats['noncard_paragraphs']+=len(cell['noncard_paragraphs'])
   for oid,obs in obs_byorg.items():
    with (spool/(safe_name(oid)+'.jsonl')).open('a',encoding='utf-8') as f:
     for ob in obs:f.write(json.dumps(ob,ensure_ascii=False,separators=(',',':'))+'\n')
   save(f'extracted/{year}/{week.replace("-","")}.cells.jsonl',cells,'source_cells',len(cells),True)
   sources.append({'source_id':sid,'file':rel,'original_name':source.name,'sha256':h,'bytes':len(raw),'report_week':week,'actual_week':week,'plan_week':(dt.date.fromisoformat(week)+dt.timedelta(days=7)).isoformat(),'table_count':len(tables),'org_count':len(presence[week]),'cell_count':len(cells),'card_count':sum(map(len,obs_byorg.values())),'header_samples':heads[:1],'date_basis':'filename_start_date; table_headers_checked','template_date_ignored':root.findtext('.//DOCSUMMARY/DATE')})
   if (si+1)%60==0 or si+1==len(paths):print(f'EXTRACT {si+1}/{len(paths)} cards={stats["card_count"]}',flush=True)
  weeks=sorted(presence);all_dates=[];d=dt.date.fromisoformat(weeks[0]);end=dt.date.fromisoformat(weeks[-1])
  while d<=end:all_dates.append(d.isoformat());d+=dt.timedelta(days=7)
  missing_reports=sorted(set(all_dates)-set(weeks))
  # Process only one organization's raw cards at a time, keeping the full archive out of memory.
  for oi,(oid,org) in enumerate(orgs.items(),1):
   folder=org['folder'];obs=loadlines(spool/(folder+'.jsonl')) if (spool/(folder+'.jsonl')).exists() else [];works={};exact={};recent={};reviewed={};candidates=[];decisions=[];candidate_seen=set()
   by_report=collections.defaultdict(list)
   for ob in obs:by_report[ob['report_week']].append(ob)
   for week,weekly in sorted(by_report.items()):
    # Candidates only come from nearby reports in the same original organization.
    cutoff=(dt.date.fromisoformat(week)-dt.timedelta(days=21)).isoformat();recent={wid:c for wid,c in recent.items() if c['report_week']>=cutoff}
    inverted=collections.defaultdict(set)
    for wid,c in recent.items():
     for tok in tokens(c['title_raw']):inverted[tok].add(wid)
    for ob in weekly:
     title=ob['title_raw'];key=('|'.join(ob['context_raw']),norm(title));wid=None;method='new_work';reason='동일 업무로 연결할 근거가 확인되지 않아 새 업무로 시작.';label=title;matches=[];rule=None
     for o,k,pat,l,r in RULES:
      if oid==o and '2026-09-14'<=week<='2026-10-12' and re.search(pat,title):rule=(k,l,r);break
     if rule and rule[0] in reviewed:wid=reviewed[rule[0]];method='reviewed_context';reason=rule[2];label=rule[1]
     elif key in exact and (dt.date.fromisoformat(week)-dt.date.fromisoformat(works[exact[key]]['last_seen'])).days<=84:
      wid=exact[key];method='normalized_title';reason='같은 조직·분류의 제목이 공백·기호·(계속) 제거 후 일치하며 마지막 관측 후 12주 이내.'
     if wid is None:
      common=collections.Counter(x for tok in sorted(tokens(title)) for x in sorted(inverted.get(tok,())))
      for prev,_ in common.most_common(30):
       old=recent[prev]
       if ob['context_raw'] and old['context_raw'] and ob['context_raw']!=old['context_raw']:continue
       score=semantic_score(ob,old)
       if score:matches.append((score[0]*.65+score[1]*.35,score,prev))
      matches.sort(reverse=True)
      if matches:
       best,score,prior=matches[0];margin=best-(matches[1][0] if len(matches)>1 else 0)
       if score[0]>=.82 and score[1]>=.50 and score[2]>=2 and margin>=.10:
        wid=prior;method='context_inference';reason=f'인접 보고의 업무 대상어 {score[2]}개 일치, 제목 유사도 {score[0]:.3f}, 본문 어휘 겹침 {score[1]:.3f}. 숫자 표현과 분류 충돌 없음. 자동 추론이며 검토 필요.'
     if wid is None:wid=uid('work',oid,ob['observation_id'])
     if rule:
      reviewed[rule[0]]=wid;method='reviewed_context';reason=rule[2];label=rule[1]
     if wid not in works:works[wid]={'work_id':wid,'org_id':oid,'title':label,'aliases':[],'context_raw':ob['context_raw'],'link_method':method,'link_reason':reason,'segments':[],'related_work_ids':[],'first_seen':week,'last_seen':week,'card_count':0,'report_count':0,'owners':[],'has_unassigned':False,'card_files':[],'weekly':{},'search_text':''}
     w=works[wid];w['last_seen']=week;w['card_count']+=1
     if method in ('reviewed_context','context_inference') and (method=='reviewed_context' or w['link_method']!='reviewed_context'):w['link_method']=method;w['link_reason']=reason
     if rule:w['title']=label
     if title not in w['aliases']:w['aliases'].append(title)
     w['has_unassigned']|=not ob['assignees']
     for a in ob['assignees']:
      if a['value_raw'] not in w['owners']:w['owners'].append(a['value_raw'])
     wk=w['weekly'].setdefault(week,{'actual':0,'plan':0,'targets':[]});wk[ob['section']]+=1
     if ob['section']=='plan' and ob['target_week'] not in wk['targets']:wk['targets'].append(ob['target_week'])
     ob['work_id']=wid;ob['link']={'method':method,'reason':reason,'is_inference':True,'confidence':'reviewed_sample' if method=='reviewed_context' else 'automatic'}
     exact[key]=wid;recent[wid]=ob
     if method in ('reviewed_context','context_inference'):decisions.append({'org_id':oid,'work_id':wid,'observation_id':ob['observation_id'],'method':method,'reason':reason,'report_week':week})
     if method=='new_work':
      for _,score,prev in matches[:2]:
       pair=tuple(sorted([prev,wid]))
       if pair not in candidate_seen:
        candidate_seen.add(pair);candidates.append({'org_id':oid,'work_a':prev,'work_b':wid,'title_a':works[prev]['title'],'title_b':title,'report_week':week,'title_similarity':round(score[0],3),'detail_overlap':round(score[1],3),'decision':'unresolved_separate','reason':'비슷한 제목이지만 동일 대상·범위의 연속이라고 확정하지 않아 별도 업무로 유지.'})
   index_by_year={};ref_by_work=collections.defaultdict(list);months=collections.defaultdict(list);counts=collections.Counter(c['report_week'] for c in obs)
   for c in obs:months[c['report_week'][:7]].append(c)
   for month,cs in sorted(months.items()):
    year=int(month[:4]);cp=f'cards/{folder}/{year}/{folder}_{month}.jsonl';save(cp,cs,'weekly_cards',len(cs),True)
    idx=index_by_year.setdefault(year,{'org_id':oid,'year':year,'card_shards':[],'by_week':{},'by_work':{}});idx['card_shards'].append(cp)
    for line,c in enumerate(cs,1):
     ref={'observation_id':c['observation_id'],'file':cp,'line':line};idx['by_week'].setdefault(c['report_week'],[]).append(ref);idx['by_work'].setdefault(c['work_id'],[]).append(ref);ref_by_work[c['work_id']].append(ref)
     w=works[c['work_id']]
     if cp not in w['card_files']:w['card_files'].append(cp)
   orgweeks=org['report_weeks'];weekpos={w:i for i,w in enumerate(orgweeks)}
   for w in works.values():
    mentions=sorted(w['weekly']);w['report_count']=len(mentions);groups=[]
    for week in mentions:
     if not groups or weekpos[week]!=weekpos[groups[-1][-1]]+1:groups.append([])
     groups[-1].append(week)
    for group in groups:
     first,last=group[0],group[-1];j=weekpos[last]+1;merge=orgweeks[j] if j<len(orgweeks) else None
     # A missing organization never proves completion. End an unobserved tail at its own last boundary.
     reason='unmentioned_in_next_available_report' if merge else ('latest_report_boundary' if last==weeks[-1] else 'organization_data_boundary')
     stop=merge or (dt.date.fromisoformat(last)+dt.timedelta(days=7)).isoformat()
     gaps=[d for d in all_dates if first<d<stop and d not in orgweeks]
     w['segments'].append({'segment_id':uid('segment',w['work_id'],first),'start_week':first,'last_seen_week':last,'mention_weeks':group,'gaps':gaps,'merge_week':merge,'end_reason':reason,'planned_target_weeks':w['weekly'][last]['targets']})
    w['search_text']=' '.join(w['aliases']+w['owners']).lower();stats['reviewed_context_work_count']+=w['link_method']=='reviewed_context';stats['inferred_context_work_count']+=w['link_method']=='context_inference'
   org['card_count']=len(obs);org['work_count']=len(works);stats['work_count']+=len(works);stats['unresolved_pair_count']+=len(candidates)
   org['overview']=f'timeline/{folder}/{folder}_전체흐름.json';org['work_catalog']=f'works/{folder}/{folder}_업무목록.jsonl';org['candidate_file']=f'reports/{folder}/{folder}_연결검토.jsonl';org['year_indexes']={str(y):f'indexes/{folder}/{y}.json' for y in index_by_year};org['week_counts']=dict(counts)
   save(org['work_catalog'],[{**w,'observation_refs':ref_by_work[w['work_id']]} for w in works.values()],'work_identity',len(works),True)
   for year,idx in index_by_year.items():save(org['year_indexes'][str(year)],idx,'lookup_index')
   save(org['overview'],{'org_id':oid,'available_weeks':orgweeks,'week_counts':dict(counts),'works':list(works.values())},'timeline_overview')
   save(org['candidate_file'],candidates,'unresolved_candidates',len(candidates),True)
   save(f'reports/{folder}/{folder}_연결판단.jsonl',decisions,'link_decisions',len(decisions),True)
   for title,short,pat,display,status in [('2026 국정감사 개별 감사 수감','국정감사 수감',r'국정감사 개별 감사 수감','2026-10-16','reported'),('2026 국정감사 종합 감사 준비','종합 감사 예정',r'국정감사 종합 감사 준비','2026-10-22','planned')]:
    c=next((o for o in obs if oid=='대외협력국' and o['report_week']=='2026-10-12' and re.search(pat,o['title_raw'])),None)
    if c:events.append({'event_id':uid('event',title,display),'title':title,'short_title':short,'display_date':display,'status':status,'source_org':oid,'org_id':oid,'work_id':c['work_id'],'observation_id':c['observation_id'],'report_week':c['report_week'],'source':c['source']})
   print(f'LINK {oi}/{len(orgs)} {oid}: {len(obs)} cards / {len(works)} works',flush=True)
  allorg=sorted(orgs.values(),key=lambda o:(o['headquarters'],o['name']));assert len(set(o['folder'].casefold() for o in allorg))==len(allorg),'조직 폴더명 충돌'
  save('indexes/organizations.json',{'years':sorted({y for o in allorg for y in o['years']}),'organizations':allorg},'organization_index');save('sources/catalog.json',sources,'source_catalog');save('timeline/events.json',events,'company_events',len(events))
  stats.update(source_count=len(sources),organization_count=len(allorg));quality=dict(stats)
  quality['coverage']=[{'report_week':s['report_week'],'present_orgs':s['org_count'],'missing_orgs':[o['name'] for o in allorg if o['report_weeks'][0]<=s['report_week']<=o['report_weeks'][-1] and o['org_id'] not in presence[s['report_week']]],'policy':'inside_observed_org_lifetime_only; gap_not_completion'} for s in sources]
  quality['missing_report_weeks']=missing_reports;quality['diagnostics']=diagnostics
  quality['limitations']=['전체 업무의 의미적 동일성을 사람이 전수 검수한 결과가 아닙니다. 자동 맥락 연결과 표본 검토를 구분했습니다.','동일 이름의 조직을 같은 원문 조직으로 묶고, 이름이 다른 조직은 개편·승계 관계를 추측하지 않습니다. 연도별 본부 표기를 별도 보존합니다.','제목·본문·시점의 제한된 자동 연결입니다. 미확정 후보는 별도 가지로 유지합니다. 숫자 표현이 달라지면 맥락 자동 연결 대상에서 제외합니다.','담당자 명시 필드만 추출하고 원문 오기·누락은 고치지 않습니다.','날짜 해석은 참고용입니다. 가지의 수명은 보고서 언급 여부이며 실제 사업 착수·완료 기간과 다릅니다.','회사 주요 이벤트는 앞서 원문을 검토한 2026년 국정감사 2건만 수록했습니다. 12년 전체 주요 이벤트를 선별한 결과는 아닙니다.','연결되지 않은 분류·표제 문단도 extracted 원문 셀에 모두 남겨 두었습니다.']
  save('reports/extraction-summary.json',quality,'extraction_report')
  manifest={'schema_version':'2.0.0','dataset_id':'kbs-weekly-archive','release_id':uid('release',*(s['sha256'] for s in sources)),'report_weeks':weeks,'time_range':{'start':weeks[0],'end':weeks[-1],'last_plan_week':sources[-1]['plan_week']},'navigation':['year','org_id'],'key_order':['org_id','work_id','observation_id'],'organization_index':'indexes/organizations.json','source_catalog':'sources/catalog.json','summary':'reports/extraction-summary.json','stats':{k:v for k,v in quality.items() if k not in ('coverage',)},'rules':{'raw_data':'unchanged','main_trunk':'report_week','return':'next_available_org_report_without_mention','missing_org':'gap','latest_boundary':'open','organization_boundary':'open_at_last_observation_not_extended_without_evidence','week_label':'thursday_month_monday_sunday','work_reuse_max_gap_days':84,'context_inference_max_gap_days':21},'files':files};dump(out/'manifest.json',manifest)
  from build_events import make_events
  make_events(out)
  print(json.dumps({'stats':dict(stats),'data_files':len(files)+1,'time_range':manifest['time_range']},ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=(ROOT/'inputs' if (ROOT/'inputs').exists() else ROOT/'sources'));ap.add_argument('--out',type=Path,default=(ROOT/'dist' if (ROOT/'dist').exists() else ROOT));a=ap.parse_args()
 # Inputs inside the output are supported without losing the originals during rebuilding.
 with tempfile.TemporaryDirectory(prefix='kbs-input-') as t:
  for p in a.source.rglob('*.hml'):
   dest=Path(t)/p.name
   if dest.exists():raise ValueError('입력 파일명 중복: '+p.name)
   shutil.copyfile(p,dest)
  build(Path(t),a.out)
