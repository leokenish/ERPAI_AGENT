#!/usr/bin/env python3
"""Read-only archive audit. Checks raw source correspondence and every JSON reference."""
import collections,hashlib,json,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
from parser_base import text
from build_events import opening_date,day
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def jl(p):
 with p.open(encoding='utf-8') as f:
  for l in f:
   if l.strip():yield json.loads(l)
def validate(root):
 start=time.time();m=read(root/'manifest.json');orgs=read(root/m['organization_index'])['organizations'];srcs=read(root/m['source_catalog']);cells={};ids=set();cardmeta={};total=0;works_count=0;source_cards=collections.Counter()
 for f in m['files']:
  p=root/f['path'];assert p.stat().st_size==f['bytes'],f['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],f['path'];assert '/org_' not in f['path'],f['path']
 print('PASS: all file hashes and readable organization paths',flush=True)
 for src in srcs:
  p=root/src['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==src['sha256'];tree=ET.parse(p).getroot();tabs=tree.findall('.//TABLE');week=src['report_week'];cp=root/f'extracted/{week[:4]}/{week.replace("-","")}.cells.jsonl';cc=0
  for c in jl(cp):
   actual=tabs[c['table']-1].findall('./ROW')[c['row']-1].findall('./CELL')[c['column']-1];pars=[text(p) for p in actual.findall('./PARALIST/P')];assert pars==c['paragraphs'];assert c['cell_id'] not in cells;cells[c['cell_id']]=pars;cc+=1
  assert cc==src['cell_count']
 print('PASS: every extracted cell matches original HML paragraphs',flush=True)
 for org in orgs:
  assert org['org_id']==org['name'];ow={w['work_id']:w for w in jl(root/org['work_catalog'])};works_count+=len(ow);counts=collections.Counter();weeks=collections.defaultdict(set);refs_bywork=collections.defaultdict(list);orgtotal=0;actualweekly=collections.defaultdict(lambda:collections.defaultdict(collections.Counter))
  for year,ip in org['year_indexes'].items():
   idx=read(root/ip);assert idx['org_id']==org['name'];iw=collections.defaultdict(list);ib=collections.defaultdict(list)
   for cp in idx['card_shards']:
    assert cp.split('/')[1]==org['folder'];cm=[]
    for line,c in enumerate(jl(root/cp),1):
     cid=c['observation_id'];assert cid not in ids;ids.add(cid);assert c['org_id']==org['org_id'];wid=c['work_id'];assert wid in ow
     pars=cells[c['source']['cell_id']];assert c['raw_text']=='\n'.join(pars[i-1] for i in c['source']['paragraphs']),cid
     counts[wid]+=1;weeks[wid].add(c['report_week']);ref={'observation_id':cid,'file':cp,'line':line};iw[c['report_week']].append(ref);ib[wid].append(ref);refs_bywork[wid].append(ref);total+=1;orgtotal+=1;source_cards[c['report_week']]+=1;actualweekly[wid][c['report_week']][c['section']]+=1
     cm.append((cid,wid,c['report_week']))
    cardmeta[cp]=cm
   assert dict(iw)==idx['by_week'],ip;assert dict(ib)==idx['by_work'],ip
  assert orgtotal==org['card_count']
  for wid,w in ow.items():
   assert counts[wid]==w['card_count'];assert len(weeks[wid])==w['report_count'];assert refs_bywork[wid]==w['observation_refs'];assert set(w['weekly'])==weeks[wid]
   for week,v in w['weekly'].items():assert v['actual']==actualweekly[wid][week]['actual'] and v['plan']==actualweekly[wid][week]['plan']
   flat=[]
   for seg in w['segments']:
    flat+=seg['mention_weeks'];assert seg['start_week']==seg['mention_weeks'][0];assert seg['last_seen_week']==seg['mention_weeks'][-1]
    after=[d for d in org['report_weeks'] if d>seg['last_seen_week']]
    if seg['merge_week']:assert after and seg['merge_week']==after[0] and seg['merge_week'] not in weeks[wid]
    else:assert not after
    assert not (set(seg['gaps'])&set(org['report_weeks']))
   assert sorted(flat)==sorted(weeks[wid])
  overview=read(root/org['overview']);assert len(overview['works'])==len(ow)
  for w in overview['works']:assert w=={k:v for k,v in ow[w['work_id']].items() if k!='observation_refs'}
 for src in srcs:assert source_cards[src['report_week']]==src['card_count']
 event_cache={};event_ids=set();evidence_checked=0;events=read(root/'timeline/events.json')
 for ev in events:
  assert ev['event_id'] not in event_ids;event_ids.add(ev['event_id']);assert ev['observation_id'] in ids
  assert ev['evidence'] and ev['evidence_count']>=len(ev['evidence'])
  for ref in ev['evidence']:
   cp=ref['card_file'];assert cp in cardmeta
   if cp not in event_cache:event_cache[cp]=list(jl(root/cp))
   assert 1<=ref['line']<=len(event_cache[cp]);c=event_cache[cp][ref['line']-1]
   for key in ['org_id','work_id','observation_id','report_week','target_week','section','title_raw','source']:assert ref[key]==c[key],(ev['event_id'],key)
   # Excerpts may join separated source lines. Every line, including a truncated
   # final line, must still occur in the original in the same order.
   cursor=0
   for part in ref['excerpt'].splitlines():
    if not part:continue
    pos=c['raw_text'].find(part,cursor);assert pos>=0,(ev['event_id'],'excerpt');cursor=pos+len(part)
   assert abs((day(ref['target_week'])-day(ev['display_date'])).days)<=35
   evidence_checked+=1
  primary=ev['evidence'][0]
  for key in ['org_id','work_id','observation_id','report_week','source','card_file']:assert ev[key]==primary[key]
  assert ev['card_line']==primary['line']
  assert ev['status']==('reported' if primary['section']=='actual' else 'planned')
  assert ev['date_basis'] in ('source_opening_date','source_target_week')
  expected=opening_date(primary) if ev['date_basis']=='source_opening_date' else primary['target_week']
  assert ev['display_date']==expected
 assert len(events)==m['event_count']
 print(f'PASS: {len(events)} event markers and {evidence_checked} source evidence references',flush=True)
 assert total==m['stats']['card_count'];assert works_count==m['stats']['work_count'];assert len(cells)==m['stats']['cell_count']
 result={'status':'passed','source_files':len(srcs),'organizations':len(orgs),'cards_checked':total,'works_checked':works_count,'cells_checked':len(cells),'events_checked':len(events),'event_evidence_checked':evidence_checked,'data_files_checked':len(m['files'])+1,'duration_seconds':round(time.time()-start,2),'checks':['All manifest sizes and SHA-256 hashes','Original organization names in folder paths','Every extracted cell vs HML paragraph text','Every card raw_text vs referenced source paragraphs','Unique card IDs and existing work IDs','Every year/week/work file-line reference','Every branch segment vs next available org report','Every summary vs work catalog','Every event evidence file, line, ID and excerpt vs original card','Every event display date vs documented source-date basis'],'limits':['Meaningful task identity is not proven by structural checks.','Visual layout was not browser-tested in this environment.']}
 (root/'reports/validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2));return result
if __name__=='__main__':validate(Path(sys.argv[1]) if len(sys.argv)>1 else (ROOT/'dist' if (ROOT/'dist').exists() else ROOT))
