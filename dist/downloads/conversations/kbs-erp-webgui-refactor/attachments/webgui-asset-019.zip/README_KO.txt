SAP WebGUI Modern V2 — 실제 SAP 적용 전 후보
작성: 2026-10-15

먼저 WebGUI_V2_Change_Report.html을 여세요.
정확한 원본 경로, MIMENAME/LONGNAME 또는 MODULPOOL, 112개 수동 체크 목록,
37개 텍스트 diff, 75개 이미지 전후 비교와 개별 파일 다운로드가 있습니다.
HTML 미리보기에서 기능이 막히면 내려받아 브라우저에서 여세요.

실제 교체 객체: CSS 21 + JS 6 + HTMLBusiness 템플릿 10 + GIF 75 = 112개
WEBGUI / SL MIME 102개, WEBGUI / DM 템플릿 10개입니다.
.sap.xml 112개 동기화까지 포함하면 변경된 물리 파일은 224개입니다.
metadata는 SE80에서 별도로 112개 객체를 더 교체한다는 뜻이 아닙니다.
추가/삭제 실행 파일 0, SYSTEM 수정 0, 새 SAP 폰트/외부 CDN/프레임워크 0.
V1이 정확히 적용되어 있으면 추가로 달라지는 실행 파일은 107개입니다.

apply/services: 완성된 교체 파일 112개. 원본 경로 그대로.
rollback_to_original/services: 위 112개의 제공 원본.
rollback_to_v1/services: 위 112개의 V1 상태.
upgrade_from_v1/services: V1 대비 변경된 107개만.
delta/services: 변경된 실행 파일과 .sap.xml 224개.
rollback_all_original/services: 물리 파일 224개의 원본.
original: 업로드한 WEBGUI/SYSTEM ZIP을 바이트 변경 없이 보존.
modified/ITS_WEBGUI_Modern_v2.zip: 전체 WEBGUI 수정본. 원본 manifest는 추출 이력.
analysis: 전체 4,243개 목록, 파일별 변경/해시, diff, 참조, 검사 결과.
review: 실제 CSS/GIF를 쓰는 가상 데이터 비교 화면과 로컬 렌더링.
tools, icon_sources, rebuild_support: 로컬 생성/검사 코드·SVG 제작 원본. SAP 업로드 대상 아님.

적용 시 주의할 실제 의존성
폰트/행 높이와 템플릿 좌표를 함께 바꿨으므로 CSS만 먼저 적용하지 마세요.
실제 CSS Response, 실행 테마, 현재 SE80 객체의 키/긴 이름을 대조하세요.
현재 시스템이 제공 원본과 다르면 현재 변경분을 백업/병합해야 합니다.
정확한 메뉴·게시 대상·전송·캐시 절차는 시스템 자료가 없어 미확인입니다.
현재 담당 절차에 맞춰 완성 세트를 반영하고 실제 업무 회귀를 수행하세요.
원본 manifest는 분석용 ITS-SOURCE-EXPORT/1이며 Z_PACKAGE_IMPORT 호환 파일이 아닙니다.

검증 결과
정적 검사 20개, Linux headless Chromium 153.0.8010.0 검사 25개 통과.
ITS 컴파일, 실제 SAP 기능, Windows Chrome/Edge/Firefox와 실제 IME는 미검증.
예시 DOM/합성 이벤트와 의존성 스텁 검사로 SAP 저장/조회 검증을 대신하지 않습니다.
미리보기는 Noto Sans KR(SIL OFL)을 내장하며 실제 SAP에는 배포하지 않습니다.

원복
현재 SAP에서 받은 백업 112개를 우선 사용하세요. 제공 원본과 같았다면
rollback_to_original, 이전 V1으로 돌아가려면 rollback_to_v1을 사용합니다.
동일한 게시/전송/캐시 절차 후 화면과 업무를 확인하세요.
