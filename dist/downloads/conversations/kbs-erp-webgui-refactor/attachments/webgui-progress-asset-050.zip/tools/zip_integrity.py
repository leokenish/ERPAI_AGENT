"""Verify finalized bytes, including the local headers read by ZIP importers."""
from io import BytesIO
from zipfile import ZipFile
from hashlib import sha256
from pathlib import Path
import json, struct, sys, zlib

def require(ok, message):
    if not ok: raise ValueError(message)

def verify_archive(raw, manifest=False):
    end = raw.rfind(b'PK\x05\x06')
    require(end >= 0, 'ZIP end-of-central-directory record missing')
    require(end + 22 <= len(raw), 'Truncated ZIP end record')
    _, disk, cd_disk, disk_count, count, cd_size, cd_start, comment = struct.unpack_from('<4s4H2IH', raw, end)
    require(disk == cd_disk == 0 and disk_count == count and count < 65535, 'Unsupported split/ZIP64 archive')
    require(end + 22 + comment == len(raw), 'Trailing or truncated ZIP data')
    require(cd_start + cd_size == end, 'Central directory bounds disagree')
    with ZipFile(BytesIO(raw)) as z:
        infos = z.infolist()
        require(len(infos) == count and len({i.filename.upper() for i in infos}) == count, 'Entry count or duplicate path')
        require(sum(i.file_size for i in infos) <= 67108864 and all(i.file_size <= 8388608 for i in infos), 'Archive size limit')
        offset = 0
        for i in sorted(infos, key=lambda v:v.header_offset):
            require(i.header_offset == offset, 'Missing/overlapping local ZIP entry')
            require(raw[offset:offset+4] == b'PK\x03\x04', 'Local header missing')
            h = struct.unpack_from('<IHHHHHIIIHH', raw, offset)
            flags, method, crc, packed, size, name_len, extra_len = h[2],h[3],h[6],h[7],h[8],h[9],h[10]
            require(flags & 9 == 0, 'Encrypted or unfinished streaming ZIP entry')
            require((method,crc,packed,size) == (i.compress_type,i.CRC,i.compress_size,i.file_size), 'Local header and central directory disagree')
            name = raw[offset+30:offset+30+name_len].decode('utf-8' if flags & 2048 else 'cp437')
            require(name == i.filename, 'Local and central filenames disagree')
            start = offset + 30 + name_len + extra_len
            offset = start + packed
            require(offset <= cd_start, 'Truncated compressed entry')
            data = raw[start:offset]
            if method == 8:
                inflater = zlib.decompressobj(-15)
                data = inflater.decompress(data, size + 1) + inflater.flush()
                require(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail, 'Incomplete DEFLATE stream')
            else:
                require(method == 0, 'Unsupported compression method')
            require(len(data) == size and zlib.crc32(data) == crc, 'Uncompressed bytes/CRC disagree')
            require(data == z.read(i), 'Independent entry reads disagree')
        require(offset == cd_start, 'Local entries do not end at central directory')
        result = {'bytes':len(raw), 'sha256':sha256(raw).hexdigest(), 'entries':count, 'zip_structure':'PASS'}
        if manifest:
            rows = json.loads(z.read('manual_file_manifest.json'))
            require(isinstance(rows,list) and bool(rows), 'Manifest must contain asset rows')
            assets=[]
            for row in rows:
                key=row['sap_key']; p=row['path']; longname=row['longname']; category=row['category']
                require(category in ['js','css'], 'Unexpected asset category')
                require(key['SERVICE']=='WEBGUI' and key['THEME']=='SL' and key['MIMENAME']==longname, 'Unexpected SAP MIME key')
                require(p == 'services/WEBGUI/themes/SL/mime/'+longname and longname.lower().endswith('.'+category), 'SAP key/path mismatch')
                check={'path':p}
                for prefix, side in [('apply/','after'),('rollback_to_original/','before')]:
                    data=z.read(prefix+p)
                    require(type(row[side+'_bytes']) is int, 'Noninteger manifest byte count')
                    require(len(data) == row[side+'_bytes'], 'Manifest byte count and ZIP content disagree: '+prefix+p)
                    require(sha256(data).hexdigest() == row[side+'_sha256'], 'Manifest SHA256 disagrees: '+prefix+p)
                    check[side+'_bytes']=len(data)
                assets.append(check)
            expected=sorted(row['path'] for row in rows)
            require(len(set(expected))==len(expected), 'Duplicate manifest target')
            for prefix in ['apply/','rollback_to_original/']:
                require(sorted(n[len(prefix):] for n in z.namelist() if n.startswith(prefix)) == expected, 'Unmapped ZIP target')
            result['manifest_contract']='PASS';result['assets']=assets
        return result

if __name__ == '__main__':
    results=[]
    for name in sys.argv[1:]:
        p=Path(name)
        result=verify_archive(p.read_bytes(),manifest=p.name.startswith('SE80_'))
        result['file']=p.name;results.append(result)
    print(json.dumps({'results':results},ensure_ascii=False,indent=2))
