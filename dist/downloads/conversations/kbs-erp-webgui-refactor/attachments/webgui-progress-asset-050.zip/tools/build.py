from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
JS = Path('services/WEBGUI/themes/SL/mime/SCRIPTS/GUI.JS')
CSS = Path('services/WEBGUI/themes/SL/mime/STYLE/GUI_BUTTON.CSS')
s = (ROOT/'baseline'/JS).read_text(encoding='utf-8')
approval = s[s.index('/* KBS_WGUI_APPROVAL_BEGIN'):]
old = '      size = Math.min(18, Math.max(1, el.clientHeight - 6), only ? Math.max(1, el.clientWidth - 6) : 18);\n      img.style.width = size + "px"; img.style.height = size + "px";'
assert s.count(old) == 1
s = s.replace(old, (ROOT/'src/button-sizing.js').read_text().rstrip())
s = s.replace('/* KBS V4.2.5: stable calendar sizing; original SAP icon contours retained. */', '/* KBS V4.2.6: bounded scroll regions and stable native icon buttons. */')
s = s.replace('api.version = "4.2.5"', 'api.version = "4.2.6"').replace('r.patch = "4.2.5"', 'r.patch = "4.2.6"')
old = 'var frame = w.frameElement, border = d.querySelector(".WebguiDynproBorder");'
assert s.count(old) == 1
s = s.replace(old, 'var frame = w.frameElement, border = d.querySelector(".WebguiDynproBorder, .WebguiPopupBorder, .WebguiDynproBorderRTL, .WebguiPopupBorderRTL");')
s = s.replace('    api.fittingPopup = true;\n', '    frame.style.boxSizing = "border-box"; // Sizes include the native iframe border.\n    api.fittingPopup = true;\n', 1)
marker = '  var oldInit42 = api.init, bound42 = false, queued42 = false;'
s = s.replace(marker, (ROOT/'src/scroll-layout.js').read_text()+'\n'+marker)
s = s.replace('api.spaceControlRows(); api.fitPopup();', 'api.spaceControlRows(); api.fitPopup(); api.layoutScrollAreas();')
s = s.replace('bound42 = true; w.addEventListener("resize", queue42, false);', '''bound42 = true; w.addEventListener("resize", queue42, false);
      d.addEventListener("click", function (event) {
        var el = event.target;
        while (el && el !== d.body) {
          if (el.id === "SHSearchCriteriaVisible") { queue42(); break; }
          el = el.parentElement;
        }
      }, false);''')
s = s.replace('    r.spacedControls = d.querySelectorAll', '''    r.scrollLayout = {version:"4.2.6", mode:(d.getElementById("webguiDynpro") || d.body).getAttribute("data-kbs-scroll-mode"),
      owners:d.querySelectorAll("[data-kbs-scroll-owner]").length};
    r.spacedControls = d.querySelectorAll''')
assert s[s.index('/* KBS_WGUI_APPROVAL_BEGIN'):] == approval
(ROOT/'modified'/JS).write_bytes(s.replace('\n','\r\n').encode('utf-8'))
css = (ROOT/'baseline'/CSS).read_text() + (ROOT/'src/button-sizing.css').read_text()
(ROOT/'modified'/CSS).write_bytes(css.replace('\n','\r\n').encode('utf-8'))
for p in (JS,CSS):
 data=(ROOT/'modified'/p).read_bytes()
 print(p.name, len(data), hashlib.sha256(data).hexdigest())
