from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json, difflib, subprocess, os, sys, xml.etree.ElementTree as ET
from io import BytesIO
from tempfile import NamedTemporaryFile
from zip_integrity import verify_archive

R=Path(__file__).resolve().parents[1]
A=R/'analysis'; O=R.parent/'deliverables'; O.mkdir(exist_ok=True)
RELS=['services/WEBGUI/themes/SL/mime/SCRIPTS/GUI.JS','services/WEBGUI/themes/SL/mime/STYLE/GUI_BUTTON.CSS']
checks=[]
def digest(b):return sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def check(name,ok):
    checks.append({'name':name,'status':'PASS' if ok else 'FAIL'})
    if not ok:raise AssertionError(name)

js0=(R/'baseline'/RELS[0]).read_bytes();js1=(R/'modified'/RELS[0]).read_bytes()
check('Exact V428 GUI.JS baseline',digest(js0)=='c0bd6269975220290e45a04f3bd80a0791dc95d2daf274f982d6088845897699')
check('Only two intended files in apply tree',sorted(str(p.relative_to(R/'modified')) for p in (R/'modified').rglob('*') if p.is_file())==sorted(RELS))
check('JavaScript syntax',subprocess.run([os.environ.get('CODEX_PRIMARY_RUNTIME_NODE','node'),'--check'],input=js1,capture_output=True).returncode==0)
check('Approval 1.4.5 byte identity',js0.split(b'/* KBS_WGUI_APPROVAL_BEGIN',1)[1]==js1.split(b'/* KBS_WGUI_APPROVAL_BEGIN',1)[1])
check('All large embedded SVG catalog lines identical',[s for s in js0.splitlines() if len(s)>100000]==[s for s in js1.splitlines() if len(s)>100000])
check('Calendar growth-fix source block unchanged',js0.split(b'  var oldPopupSize42 =',1)[1].split(b'  api.inspectUI =',1)[0]==js1.split(b'  var oldPopupSize42 =',1)[1].split(b'  api.inspectUI =',1)[0])
check('UI release markers',b'api.version = "4.2.6"' in js1 and b'r.patch = "4.2.6"' in js1 and b'--kbs-button-release:4.2.6' in (R/'modified'/RELS[1]).read_bytes())
new_source=(R/'src/scroll-layout.js').read_text()
check('Layout does not submit commands, change page ranges, or dispatch global resize',all(x not in new_source for x in ['raiseEvent(', 'webguiRaiseEvent(', 'fetch(', '.visRange =', '.totalRange =', 'dispatchEvent(']))
tests=json.loads((R/'review/layout-results.json').read_text())
check('Every browser check passed',tests['summary']['fail']==0 and tests['summary']['pass']>=59 and not tests['errors'])
check('Browser test ran against exact final assets',tests['assets']=={p:digest((R/'modified'/p).read_bytes()) for p in RELS})
readme=(R/'README.template.md').read_text().replace('{{BROWSER}}',tests['browser']).replace('{{PASSED}}',str(tests['summary']['pass']))
check('Live SAP limitation documented','실제 SAP 서버의 업무 데이터' in readme)
(O/'README_WebGUI_V429_KO.md').write_text(readme,encoding='utf-8')

rows=[];diff=[]
for rel in RELS:
    a=(R/'baseline'/rel).read_bytes();b=(R/'modified'/rel).read_bytes()
    check(rel+' UTF8 CRLF without BOM',not b.startswith(b'\xef\xbb\xbf') and b.count(b'\n')==b.count(b'\r\n') and bool(b.decode('utf-8')))
    xml=ET.fromstring((R/'reference_keys'/(rel+'.sap.xml')).read_bytes())
    key={n.tag:n.text or '' for n in xml.find('.//KEY')};longname=xml.findtext('.//LONGNAME')
    check(rel+' existing SAP MIME key',key=={'SERVICE':'WEBGUI','THEME':'SL','MIMENAME':rel.split('/mime/',1)[1]} and longname==key['MIMENAME'])
    rows.append({'path':rel,'category':'js' if rel.endswith('.JS') else 'css','sap_key':key,'longname':longname,'sap_object_type':'IAMU','operation':'replace-existing',
        'before_bytes':len(a),'after_bytes':len(b),'before_sha256':digest(a),'after_sha256':digest(b),
        'baseline':'V428 / UI4.2.5 / approval1.4.5 / button CSS4.2.0','release':'V429 / UI4.2.6 / approval1.4.5 / button CSS4.2.6',
        'reason':'중첩 브라우저 스크롤 및 아이콘 버튼 반복 축소 수정'})
    diff.extend(difflib.unified_diff(a.decode().replace('\r\n','\n').splitlines(True),b.decode().replace('\r\n','\n').splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(A/'WebGUI_V429.patch').write_text(''.join(diff),encoding='utf-8')
dump(A/'browser_validation.json',tests)

def makezip(dest,files):
    # Close all ZIP entries/central records in memory before exposing the file.
    # The delivered original apply ZIP had an unfinished local header (size 0)
    # and no central-directory end record. Do not publish a stream being built.
    stream = BytesIO()
    with ZipFile(stream,'w',ZIP_DEFLATED,compresslevel=9) as z:
        for p,n in sorted(files,key=lambda x:x[1]):z.write(p,n)
    payload = stream.getvalue()
    verify_archive(payload, manifest=dest.name.startswith('SE80_'))
    with NamedTemporaryFile(dir=dest.parent, prefix='.complete-zip-', delete=False) as tmp:
        temporary=Path(tmp.name)
        tmp.write(payload);tmp.flush();os.fsync(tmp.fileno())
    try:
        check(dest.name+' completed temporary file identity',temporary.read_bytes()==payload)
        os.replace(temporary,dest)
    finally:
        temporary.unlink(missing_ok=True)
    check(dest.name+' finalized on-disk bytes',dest.read_bytes()==payload)
    with ZipFile(dest) as z:
        names=z.namelist()
        check(dest.name+' CRC',z.testzip() is None)
        check(dest.name+' unique safe paths',len(names)==len(set(n.upper() for n in names)) and all(not n.startswith('/') and '..' not in PurePosixPath(n).parts and '\\' not in n and ':' not in n for n in names))
        check(dest.name+' size bounds',max(i.file_size for i in z.infolist())<8388608 and sum(i.file_size for i in z.infolist())<67108864)
        check(dest.name+' no captures or user media',not any(PurePosixPath(n).suffix.lower() in ['.mp4','.png','.jpg','.jpeg'] or 'WebGUI_Approval_Capture_' in n or '/transfer/' in n for n in names))

for reverse in [False,True]:
    manifest_rows=json.loads(json.dumps(rows))
    if reverse:
        for m in manifest_rows:
            for k in ['bytes','sha256']:m['before_'+k],m['after_'+k]=m['after_'+k],m['before_'+k]
            m['baseline'],m['release']=m['release'],m['baseline']
            m['reason']='V428 시점의 GUI.JS 및 GUI_BUTTON.CSS 원복'
    manifest=A/('rollback_manifest.json' if reverse else 'apply_manifest.json');dump(manifest,manifest_rows)
    name='SE80_WebGUI_V429_Rollback_to_V428_2files.zip' if reverse else 'SE80_WebGUI_V429_Scroll_ButtonFix_2files.zip'
    files=[(manifest,'manual_file_manifest.json'),(O/'README_WebGUI_V429_KO.md','README_WebGUI_V429_KO.md')]
    for rel in RELS:
        files.extend([(R/('baseline' if reverse else 'modified')/rel,'apply/'+rel),(R/('modified' if reverse else 'baseline')/rel,'rollback_to_original/'+rel)])
    makezip(O/name,files)
    with ZipFile(O/name) as z:
        check(name+' exactly two apply targets',sorted(n for n in z.namelist() if n.startswith('apply/'))==sorted('apply/'+rel for rel in RELS))
        for m in manifest_rows:
            for prefix,when in [('apply/','after'),('rollback_to_original/','before')]:
                b=z.read(prefix+m['path']);check(name+' '+m['path']+' '+when+' identity',len(b)==m[when+'_bytes'] and digest(b)==m[when+'_sha256'])
dump(A/'static_validation.json',{'passed':len(checks),'failed':0,'results':checks})
review=[(O/'README_WebGUI_V429_KO.md','README_WebGUI_V429_KO.md'),(R/'README.template.md','README.template.md')]
for folder in ['baseline','modified','src','tests','tools','reference_keys','reference']:
    review.extend((p,folder+'/'+str(p.relative_to(R/folder))) for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix.lower() in ['.js','.cjs','.css','.py','.html','.xml','.abap'])
for n in ['browser_validation.json','static_validation.json','WebGUI_V429.patch','apply_manifest.json','rollback_manifest.json','original_archive_diagnosis.json','archive_regression_validation.json']:review.append((A/n,'analysis/'+n))
makezip(O/'KBS_WebGUI_V429_Review.zip',review)
# Reopen final files from a separate process only after all writers have exited.
archive_paths=[str(p) for p in sorted(O.glob('*.zip'))]
result=subprocess.run([sys.executable,str(R/'tools/zip_integrity.py'),*archive_paths],capture_output=True,text=True)
check('Separate process validates final ZIP structures and ABAP manifest byte contract',result.returncode==0)
(A/'final_archive_validation.json').write_text(result.stdout,encoding='utf-8')
dump(A/'package_validation.json',{'passed':len(checks),'failed':0,'results':checks})
dump(A/'deliverables.json',[{'name':p.name,'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(O.iterdir()) if p.is_file()])
print(json.dumps({'browser_checks':tests['summary']['pass'],'static_and_package_checks':len(checks),'files':[p.name for p in sorted(O.iterdir())]},ensure_ascii=False))
