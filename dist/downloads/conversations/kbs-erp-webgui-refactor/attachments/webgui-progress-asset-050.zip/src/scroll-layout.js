  /* KBS V429 / UI4.2.6: one browser scroll owner per content region.
     Do not modify SAP paging ranges, move controls, or dispatch server resize. */
  function px426(el, key, value) {
    value = Math.max(1, Math.floor(value)) + "px";
    if (el.style[key] !== value) el.style[key] = value;
  }
  function overflow426(el, value) {
    if (el && el.style.overflow !== value) el.style.overflow = value;
  }
  function row426(el) {
    for (var p = el; p && p !== d.body; p = p.parentElement) if (p.tagName === "TR") return p;
    return el;
  }
  function nativeScroll426(el) {
    var a = w.its_SCArray || [];
    for (var i = 0; i < a.length; i++) if (a[i] && a[i].outerDiv === el) return a[i];
    return null;
  }
  function skipLayout426() {
    // LIST cell coordinates are also used by the approval capture/overlap code.
    return !!d.querySelector('[class*="WebguiDynproBorderList"], .WebguiUserAreaList, #Table2, .kbs-appr-root') ||
      d.documentElement.hasAttribute("data-kbs-appr-phase") || d.documentElement.hasAttribute("data-kbs-appr-view");
  }
  var oldPopupContent426 = api.popupContent;
  api.popupContent = function (border) {
    if (skipLayout426()) return null;
    var m = oldPopupContent426(border);
    if (!m || !border) return m;
    // Hidden child content belongs to its control, not the popup viewport.
    // Retain the original percentage control preferences across layout passes.
    var c = d.getElementById("searchHelpCriteria"), root = c && c.parentElement;
    if (root && border.contains(root)) {
      if (!root.kbs426Preferred) {
        var table = d.getElementById("SHSeloptDialogTable"), hit = d.getElementById("SHHitlist");
        var nativeBody = d.getElementById("SearchHelpResultBody");
        var fixedH = 0;
        for (var j = 0; j < root.children.length; j++) {
          var child = root.children[j];
          if (child !== c && child !== hit && visible42(child)) fixedH += child.offsetHeight;
        }
        root.kbs426Preferred = {width:Math.max(360, table ? table.offsetWidth + 24 : root.offsetWidth,
          nativeBody ? nativeBody.offsetWidth + 24 : 0),
          height:Math.max(180, (visible42(c) && table ? table.offsetHeight : 0) +
            (visible42(hit) ? hit.offsetHeight : 0) + fixedH + 24)};
      }
      m.width = Math.max(m.width, root.kbs426Preferred.width);
      m.height = root.kbs426Preferred.height;
    }
    return m;
  };
  api.layoutScrollAreas = function () {
    if (!api.uiEnabled() || api.fittingScroll426 || skipLayout426()) return;
    var dyn = d.getElementById("webguiDynpro"), area = d.getElementById("webguiUserArea");
    var container = d.getElementById("webguiContainer"), page = d.getElementById("webguiPage");
    if (!dyn) return;
    api.fittingScroll426 = true;
    try {
      var v = api.viewport(), uaRow = d.getElementById("webguiUAtr"), uaCell = d.getElementById("webguiUAtd");
      var host = container || area || dyn, top = host.getBoundingClientRect().top;
      var footer = d.getElementById("WebguiModalButtonBar"), footRow = footer && row426(footer);
      var status = d.getElementById("webguiStatusbar"), h, i, r, node;
      if (page && uaRow && page.contains(uaRow)) {
        var fixed = 0;
        for (i = 0; i < page.rows.length; i++) if (page.rows[i] !== uaRow) fixed += page.rows[i].offsetHeight;
        h = Math.max(1, v.height - page.getBoundingClientRect().top - fixed - 2);
        page.style.tableLayout = "fixed"; page.style.width = "100%";
        px426(page, "height", v.height - page.getBoundingClientRect().top - 2);
        px426(uaRow, "height", h);
        if (uaCell) { px426(uaCell, "height", h); uaCell.style.verticalAlign = "top"; }
      } else {
        h = Math.max(1, v.height - top - (visible42(footRow) ? footRow.offsetHeight : 0) -
          (visible42(status) && !host.contains(status) ? status.offsetHeight : 0) - 2);
      }
      // Content-box 100% plus a popup border previously created another scrollbar.
      var popupBox = d.querySelector(".WebguiPopupNoMargin");
      if (popupBox && popupBox.contains(dyn)) {
        popupBox.style.boxSizing = "border-box"; overflow426(popupBox, "hidden");
      }
      var wrappers = [container, area, dyn];
      for (i = 0; i < wrappers.length; i++) {
        node = wrappers[i]; if (!node) continue;
        node.style.boxSizing = "border-box"; node.style.minHeight = "0px"; node.style.minWidth = "0px";
        node.style.width = "100%"; px426(node, "height", h);
        overflow426(node, node === dyn ? "auto" : "hidden");
      }
      var rootSC = nativeScroll426(dyn);
      if (rootSC) {
        // This is SAP's backend dynpro scrollbar, not a redundant browser bar.
        overflow426(dyn, "hidden"); rootSC.resize();
        dyn.setAttribute("data-kbs-scroll-mode", "native-dynpro"); return;
      }
      var border = dyn.querySelector(".WebguiPopupBorder, .WebguiPopupBorderRTL, .WebguiDynproBorder, .WebguiDynproBorderRTL");
      if (!border) { dyn.setAttribute("data-kbs-scroll-mode", "form"); return; }
      if (/WebguiPopupBorder/.test(border.className)) {
        border.style.top = "4px"; border.style.left = "4px";
        border.style.width = "calc(100% - 8px)"; border.style.height = "calc(100% - 8px)";
      }
      overflow426(border, "visible");
      var cal = api.calendarControl();
      if (cal && w.webguiModalNo && border.contains(cal.container)) {
        // A dedicated calendar has one scrolling month region below its date selector.
        var other = border.querySelectorAll("input:not([type=hidden]), select, textarea, .tcContainer, .gvContainer"), onlyCal = true;
        for (i = 0; i < other.length; i++) if (!cal.container.contains(other[i]) && visible42(other[i])) onlyCal = false;
        if (onlyCal) {
          r = cal.container.getBoundingClientRect(); var br = border.getBoundingClientRect();
          cal.container.style.boxSizing = "border-box";
          px426(cal.container, "width", border.clientWidth - Math.max(0, r.left - br.left) - 2);
          px426(cal.container, "height", border.clientHeight - Math.max(0, r.top - br.top) - 2);
          overflow426(cal.container, "hidden"); overflow426(cal.scroll, "auto");
          if (typeof w.calendarOnResize === "function") w.calendarOnResize(cal.table.id, cal.container.id, cal.scroll.id);
          // Native code uses offsetWidth/Height (including borders). Use the actual inner box.
          px426(cal.scroll, "width", cal.container.clientWidth);
          var sr = cal.scroll.getBoundingClientRect(), cr = cal.container.getBoundingClientRect();
          px426(cal.scroll, "height", cal.container.clientHeight - (sr.top - cr.top - cal.container.clientTop));
          overflow426(border, "hidden"); overflow426(dyn, "hidden");
          cal.scroll.setAttribute("data-kbs-scroll-owner", "calendar");
          dyn.setAttribute("data-kbs-scroll-mode", "calendar"); return;
        }
      }
      var criteria = d.getElementById("searchHelpCriteria"), hitlist = d.getElementById("SHHitlist");
      var sh = criteria ? criteria.parentElement : (hitlist && hitlist.parentElement);
      if (sh && sh !== border && border.contains(sh)) {
        r = sh.getBoundingClientRect(); var b = border.getBoundingClientRect();
        sh.style.boxSizing = "border-box";
        px426(sh, "width", border.clientWidth - Math.max(0, r.left - b.left) - 2);
        px426(sh, "height", border.clientHeight - Math.max(0, r.top - b.top) - 2);
        var table = d.getElementById("SHSeloptDialogTable"), critH = visible42(criteria) && table ? table.offsetHeight : 0;
        if (criteria && critH) { px426(criteria, "height", critH); overflow426(criteria, "visible"); }
        // Static hit lists already contain all rows and can be resized locally.
        // Dynamic lists keep their native page size/ranges and server load callbacks.
        if (visible42(hitlist)) {
          var used = 0;
          for (i = 0; i < sh.children.length; i++) {
            node = sh.children[i]; if (node !== hitlist && node !== criteria && visible42(node)) used += node.offsetHeight;
          }
          var nativeHit = hitlist.querySelector("#SearchHelpResultBody_scrollContainerStructure");
          var hitH = nativeHit ? hitlist.offsetHeight : Math.max(80, sh.clientHeight - Math.min(critH, Math.floor(sh.clientHeight * .45)) - used - 4);
          if (critH && sh.clientHeight - used - hitH >= 60) {
            px426(criteria, "height", Math.min(critH, sh.clientHeight - used - hitH - 4));
            overflow426(criteria, "auto");
          }
          if (!nativeHit) { px426(hitlist, "height", hitH); overflow426(hitlist, "auto"); }
          else overflow426(hitlist, "hidden");
          hitlist.setAttribute("data-kbs-scroll-owner", nativeHit ? "native-results" : "results");
        }
        overflow426(sh, "auto"); overflow426(border, "hidden"); overflow426(dyn, "hidden");
        sh.setAttribute("data-kbs-scroll-owner", "search-help");
        dyn.setAttribute("data-kbs-scroll-mode", "search-help"); return;
      }
      // ALV gridviews have a native local resize routine. Only fit a dedicated,
      // percentage/fullscreen grid; fixed dynpro rows below it keep their positions.
      var grids = border.querySelectorAll(".gvContainer"), g = grids.length === 1 ? grids[0] : null;
      if (g && (border.getAttribute("fullscreencnt") === "1" || /%/.test(g.kbs426OriginalHeight || g.style.height))) {
        var name = g.getAttribute("jsname"), obj = name && w[name];
        if (obj && obj.container === g && w.its_gvMgr && typeof w.its_gvMgr.resize === "function") {
          if (!g.kbs426OriginalHeight) g.kbs426OriginalHeight = g.style.height;
          var outside = border.querySelectorAll("input:not([type=hidden]), a.d_button, .tcContainer"), dedicated = true;
          for (i = 0; i < outside.length; i++) if (!g.contains(outside[i]) && visible42(outside[i])) dedicated = false;
          if (dedicated) {
            if (border.getAttribute("fullscreencnt") === "1") { border.style.width = "100%"; border.style.height = "100%"; }
            r = g.getBoundingClientRect(); var gr = border.getBoundingClientRect();
            px426(g, "width", border.clientWidth - Math.max(0, r.left - gr.left - border.clientLeft) - 2);
            px426(g, "height", border.clientHeight - Math.max(0, r.top - gr.top - border.clientTop) - 2);
            w.its_gvMgr.resize(obj);
            overflow426(dyn, "hidden"); overflow426(border, "hidden");
            g.setAttribute("data-kbs-scroll-owner", "native-grid");
            dyn.setAttribute("data-kbs-scroll-mode", "grid"); return;
          }
        }
      }
      // Fixed SAP table controls must expose their complete rendered page.
      // A genuinely oversized form keeps ONE browser viewport, plus any backend
      // paging control required to request records that are not in the document.
      dyn.setAttribute("data-kbs-scroll-mode", "form");
      dyn.setAttribute("data-kbs-scroll-owner", "form");
    } finally { api.fittingScroll426 = false; }
  };
