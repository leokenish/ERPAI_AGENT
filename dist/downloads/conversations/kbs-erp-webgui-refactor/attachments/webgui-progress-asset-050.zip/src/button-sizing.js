      // Auto-width buttons derive their width from this image. Subtracting from
      // clientWidth on every pass feeds the previous result back down to 1px.
      // Bound only deliberately sized, positioned controls; flow buttons get
      // a stable icon slot and a CSS minimum hit area, including unmapped GIFs.
      var css = w.getComputedStyle(el), positioned = css.position === "absolute" || css.position === "fixed";
      var fixedWidth = positioned && el.style.width && el.style.width !== "auto";
      el.setAttribute("data-kbs-icon-flow", only && !fixedWidth ? "1" : "0");
      size = 18;
      if (fixedWidth) size = Math.min(size, Math.max(1, el.clientWidth - 4));
      if (positioned && el.style.height && el.style.height !== "auto") size = Math.min(size, Math.max(1, el.clientHeight - 4));
      img.style.width = size + "px"; img.style.height = size + "px";
