function calendar(fit, horizontal) {
  const header = ['월','주','월','화','수','목','금','토','일'];
  const rows = Array.from({length:20}, (_, y) => '<tr class="CalRow">' + header.map((_, x) =>
    `<td class="${x < 2 ? 'CalHM' : 'CalM0C'}" id="date${y}_${x}" onclick="parent.selectedDate='20261021';parent.dateActions++;">${x===0 ? 'OCT 2026' : (y*7+x)%31+1}</td>`).join('') + '</tr>').join('');
  return `<div ct="calendar" id="CALCONT" style="position:absolute;left:0;top:0;width:98%;height:98%;border:outset #E2E1D0 2px;overflow:hidden"><table class="dtpicker" id="CALdtpicker" cellspacing="0" cellpadding="0" style="width:100%"><tr><td><input class="dtpickerinput" value="2026" maxlength="4" style="width:32px">/10/21</td></tr></table><div id="CALSCRL" style="height:40px;overflow:auto"><table class="Calendar" id="CAL" cellspacing="0" cellpadding="0" DisplayModeAlign="left" ${fit ? 'DisplayModeFit="1"' : ''} ${horizontal ? 'DisplayModeHorizontal="1"' : ''} NSCOLS="9"><tr class="CalRow">${header.map(t=>'<td class="CalHD">'+t+'</td>').join('')}</tr>${rows}</table></div></div>`;
}
module.exports=calendar;
