/* Local fixture adapter for SYSTEM/ITS_UTILS (not in the WEBGUI export).
   No network, server behavior, grid sizing or scrollbar logic is mocked here.
   Production GUI_SCROLL.JS and GUI_GRIDVIEW.JS perform their own geometry. */
window.webguiMimeURL = "/images";
window.its_eMgr = {
  registerEvent: function (node, name, fn) { if (node) node.addEventListener(name, fn, false); },
  unregisterEvent: function (node, name, fn) { if (node) node.removeEventListener(name, fn, false); }
};
window.dom_getXPos = function (node) { return node.getBoundingClientRect().left; };
window.dom_getYPos = function (node) { return node.getBoundingClientRect().top; };
window.its_event = function (event) {
  this.event = event;
  this.target = event.target || event.srcElement;
  this.srcElement = this.target;
  this.clientX = event.clientX; this.clientY = event.clientY;
  this.pageX = event.pageX; this.pageY = event.pageY;
  this.button = event.button; this.which = event.which; this.keyCode = event.keyCode;
  this.type = event.type;
  this.cancel = function () { event.preventDefault(); event.stopPropagation(); };
};
