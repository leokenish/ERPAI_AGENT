* Read-only excerpt from Z_ITS_WEBASSET_APPLY 1.0.9, Library version 9.
  METHOD map.
    DATA: leaf TYPE ty_leaf, a TYPE ty_asset, r TYPE ty_row,
          id TYPE i, maxid TYPE i, value TYPE string, expected TYPE string,
          actual TYPE string, km TYPE iacikeym, kt TYPE iacikeyt,
          name TYPE string, key TYPE string, paths TYPE ty_texts,
          keys TYPE SORTED TABLE OF string WITH UNIQUE KEY table_line,
          file_count TYPE i, asset_count TYPE i, suffix TYPE string,
          ex TYPE REF TO cx_root.
    FIELD-SYMBOLS <file> LIKE LINE OF zip->files.
    LOOP AT leaves INTO leaf.
      IF leaf-item > maxid. maxid = leaf-item. ENDIF.
    ENDLOOP.
    DO maxid TIMES.
      id = sy-index. CLEAR: a, r, km, kt.
      a-id = id.
      a-path = get( id = id key = 'path' required = 'X' ).
      lcl_util=>safe_path( a-path ).
      IF strlen( a-path ) > 255.
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Asset path >255 chars'.
      ENDIF.
      a-category = get( id = id key = 'category' required = 'X' ).
      IF a-category <> 'css' AND a-category <> 'js'
         AND a-category <> 'html' AND a-category <> 'gif'
         AND a-category <> 'png' AND a-category <> 'jpg'
         AND a-category <> 'jpeg' AND a-category <> 'svg'
         AND a-category <> 'ico' AND a-category <> 'bmp'.
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Non-webasset category'.
      ENDIF.
      value = get( id = id key = 'sap_key/SERVICE' required = 'X' ).
      a-service = value. actual = a-service.
      IF value <> actual OR ( value <> 'WEBGUI' AND value <> 'SYSTEM' ).
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid service'.
      ENDIF.
      value = get( id = id key = 'sap_key/THEME' required = 'X' ).
      a-theme = value. actual = a-theme.
      IF value <> actual OR value IS INITIAL.
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid theme'.
      ENDIF.
      a-longname = get( id = id key = 'longname' required = 'X' ).
      IF a-longname IS INITIAL.
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Missing LONGNAME'.
      ENDIF.
      lcl_util=>safe_path( a-longname ).
      IF a-category = 'html'.
        a-objtype = 'IATU'.
        value = get( id = id key = 'sap_key/MODULPOOL' required = 'X' ).
        a-modulpool = value. actual = a-modulpool.
        IF actual <> value OR value IS INITIAL.
          RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid MODULPOOL'.
        ENDIF.
        value = get( id = id key = 'sap_key/DYNPRO' required = 'X' ).
        a-dynpro = value. actual = a-dynpro.
        IF actual <> value.
          RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid DYNPRO'.
        ENDIF.
        kt-service = a-service. kt-theme = a-theme.
        kt-modulpool = a-modulpool. kt-dynpro = a-dynpro.
        a-objname = kt.
        CONCATENATE 'services/' a-service '/themes/' a-theme
          '/templates/' a-longname '/' a-longname '.html' INTO expected.
        IF a-dynpro IS NOT INITIAL.
          RAISE EXCEPTION TYPE lcx_app
            EXPORTING text = 'This ZIP adapter supports named templates only'.
        ENDIF.
      ELSE.
        a-objtype = 'IAMU'.
        value = get( id = id key = 'sap_key/MIMENAME' required = 'X' ).
        a-mimename = value. actual = a-mimename.
        IF value <> actual OR value IS INITIAL.
          RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid MIMENAME'.
        ENDIF.
        km-service = a-service. km-theme = a-theme. km-mimename = a-mimename.
        a-objname = km.
        CONCATENATE 'services/' a-service '/themes/' a-theme
          '/mime/' a-longname INTO expected.
        actual = a-longname. TRANSLATE actual TO LOWER CASE.
        CONCATENATE '*.' a-category INTO suffix.
        IF actual NP suffix.
          RAISE EXCEPTION TYPE lcx_app
            EXPORTING text = 'MIME extension/category mismatch'.
        ENDIF.
      ENDIF.
      IF expected <> a-path.
        RAISE EXCEPTION TYPE lcx_app
          EXPORTING text = 'Manifest path and SAP key/LONGNAME disagree'.
      ENDIF.
      CONCATENATE a-objtype a-objname INTO key SEPARATED BY ':'.
      INSERT key INTO TABLE keys.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Duplicate SAP object key'.
      ENDIF.
      APPEND a-path TO paths.
      a-reason = get( id = id key = 'reason' required = space ).
      a-supplied_diff = get( id = id key = 'diff' required = space ).
      TRY.
          value = get( id = id key = 'before_bytes' required = 'X' ).
          IF value CN '0123456789'.
            RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid before_bytes'.
          ENDIF.
          a-expected_before = value.
          value = get( id = id key = 'after_bytes' required = 'X' ).
          IF value CN '0123456789'.
            RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid after_bytes'.
          ENDIF.
          a-expected_after = value.
        CATCH cx_root INTO ex.
          RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'Invalid byte count'.
      ENDTRY.
      CONCATENATE 'apply/' a-path INTO name. a-wanted = zip_get( name ).
      CONCATENATE 'rollback_to_original/' a-path INTO name.
      a-baseline = zip_get( name ).
      IF xstrlen( a-wanted ) <> a-expected_after
         OR xstrlen( a-baseline ) <> a-expected_before.
        RAISE EXCEPTION TYPE lcx_app
          EXPORTING text = 'Manifest byte count and ZIP content disagree'.
      ENDIF.
      a-wanted = lcl_util=>canonical( raw = a-wanted kind = a-category ).
      a-baseline = lcl_util=>canonical( raw = a-baseline kind = a-category ).
      r-id = id. r-light = '2'. r-service = a-service. r-theme = a-theme.
      r-objtype = a-objtype. r-category = a-category. r-path = a-path.
      IF a-objtype = 'IAMU'. r-sap_name = a-mimename.
      ELSE. r-sap_name = a-modulpool. ENDIF.
      r-reason = a-reason. r-zip_bytes = xstrlen( a-wanted ).
      r-save_status = '미실행'. r-pub_status = '미실행'.
      APPEND a TO assets. APPEND r TO rows.
    ENDDO.
    LOOP AT zip->files ASSIGNING <file>.
      IF <file>-name CP 'apply/*'.
        name = <file>-name+6.
        READ TABLE paths TRANSPORTING NO FIELDS WITH KEY table_line = name.
        IF sy-subrc <> 0.
          RAISE EXCEPTION TYPE lcx_app
            EXPORTING text = 'Unmapped apply/ entry in ZIP'.
        ENDIF.
        file_count = file_count + 1.
      ENDIF.
    ENDLOOP.
    DESCRIBE TABLE assets LINES asset_count.
    IF file_count <> asset_count OR asset_count = 0.
      RAISE EXCEPTION TYPE lcx_app EXPORTING text = 'ZIP target count mismatch'.
    ENDIF.
  ENDMETHOD.
